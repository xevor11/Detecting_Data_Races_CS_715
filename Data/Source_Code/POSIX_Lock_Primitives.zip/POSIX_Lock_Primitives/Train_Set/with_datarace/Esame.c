# 1 "Esame.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "Esame.c"
# 26 "Esame.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 27 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 28 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/stdint.h" 1
# 29 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 30 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 31 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 32 "Esame.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 33 "Esame.c" 2
# 41 "Esame.c"
pthread_t dipendenti[10];
pthread_t cuoco;

typedef struct
{
    int primi_piatti_consumati;
    sem_t primo_piatto, secondo_piatto, seconda_fase, posto_libero;
    pthread_mutex_t lock;

} Mensa;

Mensa mensa;


void * cuoco_thread(void * t)
{
    unsigned int tempo_di_preparazione;







    for(int i=0; i < 10; i++)
    {
        sem_wait(&mensa.posto_libero);

        tempo_di_preparazione = rand() % 2;

        printf("[Cuoco] Preparo un nuovo primo piatto\n");
        sleep(tempo_di_preparazione);

        sem_post(&mensa.primo_piatto);
    }

    sem_wait(&mensa.seconda_fase);

    for(int i=0; i < 10; i++)
    {
        sem_wait(&mensa.posto_libero);

        tempo_di_preparazione = rand() % 2;

        printf("[Cuoco] Preparo un nuovo secondo piatto\n");
        sleep(tempo_di_preparazione);

        sem_post(&mensa.secondo_piatto);
    }

    printf("[Cuoco] finito!\n");

    pthread_exit(0);
}

void * dipendente_thread(void * t)
{
# 107 "Esame.c"
    unsigned int tempo_di_consumazione;
    int tid = (int)(intptr_t) t;

    sem_wait(&mensa.primo_piatto);

    tempo_di_consumazione = rand() % 3;
    printf("[Dipendente %d] consumo primo piatto\n", tid);
    sleep(tempo_di_consumazione);


    pthread_mutex_lock(&mensa.lock);

    mensa.primi_piatti_consumati++;

    printf("[Dipendente %d] finito primo piatto\n", tid);

    sem_post(&mensa.posto_libero);

    if(mensa.primi_piatti_consumati == 10)
    {
        printf("[Dipendente %d] sono l'ultimo a finire il primo piatto! Si dia il via ai secondi piatti!\n", tid);
        sem_post(&mensa.seconda_fase);
    }
    pthread_mutex_unlock(&mensa.lock);

    sem_wait(&mensa.secondo_piatto);

    printf("[Dipendente %d] consumo secondo piatto\n", tid);
    sleep(tempo_di_consumazione);


    sem_post(&mensa.posto_libero);

    printf("[Dipendente %d] grazie del pranzo\n", tid);

    return 0;
}


void init(Mensa *m)
{
    sem_init(&m->posto_libero, 0, 6);
    sem_init(&m->primo_piatto, 0, 0);
    sem_init(&m->seconda_fase, 0, 0);
    sem_init(&m->secondo_piatto, 0, 0);
    pthread_mutex_init(&m->lock, 0);
}

int main(int argc, char * argv[])
{
    printf("Programma mensa avviato\n");
    int result;
    void * status;

    init(&mensa);

    for(int i=0; i < 10; i++)
    {
        result = pthread_create(&dipendenti[i], 0, dipendente_thread, (void *)(intptr_t) i);
        if(result)
        {
            perror("Errore nella creazione dei dipendenti\n");
            exit(-1);
        }
    }

    pthread_create(&cuoco, 0, cuoco_thread, 0);

    for(int i=0; i < 10; i++)
    {
        result = pthread_join(dipendenti[i], &status);
        if(result)
        {
            perror("Errore nella join\n");
            exit(-1);
        }
    }

    pthread_join(cuoco, &status);

    return 0;
}
