# 1 "PlantController.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "PlantController.c"






# 1 "pycparser/utils/fake_libc_include/assert.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/assert.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/assert.h" 2
# 8 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 9 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 10 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/stdint.h" 1
# 11 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/neutrino.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/neutrino.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/neutrino.h" 2
# 12 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/mman.h" 1
# 13 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/netmgr.h" 1
# 14 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/hw/inout.h" 1
# 15 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 16 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 17 "PlantController.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 18 "PlantController.c" 2



struct control{
 float period;
 float integral;
 float derivative;
 float error;
 float iMax;
 float iMin;
 float iState;
 float goal;
};

struct control PID;

pthread_mutex_t mutex;
pthread_t uInput;

void SetUp(){
 PID.period = 1.0;
 PID.integral = 0.099;
 PID.derivative = 0.095;
 PID.iState=0;
 PID.iMin= -100.0;
 PID.iMax = 100.0;
 PID.goal= 5.0;
 PID.error=0.0;

 pthread_mutex_init(&mutex, 0);

}






void InitializeAD(){
 uintptr_t gain_handle;
 uintptr_t chan_handle;
 gain_handle = mmap_device_io(1,0x280 +3);
 chan_handle = mmap_device_io(1,0x280 +2);
 out8(chan_handle,0x11);
 out8(gain_handle,0x0);
}




void start(){
 uintptr_t write_handle;
 write_handle = mmap_device_io(1,0x280);
 out8(write_handle,0x80);
}





int16_t convertAD(){
 uintptr_t status_handle;
 uintptr_t least_handle;
 uintptr_t most_handle;
 int LSB;
 int MSB;
 status_handle = mmap_device_io(1,0x280 +3);
 least_handle = mmap_device_io(1,0x280);
 most_handle = mmap_device_io(1,0x280 +1);
 start();
 while(in8(status_handle)& 0x80){

 }
 LSB = in8(least_handle);
 MSB = in8(most_handle);

 return MSB*256+LSB;
}

void convertDA(int16_t input){
 uintptr_t lsb_handle;
 uintptr_t msb_handle;
 uintptr_t busy_handle;
 lsb_handle= mmap_device_io(1,0x280 +6);
 msb_handle =mmap_device_io(1,0x280 +7);
 busy_handle = mmap_device_io(1,0x280 +3);


 int8_t lsb = input&255;
 int8_t msb=input/256;
 out8(lsb_handle,lsb);
 out8(msb_handle,msb);

 while(in8(busy_handle)&0x10){

 }


}

float compute(float error){

 float pTerm, iTerm, dTerm;

 pthread_mutex_lock(&mutex);
 pTerm = PID.period * error;

 PID.iState+=error;
 if(PID.iState > PID.iMax){
  PID.iState=PID.iMax;
 }
 if(PID.iState < PID.iMin){
  PID.iState=PID.iMin;
 }

 iTerm= PID.integral * PID.iState;

 dTerm = PID.derivative +(PID.error-error);
 PID.error=error;
 pthread_mutex_unlock(&mutex);

  return pTerm+iTerm+dTerm;

}


void performMath(){
 int16_t analog = 0;
 uint16_t convertOut = 0;
 float convertAnalog = 0;
 float out = 0.0;
 float error = 0.0;

 analog = convertAD();
 convertAnalog = ((float) analog)/32768 * 10;
 pthread_mutex_lock(&mutex);
 error = PID.goal - convertAnalog;
 pthread_mutex_unlock(&mutex);
 out = compute(error);
 convertOut = (int)(((out/20)*2048)+2048);

 if(convertOut > 4095)
   convertOut = 4095;
 else if(convertOut < 0)
  convertOut = 0;

 convertDA(convertOut);



}


void * userControl(void * args){
 float per;
 float inte;
 float der;

 while(1){
  pthread_mutex_lock(&mutex);
  per = PID.period;
  inte=PID.integral;
  der=PID.derivative;
  pthread_mutex_unlock(&mutex);
  printf("Current Values- Period: %f, Integral %f, Derivative %f\n",per, inte, der);
  printf("Enter Period \n");
  scanf("%f",&per);

  printf("Enter Integral \n");
  scanf("%f",&inte);

  printf("Enter Derivative \n");
  scanf("%f", &der);

  pthread_mutex_lock(&mutex);
  PID.period = per;
  PID.integral = inte;
  PID.derivative = der;
  pthread_mutex_unlock(&mutex);
 }
}

int main(int argc, char *argv[]) {


 int pid;
 int chid;
 int pulse_id = 0;
 struct _pulse pulse;
 struct _clockperiod clkper;
 struct sigevent event;
 struct itimerspec timer;
 timer_t timer_id;
 int privity_err;

 pthread_attr_t threadAttributes;
 struct sched_param parameters;
 int policy;
 pthread_attr_init(&threadAttributes);
 pthread_getschedparam(pthread_self(),&policy, &parameters);

 parameters.sched_priority--;
 pthread_attr_setdetachstate(&threadAttributes, PTHREAD_CREATE_JOINABLE);
 pthread_attr_setschedparam(&threadAttributes, &parameters);

 privity_err = ThreadCtl( _NTO_TCTL_IO, 0 );
 if ( privity_err == -1 )
 {
  fprintf( stderr, "can't get root permissions\n" );
  return -1;
 }


 clkper.nsec = 10000000;
 clkper.fract = 0;

 ClockPeriod(CLOCK_REALTIME, &clkper, 0, 0);
 chid = ChannelCreate(0);
 assert(chid != -1);


 event.sigev_notify = SIGEV_PULSE;
 event.sigev_coid = ConnectAttach(ND_LOCAL_NODE,0,chid,0,0);
 event.sigev_priority = getprio(0);
 event.sigev_code = 1023;
 event.sigev_value.sival_ptr = (void *)pulse_id;


 timer_create( CLOCK_REALTIME, &event, &timer_id );

 timer.it_value.tv_sec = 0;
 timer.it_value.tv_nsec = 10000000;
 timer.it_interval.tv_sec = 0;
 timer.it_interval.tv_nsec = 10000000;

 timer_settime( timer_id, 0, &timer, 0 );
 SetUp();
 InitializeAD();

 pthread_create(&uInput, &threadAttributes, &userControl, 0);

 while(1){
  pid = MsgReceivePulse ( chid, &pulse, sizeof( pulse ), 0 );
  performMath();
 }

 return 0;
}
