# 1 "DinningPhilosopher.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "DinningPhilosopher.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "DinningPhilosopher.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "DinningPhilosopher.c" 2
# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 4 "DinningPhilosopher.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 5 "DinningPhilosopher.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 6 "DinningPhilosopher.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 7 "DinningPhilosopher.c" 2
# 15 "DinningPhilosopher.c"
enum {THINKING,EATING,SLEEPING,SLEEPY,HUNGRY} state[5];

int N=5;
sem_t sleepsem;
sem_t pick[5];
pthread_mutex_t lock;
int duration=300;


void take_bed(int i) {

        int value;
 state[i]=SLEEPY;


 sem_wait(&sleepsem);
        sem_getvalue(&sleepsem,&value);
        printf("Thread[%d]: Sleepsm value after wait %d\n",i,value);
 if(state[i] == SLEEPY){
  state[i]=SLEEPING;
 }
}


void release_bed(int i) {
 state[i]=HUNGRY;
 sem_post(&sleepsem);
}


void test_forks(int i){
 if((state[(i+1) % 5] != EATING) && (state[(i+4) % 5] != EATING) && (state[i] == HUNGRY)){
  state[i]=EATING;
  sem_post(&pick[i]);
 }
}


void take_forks(int i) {
 pthread_mutex_lock(&lock);
 state[i]=HUNGRY;
 test_forks(i);
 pthread_mutex_unlock(&lock);
 if(state[i] != EATING){
  sem_wait(&pick[i]);
  take_forks(i);
 }
}


void release_forks(int i) {
 state[i]=THINKING;
 test_forks((i+1) % 5);
 test_forks((i+4) % 5);
}


void thinking(int i) {
 if(state[i] == THINKING){
  sleep(rand() % 5 + 1);
 }
}


void eating(int i) {
 if(state[i] == EATING){
  sleep(rand() % 5 + 1);
 }
}


void sleeping(int i) {
 if(state[i] == SLEEPING){
  sleep(rand() % 5 + 1);
 }
}


void *philosopher(void *n) {
 int i=*(int*)n;
        while(1) {
  take_bed(i);
  sleeping(i);
  release_bed(i);



  thinking(i);
        }
}


int main(int argc, char *argv[]){
 if(argc > 1){
  duration=atoi(argv[1]);
  if(duration <= 0){
   printf("Usage: %s <Number of seconds>\n",argv[0]);
   exit(1);
  }
 }

 int i, var[N];
 pthread_t tid[N];
 time_t start=time(0);

 for(i=0;i<N;i++){
  var[i]=i;
  pthread_create(&tid[i], 0, philosopher, &var[i]);
  state[i]=THINKING;
  sem_init(&pick[i],0,0);
  sem_init(&sleepsem,0,1);
 }


 while(1){
  if((time(0)-start)>duration){
   printf("Elapsed %d seconds, Exiting...\n",duration);
   exit(0);
  }
  for(i=0;i<N;i++){
   if(state[i] == THINKING){
    printf("Philosopher %d: thinking\n",i);
   }
   else if(state[i] == EATING){
    printf("Philosopher %d: eating\n",i);
   }
   else if(state[i] == SLEEPING){
    printf("Philosopher %d: sleeping\n",i);
   }
   else if(state[i] == SLEEPY){
    printf("Philosopher %d: waiting to sleep\n",i);
   }
   else if(state[i] == HUNGRY){
    printf("Philosopher %d: waiting to eat\n",i);
   }
  }
  printf("\n");
  sleep(1);
 }
}
