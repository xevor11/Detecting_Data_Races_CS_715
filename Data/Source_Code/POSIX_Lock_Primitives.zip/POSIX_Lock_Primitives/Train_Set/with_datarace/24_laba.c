# 1 "24_laba.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "24_laba.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "24_laba.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "24_laba.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 4 "24_laba.c" 2
# 1 "pycparser/utils/fake_libc_include/string.h" 1
# 5 "24_laba.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 6 "24_laba.c" 2
# 15 "24_laba.c"
struct Vertex {
    char* string;
    struct Vertex* next;
};

typedef struct Queue {
    int counter;
    pthread_cond_t cond_counter;
    pthread_mutex_t mut_counter;

    struct Vertex* head;
    struct Vertex* tail;
    char is_drop;
} Queue;

struct Param {
    char get_or_put;
    int ID;
    Queue* queue;
};

void mymsginit(Queue *);
void mymsqdrop(Queue *);
void mymsgdestroy(Queue *);
int mymsgput(Queue *, char * msg);
int mymsgget(Queue *, char * buf, size_t bufsize);

int start_thread(pthread_t* pthread, struct Param* param);
void* thread_body(void* raram);
struct Param* get_param(char get_or_put, int ID, Queue* queue);

int main(int argc, char* argv) {
    int i;
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    struct Param** params = (struct Param**)malloc(sizeof(struct Param*)*4);
    pthread_t** pthreads = (pthread_t**)malloc(sizeof(pthread_t*)*4);
    mymsginit(queue);
    for(i=0; i<4; ++i){
        pthreads[i] = (pthread_t*)malloc(sizeof(pthread_t));
        if(i < 2){
            params[i] = get_param(1, i, queue);
        } else {
            params[i] = get_param(0, i, queue);
        }
        start_thread(pthreads[i], params[i]);
    }

    for(i = 0; i < 4; ++i){
        pthread_join(*pthreads[i], 0);
        free(params[i]);
        free(pthreads[i]);
    }
    mymsgdestroy(queue);
    free(params);
    free(pthreads);

}

void mymsginit(Queue* queue) {
    pthread_cond_init(&queue->cond_counter, 0);
    pthread_mutex_init(&queue->mut_counter, 0);
    queue->counter = 0;
    queue->head = 0;
    queue->tail = 0;
    queue->is_drop = 0;
}

void mymsqdrop(Queue *queue) {
    queue->is_drop = 1;
    pthread_cond_broadcast(&queue->cond_counter);
}

void mymsgdestroy(Queue *queue) {
    int i;
    struct Vertex* ver = queue->head;
    struct Vertex* next;
    for(; ver != 0; ver = next){
        next = ver->next;
        free(ver);
    }
    queue->is_drop = 1;
    queue->head = 0;
    queue->tail = 0;
    pthread_cond_destroy(&queue->cond_counter);
    pthread_mutex_destroy(&queue->mut_counter);
}

int mymsgput(Queue *queue, char * msg) {
    struct Vertex* newVertex;
    int size_str;
    if(queue->is_drop){
        return 0;
    }
    if((newVertex = (struct Vertex*)malloc(sizeof(struct Vertex))) == 0 ){
        return -1;
    }
    newVertex->next = 0;
    newVertex->string = (char*)malloc(sizeof(char)*80);
    size_str = strlen(strncpy(newVertex->string, msg, 80));


    pthread_mutex_lock(&queue->mut_counter);
    while(1){
        if(queue->is_drop){
            pthread_mutex_unlock(&queue->mut_counter);
            return 0;
        }
        if(queue->counter < 10){
            break;
        }
        pthread_cond_wait(&queue->cond_counter,&queue->mut_counter);
    }

    if(queue->head == 0) {
        queue->tail = newVertex;
        queue->head = newVertex;
    } else {
        queue->tail->next = newVertex;
        queue->tail = newVertex;
    }
    ++(queue->counter);
    pthread_mutex_unlock(&queue->mut_counter);
    pthread_cond_broadcast(&queue->cond_counter);
    return size_str;
}

int mymsgget(Queue *queue, char * buf, size_t bufsize) {
    struct Vertex* ver_get;
    int size;
    if(queue->is_drop){
        return 0;
    }

    pthread_mutex_lock(&queue->mut_counter);
    while(1){
        if(queue->is_drop){
            pthread_mutex_unlock(&queue->mut_counter);
            return 0;
        }
        if(queue->counter > 0){
            break;
        }
        pthread_cond_wait(&queue->cond_counter,&queue->mut_counter);
    }
    ver_get = queue->head;
    if(queue->head->next == 0){
        if(queue->head->next == 0){
            queue->head = 0;
            queue->tail = 0;
        }
    } else {
        queue->head = queue->head->next;
    }
    --(queue->counter);
    pthread_mutex_unlock(&queue->mut_counter);
    pthread_cond_broadcast(&queue->cond_counter);
    size = strlen(strncpy(buf, ver_get->string, bufsize));
    free(ver_get);
    return size;
}

int start_thread(pthread_t* pthread, struct Param* param) {
    int code;
    code = pthread_create(pthread, 0, thread_body, param);
    if (code!=0) {
        char buf[256];
        strerror_r(code, buf, sizeof buf);
        fprintf(stderr, " creating thread: %s\n", buf);
        return 1;
    }
    return 0;
}

void* thread_body(void* param_) {
    int i;
    struct Param* param = (struct Param*)param_;
    if(param->get_or_put == 1){
        for(i=0; i < 10; ++i){
            sleep(1);
            fprintf(stderr, "put i=%d\n", i);
            mymsgput(param->queue, "string111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
        }
    } else if(param->get_or_put == 0){
        for(i=0; i < 10; ++i){
            size_t bufsize = 10*i;
            sleep(10);
            fprintf(stderr, "get i=%d\n", i);
            char *buf = (char*)malloc(sizeof(char) * bufsize);
            mymsgget(param->queue,buf,bufsize);
            fprintf(stderr, "%s\n", buf);
            free(buf);
        }
    } else {
        fprintf(stderr, "error param thread\n");
    }
    return 0;
}

struct Param* get_param(char get_or_put, int ID, Queue* queue) {
    struct Param* param = (struct Param*)malloc(sizeof(struct Param));
    param->get_or_put = get_or_put;
    param->ID = ID;
    param->queue = queue;
    return param;
}
