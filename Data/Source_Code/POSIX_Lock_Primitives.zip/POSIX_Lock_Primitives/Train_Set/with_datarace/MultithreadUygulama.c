# 1 "MultithreadUygulama.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "MultithreadUygulama.c"
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/pthread.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/pthread.h" 2
# 2 "MultithreadUygulama.c" 2
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 3 "MultithreadUygulama.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 4 "MultithreadUygulama.c" 2




void SayiUret();
void *Siralama(void *parametre);
void *Birlesme(void *parametre);
void ThreadYarat();
void DosyayaYaz();

pthread_mutex_t lock;
int liste[1000];
int sonuc[1000];

FILE *dosya;

typedef struct
{
    int baslangic;
    int bitis;
} parametreler;

int main (int argc, const char * argv[])
{
 dosya = fopen("dizileriGoster.txt", "w+");
 if(dosya == 0)
 {
  printf("dizileriGoster.txt açılamadı..\n");
  exit(1);
 }
 SayiUret();
 ThreadYarat();
 DosyayaYaz();
 return 0;
}
void SayiUret()
{
int rnd;
int flag;
int i, j;

printf("***RANDOM DİZİ***\n");
fprintf(dosya,"%s","****RANDOM DİZİ***");
    fputc('\n',dosya);

for(i = 0; i < 1000; i++) {
     do {
        flag = 1;
        rnd = rand() % (1000) + 1;

        for (j = 0; j < i && flag == 1; j++) {
           if (liste[j] == rnd) {
              flag = 0;
           }
        }
     } while (flag != 1);
     liste[i] = rnd;
    printf("%d.sayi : %d\t",i+1,liste[i]);
 if(i % 10 == 0)
  printf("\n");
 fprintf(dosya,"%d %s %d" ,i+1,".eleman:",liste[i]);
    fputc('\n',dosya);
}
}

void ThreadYarat()
{
   int i;
   if (pthread_mutex_init(&lock, 0) != 0)
    {
        printf("\n mutex başlatılamadı\n");
        exit(0);
    }

    pthread_t threadler[3];


    parametreler *veri = (parametreler *) malloc (sizeof(parametreler));

    veri->baslangic = 0;
    veri->bitis = (1000/2) - 1;
    pthread_create(&threadler[0], 0, Siralama, veri);


    parametreler *veri2 = (parametreler *) malloc (sizeof(parametreler));
    veri2->baslangic = (1000/2);
    veri2->bitis = 1000 - 1;
    pthread_create(&threadler[1], 0, Siralama, veri2);

   for (i = 0; i < 3 -1; i++)
   {
   pthread_join(threadler[i], 0);

   }
    pthread_mutex_destroy(&lock);

    parametreler *veri3 = (parametreler *) malloc(sizeof(parametreler));
    veri3->baslangic = 0;
    veri3->bitis = 1000;
    pthread_create(&threadler[2], 0, Birlesme, veri3);
    pthread_join(threadler[2], 0);

}

void *Siralama(void *parametre)
{
    parametreler *p = (parametreler *)parametre;
    int ilk = p->baslangic;
    int son = p->bitis+1;

    int z;

    fprintf(dosya,"%s","****SIRALANMAMIŞ ELEMANLAR***");
    fputc('\n',dosya);
    for(z = ilk; z < son; z++){

 fprintf(dosya,"%d %s %d" ,z+1,".eleman:",liste[z]);
    fputc('\n',dosya);
    }

    printf("\n");
    int i,j,t,k;



    pthread_mutex_lock(&lock);

    for(i=ilk; i< son; i++)
    {
        for(j=ilk; j< son-1; j++)
        {
            if(liste[j] > liste[j+1])
            {
                t = liste[j];
                liste[j] = liste[j+1];
                liste[j+1] = t;

            }
        }
    }
    pthread_mutex_unlock(&lock);


    fprintf(dosya,"%s","****SIRALANMIŞ ELEMANLAR***");
    fputc('\n',dosya);
    for(k = ilk; k< son; k++){

 fprintf(dosya,"%d %s %d" ,k+1,".eleman:",liste[k]);
    fputc('\n',dosya);
    }

    int x;
    for(x=ilk; x<son; x++)
    {
            sonuc[x] = liste[x];
    }
  printf("\n");
  return 0;
}

void *Birlesme(void *parametre)
{
    parametreler *p = (parametreler *)parametre;

    int ilk = p->baslangic;
    int son = p->bitis-1;

    int i,j,t;


    for(i=ilk; i< son; i++)
    {
        for(j=ilk; j< son-i; j++)
        {

            if(sonuc[j] > sonuc[j+1])
            {
                t = sonuc[j];
                sonuc[j] = sonuc[j+1];
                sonuc[j+1] = t;

            }
        }
    }

    int d;
# 200 "MultithreadUygulama.c"
    pthread_exit(0);
}

void DosyayaYaz()
{
 int i = 0;
 FILE *fp ;
 fp = fopen("son.txt","w+");
 fprintf(fp,"%s","****SIRALANMIŞ ELEMANLAR***");
 fputc('\n',fp);
 for(i = 0; i<1000; i++)
 {
    fprintf(fp,"%d %s %d" ,i+1,".eleman:",sonuc[i]);
    fputc('\n',fp);
 }
 fclose(fp);
}
