# 1 "03srv.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "03srv.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/string.h" 1
# 4 "03srv.c" 2

# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 6 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/types.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/types.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/types.h" 2
# 7 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/signal.h" 1
# 8 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/wait.h" 1
# 9 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/errno.h" 1
# 10 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/signal.h" 1
# 11 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/ipc.h" 1
# 12 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 13 "03srv.c" 2


# 1 "pycparser/utils/fake_libc_include/comsock.h" 1
# 16 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/myipc_shm.h" 1
# 17 "03srv.c" 2
# 1 "pycparser/utils/fake_libc_include/myipc_sem.h" 1
# 18 "03srv.c" 2

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
# 33 "03srv.c"
void handle(int signum)
{
 int pid = 0;
 printf("recv signum:%d \n", signum);


 while ((pid = waitpid(-1, 0, WNOHANG) ) > 0)
 {
  printf("退出子进程pid%d \n", pid);
  fflush(stdout);
 }
}



int srv_init()
{

 int ret = 0;
 int shmhdl = 0;
 key_t key = 0;
 ret = IPC_CreatShm(".", sizeof(int), &shmhdl);
 if (ret != 0)
 {
  printf("func IPC_CreatShm() err:%d \n", ret);
  return ret;
 }

 key = ftok(".", 'z');

  int semid = 0;
 ret = sem_creat(key, &semid);
 if (ret != 0)
 {
  printf("func sem_creat() err:%d,重新按照open打开信号酿\n", ret);
  if (ret == SEMERR_EEXIST)
  {
   ret = sem_open(key, &semid);
   if (ret != 0)
   {
    printf("按照打开的方式，重新获取sem失败:%d \n", ret);
    return ret;
   }
  }
  else
  {
   return ret;
  }

 }

 int val = 0;
 ret = sem_getval(semid, &val);
 if (ret != 0 )
 {
  printf("func sem_getval() err:%d \n", ret);
  return ret;
 }
 printf("sem val:%d\n", val);
 return ret;
}

void TestFunc_sem()
{
 int ncount = 0;
 int ret = 0;
 int shmhdl = 0;
 int *addr = 0;
 key_t key = 0;

 int semid = 0;

 key = ftok(".", 'z');
 sem_open(key, &semid);

  sem_p(semid);
 ret = IPC_CreatShm(".", 0, &shmhdl);
 ret =IPC_MapShm(shmhdl, (void **)&addr);
 *((int *)addr) = *((int *)addr) + 1;
 ncount = *((int *)addr);
 printf("ncount:%d\n", ncount);
 ret =IPC_UnMapShm(addr);
 sem_v(semid);
}


void TestFunc_mutex()
{
 int ncount = 0;
 int ret = 0;
 int shmhdl = 0;
 int *addr = 0;
 key_t key = 0;

 int semid = 0;

 key = ftok(".", 'z');
 sem_open(key, &semid);

  pthread_mutex_lock(&mutex);
 ret = IPC_CreatShm(".", 0, &shmhdl);
 ret =IPC_MapShm(shmhdl, (void **)&addr);
 *((int *)addr) = *((int *)addr) + 1;
 ncount = *((int *)addr);
 printf("ncount:%d\n", ncount);
 ret =IPC_UnMapShm(addr);
 pthread_mutex_unlock(&mutex);
}

void *Malloc_my_routine(void *arg)
{
 int ret = 0;
 ret = pthread_detach(pthread_self());
 if (0 == arg)
 {
  printf("fucn err my_routine param err\n");
  return 0;
 }
 int connfd = *((int*)arg);
 free(arg);


 char recvbuf[1024];
 unsigned int recvbuflen = 1024;

 while(1)
 {
  memset(recvbuf, 0, sizeof(recvbuf));
  ret = sck_server_recv(connfd, 0, recvbuf, &recvbuflen);
  if (ret >= 3000)
  {
   printf("func sck_server_recv() err:%d \n", ret);
   break;
  }


  TestFunc_mutex();
  printf("recvbuf = %s\n", recvbuf);

  ret = sck_server_send(connfd, 0, recvbuf, recvbuflen);
  if (ret >= 3000)
  {
   printf("func sck_server_send() err:%d \n", ret);
   break;
  }
 }
 close(connfd);

 return 0;
}
# 225 "03srv.c"
int main(void)
{
 int ret = 0;
 int listenfd = 0;
 char ip[1024] = {0};
 int port = 0;
 int connfd = 0;

 signal(SIGCHLD, handle);
 signal(SIGPIPE, SIG_IGN);

 ret = srv_init();

 ret = sck_server_init(8001, &listenfd);
 if (ret != 0)
 {
  printf("sckServer_init() err:%d \n", ret);
  return ret;
 }

 while(1)
 {
  int ret = 0;
  int wait_seconds = 5;


  ret = sck_server_accept(listenfd, wait_seconds, &connfd, ip, &port);
  if (ret >= 3000)
  {
   printf("timeout....\n");
   continue;
  }
  printf("客户端连接成功...\n");

  pthread_t tid = 0;

  int *pCon = 0;
  pCon = (int *)malloc(sizeof(int));
  *pCon = connfd;
  ret = pthread_create(&tid, 0, Malloc_my_routine, (void *)pCon);


 }

 sck_server_close(listenfd);
 sck_server_close(connfd);
 return 0;
}
