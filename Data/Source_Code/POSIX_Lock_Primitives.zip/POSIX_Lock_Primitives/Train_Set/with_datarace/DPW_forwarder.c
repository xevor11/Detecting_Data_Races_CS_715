# 1 "DPW_forwarder.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "DPW_forwarder.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "DPW_forwarder.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 3 "DPW_forwarder.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 4 "DPW_forwarder.c" 2
# 1 "pycparser/utils/fake_libc_include/string.h" 1
# 5 "DPW_forwarder.c" 2
# 1 "pycparser/utils/fake_libc_include/errno.h" 1
# 6 "DPW_forwarder.c" 2
# 1 "pycparser/utils/fake_libc_include/DPW_forwarder.h" 1
# 7 "DPW_forwarder.c" 2

int DPW_countack, num_ack[NUM_M];
int DPW_infly_high, DPW_infly_low;
int *DPW_table4g;

pthread_t DPW_recv_g_send_m_t[NUM_G], DPW_recv_m_send_g_t[NUM_M], DPW_FT_send_b_t;
pthread_mutex_t ordered_mutex, ack_mutex;

struct DPW_order *DPW_order_list;
struct timespec DPW_DA_begin_time;
struct timespec *DPW_DA_end_list, *DPW_DA_start_list;

void *DPW_recv_g_send_m_task(void *arg);
void *DPW_recv_m_send_g_task(void *arg);
void *DPW_FT_send_b_task(void *arg);

int main(int argc, char **argv) {
  int i, tmp_g[NUM_G], tmp_m[NUM_M], ack;
  int accepted;


  if (argc != 3) {
    printf("Usage: %s type infly_high\n", argv[0]);
    exit(1);
  }
  me = DPW_initialize_cluster(argv[1]);
  printf("%d\n", me);
  DPW_infly_low = DPW_infly_high = atoi(argv[2]);


  DPW_countack = 0;
  for (i = 0; i < NUM_M; i++) num_ack[i] = -1;
  DPW_order_list = (struct DPW_order *) malloc(BUFFER_SIZE * sizeof (struct DPW_order));
  DPW_table4g = (int *) malloc(BUFFER_SIZE * sizeof (int));
  DPW_DA_end_list = (struct timespec *) malloc(BUFFER_SIZE * sizeof (struct timespec));
  DPW_DA_start_list = (struct timespec *) malloc(BUFFER_SIZE * sizeof (struct timespec));

  pthread_mutex_init(&ordered_mutex, 0);
  pthread_mutex_init(&ack_mutex, 0);
  if (NTU_listen_unit() < 0) ERROR("listen_unit");

  INFO("Start %s", get_name(me));


  NTU_connect_unit(M0);
  NTU_connect_unit(M1);
  NTU_connect_unit(R);

  if (NTU_connect_unit(B) == B) {
    if (NTU_recv_unit(B, &DPW_countack, sizeof (int)) < 0) {
    }
    else INFO("Recover DPW_countack=[%d]", DPW_countack);
    if (NTU_recv_unit(B, &ack, sizeof (int)) < 0) {
    }
    else {
      INFO("Recover ack=[%d]", ack);
      num_ack[0] = ack;
      num_ack[1] = ack;
    }
  }


  for (i = 0; i < NUM_G; i++) {
    tmp_g[i] = i;
    while (pthread_create(&DPW_recv_g_send_m_t[i], 0, DPW_recv_g_send_m_task, (void *) &tmp_g[i]) < 0) {
      WARN("pthread_create m_main_t[%d]", i);
    }
  }
  for (i = 0; i < NUM_M; i++) {
    tmp_m[i] = i;
    while (pthread_create(&DPW_recv_m_send_g_t[i], 0, DPW_recv_m_send_g_task, (void *) &tmp_m[i]) < 0) {
      WARN("pthread_create m_main_t[%d]", i);
    }
  }
  while (pthread_create(&DPW_FT_send_b_t, 0, DPW_FT_send_b_task, 0) < 0) {
    WARN("pthread_create DPW_FT_send_b_t");
  }



  while (1) {
    accepted = NTU_accept_unit();

    if (accepted >= F0 + NUM_F) {
      INFO("Reconnect to %s", get_name(accepted));
      while (NTU_connect_unit(accepted) < 0) {
        sleep(1);
      }
    }
    if(accepted < F0);
  }
  return 0;
}

void *DPW_recv_m_send_g_task(void *arg){
  int w = *((int *) arg);
  int M = M0 + w;
  int ack, ok = 0, protocol, gw;


  while (1) {
    if (get_status(M) == DEAD) continue;
    if (num_ack[w] >= DPW_countack - 1) continue;

    if (NTU_recv_unit(M, &ack, sizeof (int)) < 0) {
      protocol = w + 3;
      if (NTU_send_unit(R, &protocol, sizeof (int)) < 0) {
      }
      INFO("Notify R that %s die", get_name(M));
      continue;
    }
    DEBUG("Recv %s ack=[%d]", get_name(M), ack);



    pthread_mutex_lock(&ack_mutex);
    if (ack > num_ack[0] && ack > num_ack[1]) {
      num_ack[w] = ack;
      ok = 1;
    }
    pthread_mutex_unlock(&ack_mutex);

    if (ok == 1) {
      ok = 0;
      gw = DPW_table4g[ack % BUFFER_SIZE];
      if (NTU_send_unit(gw, &ack, sizeof (int)) < 0) continue;
      DEBUG("Send G%d ack=[%d]", gw, ack);

      clock_gettime(CLOCK_REALTIME, &DPW_DA_end_list[ack % BUFFER_SIZE]);
      DA_data_analysis(ack, DPW_DA_start_list[ack%BUFFER_SIZE], DPW_DA_end_list[ack%BUFFER_SIZE], DPW_DA_begin_time);
      fflush(stdout);
    }

    if (ack > num_ack[w]) num_ack[w] = ack;
  }

  pthread_exit(0);
}

void *DPW_recv_g_send_m_task(void *arg) {
  int w = *((int *) arg);
  int G = G0 + w;
  struct DPW_order odr;
  int i, infly = 0;


  while (1) {
    if (get_status(G) == DEAD) continue;

    if (DPW_countack - (DPW_infly_high - infly) > num_ack[0] && DPW_countack - (DPW_infly_high - infly) > num_ack[1]) {
      infly = DPW_infly_high - DPW_infly_low;
      continue;
    }
    INFO("%d %d",DPW_countack - num_ack[0], DPW_countack - num_ack[1]);
    infly = 0;
    if (NTU_recv_unit(G, odr.str, DPW_order_size) < 0) continue;
    DEBUG("Recv %s str=[%s]", get_name(G), odr.str);

    if (DPW_countack < 1) clock_gettime(CLOCK_REALTIME, &DPW_DA_begin_time);
    clock_gettime(CLOCK_REALTIME, &DPW_DA_start_list[DPW_countack % BUFFER_SIZE]);

    pthread_mutex_lock(&ack_mutex);


    odr.id = DPW_countack;
    DPW_table4g[DPW_countack % BUFFER_SIZE] = w;
    DPW_order_list[DPW_countack % BUFFER_SIZE] = odr;


    for (i = 0; i < NUM_M; i++) {
      if (NTU_send_unit(M0 + i, &odr, DPW_order_size) < 0) {
      }
      else DEBUG("Send M%d id=[%d] str=[%s]", i, odr.id, odr.str);
    }

    pthread_mutex_unlock(&ack_mutex);


    if (NTU_send_unit(B, &odr, DPW_order_size) < 0) {
    }
    else DEBUG("Send B id=[%d] str=[%s]", odr.id, odr.str);

    DPW_countack++;
  }

  pthread_exit(0);
}

void *DPW_FT_send_b_task(void *arg) {
  struct DPW_order odr;

  while (1) {
    odr.id = -1;
    if (NTU_send_unit(B, &odr, DPW_order_size) < 0) {
    }
    sleep(1);
  }

  pthread_exit(0);
}
