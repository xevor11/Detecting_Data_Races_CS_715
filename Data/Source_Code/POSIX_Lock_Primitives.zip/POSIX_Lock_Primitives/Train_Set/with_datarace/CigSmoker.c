# 1 "CigSmoker.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "CigSmoker.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "CigSmoker.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "CigSmoker.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 4 "CigSmoker.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 5 "CigSmoker.c" 2
# 1 "pycparser/utils/fake_libc_include/stdbool.h" 1
# 6 "CigSmoker.c" 2
# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 7 "CigSmoker.c" 2


sem_t sem_agent;
sem_t sem_tobacco;
sem_t sem_paper;
sem_t sem_match;
sem_t tobacco;
sem_t match;
sem_t paper;
sem_t sem_mutex;

bool tobFree = 0;
bool paperFree = 0;
bool matchesFree = 0;

void *agentA(void *);
void *agentB(void *);
void *agentC(void *);
void *pusherA(void *);
void *pusherB(void *);
void *pusherC(void *);
void *smoker1(void *);
void *smoker2(void *);
void *smoker3(void *);

pthread_mutex_t print_mutex;

int main( int argc, char *argv[] ) {

   pthread_t a1, a2, a3, p1, p2, p3, s1, s2, s3;


 sem_init(&sem_agent, 0, 1);
 sem_init(&sem_tobacco, 0, 0);
 sem_init(&sem_paper, 0, 0);
 sem_init(&sem_match, 0, 0);
 sem_init(&tobacco, 0, 0);
 sem_init(&paper, 0, 0);
 sem_init(&match, 0, 0);
 sem_init(&sem_mutex, 0, 1);
    pthread_mutex_init(&print_mutex, 0);

    pthread_create(&a1, 0, agentA, 0);
    pthread_create(&a2, 0, agentB, 0);
    pthread_create(&a3, 0, agentC, 0);
    pthread_create(&s1, 0, smoker1, 0);
    pthread_create(&s2, 0, smoker2, 0);
    pthread_create(&s3, 0, smoker3, 0);
    pthread_create(&p1, 0, pusherA, 0);
    pthread_create(&p2, 0, pusherB, 0);
    pthread_create(&p3, 0, pusherC, 0);

    while(1){
    }

}


void *agentA(void *a){
 while(1){
  sem_wait(&sem_agent);
  sem_post(&sem_tobacco);
  sem_post(&sem_paper);
 }
}

void *agentB(void *b){
 while(1){
  sem_wait(&sem_agent);
  sem_post(&sem_tobacco);
  sem_post(&sem_match);
 }
}

void *agentC(void *c){
 while(1){
  sem_wait(&sem_agent);
  sem_post(&sem_paper);
  sem_post(&sem_match);
 }
}

void *smoker1(void *a){
 while(1){
  pthread_mutex_lock(&print_mutex);
  printf("S1 needs tobacco\n");
  pthread_mutex_unlock(&print_mutex);

  sem_wait(&tobacco);

  pthread_mutex_lock(&print_mutex);
  printf("S1 gets tobacco, roll cig\n");
  pthread_mutex_unlock(&print_mutex);

  sem_post(&sem_agent);

  pthread_mutex_lock(&print_mutex);
  printf("S1 rolls one and drops the tabacco\n" );
  pthread_mutex_unlock(&print_mutex);
  sleep(4);
 }
}

void *smoker2(void *b){
 while(1){
  pthread_mutex_lock(&print_mutex);
  printf("S2 needs Paper\n");
  pthread_mutex_unlock(&print_mutex);

  sem_wait(&paper);

  pthread_mutex_lock(&print_mutex);
  printf("S2 gets paper, roll cig\n");
  pthread_mutex_unlock(&print_mutex);

  sem_post(&sem_agent);
  pthread_mutex_lock(&print_mutex);
  printf("S2 rolls one and drops papers\n" );
  pthread_mutex_unlock(&print_mutex);
  sleep(4);
 }
}

void *smoker3(void *c){
 while(1){
  pthread_mutex_lock(&print_mutex);
  printf("S3 needs matches\n");
  pthread_mutex_unlock(&print_mutex);

  sem_wait(&match);
  pthread_mutex_lock(&print_mutex);
  printf("S3 gets matches, roll cig\n");
  pthread_mutex_unlock(&print_mutex);
  sem_post(&sem_agent);

  pthread_mutex_lock(&print_mutex);
  printf("S3 rolls one and drops matches\n" );
  pthread_mutex_unlock(&print_mutex);

  sleep(4);
 }
}

void *pusherA(void *a){
 while(1){
   sem_wait(&sem_tobacco);
   pthread_mutex_lock(&print_mutex);
   printf("Tobacco is on the table.\n");
   pthread_mutex_unlock(&print_mutex);

   sem_wait(&sem_mutex);
    if(paperFree){
     paperFree = 0;
     sem_post(&paper);
    }else if(matchesFree){
     matchesFree = 0;
     sem_post(&match);
    }else{
     tobFree = 1;
    }
   sem_post(&sem_mutex);
 }
}


void *pusherB(void *b){
 while(1){
  sem_wait(&sem_match);
  pthread_mutex_lock(&print_mutex);
  printf("Matches are on the table.\n");
  pthread_mutex_unlock(&print_mutex);

  sem_wait(&sem_mutex);
   if(paperFree){
    paperFree = 0;
    sem_post(&match);
   }else if(tobFree){
    tobFree = 0;
    sem_post(&tobacco);
   }else{
    matchesFree = 1;
   }
  sem_post(&sem_mutex);
 }
}

void *pusherC(void *c){
 while(1){
  sem_wait(&sem_paper);
  pthread_mutex_lock(&print_mutex);
  printf("Paper is on the table.\n");
  pthread_mutex_unlock(&print_mutex);

  sem_wait(&sem_mutex);
   if(tobFree){
    tobFree = 0;
    sem_post(&tobacco);
   }else if(matchesFree){
    matchesFree = 0;
    sem_post(&match);
   }else{
    paperFree = 1;
   }
  sem_post(&sem_mutex);
 }
}
