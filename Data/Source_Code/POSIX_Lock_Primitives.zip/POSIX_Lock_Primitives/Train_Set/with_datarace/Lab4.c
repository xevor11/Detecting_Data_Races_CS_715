# 1 "Lab4.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "Lab4.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 4 "Lab4.c" 2

# 1 "pycparser/utils/fake_libc_include/sys/types.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/types.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/types.h" 2
# 6 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/wait.h" 1
# 7 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/syscall.h" 1
# 8 "Lab4.c" 2

# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 10 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 11 "Lab4.c" 2
# 1 "pycparser/utils/fake_libc_include/semaphore.h" 1
# 12 "Lab4.c" 2



sem_t customer_sem;

sem_t barber_sem;

sem_t leaving_sem;




pthread_cond_t barber_cv;




pthread_mutex_t seat_mutex;

pthread_mutex_t barber_mutex;

pthread_mutex_t print_mutex;

pthread_mutex_t count_mutex;


int barber_working;

int free_seat_count;
int max_seat_count;
int barber_count;
int customer_count;
int customers_visited;


void* customer_run(void* arg)
{
   int check_in_time = (rand()%10) + 1;
   printf("Customer %d! I will appear in %d time\n", syscall(SYS_gettid), check_in_time);


   sleep(check_in_time);


   pthread_mutex_lock(&seat_mutex);

   if (free_seat_count > 0)
     {

 free_seat_count--;
 pthread_mutex_unlock(&seat_mutex);

 sem_post(&customer_sem);


 pthread_mutex_lock(&barber_mutex);


        printf("\nCustomer %d is sitting in seat %d\n", syscall(SYS_gettid), (free_seat_count + 1));


 while(!barber_working)
   {

      pthread_cond_wait(&barber_cv, &barber_mutex);
   }

 pthread_mutex_unlock(&barber_mutex);



 sem_wait(&barber_sem);


 pthread_mutex_lock(&count_mutex);
 customers_visited++;
 pthread_mutex_unlock(&count_mutex);


 time_t t;
 time(&t);
 pthread_mutex_lock(&print_mutex);
 printf("\n---Customer %d hair is cut. The time is %s", syscall(SYS_gettid), ctime(&t));
 pthread_mutex_unlock(&print_mutex);


 sem_post(&leaving_sem);
     }


   else
     {
 pthread_mutex_unlock(&seat_mutex);
 pthread_mutex_lock(&print_mutex);
 printf("\n---No more seats! I am Customer %d\n", syscall(SYS_gettid));
 pthread_mutex_unlock(&print_mutex);


 pthread_mutex_lock(&count_mutex);
 customers_visited++;
 pthread_mutex_unlock(&count_mutex);
     }

}



void* barber_run(void* arg)
{
   int cut_time = (rand()%3) + 1;
   printf("Barber %d! It takes me %d time to cut hair\n\n", syscall(SYS_gettid), cut_time);

   while(customers_visited < customer_count)
     {
 pthread_mutex_unlock(&count_mutex);

 sem_wait(&customer_sem);


 pthread_mutex_lock(&seat_mutex);
 free_seat_count++;
 pthread_mutex_unlock(&seat_mutex);


 pthread_mutex_lock(&barber_mutex);
 barber_working = 1;
 pthread_cond_signal(&barber_cv);
 pthread_mutex_unlock(&barber_mutex);


 sleep(cut_time);


 pthread_mutex_lock(&barber_mutex);
 barber_working = 0;
 pthread_cond_signal(&barber_cv);
 pthread_mutex_unlock(&barber_mutex);



 sem_post(&barber_sem);


 sem_wait(&leaving_sem);

 pthread_mutex_lock(&count_mutex);
     }
   printf("I QUIT! Barber helped %d people\n", customers_visited);
}


int main(int argc, char** argv)
{
   if (argc == 3)
     {

 customers_visited = 0;


 srand(time(0));


 char* endptr;


 barber_count = 1;
 customer_count = (int)strtol(argv[1], &endptr, 10);
 free_seat_count = (int)strtol(argv[2], &endptr, 10);

 max_seat_count = free_seat_count;

 printf(" Barbers %d\n Customers %d\n Free Seats %d \n", barber_count, customer_count, free_seat_count);


 pthread_mutex_init(&count_mutex, 0);


 pthread_mutex_init(&print_mutex, 0);


 sem_init(&customer_sem, 0, 0);
 sem_init(&barber_sem, 0, 0);
 sem_init(&leaving_sem, 0, 0);


 pthread_t barber;
 pthread_t customer[customer_count];


 pthread_mutex_init(&barber_mutex, 0);
 pthread_cond_init(&barber_cv, 0);


 pthread_mutex_init(&seat_mutex, 0);



 int i;


 pthread_create(&barber, 0, &barber_run, 0);


 for (i = 0; i < customer_count; i++)
   {
      pthread_create(&customer[i], 0, &customer_run, 0);
   }



 for (i = 0; i < customer_count; i++)
   {
      pthread_join(customer[i], 0);
   }


 pthread_join(barber, 0);

     }
   else
     {
 printf("This version uses one barber\n");
 printf("Please enter the number of: customers and free seats respectively as arguments\n");
     }


   return 0;
}
