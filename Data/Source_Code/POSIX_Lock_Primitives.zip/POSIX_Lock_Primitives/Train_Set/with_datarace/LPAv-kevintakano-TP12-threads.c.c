# 1 "LPAv-kevintakano-TP12-threads.c.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "LPAv-kevintakano-TP12-threads.c.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "LPAv-kevintakano-TP12-threads.c.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "LPAv-kevintakano-TP12-threads.c.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 4 "LPAv-kevintakano-TP12-threads.c.c" 2


int amount_of_elements_in_run = 0;

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;


void print_v(int v[], int n)
{
  int i = 0;
  while(i<n)
  {
    printf("%d\t",v[i]);
    i++;
  }
  printf("\n");
}


void *calculate_two_elements(void *vectorptr)
{
 pthread_mutex_lock(&mutex1);
 int i;

 int *vector = (int*)vectorptr;

 while(amount_of_elements_in_run > 1)
 {
  vector[0] = vector[0] + vector[amount_of_elements_in_run-1];

  amount_of_elements_in_run--;
 }
 pthread_mutex_unlock(&mutex1);
}


void swap(int *a, int *b)
{
  int tmp;
  tmp = *a;
  *a = *b;
  *b = tmp;
}


int *generate_random_vector( int n)
{
 int *v;
 v = (int*)malloc(sizeof(int)*n);
 int i;

 for(i = 0;i < n;++i)
  v[i] = i;


 int w ;
 for(i = n - 1;i > 0;--i)
 {
    w = rand() % i;
   swap(&v[i],&v[w]);
 }

 return v;
}

int calculate_sum_vector_in_main(int vector[], int n, double *spent_time)
{
 struct timeval antes, depois ;
    *spent_time = 0;
    gettimeofday (&antes, 0) ;
 int sum = 0;
 int i = 0;
 while(i < n)
 {
  sum = sum + vector[i];
  i++;
 }
 gettimeofday (&depois, 0) ;
    *spent_time = (double)( (depois.tv_sec * 1000000 + depois.tv_usec) - (antes.tv_sec * 1000000 + antes.tv_usec) );
 return sum;
}

void close_threads(pthread_t threads_vector[], int amount_of_threads)
{
 int index;
 for(index=0;index<amount_of_threads;index++)
 {
  pthread_join(threads_vector[index] ,0);
 }
}

void calculate_sum_vector_with_k_threads(int *vector, int n, int amount_of_threads, double *spent_time)
{
 struct timeval antes, depois ;
    *spent_time = 0;
    gettimeofday (&antes, 0) ;

    amount_of_elements_in_run = n;



 pthread_t threads_vector[amount_of_threads];

 int index;
 for(index=0;index<amount_of_threads ;index++)
 {
  pthread_create(threads_vector + index,0,&calculate_two_elements,(void*)vector);
 }
 close_threads(threads_vector,amount_of_threads);
 gettimeofday (&depois, 0) ;
    *spent_time = (double)( (depois.tv_sec * 1000000 + depois.tv_usec) - (antes.tv_sec * 1000000 + antes.tv_usec) );
}


int main(int argc, char **argv)
{
 if(argc == 3)
 {
   srand(time(0));
  int n = atoi(argv[1]);
  int k = atoi(argv[2]);
  int *vector;

  printf("* Tamanho da entrada: %d\n",n);
  printf("* Quantidade de threads: %d\n",k);
  amount_of_elements_in_run = n;
  printf("\n");

  double spent_time = 0,spent_time2 = 0;

  vector = generate_random_vector(n);

  printf("* Soma dos elementos do vetor na Thread Main: %d\n",calculate_sum_vector_in_main(vector,n,&spent_time));
  printf("* Tempo decorrido na Thread Main (microssegundos): %lf\n\n",spent_time);

  calculate_sum_vector_with_k_threads(vector,n,k,&spent_time2);
  printf("* Soma dos elementos do vetor Com k(%d)-Threads: %d\n",k,vector[0]);
  printf("* Tempo decorrido com k(%d)-Threads (microssegundos): %lf\n",k,spent_time2);
  printf("%lf\n",spent_time2);
 } else
 {
  printf("* Deve-se haver três argumentos de entrada!\n");
  printf("* ./<arquivo-executavel> <tamanho do vetor> <quantidade de threads>\n");
 }

 exit(0);
}
