# 1 "Cw4Extra.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "Cw4Extra.c"
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/pthread.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/pthread.h" 2
# 2 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 3 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 4 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 5 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/math.h" 1
# 6 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/neutrino.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/neutrino.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/neutrino.h" 2
# 7 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/netmgr.h" 1
# 8 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/ctype.h" 1
# 9 "Cw4Extra.c" 2
# 1 "pycparser/utils/fake_libc_include/errno.h" 1
# 10 "Cw4Extra.c" 2

typedef struct {
 int typ;
 int pocz;
 int kon;
 int numer;
} par_t;

volatile int running_threads = 0;
volatile int p_count = 0;
pthread_mutex_t primes_mutex = PTHREAD_MUTEX_INITIALIZER;
int pid;
int chid;

void *count_primes2(void *arg) {
 int status;
 int coid;
 par_t reply;

 coid = ConnectAttach(ND_LOCAL_NODE, pid, chid, _NTO_SIDE_CHANNEL, 0);
 while (1) {
  par_t args;
  args.typ = 10;
  args.numer = pthread_self();

  status = MsgSend(coid, &args, sizeof(args), &reply, sizeof(reply));
  if (reply.typ == 1) {
   sleep(1);

   int primes_count = 0;

   printf("Proces: %d, watek: %d\n", getpid(), pthread_self());
   int i;
   for (i = reply.pocz; i < reply.kon; i++) {
    int c;
    int prime = 1;
    for (c = 2; c <= i / 2; c++) {
     if (i % c == 0) {
      prime = 0;
      break;
     }
    }
    if (prime && i != 0 && i != 1)
     primes_count++;
   }



   printf("\twatek: %d, poczatek %d, koniec %d, primes %d\n",
     pthread_self(), reply.pocz, reply.kon, primes_count);

   pthread_mutex_lock(&primes_mutex);
   p_count += primes_count;
        pthread_mutex_unlock(&primes_mutex);
  } else if (reply.typ == 0) {
   return 0;
  }

 }
}

int main(int argc, char *argv[]) {
 pid = getpid();
 chid = ChannelCreate(0);
 if (argc != 4) {
  printf("Proper usage: ./lab2 range_start range_end thread_count\n");
  return 0;
 }

 int range_start = atoi(argv[1]);
 int range_end = atoi(argv[2]);
 int threads_count = atoi(argv[3]);
 int range_length = (range_end - range_start) / (threads_count * 4);

 int i = 0;
 int f = 0;
 pthread_t tid;

 while (1) {

  if (running_threads < threads_count && !f) {


   pthread_create(&tid, 0, count_primes2, 0);
   running_threads++;
   printf("in if\n");


  } else {
   printf("in first else\n");
   f = 1;
   par_t args;
   int rcvid = MsgReceive(chid, &args, sizeof(args), 0);
   if (range_start + (i + 1) * range_length <= range_end) {
      printf("if <=range end\n");
    if (args.typ == 10) {

     args.typ = 1;
     args.numer = i;

     args.pocz = range_start + i * range_length;
     args.kon = range_start + (i + 1) * range_length;

     int status = MsgReply(rcvid, EOK, &args, sizeof(args));
     if (-1 == status) {
      perror("MsgReply");
     }
    }

    i++;
   } else {
    printf(".else args.typ == 0 ");
    args.typ = 0;
    int status = MsgReply(rcvid, EOK, &args, sizeof(args));
    if (-1 == status) {
     perror("MsgReply");
    }
    printf("Watek %d poprosil, ale nie ma\n", args.numer);
    running_threads--;
    if (!running_threads) {
     break;
    }
   }
  }
 }
 printf("Liczb pierwszych: %d\n", p_count);

 return 0;
}
