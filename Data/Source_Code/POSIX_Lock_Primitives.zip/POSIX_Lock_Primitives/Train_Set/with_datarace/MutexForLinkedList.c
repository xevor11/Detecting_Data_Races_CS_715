# 1 "MutexForLinkedList.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "MutexForLinkedList.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/string.h" 1
# 3 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 4 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/stdbool.h" 1
# 5 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/time.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/time.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/time.h" 2
# 6 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 7 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/math.h" 1
# 8 "MutexForLinkedList.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 9 "MutexForLinkedList.c" 2



struct list_node_s {
    int data;
    struct list_node_s *next;
};

struct list_node_s *head_pp = 0;
bool unique_array[65536] = {0};
int *operation_array;
float *time_array;
int elements;
int count = 0;
float overhead;

long thread_count;
pthread_mutex_t mutex;

int member(int value) {
    struct list_node_s *curr_p = head_pp;

    while (curr_p != 0 && curr_p->data < value) {
        curr_p = curr_p->next;
    }

    if (curr_p == 0 || curr_p->data > value) {
        return 0;
    } else {
        return 1;
    }
}

int insert(int value) {
    struct list_node_s *curr_p = head_pp;
    struct list_node_s *pred_p = 0;
    struct list_node_s *temp_p = 0;

    while (curr_p != 0 && curr_p->data < value) {
        pred_p = curr_p;
        curr_p = curr_p->next;
    }

    if (curr_p == 0 || curr_p->data > value) {
        temp_p = malloc(sizeof(struct list_node_s));
        temp_p->data = value;
        temp_p->next = curr_p;

        if (pred_p == 0) {
            head_pp = temp_p;
        } else {
            pred_p->next = temp_p;
        }
        return 1;
    } else {
        return 0;
    }
}

int delete(int value) {
    struct list_node_s *curr_p = head_pp;
    struct list_node_s *pred_p = 0;

    while (curr_p != 0 && curr_p->data < value) {
        pred_p = curr_p;
        curr_p = curr_p->next;
    }

    if (curr_p != 0 && curr_p->data < value) {
        if (pred_p == 0) {
            head_pp = curr_p->next;
            free(curr_p);
        } else {
            pred_p->next = curr_p->next;
            free(curr_p);
        }
        unique_array[value] = 0;
        return 1;
    } else {
        return 0;
    }
}

void populateLinkedList(int size) {
    srand(time(0));
    int *rand_array = malloc(size * sizeof(int));
    int i;
    for (i = 0; i < size; i++) {
        int value = rand() % 65536;
        if (!unique_array[value]) {
            insert(value);
            unique_array[value] = 1;
        } else {
            i = i - 1;
        }
    }
}

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void shuffleArray(int *array, int size) {
    srand(time(0));
    int i;
    for (i = size - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        swap(&array[i], &array[j]);
    }
}

int getUniqueRandomNumber() {
    int random = rand() % 65536;

    while (unique_array[random]) {
        random = rand() % 65536;
    }
    return random;
}

int *operationProceduence(int m, float mem, float ins, float del) {
    float tot_mem = m * mem;
    float tot_ins = tot_mem + m * ins;
    float tot_del = tot_ins + m * del;

    operation_array = malloc(m * sizeof(int));
    int j;
    for (j = 0; j < m; j++) {
        if (j < tot_mem) {
            operation_array[j] = 1;
        } else if (j < tot_ins) {
            operation_array[j] = 2;
        } else if (j < tot_del) {
            operation_array[j] = 3;
        }
    }
    shuffleArray(operation_array, m);

    return operation_array;
}

int printList() {
    struct list_node_s *curr_p = head_pp;
    int count = 0;
    while (curr_p != 0) {
        curr_p = curr_p->next;
        count++;
    }
    return count;
}

float calculateSD(float data[], int size) {
    float sum = 0.0, mean, standardDeviation = 0.0;
    int i;
    for (i = 0; i < size; ++i) {
        sum += data[i];
    }
    mean = sum / size;
    for (i = 0; i < size; ++i) {
        standardDeviation += pow(data[i] - mean, 2);
    }
    return sqrt(standardDeviation / size);
}

float calculateMean(float data[], int size) {
    float sum = 0.0, mean = 0.0;
    int i;
    for (i = 0; i < size; ++i) {
        sum += data[i];
    }
    return sum / size;
}

void *thread_oparation(void *rank) {

    int thread_number = (long) rank;
    int instances = elements / thread_count;
    int val1, val2, val3;
    int start = thread_number, j;
    for (j = start; j < elements; j = j + thread_count) {
        count++;
        if (operation_array[j] == 1) {
            pthread_mutex_lock(&mutex);
            val1 = rand() % 65536;
            member(val1);
            pthread_mutex_unlock(&mutex);
        } else if (operation_array[j] == 2) {
            pthread_mutex_lock(&mutex);
            val2 = getUniqueRandomNumber();
            insert(val2);

            pthread_mutex_unlock(&mutex);
        } else if (operation_array[j] == 3) {
            pthread_mutex_lock(&mutex);
            val3 = rand() % 65536;
            delete(val3);

            pthread_mutex_unlock(&mutex);
        }


    }
    return 0;
}

int main(int argc, char **argv) {
    int i, size = 100;
    time_array = malloc(size * sizeof(int));
    elements = atoi(argv[2]);

    thread_count = atoi(argv[6]);
    long thread;
    pthread_t *thread_handles;

    thread_handles = (pthread_t *) malloc(thread_count * sizeof(pthread_t));

    for (i = 0; i < size; i++) {
        overhead = 0;
        populateLinkedList(atoi(argv[1]));
        operationProceduence(atoi(argv[2]), atof(argv[3]), atof(argv[4]), atof(argv[5]));

        pthread_mutex_init(&mutex, 0);

        clock_t begin = clock();
        for (thread = 0; thread < thread_count; thread++) {
            pthread_create(&thread_handles[thread], 0, thread_oparation, (void *) thread);
        }

        for (thread = 0; thread < thread_count; thread++) {
            pthread_join(thread_handles[thread], 0);
        }
        clock_t end = clock();
        pthread_mutex_destroy(&mutex);

        double time_spent = (double) (end - begin) / CLOCKS_PER_SEC;
        time_array[i] = time_spent - overhead;
        printf("%d\n", i);

        printf("count = %d \n", printList());
        head_pp = 0;
        int l;
        for (l = 0; l < 65536; ++l) {
            unique_array[l] = 0;
        }

    }

    printf("STD = %f \t", calculateSD(time_array, size));
    printf("AVERAGE = %f \n", calculateMean(time_array, size));


    return 0;
}
