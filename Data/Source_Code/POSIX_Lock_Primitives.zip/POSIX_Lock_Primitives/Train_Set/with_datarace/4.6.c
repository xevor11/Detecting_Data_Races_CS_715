# 1 "4.6.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "4.6.c"







# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 9 "4.6.c" 2
# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 10 "4.6.c" 2
# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 11 "4.6.c" 2
# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 12 "4.6.c" 2
# 1 "pycparser/utils/fake_libc_include/sys/time.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/time.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1
# 2 "pycparser/utils/fake_libc_include/sys/time.h" 2
# 13 "4.6.c" 2

typedef struct {
    int Escritores;
    int EscritoresEsp;
    int Lectores;
    pthread_mutex_t mutex;
    pthread_cond_t AccesoEs;
    pthread_cond_t AccesoLec;
}mutex_rw;

int mutex_create( mutex_rw* x){
    x->Lectores=0;
    x->Escritores=0;
    x->EscritoresEsp=0;
    pthread_cond_init(&(x->AccesoLec),0);
    pthread_cond_init(&(x->AccesoEs),0);
    pthread_mutex_init(&(x->mutex),0);
    return 1;
}
void mutex_rdlock( mutex_rw* x){
    pthread_mutex_lock(&(x->mutex));
    while(x->Escritores > 0)
        pthread_cond_wait(&(x->AccesoLec), &(x->mutex));
    x->Lectores++;
    pthread_mutex_unlock(&(x->mutex));

}
void mutex_rdunlock( mutex_rw* x){
    pthread_mutex_lock(&(x->mutex));
        x->Lectores--;
        if(x->Lectores==0 && x->EscritoresEsp>0)
            pthread_cond_signal(&(x->AccesoEs));
        pthread_mutex_unlock(&(x->mutex));
}
void mutex_wrlock( mutex_rw* x)
{
        pthread_mutex_lock(&(x->mutex));
        x->EscritoresEsp++;
        while(x->Lectores>0 || x->Escritores>0)
        {
            pthread_cond_wait(&(x->AccesoEs), &(x->mutex));
        }
        x->EscritoresEsp--; x->Escritores++;
        pthread_mutex_unlock(&(x->mutex));
}
void mutex_wrunlock( mutex_rw* x)
{
        pthread_mutex_lock(&(x->mutex));
        x->Escritores--;
        if(x->EscritoresEsp>0)
            pthread_cond_signal(&(x->AccesoEs));
        pthread_cond_broadcast(&(x->AccesoLec));
        pthread_mutex_unlock(&(x->mutex));
}

double timeval_diff(struct timeval *a, struct timeval *b)
{
  return
    (double)(a->tv_sec + (double)a->tv_usec/1000000) -
    (double)(b->tv_sec + (double)b->tv_usec/1000000);
}
struct list_node_s
{
    int data;
    struct list_node_s* next;
    pthread_mutex_t mutex;
};


int thread_count;
struct list_node_s** head_pp;
pthread_mutex_t mutex;
pthread_mutex_t head_p_mutex;
pthread_rwlock_t rwlock;



int MemberP(int value)
{
    struct list_node_s* temp_p;
    pthread_mutex_lock(&head_p_mutex);
    temp_p=*head_pp;
    while(temp_p != 0 && temp_p->data<value)
    {
        if (temp_p->next != 0)
        {
            pthread_mutex_lock(&(temp_p->next->mutex));
        }
        if (temp_p == *head_pp)
        {
            pthread_mutex_unlock(&head_p_mutex);
        }
        pthread_mutex_unlock(&(temp_p->mutex));
        temp_p=temp_p->next;
    }
    if (temp_p == 0 || temp_p->data >value)
    {
        if (temp_p == *head_pp)
        {
            pthread_mutex_unlock(&head_p_mutex);
        }
        if (temp_p != 0)
        {
            pthread_mutex_unlock(&(temp_p->mutex));
        }
        return 0;
    }
    else
    {
        if (temp_p == *head_pp)
        {
            pthread_mutex_unlock(&head_p_mutex);
        }
        pthread_mutex_unlock(&(temp_p->mutex));
        return 1;
    }
}
int Member(int value)
{
    struct list_node_s* curr_p=*head_pp;
    while(curr_p!=0 && curr_p->data < value)
        curr_p=curr_p->next;
    if(curr_p == 0 || curr_p->data >value)
        return 0;
    else
        return 1;
}
int Insert(int value)
{
    struct list_node_s* curr_p= *head_pp;
    struct list_node_s* pred_p= 0;
    struct list_node_s* temp_p;
    while(curr_p != 0 && curr_p->data<value)
    {
        pred_p=curr_p;
        curr_p=curr_p->next;
    }
    if(curr_p == 0 || curr_p->data > value)
    {
        temp_p=malloc(sizeof(struct list_node_s));
        temp_p->data=value;
        temp_p->next=curr_p;
        if (pred_p == 0)
            *head_pp=temp_p;
        else
            pred_p->next=temp_p;
        return 1;
    }
    else
        return 0;
}
int Delete(int value)
{
    struct list_node_s* curr_p=*head_pp;
    struct list_node_s* pred_p= 0;
    while(curr_p != 0 && curr_p->data < value)
    {
        pred_p=curr_p;
        curr_p=curr_p->next;
    }
    if(curr_p != 0 && curr_p->data == value)
    {
        if(pred_p == 0)
        {
            *head_pp=curr_p->next;
            free(curr_p);
        }
        else
        {
            pred_p->next=curr_p->next;
            free(curr_p);
        }
        return 1;
    }
    else
        return 0;
}
void* LLamarFunc(void* rango)
{

    mutex_rw n_rwlock;
    mutex_create(&n_rwlock);

    long mi_rango=(long) rango;
    printf("Thread numero %ld\n",mi_rango);

    mutex_wrlock(&n_rwlock);
    Insert((int)mi_rango);
    mutex_wrunlock(&n_rwlock);

    mutex_rdlock(&n_rwlock);
    int numero=Member((int)mi_rango);
    mutex_rdunlock(&n_rwlock);

    printf("Presente %d\n",numero);
    return 0;
}
int main(int argc,char* argv[])
{

    long thread;
    pthread_t* thread_handles;
    struct list_node_s* head;
    head=malloc(sizeof(struct list_node_s));
    head->data=0;
    head->next=0;
    head_pp=&head;
    thread_count=strtol(argv[1],0,10);
    thread_handles=malloc (thread_count*sizeof(pthread_t));
    struct timeval t_ini, t_fin;
    double secs;

    gettimeofday(&t_ini, 0);
    for(thread=0;thread<thread_count;thread++)
    pthread_create(&thread_handles[thread],0,LLamarFunc,(void *)thread);

    for(thread=0;thread<thread_count;thread++)
    pthread_join(thread_handles[thread],0);
    gettimeofday(&t_fin, 0);

    secs = timeval_diff(&t_fin, &t_ini);
    printf("%.16g millisegundos\n", secs * 1000.0);
    free(thread_handles);
    return 0;
}
