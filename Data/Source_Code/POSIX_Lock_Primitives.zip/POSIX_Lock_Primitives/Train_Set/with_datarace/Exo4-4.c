# 1 "Exo4-4.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "Exo4-4.c"
# 1 "pycparser/utils/fake_libc_include/stdio.h" 1
# 1 "pycparser/utils/fake_libc_include/_fake_defines.h" 1
# 41 "pycparser/utils/fake_libc_include/_fake_defines.h"
typedef int va_list;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 1 "pycparser/utils/fake_libc_include/_fake_typedefs.h" 1



typedef int size_t;
typedef int __builtin_va_list;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int64_t;
typedef int __uint64_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int __s8;
typedef int __u8;
typedef int __s16;
typedef int __u16;
typedef int __s32;
typedef int __u32;
typedef int __s64;
typedef int __u64;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int __sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int jmp_buf;
typedef int rlim_t;
typedef int sa_family_t;
typedef int sigjmp_buf;
typedef int stack_t;
typedef int siginfo_t;
typedef int z_stream;


typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;


typedef int int_least8_t;
typedef int uint_least8_t;
typedef int int_least16_t;
typedef int uint_least16_t;
typedef int int_least32_t;
typedef int uint_least32_t;
typedef int int_least64_t;
typedef int uint_least64_t;


typedef int int_fast8_t;
typedef int uint_fast8_t;
typedef int int_fast16_t;
typedef int uint_fast16_t;
typedef int int_fast32_t;
typedef int uint_fast32_t;
typedef int int_fast64_t;
typedef int uint_fast64_t;


typedef int intptr_t;
typedef int uintptr_t;


typedef int intmax_t;
typedef int uintmax_t;


typedef _Bool bool;

typedef int va_list;


typedef struct Display Display;
typedef unsigned long XID;
typedef unsigned long VisualID;
typedef XID Window;


typedef void* MirEGLNativeWindowType;
typedef void* MirEGLNativeDisplayType;
typedef struct MirConnection MirConnection;
typedef struct MirSurface MirSurface;
typedef struct MirSurfaceSpec MirSurfaceSpec;
typedef struct MirScreencast MirScreencast;
typedef struct MirPromptSession MirPromptSession;
typedef struct MirBufferStream MirBufferStream;
typedef struct MirPersistentId MirPersistentId;
typedef struct MirBlob MirBlob;
typedef struct MirDisplayConfig MirDisplayConfig;


typedef struct xcb_connection_t xcb_connection_t;
typedef uint32_t xcb_window_t;
typedef uint32_t xcb_visualid_t;
# 2 "pycparser/utils/fake_libc_include/stdio.h" 2
# 2 "Exo4-4.c" 2

# 1 "pycparser/utils/fake_libc_include/stdlib.h" 1
# 4 "Exo4-4.c" 2

# 1 "pycparser/utils/fake_libc_include/unistd.h" 1
# 6 "Exo4-4.c" 2

# 1 "pycparser/utils/fake_libc_include/time.h" 1
# 8 "Exo4-4.c" 2

# 1 "pycparser/utils/fake_libc_include/pthread.h" 1
# 10 "Exo4-4.c" 2







struct data {
 int IMAGE[100];
 int DernierThreadSurLaZone[100];
 pthread_mutex_t *verrou;
 pthread_cond_t *condition;
}data;

void* Fonction1(void*);
void* Fonction2(void*);
void* Focntion3(void*);
void* Fonction4(void*);

void * Fonction1(void *par){
 int ma_fonction_numero = 1;
 struct data *mon_D1 = (struct data*)par;
   for(int i=0; i<100;i++){
    pthread_mutex_lock(&(mon_D1->verrou[i]));
    mon_D1->IMAGE[i]=mon_D1->IMAGE[i]+5;
    mon_D1->DernierThreadSurLaZone[i]=2;
   printf("Le thread numero %i travail sur la partie %i\n",1,i);


   pthread_cond_broadcast(&(mon_D1->condition[i]));
   pthread_mutex_unlock(&(mon_D1->verrou[i]));


   }
   printf("Je suis %i-er le premier thread j'ai fini mon travail.\n",ma_fonction_numero);
   pthread_exit(0);
 }

 void * Fonction2( void * par){
  int ma_fonction_numero = 2;
  struct data *mon_D1 = (struct data*)par;
   for(int i=0;i<100;i++){
   pthread_mutex_lock(&(mon_D1->verrou[i]));
    while(mon_D1->DernierThreadSurLaZone[i]!=ma_fonction_numero){
    pthread_cond_wait(&(mon_D1->condition[i]),&(mon_D1->verrou[i]));
   }
    mon_D1->IMAGE[i]=mon_D1->IMAGE[i]+5;
   printf("Le thread numero %i travail sur la partie %i\n",2,i);
   mon_D1->DernierThreadSurLaZone[i]++;
   pthread_cond_broadcast(&(mon_D1->condition[i]));
   pthread_mutex_unlock(&(mon_D1->verrou[i]));


  }
  printf("Je suis le second thread j'ai fini mon travail.\n");
   pthread_exit(0);
 }

 void * Fonction3(void* par){
  int ma_fonction_numero = 3;
  struct data *mon_D1 = (struct data*)par;
   for(int i=0;i<100;i++){
   pthread_mutex_lock(&(mon_D1->verrou[i]));
    while(mon_D1->DernierThreadSurLaZone[i]!=ma_fonction_numero){
    pthread_cond_wait(&(mon_D1->condition[i]),&(mon_D1->verrou[i]));
   }
    mon_D1->IMAGE[i]=mon_D1->IMAGE[i]+5;
   printf("Le thread numero %i travail sur la partie %i\n",3,i);
   mon_D1->DernierThreadSurLaZone[i]++;
   pthread_cond_broadcast(&(mon_D1->condition[i]));
   pthread_mutex_unlock(&(mon_D1->verrou[i]));
  }
  printf("Je suis le troisième thread j'ai fini mon travail.\n");
   pthread_exit(0);
 }

 void * Fonction4(void* par){
  int ma_fonction_numero = 4;
  struct data *mon_D1 = (struct data*)par;
  for(int i=0;i<100;i++){
   pthread_mutex_lock(&(mon_D1->verrou[i]));
   while(mon_D1->DernierThreadSurLaZone[i]!=ma_fonction_numero){
    pthread_cond_wait(&(mon_D1->condition[i]),&(mon_D1->verrou[i]));
   }
   mon_D1->IMAGE[i]=mon_D1->IMAGE[i]+5;
   printf("Le thread numero %i travail sur la partie %i\n",4,i);
   mon_D1->DernierThreadSurLaZone[i]++;
   pthread_cond_broadcast(&(mon_D1->condition[i]));
   pthread_mutex_unlock(&(mon_D1->verrou[i]));
  }
  printf("Je suis %i le quatrième thread j'ai fini mon travail.\n",ma_fonction_numero);
  pthread_exit(0);
 }





 int main(){
 srand(time(0));
 pthread_t T1,T2,T3,T4;

 struct data D1;
 for(int i=0;i<100;i++){
  D1.DernierThreadSurLaZone[i]=0;
  D1.IMAGE[i]=0;
 }

 D1.verrou=malloc(sizeof(pthread_mutex_t)*100);
  D1.condition=malloc(sizeof(pthread_cond_t)*100);

 for(size_t i=0;i<100;i++){


   pthread_mutex_init(&(D1.verrou[i]),0);
     pthread_cond_init(&(D1.condition[i]),0);
 }



  pthread_create(&T2,0,Fonction2,&D1);
  pthread_create(&T3,0,Fonction3,&D1);
  pthread_create(&T4,0,Fonction4,&D1);
  pthread_create(&T1,0,Fonction1,&D1);


  pthread_join(T1,0);
  pthread_join(T2,0);
  pthread_join(T3,0);
  pthread_join(T4,0);
  printf("IMAGE(");
  for(int i=0;i<100 -1;i++){
   printf("%i,",D1.IMAGE[i]);
  }
  printf("%i)\n\n\n",D1.IMAGE[100 -1]);



return 0;
 }
