/**     Using Condition Varialbles */

#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX 10
typedef char* string;

typedef struct{
  pthread_mutex_t stack_lock;
  pthread_cond_t notFull;
  pthread_cond_t notEmpty;
  int current_index;
  void* data[MAX];
} stack_type;
typedef stack_type* stack_ptr;

stack_ptr createStack()
{
  stack_ptr _quad_stack;
  int i;
  _quad_stack = (stack_ptr) malloc(sizeof(stack_type));
  if (_quad_stack == NULL)
    return (NULL);
  pthread_mutex_init(&_quad_stack->stack_lock, NULL) ;
  pthread_cond_init(&_quad_stack->notFull, NULL);
  pthread_cond_init(&_quad_stack->notEmpty, NULL);
  _quad_stack->current_index = 0;
  for(i = 0; i < MAX; i++)
    (_quad_stack->data)[i] = NULL;
  return(_quad_stack);                         
}

void kilStack(stack_ptr dying_stack)
{
  pthread_mutex_destroy(&dying_stack->stack_lock);
  pthread_cond_destroy(&dying_stack->notFull);
  pthread_cond_destroy(&dying_stack->notEmpty);
  free(dying_stack);
  return;
}

/* This function should be called by the
   data inserting thread.*/
void push(stack_ptr stack, void* data)
{
  /* Lock the mutex the following is
     "CRITICAL SECTION" of the code. */
  pthread_mutex_lock(&stack->stack_lock);

  /* wait for the stack to have a space to
     put the data in */
  if (stack->current_index -1 == MAX)
    pthread_cond_wait(&stack->notFull, &stack->stack_lock);

  /* push the the new data */
  (stack->data)[stack->current_index] = data;
  printf("\n Push - Data : %s Index : %d",(char*)(stack->data)[stack->current_index],                                                stack->current_index);
  stack->current_index++;

  /* Have the data reading thread know that
     the stack is not empty */
  pthread_cond_signal(&stack->notEmpty);
  /* Unlock the mutex */
  pthread_mutex_unlock(&stack->stack_lock);
}

/* This function should be called by
   the data retrieving thread */                 
void* pop(stack_ptr stack)
{
  void* poping_data;

  /* Lock the mutex the following is
    "CRITICAL SECTION" of the code. */
  pthread_mutex_lock(&stack->stack_lock);

  /* wait for the stack to have a data pushed */
  if (stack->current_index -1 == -1)
    pthread_cond_wait(&stack->notEmpty, &stack->stack_lock);

  /* pop the data */
  stack->current_index--;
  printf("\n Pop - Data : %s Index : %d",(char*)(stack->data)[stack->current_index],
                                               stack->current_index);
  poping_data = (stack->data)[stack->current_index];
  (stack->data)[stack->current_index] = NULL;

  /* Have the data writing thread know that
   the stack has a room for a new data*/
  pthread_cond_signal(&stack->notFull);
  /* Unlock the mutex */
  pthread_mutex_unlock(&stack->stack_lock);

  return(poping_data);
}
void* pop_thread(void *);
void* push_thread(void *);               

int main()
{
   stack_ptr my_stack = createStack();
//   char data2[10];
   void **data3 ;
   pthread_t th1, th2;
   int error_code;
   pthread_attr_t attribute;
   char **finaldata;
   int i;
   pthread_attr_init(&attribute);
   pthread_attr_setdetachstate(&attribute,
                               PTHREAD_CREATE_DETACHED);
   printf("\n Invoking the push thread...");
   error_code = pthread_create(&th1, &attribute, push_thread, (void*)my_stack);
   if (error_code != 0)
   {
       printf("\n Error : Push Thread was not created..\n");
   }
   sleep(1);
   printf("\n Invoking the pop thread...");
   error_code = pthread_create(&th2, NULL, pop_thread, (void*)my_stack);
   if (error_code != 0)
   {
       printf("\n Error : Pop Thread was not created..\n");
   }
//   sleep(5);                         
/* printf("\n Invoking the push thread..."); */
   error_code = pthread_create(&th1, &attribute, push_thread, (void*)my_stack);
   if (error_code != 0)
   {
       printf("\n Error : Push Thread was not created..\n");
   }
   data3 = (void **)malloc(sizeof(void **));
   pthread_join(th2, data3);
   finaldata = (char **)*data3;
//   strcpy(data2, (char *)*data3);
   for(i=0; i<5; i++)
           printf("\n Main : Recieved Data : %d. %s", i+1, finaldata[i]);
   for(i=0; i<5; i++)
        free(finaldata[i]);
   free(data3);
   kilStack(my_stack);
   printf("\n\n The Program Ends... \n\n");
   exit(0);
}

void* push_thread(void *arg)
{
   int i;
   char *data1[5] = {"Satish\0","Singhal\0","Mr_single\0","satish\0","singhal\0"};
   printf("\n I am inside push_thread...");
   for(i=0; i<5; i++)
   {
        sleep(1);
        printf("\n Pushing Data : %s", data1[i]);
        push((stack_ptr)arg, data1[i]);
   }                                               
   printf("\n Exiting push_thread...\n");
   fflush(stdout);
   pthread_exit(NULL);
}

void* pop_thread(void *arg)
{
   int i;
//   char *data2;
    char *data2[5];
   printf("\n I am inside pop_thread...");
//   data2 = (char *)malloc(10);
//   data2 = (char **)malloc(sizeof(char **) *5);
   for(i=0; i<5; i++)
        data2[i] = (char *)malloc(10);
   for(i=0; i<5; i++)
   {
        sleep(1);
        strcpy(data2[i], (char *)pop((stack_ptr)arg));
        printf("\n Popped Data : %s", data2[i]);
   }
   printf("\n Exiting pop_thread...\n");
   fflush(stdout);
   pthread_exit((void*)data2);           
}
