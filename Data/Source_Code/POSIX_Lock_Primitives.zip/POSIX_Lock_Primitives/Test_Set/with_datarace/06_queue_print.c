#include<stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>
#define MAX_SIZE 10
static char *printer_queue[MAX_SIZE];
static int front = 0;
static int rear = 0;
sem_t sem_in,sem_out;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
void enqueue(char *str)
{
	
	if((front+1)%MAX_SIZE==rear)
	{
		printf("the queue is full\n");
	
	}
	else
	{	
		printer_queue[rear]=(char *)malloc(sizeof(char)*100);
		strcpy(printer_queue[rear],str);
		rear=(rear+1)%MAX_SIZE;
	
	}

}
char *outqueue(void )
{
	char *str;
	str=(char *)malloc(100);
	if(front==rear)
	{
		printf("the queue is empty\n");
	}
	else
	{
		strcpy(str,printer_queue[front]);
		front = (front+1)%MAX_SIZE;
	
	}
	return str;
}
void *deal_pthread_one(void *arg)
{
	while(1)
	{
		sleep(1);
		char str1[50]="deal_pthread_one";
		
		sem_wait(&sem_in);
		pthread_mutex_lock(&mutex);
		enqueue(str1);
		pthread_mutex_unlock(&mutex);
		
		sem_post(&sem_out);
	
	}
	return NULL;
}
void *deal_pthread_two(void *arg)
{
	while(1)
	{
		sleep(4);
		char str2[50]="deal_pthread_two";
		sem_wait(&sem_in);
		pthread_mutex_lock(&mutex);
		enqueue(str2);
		pthread_mutex_unlock(&mutex);
		sem_post(&sem_out);
	
	}

	return NULL;
}
void *deal_pthread_three(void *arg)
{
	while(1)
	{
		sleep(2);
		char str3[50]="deal_pthread_three";
		sem_wait(&sem_in);
		pthread_mutex_lock(&mutex);
		enqueue(str3);
		pthread_mutex_unlock(&mutex);
		sem_post(&sem_out);
	
	}

	return NULL;
}
void *deal_pthread_print(void *arg)
{	char str[100];
	while(1)
	{
		memset(str,0,sizeof(str));
		sem_wait(&sem_out);
			pthread_mutex_lock(&mutex);
		strcpy(str,outqueue());
		pthread_mutex_unlock(&mutex);
		printf("the str is %s\n",str);
		sem_post(&sem_in);
	
	}


}
void create_pthread()
{
	pthread_t pthread_one,pthread_two,pthread_three;
	pthread_t pthread_print;
	
	pthread_create(&pthread_one,NULL,deal_pthread_one,NULL);
	pthread_create(&pthread_two,NULL,deal_pthread_two,NULL);
	pthread_create(&pthread_three,NULL,deal_pthread_three,NULL);
	pthread_create(&pthread_print,NULL,deal_pthread_print,NULL);
	
	
	pthread_join(pthread_print,NULL);
	pthread_detach(pthread_one);
	pthread_detach(pthread_two);
	pthread_detach(pthread_three);

}
int main()
{
	sem_init(&sem_in,0,10);	//�ź���1��ʼֵΪ10����ʾ�˴�ӡ����ʼ�����Ի���10����ӡ��Ϣ
	sem_init(&sem_out,0,0);	//�ź���2��ʼֵΪ0����ʾ�˶����ﻹ�ж���������ӡ��Ϣ
	pthread_mutex_init(&mutex, NULL);
	create_pthread();
	
	return 0;
}
