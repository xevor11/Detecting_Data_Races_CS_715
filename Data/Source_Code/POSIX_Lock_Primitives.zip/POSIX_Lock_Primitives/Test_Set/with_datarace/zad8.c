#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#define GUYS 4
#define ITEMS 100
#define unused(x) (void)(x)
// List monitor. It's not so the list can be accessed by one thread
// but rather it's controlling so the conditions are fulfilled if you
// try to invoke certain methods.
pthread_cond_t searchable = PTHREAD_COND_INITIALIZER;
pthread_cond_t modifiable = PTHREAD_COND_INITIALIZER;
pthread_cond_t deletable = PTHREAD_COND_INITIALIZER; 
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int num_reading = 0;
int num_modifying = 0;
int num_deleting = 0;
// You can always search given the mutex is unlocked
// Deleting just locks the mutex
void start_search() 
{
    
        while(num_deleting > 0)
            pthread_cond_wait(&searchable,&mutex);
        printf("Start search. [%d] [+1]\n",num_reading);
        num_reading++;
    
}

void end_search()
{
    
        printf("End search. [%d] [-1]\n",num_reading);
        num_reading--;
        if(num_reading == 0 && num_modifying == 0)
            pthread_cond_signal(&deletable); 
    
}

// Only one can add. Wait until the other stops modyfing and the mutex must be unlocked.
void start_add()
{
    
        while(num_modifying > 0 || num_deleting > 0) 
            pthread_cond_wait(&modifiable,&mutex);
        printf("Start add.\n");
        num_modifying++;
    
}

void end_add()
{
    
        printf("End add.\n");
        num_modifying--;
        if(num_reading == 0) pthread_cond_signal(&deletable);
            pthread_cond_signal(&modifiable); 
    
}

// If you can lock the mutex. Delete and unlock it.
void start_delete()
{
    
        while(num_reading > 0 || num_modifying > 0 || num_deleting > 0) 
            pthread_cond_wait(&deletable,&mutex);
        printf("Start delete.\n");
        num_deleting++;
    
}

void end_delete()
{
    
        num_deleting--;
        printf("End delete.\n");
        pthread_cond_signal(&searchable);
        pthread_cond_signal(&modifiable);
        pthread_cond_signal(&deletable);
    
}

// Monitor end



typedef struct Elem
{
    struct Elem * next;
    int value;
}Elem;

void delete(Elem ** head,int val)// deletes first element with value == val
{
    start_delete();
    usleep(rand()%90+10);
    if(*head == NULL)
    {
        end_delete(); 
        return;
    }
    if((*head)->value == val)
    {
        Elem * tmp = *head;
        *head = (*head)->next;
        free(tmp);   
        end_delete();    
        return;
    }
    Elem * current = (*head)->next;
    Elem * last = *head;
    while(current != NULL)
    {
        if(current->value == val)
        {
            last->next = current->next;
            free(current);
            end_delete();
            return;
        }
        last = current;
        current = current->next;
    }
    end_delete();
}

int search(Elem * head)// returns last element
{
    start_search();
    usleep(rand()%90+10);
    Elem * current = head;
    if(current == NULL)
    {
        end_search();
        return -1;
    }
    while(current->next!=NULL)
    {
        current = current->next;
    }
    end_search();
    return current->value;
}

void add(Elem ** head,int val)
{
    start_add();
    usleep(rand()%90+10);
    Elem * new = malloc(sizeof(Elem));
    new->value = val;
    new->next = NULL;
    if(*head == NULL)
    {
        *head = new;
        end_add();
        return;
    }
    Elem * current = *head;
    while(current->next!=NULL)
    {   
        current = current->next;
    }
    current->next = new;
    end_add();
}

Elem * list;

void * reader(void * data)
{
    unused(data);
    for(int i = 0;i<ITEMS;i++)
        search(list);
    return NULL;
}

void * writer(void * data)
{
    unused(data);
    for(int i =0;i<ITEMS;i++)
    {
        add(&list,1);
        add(&list,2);
    }
    return NULL;
}

void * killer(void * data)
{
    unused(data);
    usleep(rand()%9+1);
    for(int i = 0;i<ITEMS;i++)
    {
        delete(&list,2);
        delete(&list,1);
    }
    return NULL;
}

int main()
{
    srand(time(0));    

    Elem * list_test = NULL;
    add(&list_test,1);
    printf("%d\n",search(list_test));
    add(&list_test,2);
    printf("%d\n",search(list_test));
    add(&list_test,3);
    printf("%d\n",search(list_test));
    delete(&list_test,1);
    delete(&list_test,3);
    printf("%d\n",search(list_test));
    delete(&list,2);
    printf("%d\nReal test:\n",search(list_test));

    pthread_t readers[GUYS];
    pthread_t writers[GUYS];
    pthread_t killers[GUYS];
   
    for(int i = 0;i<GUYS;i++)
    {
        pthread_create(&readers[i],NULL,reader,NULL);
        pthread_create(&writers[i],NULL,writer,NULL);
        pthread_create(&killers[i],NULL,killer,NULL);
    }

    for(int i = 0;i<GUYS;i++)
    {
        pthread_join(readers[i],NULL);
        pthread_join(writers[i],NULL);
        pthread_join(killers[i],NULL);
    }

    printf("Should be -1: %d\n",search(list));
    pthread_cond_destroy(&deletable);
    pthread_cond_destroy(&searchable);
    pthread_cond_destroy(&modifiable);
    pthread_mutex_destroy(&mutex);
    return 0;
}
