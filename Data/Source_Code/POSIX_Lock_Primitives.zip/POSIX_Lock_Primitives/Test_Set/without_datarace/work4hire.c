#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Roughly based on code from http://rosettacode.org/

typedef struct CompanyData {
    pthread_mutex_t *prog_left, *prog_right;
    const char *name;
    pthread_t thread;
    int   fail;
    int hire_count;
} CompanyData;
 
int running = 1;
 
void *work4hire(void *p); 

int main()
{
    srand(0); // Make rand()/scheduling somewhat repeatable
    const char *nameList[] = { "Goggles", "Foosebuck", "Mackrowsoft", "StartupUlike", "Orangesoft" };
    pthread_mutex_t programmers[5];
    CompanyData companies[5];
    CompanyData *company;
    int i;
    int failed;
    for (i=0;i<5; i++) {
        failed = pthread_mutex_init(&programmers[i], NULL);
        if (failed) {
            printf("Failed to initialize mutexes.");
            exit(1);
        }
    }
 
    for (i=0;i<5; i++) {
        company = &companies[i];
        company->name = nameList[i];
        company->prog_left = &programmers[i];
        company->prog_right = &programmers[(i+1)%5];
        company->hire_count = 0;
        company->fail = pthread_create( &company->thread, NULL, work4hire, company);
    }
 
    sleep(20);
    running = 0;
    printf("cleanup time\n");
 
    int total = 0; // Number of billable days
    for(i=0; i<5; i++) {
        company = &companies[i];
        if ( !company->fail && pthread_join( company->thread, NULL) ) {
          
            printf("error joining thread for %s", company->name);
            exit(1);
        } else {
          printf("Company %s used our services for %d billable days.\n", company->name, company->hire_count);
          total +=company->hire_count;
        }
    }
    printf("\nTotal Billable days : %d\n", total);
    return 0;
}
void *work4hire(void *p) {
    CompanyData *company = (CompanyData*)p;
    pthread_mutex_t *prog_left, *prog_right, *temp;
 
    while (running) {
 
        prog_left = company->prog_left;
        prog_right = company->prog_right;
        printf("%s needs their pair programmers\n", company->name);
        pthread_mutex_lock( prog_left );
        usleep(10);
        pthread_mutex_lock( prog_right );
        printf("%s is working\n", company->name);
        usleep( 1+ rand() % 3);
        company->hire_count ++;
        pthread_mutex_unlock( prog_right );
        pthread_mutex_unlock( prog_left );
        printf("%s has finished working with us\n", company->name);
    }
    return NULL;
}



