#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t m;//PTHREAD_MUTEX_INITIALIZER;

void * func(void *p)
{
  int * source = (int *)p;

  int i;
  for(i = 0; i < 10;i++){

    pthread_mutex_lock(&m);//等待main里面的解锁操作执行完之后才会往下执行，并且让main里的第一次循环等待本函数的unlock
    int t = *(source+i);
    printf("t = %d\n",t);
    pthread_mutex_unlock(&m);//解锁，让main里面的第一个循环继续执行
    int j;//插入法排序
    for(j = i;j>0 && t<source[j-1];j--){

      source[j]=source[j-1];
      
    }
    source[j] = t;//把t赋给j前面的数据
    usleep(1);
  }

  return NULL;
}

int main()
{
  int a[10];
  pthread_t id;
  pthread_mutex_init(&m,NULL);
  pthread_mutex_lock(&m);//在子线程创建之前先将m加锁，让其等待本线程解锁。
  int success =  pthread_create(&id,NULL,func,a);
  if(success != 0){perror("pthread_create"); return -1;}
  int i;
  for(i = 0; i< 10;i++){

    printf("请输入第%d个数据",i+1);
    scanf("%d",&a[i]);
    pthread_mutex_unlock(&m);//输入字符完毕，解锁，让子线程往下执行
    usleep(1);//等待子线程执行1微秒，然后将m加锁，让子线程等待下一次执行
    pthread_mutex_lock(&m);
  }
   
  pthread_mutex_unlock(&m);

  while(i>0){
    
    printf("%d ",a[10-i]);  
    i--;
  }
  printf("\n");
  return 0;
}
