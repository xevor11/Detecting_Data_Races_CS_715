extern int omp_get_num_threads(void);
int x;
int y;
int t;
int z[1000];
#pragma omp threadprivate(x);
void a24(int a)
{
  int i;
  int count = 0;
  float s = 0.0;
  #pragma omp parallel for schedule (static) private(i) reduction(+:s, count)
  for (i = 0; i < rows; i++)
  {
    s += fabs(x[i]);
    count++;
  }

  #pragma omp single
  {
    *value = s;
  }
  return;

  const int c = 1;
  int i = 0;
  int l = 0;
  #pragma omp parallel default(none) shared(z)
  {
    int j = omp_get_num_threads();
    x = c;
    z[i] = y;
    #pragma omp for firstprivate(y)
    for (i = 0; i < 10; i++)
    {
      z[i] = y;
    }

    z[l] = t;
  }
}

