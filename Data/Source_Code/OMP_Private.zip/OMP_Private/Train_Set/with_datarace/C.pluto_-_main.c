int main(int argc, const char *argv[])
{
  int x;
  int y;
};
int main(int argc, char *argv[])
{
  struct point p[10000];
  int n;
  int m;
  int initTour[10000];
  int tour[10000];
  int prec[10000];
  int i;
  int j;
  int times = 10;
  int count = 0;
  double initialT = 1000.0;
  double finalT = 0.1;
  double coolingRate = 0.99;
  double min = 0;
  if (argc != 2)
  {
    fprintf(stderr, "Usage: %s <tsp_filename>\n", argv[0]);
    exit(1);
  }

  read_tsp_data(argv[1], p, &n, prec, &m);
  nn(p, n, initTour, m, prec);
  printf("This program use %d Threads\n", omp_get_max_threads());
  printf("init tour length : %.3lf\n\n", tour_length(p, n, initTour));
  #pragma omp parallel for private(tour, j)
  for (i = 0; i < (times * omp_get_max_threads()); i++)
  {
    for (j = 0; j < n; j++)
      tour[j] = initTour[j];

    SimulatedAnnealing(p, n, tour, m, prec, initialT, finalT, coolingRate);
    count++;
    if (count < 10)
      putchar('0');

    printf("%d : %.3lf ", count, tour_length(p, n, tour));
    if ((!min) || (tour_length(p, n, tour) < min))
    {
      write_tour_data("res_nng.dat", n, tour);
      min = tour_length(p, n, tour);
      putchar('*');
    }

    putchar('\n');
  }

  exit(0);

  int t1;
  int t2;
  int lb;
  int ub;
  int lbp;
  int ubp;
  int lb2;
  int ub2;
  register int lbv;
  register int ubv;
  a[0 + 4][0 + 1] = b[0][0];
  ;
  for (t1 = 1; t1 <= 10; t1++)
  {
    lbp = ceil(((double) t1) / ((double) 2));
    ubp = floor(((double) (2 * t1)) / ((double) 3));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      a[((-t1) + (2 * t2)) + 4][((-t1) + (2 * t2)) + 1] = b[t1 - t2][(-t1) + (2 * t2)];
      ;
    }

    lbp = ceil(((double) ((2 * t1) + 1)) / ((double) 3));
    ubp = t1;
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      a[((-t1) + (2 * t2)) + 4][((-t1) + (2 * t2)) + 1] = b[t1 - t2][(-t1) + (2 * t2)];
      ;
      b[t1 - t2][(((-2) * t1) + (3 * t2)) - 1] = a[((t1 - t2) + (2 * ((((-2) * t1) + (3 * t2)) - 1))) + 1][((t1 - t2) + ((((-2) * t1) + (3 * t2)) - 1)) + 3];
      ;
    }

  }

  for (t1 = 11; t1 <= 28; t1++)
  {
    lbp = (ceil(((double) t1) / ((double) 2)) > (t1 - 10)) ? (ceil(((double) t1) / ((double) 2))) : (t1 - 10);
    ubp = floor(((double) (2 * t1)) / ((double) 3));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      a[((-t1) + (2 * t2)) + 4][((-t1) + (2 * t2)) + 1] = b[t1 - t2][(-t1) + (2 * t2)];
      ;
    }

    lbp = ceil(((double) ((2 * t1) + 1)) / ((double) 3));
    ubp = floor(((double) (t1 + 10)) / ((double) 2));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      a[((-t1) + (2 * t2)) + 4][((-t1) + (2 * t2)) + 1] = b[t1 - t2][(-t1) + (2 * t2)];
      ;
      b[t1 - t2][(((-2) * t1) + (3 * t2)) - 1] = a[((t1 - t2) + (2 * ((((-2) * t1) + (3 * t2)) - 1))) + 1][((t1 - t2) + ((((-2) * t1) + (3 * t2)) - 1)) + 3];
      ;
    }

    lbp = ceil(((double) (t1 + 11)) / ((double) 2));
    ubp = floor(((double) ((2 * t1) + 11)) / ((double) 3));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      b[t1 - t2][(((-2) * t1) + (3 * t2)) - 1] = a[((t1 - t2) + (2 * ((((-2) * t1) + (3 * t2)) - 1))) + 1][((t1 - t2) + ((((-2) * t1) + (3 * t2)) - 1)) + 3];
      ;
    }

  }

  for (t1 = 29; t1 <= 30; t1++)
  {
    a[(t1 - 20) + 4][(t1 - 20) + 1] = b[10][t1 - 20];
    ;
    lbp = ceil(((double) (t1 + 11)) / ((double) 2));
    ubp = floor(((double) ((2 * t1) + 11)) / ((double) 3));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      b[t1 - t2][(((-2) * t1) + (3 * t2)) - 1] = a[((t1 - t2) + (2 * ((((-2) * t1) + (3 * t2)) - 1))) + 1][((t1 - t2) + ((((-2) * t1) + (3 * t2)) - 1)) + 3];
      ;
    }

  }

  for (t1 = 31; t1 <= 41; t1++)
  {
    lbp = t1 - 10;
    ubp = floor(((double) ((2 * t1) + 11)) / ((double) 3));
    #pragma omp parallel for
    for (t2 = lbp; t2 <= ubp; t2++)
    {
      b[t1 - t2][(((-2) * t1) + (3 * t2)) - 1] = a[((t1 - t2) + (2 * ((((-2) * t1) + (3 * t2)) - 1))) + 1][((t1 - t2) + ((((-2) * t1) + (3 * t2)) - 1)) + 3];
      ;
    }

  }

  return 0;
}

