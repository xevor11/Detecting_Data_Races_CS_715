float **Matrix_Mul(float **X, float **Y, int m, int n, int q)
{
  double **M;
  double **L;
  int i;
  int j;
  int k;
  M = (double **) calloc(size, sizeof(double *));
  L = (double **) calloc(size, sizeof(double *));
  for (i = 0; i < size; i++)
  {
    M[i] = (double *) calloc(size, sizeof(double));
    L[i] = (double *) calloc(size, sizeof(double));
  }

  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      if (i == j)
        M[i][j] = 1.0;
      else
        M[i][j] = (1.0 + (i * size)) + j;

      L[i][j] = 0.0;
    }

  }

  for (k = 0; k < (size - 1); k++)
  {
    #pragma omp parallel for default(none) shared(M,L,size,k) private(i,j) schedule(static,1)
    for (i = k + 1; i < size; i++)
    {
      L[i][k] = M[i][k] / M[k][k];
      for (j = k + 1; j < size; j++)
        M[i][j] = M[i][j] - (L[i][k] * M[k][j]);

    }

  }

  printf("done!\n");

  float **Q;
  Q = Matrix_Alloc(m, m);
  int i;
  int j;
  int k;
  #pragma omp parallel shared(Q,X,Y)
  {
    #pragma omp for schedule (static)
    for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)
      {
        for (k = 0; k < q; k++)
          Q[i][j] = Q[i][j] + (X[i][k] * Y[k][j]);

      }

    }

  }
  return Q;
}

