const int MAX_ROW = 200;
const int MAX_COL = 200;
const int counter_hit = 100;
void evolution(int (*pop)[MAX_COL], int generation);
void evolution_paralell(int (*pop)[MAX_COL]);
void evolution_paralell_chaos(int (*pop)[MAX_COL]);
void print(int (*pop)[MAX_COL], int generation);
int generation_pass(int (*pop)[MAX_COL], int i, int j);
int check_neighbour(int pop);
void evolution_paralell_chaos(int (*pop)[MAX_COL])
{
  int gijosNr = omp_get_thread_num();
  int i = 0;
  omp_set_num_threads(MAX_ROW * MAX_COL);
  #pragma omp parallel
  {
    gijosNr = omp_get_thread_num();
    int row = gijosNr / MAX_ROW;
    int col = gijosNr - (MAX_ROW * row);
    for (i = 0; i < 100; i++)
    {
      pop[row][col] = generation_pass(pop, row, col);
    }

  }

  clock_t start;
  clock_t end;
  int *sequence;
  int *partial;
  int *aux;
  int numThreads;
  int work;
  int n;
  int i;
  int k;
  int mynum;
  int last;
  double cpu_time_used;
  start = clock();
  for (k = 8; k <= 14; k++)
  {
    n = pow(2, k);
    if (!(sequence = (int *) malloc((sizeof(int)) * n)))
      return -1;

    for (i = 0; i < n; i++)
      sequence[i] = i;

    #pragma omp parallel default(none) private(i, mynum, last) shared(sequence, partial, aux, numThreads, work, n)
    {
      #pragma omp single
      {
        numThreads = omp_get_num_threads();
        if (!(partial = (int *) malloc((sizeof(int)) * numThreads)))
          exit(-1);

        if (!(aux = (int *) malloc((sizeof(int)) * numThreads)))
          exit(-1);

        work = (n / numThreads) + 1;
      }
      mynum = omp_get_thread_num();
      for (i = (work * mynum) + 1; (i < ((work * mynum) + work)) && (i < n); i++)
        sequence[i] += sequence[i - 1];

      partial[mynum] = sequence[i - 1];
      #pragma omp barrier
      for (i = 1; i < numThreads; i <<= 1)
      {
        if (mynum >= i)
          aux[mynum] = partial[mynum] + partial[mynum - i];

        #pragma omp barrier
        #pragma omp single
        memcpy(partial + 1, aux + 1, (sizeof(int)) * (numThreads - 1));
      }

      for (i = work * mynum; i < (last = (((work * mynum) + work) < n) ? ((work * mynum) + work) : (n)); i++)
        sequence[i] += partial[mynum] - sequence[last - 1];

    }
    for (i = 0; i < n; i++)
      printf("%d ", sequence[i]);

    printf("\n");
  }

  end = clock();
  cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  printf("%f\n", cpu_time_used);
  return 0;
}

