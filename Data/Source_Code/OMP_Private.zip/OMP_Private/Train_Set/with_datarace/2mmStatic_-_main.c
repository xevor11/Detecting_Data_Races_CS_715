double alpha1;
double beta1;
double alpha2;
double beta2;
double C[4000][4000];
double A[4000][4000];
double B[4000][4000];
double D[4000][4000];
double E[4000][4000];
int main(int argc, char **argv)
{
  int i;
  int j;
  int k;
  int ni = 4000;
  int nj = 4000;
  int nk = 4000;
  int nl = 4000;
  init_array();
  #pragma omp parallel for schedule(static) check
  for (i = 0; i < ni; i++)
    for (j = 0; j < nj; j++)
  {
    C[i][j] = 0;
    for (k = 0; k < nk; ++k)
      C[i][j] += A[i][k] * B[k][j];

  }


  #pragma omp parallel for schedule(static) check
  for (i = 0; i < ni; i++)
    for (j = 0; j < nl; j++)
  {
    E[i][j] = 0;
    for (k = 0; k < nj; ++k)
      E[i][j] += C[i][k] * D[k][j];

  }


  double total = 0;
  for (int y = 0; y < ni; ++y)
  {
    for (int x = 0; x < ni; ++x)
    {
      total += E[y][x];
    }

  }

  printf("Total: %f\n", total);
  return 0;
}

