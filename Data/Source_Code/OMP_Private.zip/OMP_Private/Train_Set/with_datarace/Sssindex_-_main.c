void copiavalor(double *a, double *b, int DIM);
double distancia(double *p1, double *p2, int DIM);
double leedato(double *dato, FILE *file, int DIM);
double distancia_max(double *DB, int DIM, int cant_Vectores);
void matrixToVector(double **matrix, int num_cols, int num_rows, double *vector);
double realloc_(int *pivo_Id, int tam);
int main(int argc, const char *argv[])
{
  if (argc != 4)
  {
    printf("Error :: Ejecutar como : a.out archivo_BD Num_elem DIM\n");
    return 0;
  }

  int DIM;
  int cant_Vectores;
  int *pivo_Id;
  int centro;
  cant_Vectores = atoi(argv[2]);
  DIM = atoi(argv[3]) + 2;
  char str_f[256];
  FILE *archivo_BD;
  double *Distancias;
  double **DB;
  double dato[DIM - 2];
  double *DB_vector;
  double dist_temp[120];
  srand(time(0));
  int num_threads;
  int thread_num;
  int i = 0;
  int j = 0;
  int k = 0;
  for (i = 0; i < 120; ++i)
    dist_temp[i] = 0;

  int ind_pivote = DIM - 1;
  int ind_estado = DIM - 2;
  int cant_pivotes = 1;
  sprintf(str_f, "%s", argv[1]);
  printf("\nAbriendo %s... ", argv[1]);
  fflush(stdout);
  archivo_BD = fopen(str_f, "r");
  printf("OK\n");
  fflush(stdout);
  DB = (double **) malloc((sizeof(double *)) * cant_Vectores);
  for (i = 0; i < cant_Vectores; i++)
    DB[i] = (double *) malloc((sizeof(double)) * DIM);

  for (i = 0; i < cant_Vectores; ++i)
  {
    for (j = DIM - 2; j < DIM; ++j)
    {
      DB[i][j] == (-1);
    }

  }

  printf("\nCargando DB... ");
  fflush(stdout);
  for (i = 0; i < cant_Vectores; i++)
  {
    if ((leedato(dato, archivo_BD, DIM) == (-1)) || feof(archivo_BD))
    {
      printf("\n\nERROR :: N_DB mal establecido\n\n");
      fflush(stdout);
      fclose(archivo_BD);
      break;
    }

    copiavalor(DB[i], dato, DIM);
  }

  fclose(archivo_BD);
  printf("OK\n");
  fflush(stdout);
  centro = rand() % cant_Vectores;
  centro = 3;
  DB[centro][ind_pivote] = 1;
  DB[centro][ind_estado] = 1;
  pivo_Id[0] = centro;
  DB_vector = (double *) _mm_malloc(((sizeof(double)) * DIM) * cant_Vectores, 64);
  pivo_Id = (int *) _mm_malloc((sizeof(int)) * cant_pivotes, 64);
  matrixToVector(DB, DIM, cant_Vectores, DB_vector);
  #pragma offload target(mic:0) in(centro) in(ind_pivote) in(dist_temp) in(pivo_Id:length(cant_pivotes)) in(cant_Vectores) in(DIM) in(ind_estado) in(DB_vector:length(DIM*cant_Vectores))
  {
    #pragma omp parallel shared(DB_vector, DIM, num_threads)
    {
      #pragma omp master
      {
        num_threads = omp_get_num_threads();
        printf("run with %d threads\n", num_threads);
        printf("cant_Vectores: %d\n", cant_Vectores);
        fflush(0);
      }
      #pragma omp barrier
      thread_num = omp_get_thread_num();
      for (i = thread_num * DIM; i < (cant_Vectores * DIM); i += num_threads * DIM)
      {
        for (j = i + DIM; j < (cant_Vectores * DIM); j += DIM)
        {
          double temp = distancia(&DB_vector[i], &DB_vector[j], DIM);
          if (temp > dist_temp[thread_num])
            dist_temp[thread_num] = temp;

          printf("Distancias: %lf\n", dist_temp[thread_num]);
          fflush(0);
        }

      }

      #pragma omp barrier
      #pragma omp master
      {
        double distancia_M = 0;
        int i = 0;
        for (i = 0; i < 120; ++i)
        {
          if (dist_temp[i] > distancia_M)
            distancia_M = dist_temp[i];

        }

        distancia_M *= 0.4;
        printf("Distancia M: %lf\n", distancia_M);
        fflush(0);
      }
    }
  }
  return 0;
}

