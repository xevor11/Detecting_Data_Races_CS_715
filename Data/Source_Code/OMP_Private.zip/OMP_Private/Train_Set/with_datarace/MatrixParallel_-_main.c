void main()
{
  int i;
  int j;
  int k;
  int tid;
  double sum = 0;
  GetArray();
  inputMatrix_T = getMemory(ArraySize);
  outputMatrix = getMemory(ArraySize);
  #pragma omp parallel for num_threads(NUM_THREADS) shared(inputMatrix,inputMatrix_T)
  for (i = 0; i < ArraySize; i++)
  {
    for (j = 0; j < ArraySize; j++)
    {
      inputMatrix_T[i][j] = inputMatrix[j][i];
    }

  }

  start();
  #pragma omp parallel for num_threads(NUM_THREADS) shared(inputMatrix,inputMatrix_T,outputMatrix,ArraySize) reduction(+:sum)
  for (i = 0; i < ArraySize; i++)
  {
    for (j = 0; j < ArraySize; j++)
    {
      sum = 0;
      for (k = 0; k < ArraySize; k++)
      {
        sum += inputMatrix[i][k] * inputMatrix_T[j][k];
      }

      outputMatrix[i][j] = sum;
    }

  }

  stop();
  write_output("parallel_output.csv");
  free(outputMatrix);
  free(inputMatrix);
  free(inputMatrix_T);
}

