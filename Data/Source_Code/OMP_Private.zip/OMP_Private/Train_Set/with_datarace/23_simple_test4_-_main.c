int main()
{
  int i;
  int tid;
  omp_set_num_threads(4);
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    #pragma omp sections
    {
      #pragma omp section
      {
        for (i = 0; i < 4; i++)
          printf("L1 tid=%d\n", tid);

      }
      #pragma omp section
      {
        for (i = 0; i < 4; i++)
          printf("L2 tid=%d\n", tid);

        sleep(2);
      }
    }
    printf("end tid=%d\n", tid);
  }
}

