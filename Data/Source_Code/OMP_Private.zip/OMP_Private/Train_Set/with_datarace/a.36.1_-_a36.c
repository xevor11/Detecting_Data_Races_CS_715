void a36(float *x, int npoints)
{
  Byte r;
  Byte g;
  Byte b;
} Pixel;
{
  unsigned int ancho;
  unsigned int alto;
  Pixel *datos;
} Imagen;
void encaja(Imagen *ima)
{
  unsigned n;
  unsigned i;
  unsigned j;
  unsigned x;
  unsigned linea_minima = 0;
  long unsigned distancia;
  long unsigned distancia_minima;
  const long unsigned grande = 1 + (ima->ancho * 768ul);
  n = ima->alto - 2;
  for (i = 0; i < n; i++)
  {
    distancia_minima = grande;
    for (j = i + 1; j < ima->alto; j++)
    {
      distancia = 0;
      #pragma omp parallel for private(distancia)
      for (x = 0; x < ima->ancho; x++)
      {
        distancia += diferencia(&ima->datos[x + (i * ima->ancho)], &ima->datos[x + (j * ima->ancho)]);
      }

      if (distancia < distancia_minima)
      {
        distancia_minima = distancia;
        linea_minima = j;
      }

    }

    intercambia_lineas(ima, i + 1, linea_minima);
  }


  int iam;
  int ipoints;
  omp_set_dynamic(0);
  omp_set_num_threads(16);
  #pragma omp parallel shared(x, npoints)
  {
    if (omp_get_num_threads() != 16)
      abort();

    iam = omp_get_thread_num();
    ipoints = npoints / 16;
    do_by_16(x, iam, ipoints);
  }
}

