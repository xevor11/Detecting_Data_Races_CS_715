int ALG_MATMUL2D(int M, int N, int P, float **A, float **B, float **C)
{
  int I = 0;
  int J;
  int K;
  float temp;
  #pragma omp parallel shared(A,B,C, M, N, P)
  {
    J = 0;
    K = 0;
    temp = 0.0;
    #pragma omp parallel for schedule(static)
    for (I = 0; I < M; I++)
    {
      for (J = 0; J < N; J++)
      {
        temp = 0.0;
        for (K = 0; K < P; K++)
        {
          temp += A[I][K] * B[K][J];
        }

        C[I][J] = temp;
      }

    }

  }
  return 0;
}

