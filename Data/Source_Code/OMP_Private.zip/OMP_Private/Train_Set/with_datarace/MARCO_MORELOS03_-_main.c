int initialize(double *matrix);
int _initialize(double *matrix);
int main()
{
  int i;
  int j;
  int k;
  double *A;
  double *B;
  double *Cs;
  double *Cp;
  struct timeval start;
  struct timeval end;
  double timeCost;
  A = (double *) malloc(((sizeof(double)) * 1000) * 1000);
  B = (double *) malloc(((sizeof(double)) * 1000) * 1000);
  Cs = (double *) malloc(((sizeof(double)) * 1000) * 1000);
  Cp = (double *) malloc(((sizeof(double)) * 1000) * 1000);
  initialize(A);
  initialize(B);
  _initialize(Cs);
  _initialize(Cp);
  gettimeofday(&start, 0);
  for (i = 0; i < 1000; i++)
    for (j = 0; j < 1000; j++)
    for (k = 0; k < 1000; k++)
    Cs[(i * 1000) + j] += A[(i * 1000) + k] * B[(k * 1000) + j];



  gettimeofday(&end, 0);
  timeCost = (1000000 * (end.tv_sec - start.tv_sec)) + (end.tv_usec - start.tv_usec);
  timeCost /= 1000000;
  printf("The squential version of matrix multiplication costs %lf seconds\n", timeCost);
  int numthreads;
  for (numthreads = 1; numthreads <= 8; numthreads++)
  {
    omp_set_num_threads(numthreads);
    gettimeofday(&start, 0);
    double sum = 0.0;
    #pragma omp parallel for reduction(+:sum)
    for (i = 0; i < 1000; i++)
    {
      for (j = 0; j < 1000; j++)
      {
        sum = 0.0;
        for (k = 0; k < 1000; k++)
        {
          int a = (i * 1000) + k;
          int b = (k * 1000) + j;
          sum += A[a] * B[b];
        }

        Cp[(i * 1000) + j] = sum;
      }

    }

    gettimeofday(&end, 0);
    timeCost = (1000000 * (end.tv_sec - start.tv_sec)) + (end.tv_usec - start.tv_usec);
    timeCost /= 1000000;
    printf("The parallel version (%i threads) of matrix multiplication costs %lf seconds\n", numthreads, timeCost);
  }

  for (i = 0; i < 1000; i++)
    for (j = 0; j < 1000; j++)
  {
    if ((Cs[(i * 1000) + j] - Cp[(i * 1000) + j]) < 0.000001)
      continue;
    else
    {
      printf("ERRORS DETECTED!!!!!!!!!!!!!\n");
      printf("%f\n", Cs[(i * 1000) + j] - Cp[(i * 1000) + j]);
      return -1;
    }

  }


  free(A);
  free(B);
  free(Cs);
  free(Cp);
  return 0;
}

