void main()
{
  int n;
  long i;
  double x;
  double a;
  double z;
  double pi16ds = 3.1415926535897932;
  double sum = 0.0;
  printf("Introduce la precision del calculo (número de intervalos > 0): ");
  scanf("%d", &n);
  a = omp_get_wtime();
  double h = 1.0 / ((double) n);
  #pragma omp for num_threads(NH) reduction(+:sum) schedule(dynamic, n/NH)
  for (i = 0; i < n; i++)
  {
    x = h * (0.5 + ((double) i));
    sum += 4.0 / (1.0 + (x * x));
  }

  double pi = sum * h;
  printf("\nEl valor aproximado de PI es %0.9f con un error de %0.9f\n", pi, fabs(pi - pi16ds));
  z = omp_get_wtime();
  printf("El programa ha tardado %0.9f segundos \n", z - a);

  int t;
  int y;
  int x;
  int k;
  double total_lattice_pts = (((double) 1024) * ((double) 1024)) * ((double) 50000);
  int ts_return = -1;
  struct timeval start;
  struct timeval end;
  struct timeval result;
  double tdiff = 0.0;
  omega = 2.0 / ((((6.0 * uTop) * (1024 - 0.5)) / re) + 1.0);
  printf("2D Lid Driven Cavity simulation with D2Q9 lattice:\n\tscheme     : 2-Grid, Fused, Pull\n\tgrid size  : %d x %d = %.2lf * 10^3 Cells\n\tnTimeSteps : %d\n\tRe         : %.2lf\n\tuTop       : %.6lf\n\tomega      : %.6lf\n", 1024, 1024, (1024 * 1024) / 1.0e3, 50000, re, uTop, omega);
  for (y = 0; y < ((1024 + 2) + 4); y++)
  {
    for (x = 0; x < ((1024 + 2) + 2); x++)
    {
      for (k = 0; k < 9; k++)
      {
        grid[0][y][x][k] = 1.0;
        grid[1][y][x][k] = 1.0;
      }

    }

  }

  short _nX = 1024 + 3;
  short _nY = 1024 + 4;
  int _nTimesteps = 50000;
  int t1;
  int t2;
  int t3;
  int t4;
  int t5;
  int t6;
  int lb;
  int ub;
  int lbp;
  int ubp;
  int lb2;
  int ub2;
  register int lbv;
  register int ubv;
  if (((_nTimesteps >= 1) && (_nX >= 2)) && (_nY >= 3))
  {
    for (t1 = -1; t1 <= floor(((double) (_nTimesteps - 1)) / ((double) 4)); t1++)
    {
      lbp = (ceil(((double) t1) / ((double) 2)) > ceil(((double) (((8 * t1) - _nTimesteps) + 3)) / ((double) 8))) ? (ceil(((double) t1) / ((double) 2))) : (ceil(((double) (((8 * t1) - _nTimesteps) + 3)) / ((double) 8)));
      ubp = (floor(((double) ((_nTimesteps + _nY) - 2)) / ((double) 8)) < floor(((double) (((4 * t1) + _nY) + 2)) / ((double) 8))) ? (floor(((double) ((_nTimesteps + _nY) - 2)) / ((double) 8))) : (floor(((double) (((4 * t1) + _nY) + 2)) / ((double) 8)));
      #pragma omp parallel for private(lbv, ubv, t3, t4, t5, t6)
      for (t2 = lbp; t2 <= ubp; t2++)
      {
        for (t3 = (((0 > ceil(((double) (t1 - 1)) / ((double) 2))) ? (0) : (ceil(((double) (t1 - 1)) / ((double) 2)))) > ceil(((double) (((8 * t2) - _nY) - 5)) / ((double) 8))) ? ((0 > ceil(((double) (t1 - 1)) / ((double) 2))) ? (0) : (ceil(((double) (t1 - 1)) / ((double) 2)))) : (ceil(((double) (((8 * t2) - _nY) - 5)) / ((double) 8))); t3 <= ((((((floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8)) < floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8))) ? (floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8))) : (floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8)))) < floor(((double) (((8 * t2) + _nX) + 4)) / ((double) 8))) ? ((floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8)) < floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8))) ? (floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8))) : (floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8)))) : (floor(((double) (((8 * t2) + _nX) + 4)) / ((double) 8)))) < floor(((double) (((((8 * t1) - (8 * t2)) + _nY) + _nX) + 5)) / ((double) 8))) ? ((((floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8)) < floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8))) ? (floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8))) : (floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8)))) < floor(((double) (((8 * t2) + _nX) + 4)) / ((double) 8))) ? ((floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8)) < floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8))) ? (floor(((double) ((_nTimesteps + _nX) - 2)) / ((double) 8))) : (floor(((double) (((4 * t1) + _nX) + 6)) / ((double) 8)))) : (floor(((double) (((8 * t2) + _nX) + 4)) / ((double) 8)))) : (floor(((double) (((((8 * t1) - (8 * t2)) + _nY) + _nX) + 5)) / ((double) 8)))); t3++)
        {
          for (t4 = (((((((0 > (4 * t1)) ? (0) : (4 * t1)) > (((8 * t1) - (8 * t2)) + 2)) ? ((0 > (4 * t1)) ? (0) : (4 * t1)) : (((8 * t1) - (8 * t2)) + 2)) > (((8 * t2) - _nY) + 1)) ? ((((0 > (4 * t1)) ? (0) : (4 * t1)) > (((8 * t1) - (8 * t2)) + 2)) ? ((0 > (4 * t1)) ? (0) : (4 * t1)) : (((8 * t1) - (8 * t2)) + 2)) : (((8 * t2) - _nY) + 1)) > (((8 * t3) - _nX) + 1)) ? ((((((0 > (4 * t1)) ? (0) : (4 * t1)) > (((8 * t1) - (8 * t2)) + 2)) ? ((0 > (4 * t1)) ? (0) : (4 * t1)) : (((8 * t1) - (8 * t2)) + 2)) > (((8 * t2) - _nY) + 1)) ? ((((0 > (4 * t1)) ? (0) : (4 * t1)) > (((8 * t1) - (8 * t2)) + 2)) ? ((0 > (4 * t1)) ? (0) : (4 * t1)) : (((8 * t1) - (8 * t2)) + 2)) : (((8 * t2) - _nY) + 1)) : (((8 * t3) - _nX) + 1); t4 <= (((((((((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) < ((8 * t2) + 5)) ? (((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) : ((8 * t2) + 5)) < ((8 * t3) + 6)) ? (((((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) < ((8 * t2) + 5)) ? (((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) : ((8 * t2) + 5)) : ((8 * t3) + 6)) < ((((8 * t1) - (8 * t2)) + _nY) + 6)) ? (((((((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) < ((8 * t2) + 5)) ? (((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) : ((8 * t2) + 5)) < ((8 * t3) + 6)) ? (((((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) < ((8 * t2) + 5)) ? (((_nTimesteps - 1) < ((4 * t1) + 7)) ? (_nTimesteps - 1) : ((4 * t1) + 7)) : ((8 * t2) + 5)) : ((8 * t3) + 6)) : ((((8 * t1) - (8 * t2)) + _nY) + 6)); t4++)
          {
            if ((t4 % 2) == 0)
            {
              for (t5 = ((((8 * t2) > (t4 + 2)) ? (8 * t2) : (t4 + 2)) > (((((-8) * t1) + (8 * t2)) + (2 * t4)) - 7)) ? (((8 * t2) > (t4 + 2)) ? (8 * t2) : (t4 + 2)) : (((((-8) * t1) + (8 * t2)) + (2 * t4)) - 7); t5 <= ((((((8 * t2) + 7) < ((((-8) * t1) + (8 * t2)) + (2 * t4))) ? ((8 * t2) + 7) : ((((-8) * t1) + (8 * t2)) + (2 * t4))) < ((t4 + _nY) - 1)) ? ((((8 * t2) + 7) < ((((-8) * t1) + (8 * t2)) + (2 * t4))) ? ((8 * t2) + 7) : ((((-8) * t1) + (8 * t2)) + (2 * t4))) : ((t4 + _nY) - 1)); t5++)
              {
                lbv = ((8 * t3) > (t4 + 1)) ? (8 * t3) : (t4 + 1);
                ubv = (((8 * t3) + 7) < ((t4 + _nX) - 1)) ? ((8 * t3) + 7) : ((t4 + _nX) - 1);
                #pragma ivdep
                #pragma vector always
                for (t6 = lbv; t6 <= ubv; t6++)
                {
                  lbm_kernel(grid[0][(-t4) + t5][(-t4) + t6][0], grid[0][((-t4) + t5) - 1][(-t4) + t6][2], grid[0][((-t4) + t5) + 1][(-t4) + t6][4], grid[0][(-t4) + t5][((-t4) + t6) - 1][1], grid[0][(-t4) + t5][((-t4) + t6) + 1][3], grid[0][((-t4) + t5) - 1][((-t4) + t6) - 1][5], grid[0][((-t4) + t5) - 1][((-t4) + t6) + 1][6], grid[0][((-t4) + t5) + 1][((-t4) + t6) - 1][8], grid[0][((-t4) + t5) + 1][((-t4) + t6) + 1][7], &grid[1][(-t4) + t5][(-t4) + t6][0], &grid[1][(-t4) + t5][(-t4) + t6][2], &grid[1][(-t4) + t5][(-t4) + t6][4], &grid[1][(-t4) + t5][(-t4) + t6][1], &grid[1][(-t4) + t5][(-t4) + t6][3], &grid[1][(-t4) + t5][(-t4) + t6][5], &grid[1][(-t4) + t5][(-t4) + t6][6], &grid[1][(-t4) + t5][(-t4) + t6][8], &grid[1][(-t4) + t5][(-t4) + t6][7], t4, (-t4) + t5, (-t4) + t6);
                  ;
                }

              }

            }
            else
            {
              for (t5 = ((((8 * t2) > (t4 + 2)) ? (8 * t2) : (t4 + 2)) > (((((-8) * t1) + (8 * t2)) + (2 * t4)) - 7)) ? (((8 * t2) > (t4 + 2)) ? (8 * t2) : (t4 + 2)) : (((((-8) * t1) + (8 * t2)) + (2 * t4)) - 7); t5 <= ((((((8 * t2) + 7) < ((((-8) * t1) + (8 * t2)) + (2 * t4))) ? ((8 * t2) + 7) : ((((-8) * t1) + (8 * t2)) + (2 * t4))) < ((t4 + _nY) - 1)) ? ((((8 * t2) + 7) < ((((-8) * t1) + (8 * t2)) + (2 * t4))) ? ((8 * t2) + 7) : ((((-8) * t1) + (8 * t2)) + (2 * t4))) : ((t4 + _nY) - 1)); t5++)
              {
                lbv = ((8 * t3) > (t4 + 1)) ? (8 * t3) : (t4 + 1);
                ubv = (((8 * t3) + 7) < ((t4 + _nX) - 1)) ? ((8 * t3) + 7) : ((t4 + _nX) - 1);
                #pragma ivdep
                #pragma vector always
                for (t6 = lbv; t6 <= ubv; t6++)
                {
                  lbm_kernel(grid[1][(-t4) + t5][(-t4) + t6][0], grid[1][((-t4) + t5) - 1][(-t4) + t6][2], grid[1][((-t4) + t5) + 1][(-t4) + t6][4], grid[1][(-t4) + t5][((-t4) + t6) - 1][1], grid[1][(-t4) + t5][((-t4) + t6) + 1][3], grid[1][((-t4) + t5) - 1][((-t4) + t6) - 1][5], grid[1][((-t4) + t5) - 1][((-t4) + t6) + 1][6], grid[1][((-t4) + t5) + 1][((-t4) + t6) - 1][8], grid[1][((-t4) + t5) + 1][((-t4) + t6) + 1][7], &grid[0][(-t4) + t5][(-t4) + t6][0], &grid[0][(-t4) + t5][(-t4) + t6][2], &grid[0][(-t4) + t5][(-t4) + t6][4], &grid[0][(-t4) + t5][(-t4) + t6][1], &grid[0][(-t4) + t5][(-t4) + t6][3], &grid[0][(-t4) + t5][(-t4) + t6][5], &grid[0][(-t4) + t5][(-t4) + t6][6], &grid[0][(-t4) + t5][(-t4) + t6][8], &grid[0][(-t4) + t5][(-t4) + t6][7], t4, (-t4) + t5, (-t4) + t6);
                  ;
                }

              }

            }

          }

        }

      }

    }

  }

  return 0;
}

