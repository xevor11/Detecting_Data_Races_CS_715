void downsample(unsigned char *inbuffer, unsigned char *outbuffer, int tfactor, int ffactor, int nchans, int nsamps)
{
  float temp;
  int ii;
  int jj;
  int kk;
  int ll;
  int pos;
  int newnsamps = nsamps / tfactor;
  int newnchans = nchans / ffactor;
  int totfactor = ffactor * tfactor;
  #pragma omp parallel for default(shared)
  for (ii = 0; ii < newnsamps; ii++)
  {
    for (jj = 0; jj < newnchans; jj++)
    {
      temp = 0;
      pos = ((nchans * ii) * tfactor) + (jj * ffactor);
      for (kk = 0; kk < tfactor; kk++)
      {
        for (ll = 0; ll < ffactor; ll++)
        {
          temp += inbuffer[((kk * nchans) + ll) + pos];
        }

      }

      outbuffer[(ii * newnchans) + jj] = (unsigned char) ((temp / totfactor) + 0.5);
    }

  }

}

