int main(int argc, char **argv)
{
  if (argc < 2)
  {
    printf("Incorrect number of parameters");
    return -1;
  }

  int MAX = atoi(argv[1]);
  int arrA[MAX][MAX];
  int arrB[MAX][MAX];
  int arrRes[MAX][MAX];
  int i;
  int j;
  int k;
  #pragma omp parallel shared(arrA, arrB, arrRes)
  {
    #pragma omp for schedule(dynamic, MAX/200) nowait
    for (i = 0; i < MAX; i++)
      for (j = 0; j < MAX; j++)
      for (k = 0; k < MAX; k++)
      arrRes[i][j] += arrA[i][k] * arrB[k][j];



  }
  return 0;
}

