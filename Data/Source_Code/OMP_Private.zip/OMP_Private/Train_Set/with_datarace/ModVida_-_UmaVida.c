double wall_time(void);
void UmaVida(int *tabulIn, int *tabulOut, int tam)
{
  int i;
  int j;
  int vizviv;
  int k;
  int sqtam = tam * tam;
  #pragma omp parallel for
  for (k = 0; k < sqtam; k++)
  {
    i = (k % tam) + 1;
    j = (k / tam) + 1;
    vizviv = ((((((tabulIn[(((i - 1) * (tam + 2)) + j) - 1] + tabulIn[((i - 1) * (tam + 2)) + j]) + tabulIn[(((i - 1) * (tam + 2)) + j) + 1]) + tabulIn[((i * (tam + 2)) + j) - 1]) + tabulIn[((i * (tam + 2)) + j) + 1]) + tabulIn[(((i + 1) * (tam + 2)) + j) - 1]) + tabulIn[((i + 1) * (tam + 2)) + j]) + tabulIn[(((i + 1) * (tam + 2)) + j) + 1];
    if (tabulIn[(i * (tam + 2)) + j] && (vizviv < 2))
      tabulOut[(i * (tam + 2)) + j] = 0;
    else
      if (tabulIn[(i * (tam + 2)) + j] && (vizviv > 3))
      tabulOut[(i * (tam + 2)) + j] = 0;
    else
      if ((!tabulIn[(i * (tam + 2)) + j]) && (vizviv == 3))
      tabulOut[(i * (tam + 2)) + j] = 1;
    else
      tabulOut[(i * (tam + 2)) + j] = tabulIn[(i * (tam + 2)) + j];



  }

}

