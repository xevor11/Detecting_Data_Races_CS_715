int main(int argc, char *argv[])
{
  int i;
  int j;
  int k;
  int n;
  int nx = 256;
  int ny = 256;
  int nz = 256;
  int nsteps = 2000;
  float x[256][256][256];
  float y[256][256][256];
  float z[256][256][256];
  float f[256][256][256];
  float g[256][256][256];
  float fp[256][256][256];
  float gp[256][256][256];
  float dx = 2.0f / (nx - 1);
  float dy = 2.0f / (ny - 1);
  float dz = 2.0f / (nz - 1);
  float dt = 0.00000005f;
  for (i = 0; i < 256; i++)
  {
    for (j = 0; j < 256; j++)
    {
      for (k = 0; k < 256; k++)
      {
        x[i][j][k] = (-1.0f) + (i * dx);
        y[i][j][k] = (-1.0f) + (j * dy);
        z[i][j][k] = (-1.0f) + (k * dz);
      }

    }

  }

  for (i = 0; i < 256; i++)
  {
    for (j = 0; j < 256; j++)
    {
      for (k = 0; k < 256; k++)
      {
        f[i][j][k] = 0.2f * exp((-(((x[i][j][k] * x[i][j][k]) + (y[i][j][k] * y[i][j][k])) + (z[i][j][k] * z[i][j][k]))) / 0.05f);
        g[i][j][k] = 0.0f;
      }

    }

  }

  FILE *fPtr = fopen("wave3d.xline", "w");
  for (i = 0; i < 256; i++)
  {
    fprintf(fPtr, "%5.3f %10.6e\n", x[i][256 / 2][256 / 2], f[i][256 / 2][256 / 2]);
  }

  fprintf(fPtr, "\n");
  float step = 0.0f;
  int printevery = 20;
  printf("step = %9.6f \n", step);
  StartTimer();
  for (n = 0; n < nsteps; n++)
  {
    step = step + dt;
    if (((n + 1) % printevery) == 0)
      printf("step = %9.6f \n", step);

    #pragma omp parallel
    {
      #pragma omp for schedule(static)
      for (i = 0; i < 256; i++)
      {
        for (j = 0; j < 256; j++)
        {
          for (k = 0; k < 256; k++)
          {
            fp[i][j][k] = f[i][j][k] + (dt * g[i][j][k]);
          }

        }

      }

      for (j = 0; j < 256; j++)
      {
        for (k = 0; k < 256; k++)
        {
          gp[0][j][k] = g[0][j][k];
          gp[256 - 1][j][k] = g[256 - 1][j][k];
        }

      }

      for (i = 0; i < 256; i++)
      {
        for (k = 0; k < 256; k++)
        {
          gp[i][0][k] = g[i][0][k];
          gp[i][256 - 1][k] = g[i][256 - 1][k];
        }

      }

      for (i = 0; i < 256; i++)
      {
        for (j = 0; j < 256; j++)
        {
          gp[i][j][0] = g[i][j][0];
          gp[i][j][256 - 1] = g[i][j][256 - 1];
        }

      }

      #pragma omp for schedule(static)
      for (i = 1; i < (256 - 1); i++)
      {
        for (j = 1; j < (256 - 1); j++)
        {
          for (k = 1; k < (256 - 1); k++)
          {
            gp[i][j][k] = g[i][j][k] + (dt * ((((((fp[i + 1][j][k] - (2.0f * fp[i][j][k])) + fp[i - 1][j][k]) / dx) / dx) + ((((fp[i][j + 1][k] - (2.0f * fp[i][j][k])) + fp[i][j - 1][k]) / dy) / dy)) + ((((fp[i][j][k + 1] - (2.0f * fp[i][j][k])) + fp[i][j][k - 1]) / dz) / dz)));
          }

        }

      }

      #pragma omp for schedule(static)
      for (i = 0; i < 256; i++)
      {
        for (j = 0; j < 256; j++)
        {
          for (k = 0; k < 256; k++)
          {
            fp[i][j][k] = f[i][j][k] + (dt * (0.5f * (g[i][j][k] + gp[i][j][k])));
          }

        }

      }

      #pragma omp for schedule(static)
      for (i = 0; i < 256; i++)
      {
        for (j = 0; j < 256; j++)
        {
          for (int k = 0; k < 256; k++)
          {
            f[i][j][k] = fp[i][j][k];
            g[i][j][k] = gp[i][j][k];
          }

        }

      }

    }
    if (((n + 1) % printevery) == 0)
    {
      for (i = 0; i < 256; i++)
      {
        fprintf(fPtr, "%5.3f %10.6e\n", x[i][256 / 2][256 / 2], f[i][256 / 2][256 / 2]);
      }

      fprintf(fPtr, "\n");
    }

  }

  float computeTime = GetTimer();
  printf("Compute time: %f seconds\n", computeTime / 1000.0f);
  exit(0);
}

