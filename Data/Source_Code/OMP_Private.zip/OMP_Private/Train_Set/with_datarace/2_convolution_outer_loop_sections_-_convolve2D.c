struct imagenppm
{
  int altura;
  int ancho;
  char *comentario;
  int maxcolor;
  int P;
  int *R;
  int *G;
  int *B;
};
struct structkernel
{
  int kernelX;
  int kernelY;
  float *vkern;
};
ImagenData initimage(char *nombre, FILE **fp, int partitions, int halo);
ImagenData duplicateImageData(ImagenData src, int partitions, int halo);
int readImage(ImagenData Img, FILE **fp, int dim, int halosize, long int *position);
int duplicateImageChunk(ImagenData src, ImagenData dst, int dim);
int initfilestore(ImagenData img, FILE **fp, char *nombre, long *position);
int savingChunk(ImagenData img, FILE **fp, int dim, int offset);
int convolve2D(int *inbuf, int *outbuf, int sizeX, int sizeY, float *kernel, int ksizeX, int ksizeY);
void freeImagestructure(ImagenData *src);
int convolve2D(int *in, int *out, int dataSizeX, int dataSizeY, float *kernel, int kernelSizeX, int kernelSizeY)
{
  int i;
  int j;
  int m;
  int n;
  int *inPtr;
  int *inPtr2;
  int *outPtr;
  int *base;
  float *kPtr;
  int kCenterX;
  int kCenterY;
  int rowMin;
  int rowMax;
  int colMin;
  int colMax;
  float sum;
  if (((!in) || (!out)) || (!kernel))
    return -1;

  if ((dataSizeX <= 0) || (kernelSizeX <= 0))
    return -1;

  kCenterX = ((int) kernelSizeX) / 2;
  kCenterY = ((int) kernelSizeY) / 2;
  inPtr = (inPtr2 = (base = &in[(dataSizeX * kCenterY) + kCenterX]));
  outPtr = out;
  kPtr = kernel;
  #pragma omp parallel for default(none) firstprivate(inPtr, inPtr2, kPtr, outPtr, out, base, dataSizeY, kCenterY, kCenterX, dataSizeX, kernelSizeX, kernelSizeY, kernel)
  for (i = 0; i < dataSizeY; ++i)
  {
    rowMax = i + kCenterY;
    rowMin = (i - dataSizeY) + kCenterY;
    outPtr = (i * dataSizeX) + out;
    inPtr = (inPtr2 = (i * dataSizeX) + base);
    for (j = 0; j < dataSizeX; ++j)
    {
      colMax = j + kCenterX;
      colMin = (j - dataSizeX) + kCenterX;
      sum = 0;
      for (m = 0; m < kernelSizeY; ++m)
      {
        if ((m <= rowMax) && (m > rowMin))
        {
          for (n = 0; n < kernelSizeX; ++n)
          {
            if ((n <= colMax) && (n > colMin))
            {
              sum += (*(inPtr - n)) * (*kPtr);
            }

            ++kPtr;
          }

        }
        else
          kPtr += kernelSizeX;

        inPtr -= dataSizeX;
      }

      if (sum >= 0)
        *outPtr = (int) (sum + 0.5f);
      else
        *outPtr = (int) (sum - 0.5f);

      kPtr = kernel;
      inPtr = ++inPtr2;
      outPtr++;
    }

  }

  return 0;
}

