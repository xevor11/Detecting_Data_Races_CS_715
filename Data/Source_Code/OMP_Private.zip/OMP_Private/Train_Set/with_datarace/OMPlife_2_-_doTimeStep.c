int i;
int j;
int n;
int im;
int ip;
int jm;
int jp;
int nsum;
int isum;
int offset;
int **old;
int **new;
float x;
int id;
int iBound;
clock_t timer;
clock_t start_timer;
clock_t end_timer;
void doTimeStep(int n)
{
  int *n = (int *) arg_list[1];
  int *t = (int *) arg_list[2];
  int *tsteps = (int *) arg_list[3];
  int i;
  int j;
  #pragma omp single
  {
    arg_list_parallel_for_body1_0 = calloc(((*n) - 1) - 1, sizeof(void **));
    arg_list_OmpRegBody1_0 = calloc(((*n) - 1) - 1, sizeof(void **));
    arg_list_parallel_for_body1__while__0_0 = calloc(((*n) - 1) - 1, sizeof(void **));
  }
  #pragma omp for private(i)
  for (i = 1; i < ((*n) - 1); i++)
  {
    if (arg_list_parallel_for_body1_0[i] == 0)
    {
      arg_list_parallel_for_body1_0[i] = malloc(6 * (sizeof(void *)));
    }

    arg_list_parallel_for_body1_0[i][0] = i;
    arg_list_parallel_for_body1_0[i][1] = t;
    arg_list_parallel_for_body1_0[i][2] = tsteps;
    struct __cont_env *OmpRegBody1_cps_cps_cont_env_1_1 = malloc(sizeof(struct __cont_env));
    OmpRegBody1_cps_cps_cont_env_1_1->arg_list = arg_list_parallel_for_body1_0[i];
    OmpRegBody1_cps_cps_cont_env_1_1->contn_env = contn_env;
    OmpRegBody1_cps_cps_cont_env_1_1->cont_fn = parallel_for_body1_cps;
    uwomp_add_to_local_pending_worklist(OmpRegBody1_cps_cps_cont_env_1_1, 0);
  }

  uwomp_execute_worklist();

  omp_set_num_threads(8);
  #pragma omp parallel
  {
    id = omp_get_thread_num();
    for (i = 0; i < 1000; i++)
    {
      #pragma omp for schedule(static)
      for (j = 0; j < 1000; j++)
      {
        im = i - 1;
        ip = i + 1;
        jm = j - 1;
        jp = j + 1;
        if (im == (-1))
          im = 1000 - 1;

        if (ip == 1000)
          ip = 0;

        if (jm == (-1))
          jm = 1000 - 1;

        if (jp == 1000)
          jp = 0;

        nsum = ((((((old[im][jp] + old[i][jp]) + old[ip][jp]) + old[im][j]) + old[ip][j]) + old[im][jm]) + old[i][jm]) + old[ip][jm];
        switch (nsum)
        {
          case 3:
            new[i][j] = 1;
            break;

          case 2:
            new[i][j] = old[i][j];
            break;

          default:
            new[i][j] = 0;

        }

      }

    }

    for (i = 0; i < 1000; i++)
    {
      #pragma omp for schedule(static)
      for (j = 0; j < 1000; j++)
      {
        old[i][j] = new[i][j];
      }

    }

  }
}

