int main()
{
  int i1;
  int i2;
  int i;
  int j;
  int k;
  int *A;
  int *B;
  int *C;
  int temp;
  int id;
  int start;
  int stop;
  int sum = 0;
  A = (int *) malloc((6 * 6) * (sizeof(int)));
  B = (int *) malloc((6 * 6) * (sizeof(int)));
  C = (int *) malloc((6 * 6) * (sizeof(int)));
  printf("Ma tran A:\n");
  for (i = 0; i < 6; i++)
    for (j = 0; j < 6; j++)
    if (i == j)
    *((A + (i * 6)) + j) = 1;
  else
    *((A + (i * 6)) + j) = 0;



  for (i = 0; i < 6; i++)
  {
    for (j = 0; j < 6; j++)
      printf("%d", *((A + (i * 6)) + j));

    printf("\n");
  }

  printf("\n");
  printf("Ma tran B:\n");
  for (i = 0; i < 6; i++)
    for (j = 0; j < 6; j++)
    *((B + (i * 6)) + j) = (i * 6) + j;


  for (i = 0; i < 6; i++)
  {
    for (j = 0; j < 6; j++)
      printf("%d", *((B + (i * 6)) + j));

    printf("\n");
  }

  omp_set_num_threads(9);
  #pragma omp parallel
  {
    id = omp_get_thread_num();
    i1 = (6 / 4) * id;
    i2 = (6 / 4) * (id + 1);
    for (i = 0; i < 6; i++)
    {
      for (j = i1; j < i2; j++)
      {
        for (k = 0; k < 6; k++)
          sum += (*((A + (i * 6)) + k)) * (*((B + (k * 6)) + j));

        *((C + (i * 6)) + j) = sum;
        sum = 0;
      }

    }

  }
  printf("\n");
  printf("Ma tran C:\n");
  for (i = 0; i < 6; i++)
  {
    for (j = 0; j < 6; j++)
      printf("%d\t", *((C + (i * 6)) + j));

    printf("\n");
  }

  return 0;
}

