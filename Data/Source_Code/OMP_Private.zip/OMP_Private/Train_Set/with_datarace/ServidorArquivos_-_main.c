int main(int argc, char *argv[])
{
  printf("Iniciando Servidor\n");
  char filename[256];
  int listenToSocket;
  int socketToFile;
  int sendToSocket;
  struct sockaddr_in serverSocketAddress;
  struct sockaddr_in clientSocketAddress;
  printf("Criando Socket\n");
  listenToSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  bzero(&serverSocketAddress, sizeof(serverSocketAddress));
  serverSocketAddress.sin_family = AF_INET;
  serverSocketAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  serverSocketAddress.sin_port = htons(1337);
  printf("Binding...\n");
  if (bind(listenToSocket, (struct sockaddr *) (&serverSocketAddress), sizeof(serverSocketAddress)) < 0)
  {
    perror("Bind error.");
    return -1;
  }

  printf("Listening...\n");
  if (listen(listenToSocket, 1024) < 0)
  {
    perror("Listen error.");
    return -1;
  }

  int client_len = sizeof(clientSocketAddress);
  #pragma omp parallel
  {
    #pragma omp single
    {
      while (1)
      {
        bzero(&clientSocketAddress, client_len);
        printf("Aguardando conexao\n");
        sendToSocket = accept(listenToSocket, (struct sockaddr *) (&clientSocketAddress), socklen_t & client_len);
        if (sendToSocket < 0)
        {
          perror("Accept error.");
          continue;
        }

        #pragma omp task firstprivate(sendToSocket)
        {
          printf("Conectado ao servidor. Aguardando operacao\n");
          bzero(&filename, sizeof(filename));
          int tam = read(sendToSocket, filename, 256);
          filename[tam] = '\0';
          char op = filename[0];
          char path[tam];
          strncpy(path, filename + 1, tam - 1);
          if (op == 'u')
          {
            printf("Sera enviado o arquivo: %s\n", path);
            RFile(path, sendToSocket);
          }
          else
            if (op == 'd')
          {
            printf("Solicitado o arquivo: %s\n", path);
            SFile(path, sendToSocket);
          }
          else
          {
            perror("invalid operation");
            close(sendToSocket);
          }


        }
      }

    }
  }
}

