{
  int **M;
  int *v1;
  int *v2;
  int i;
  int k;
  int N;
  double cgt1;
  double cgt2;
  double ncgt;
  time_t t;
  srand((unsigned) time(&t));
  if (argc < 2)
  {
    fprintf(stderr, "Falta iteraciones\n");
    exit(-1);
  }

  N = atoi(argv[1]);
  v1 = (int *) malloc(N * (sizeof(int)));
  v2 = (int *) malloc(N * (sizeof(int)));
  if ((v1 == 0) || (v2 == 0))
  {
    printf("Error en la reserva de espacio para los vectores\n");
    exit(-2);
  }

  M = (int **) malloc(N * (sizeof(int *)));
  #pragma omp parallel for shared(M,N) private(i) default(none)
  for (i = 0; i < N; i++)
  {
    M[i] = (int *) malloc(N * (sizeof(int)));
    if (M[i] == 0)
    {
      printf("Error en la reserva de espacio para los vectores\n");
      exit(-2);
    }

  }

  for (i = 0; i < N; i++)
  {
    #pragma omp parallel for shared(M,i,N) private(k) default(none)
    for (k = 0; k < N; k++)
      M[i][k] = rand() % 8;

  }

  #pragma omp parallel for shared(v1,v2,N) private(i) default(none)
  for (i = 0; i < N; i++)
  {
    v1[i] = rand() % 6;
    v2[i] = 0;
  }

  cgt1 = omp_get_wtime();
  for (i = 0; i < N; i++)
  {
    #pragma omp parallel shared(M,i,N,v2,v1) private(k) default(none)
    {
      int sumalocal = 0;
      #pragma omp for
      for (k = 0; k < N; k++)
        sumalocal += M[i][k] * v1[k];

      #pragma omp atomic
      v2[i] += sumalocal;
    }
  }

  cgt2 = omp_get_wtime();
  ncgt = (double) (cgt2 - cgt1);
  printf("Tiempo(seg.):%11.9f\n", ncgt);
  printf("Tamaño de los vectores: %u\n", N);
  printf("\tv1 = %uElem -> %lu bytes\n\tv2 = %uElem -> %lu bytes\n", N, N * (sizeof(int)), N, N * (sizeof(int)));
  printf("Tamaño de la matriz: %ux%u -> %lu bytes\n", N, N, (N * N) * (sizeof(int)));
  printf("v2[0] = %u ... v2[N-1] = %u \n", v2[0], v2[N - 1]);
  if (N < 15)
  {
    printf("\n----------- Matriz M ----------- \n");
    for (i = 0; i < N; i++)
    {
      for (k = 0; k < N; k++)
        printf("%u\t", M[i][k]);

      printf("\n");
    }

    printf("\n----------- Vector V1 ----------- \n");
    for (i = 0; i < N; i++)
      printf("%u\t", v1[i]);

    printf("\n");
    printf("\n----------- Vector V2----------- \n");
    for (i = 0; i < N; i++)
      printf("%u\t", v2[i]);

    printf("\n");
  }

  free(v1);
  free(v2);
  #pragma omp parallel for shared(M,N) private(i) default(none)
  for (i = 0; i < N; i++)
    free(M[i]);

  free(M);

  int nx;
  int ny;
  int maxIters;
  int reynolds_dim;
  double density;
  double accel;
  double omega;
} t_param;
{
  double speeds[9];
} t_speed;
enum boolean {FALSE, TRUE};
int initialise(const char *paramfile, const char *obstaclefile, t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
int timestep(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int accelerate_flow(const t_param params, t_speed *cells, int *obstacles);
int propagate(const t_param params, t_speed *cells, t_speed *tmp_cells);
int rebound(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int collision(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int write_values(const t_param params, t_speed *cells, int *obstacles, double *av_vels);
int finalise(const t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
double total_density(const t_param params, t_speed *cells);
double av_velocity(const t_param params, t_speed *cells, int *obstacles);
double calc_reynolds(const t_param params, t_speed *cells, int *obstacles);
void die(const char *message, const int line, const char *file);
void usage(const char *exe);
int propagate(const t_param params, t_speed *cells, t_speed *tmp_cells)
{
  int ii;
  int jj;
  int x_e;
  int x_w;
  int y_n;
  int y_s;
  #pragma omp parallel for shared(cells,tmp_cells)
  for (ii = 0; ii < params.ny; ii++)
  {
    for (jj = 0; jj < params.nx; jj++)
    {
      y_n = (ii + 1) % params.ny;
      x_e = (jj + 1) % params.nx;
      y_s = (ii == 0) ? ((ii + params.ny) - 1) : (ii - 1);
      x_w = (jj == 0) ? ((jj + params.nx) - 1) : (jj - 1);
      tmp_cells[(ii * params.nx) + jj].speeds[0] = cells[(ii * params.nx) + jj].speeds[0];
      tmp_cells[(ii * params.nx) + x_e].speeds[1] = cells[(ii * params.nx) + jj].speeds[1];
      tmp_cells[(y_n * params.nx) + jj].speeds[2] = cells[(ii * params.nx) + jj].speeds[2];
      tmp_cells[(ii * params.nx) + x_w].speeds[3] = cells[(ii * params.nx) + jj].speeds[3];
      tmp_cells[(y_s * params.nx) + jj].speeds[4] = cells[(ii * params.nx) + jj].speeds[4];
      tmp_cells[(y_n * params.nx) + x_e].speeds[5] = cells[(ii * params.nx) + jj].speeds[5];
      tmp_cells[(y_n * params.nx) + x_w].speeds[6] = cells[(ii * params.nx) + jj].speeds[6];
      tmp_cells[(y_s * params.nx) + x_w].speeds[7] = cells[(ii * params.nx) + jj].speeds[7];
      tmp_cells[(y_s * params.nx) + x_e].speeds[8] = cells[(ii * params.nx) + jj].speeds[8];
    }

  }

  return 0;
}

