int hilos = 0;
void Convolucion(float *y, float s1[], float s2[], int tam_s1, int tam_s2)
{
  float *x;
  float *h;
  int tam_x;
  int tam_h;
  if (tam_s1 < tam_s2)
  {
    h = s1;
    tam_h = tam_s1;
    x = s2;
    tam_x = tam_s2;
  }
  else
  {
    h = s2;
    tam_h = tam_s2;
    x = s1;
    tam_x = tam_s1;
  }

  int tam_y = (tam_x + tam_h) - 1;
  int n;
  int k;
  int dif_izq;
  int dif_der;
  #pragma omp parallel for schedule(static) default(none) shared(tam_x,tam_h,tam_y,y,x,h)
  for (n = 0; n < tam_y; n++)
  {
    dif_izq = ((n - tam_h) + abs(n - tam_h)) / 2;
    dif_der = ((n - tam_x) + abs(n - tam_x)) / 2;
    for (k = 0 + dif_izq; k < (n - dif_der); k++)
    {
      y[n] += x[k] * h[n - k];
    }

  }

}

