struct elem
{
  double Length;
  double *PolynomA;
  double *PolynomB;
  int MaxOrder;
  int NumIntSteps;
  double BendingAngle;
  double EntranceAngle;
  double ExitAngle;
  int FringeBendEntrance;
  int FringeBendExit;
  double FringeInt1;
  double FringeInt2;
  double FullGap;
  int FringeQuadEntrance;
  int FringeQuadExit;
  double *fringeIntM0;
  double *fringeIntP0;
  double *R1;
  double *R2;
  double *T1;
  double *T2;
  double *RApertures;
  double *EApertures;
};
void BndMPoleSymplectic4Pass(double *r, double le, double irho, double *A, double *B, int max_order, int num_int_steps, double entrance_angle, double exit_angle, int FringeBendEntrance, int FringeBendExit, double fint1, double fint2, double gap, int FringeQuadEntrance, int FringeQuadExit, double *fringeIntM0, double *fringeIntP0, double *T1, double *T2, double *R1, double *R2, double *RApertures, double *EApertures, int num_particles)
{
  int c;
  int m;
  double *r6;
  double SL;
  double L1;
  double L2;
  double K1;
  double K2;
  double p_norm;
  double NormL1;
  double NormL2;
  bool useLinFrEleEntrance = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadEntrance == 2);
  bool useLinFrEleExit = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadExit == 2);
  SL = le / num_int_steps;
  L1 = SL * 0.6756035959798286638;
  L2 = SL * (-0.1756035959798286639);
  K1 = SL * 1.351207191959657328;
  K2 = SL * (-1.702414383919314656);
  #pragma omp parallel for if (num_particles > OMP_PARTICLE_THRESHOLD) default(shared) shared(r,num_particles)
  for (c = 0; c < num_particles; c++)
  {
    r6 = r + (c * 6);
    if (!atIsNaN(r6[0]))
    {
      if (T1)
        ATaddvv(r6, T1);

      if (R1)
        ATmultmv(r6, R1);

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      edge_fringe_entrance(r6, irho, entrance_angle, fint1, gap, FringeBendEntrance);
      if (FringeQuadEntrance && (B[1] != 0))
      {
        if (useLinFrEleEntrance)
          linearQuadFringeElegantEntrance(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassP(r6, B[1]);

      }

      p_norm = 1 / (1 + r6[4]);
      NormL1 = L1 * p_norm;
      NormL2 = L2 * p_norm;
      for (m = 0; m < num_int_steps; m++)
      {
        fastdrift(r6, NormL1);
        bndthinkick(r6, A, B, K1, irho, max_order);
        fastdrift(r6, NormL2);
        bndthinkick(r6, A, B, K2, irho, max_order);
        fastdrift(r6, NormL2);
        bndthinkick(r6, A, B, K1, irho, max_order);
        fastdrift(r6, NormL1);
      }

      if (FringeQuadExit && (B[1] != 0))
      {
        if (useLinFrEleExit)
          linearQuadFringeElegantExit(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassN(r6, B[1]);

      }

      edge_fringe_exit(r6, irho, exit_angle, fint2, gap, FringeBendExit);
      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (R2)
        ATmultmv(r6, R2);

      if (T2)
        ATaddvv(r6, T2);

    }

  }

}

