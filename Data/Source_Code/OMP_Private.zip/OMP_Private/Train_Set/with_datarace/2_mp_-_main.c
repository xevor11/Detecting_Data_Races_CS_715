int main()
{
  int a[1000][1];
  int b[1][1000];
  int c = 0;
  int i;
  int j;
  double start = omp_get_wtime();
  for (i = 0; i < 1000; i++)
  {
    for (j = 0; j < 1; j++)
    {
      a[i][j] = 1;
    }

  }

  for (i = 0; i < 1; i++)
  {
    for (j = 0; j < 1000; j++)
    {
      b[i][j] = 1;
    }

  }

  omp_set_num_threads(2);
  #pragma omp parallel shared(a,b,c)
  {
    #pragma omp for reduction(+:c)
    for (i = 0; i < 1000; i++)
    {
      c += a[i][0] * b[0][i];
    }

  }
  printf("%d ", c);
  printf("\n");
  double end = omp_get_wtime();
  printf("start = %.16g\nend = %.16g\ndiff = %.16g seconds\n", start, end, end - start);
  return 0;
}

