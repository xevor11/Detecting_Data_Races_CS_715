extern int decode;
extern int latlon;
extern double *lat;
extern double *lon;
int f_stats(ARG0)
{
  double sum;
  double sum_wt;
  double wt;
  double t;
  double sum_thread;
  double sum_wt_thread;
  double wt_thread;
  double last_t;
  double last_lat;
  int do_wt;
  unsigned int n;
  unsigned int n_thread;
  unsigned int first;
  unsigned int i;
  float mn;
  float mx;
  float min_thread;
  float max_thread;
  if (mode == (-1))
  {
    latlon = (decode = 1);
  }

  if (mode < 0)
    return 0;

  sum = (wt = (sum_wt = 0.0));
  for (first = 0; first < ndata; first++)
  {
    if (DEFINED_VAL(data[first]))
      break;

  }

  if (first >= ndata)
  {
    sprintf(inv_out, "ndata=%u:undef=%u:mean=%lg:min=%lg:max=%lg", ndata, ndata, sum, sum, sum);
    return 0;
  }

  mn = (mx = data[first]);
  do_wt = lat != 0;
  n = 0;
  sum = (wt = (sum_wt = 0.0));
  #pragma omp parallel
  {
    min_thread = (max_thread = mx);
    n_thread = 0;
    sum_thread = (wt_thread = (sum_wt_thread = 0.0));
    last_t = 1.0;
    last_lat = 0.0;
    #pragma omp for schedule(static) nowait
    for (i = first; i < ndata; i++)
    {
      if (DEFINED_VAL(data[i]))
      {
        min_thread = (min_thread > data[i]) ? (data[i]) : (min_thread);
        max_thread = (max_thread < data[i]) ? (data[i]) : (max_thread);
        sum_thread += data[i];
        n_thread++;
        if (do_wt)
        {
          if (lat[i] == last_lat)
          {
            t = last_t;
          }
          else
          {
            last_t = (t = cosf(((float) (3.14159265 / 180.0)) * lat[i]));
            last_lat = lat[i];
          }

          wt_thread += t;
          sum_wt_thread += data[i] * t;
        }

      }

    }

    #pragma omp critical
    {
      if (min_thread < mn)
        mn = min_thread;

      if (max_thread > mx)
        mx = max_thread;

      sum += sum_thread;
      n += n_thread;
      wt += wt_thread;
      sum_wt += sum_wt_thread;
    }
  }
  sum /= n;
  sprintf(inv_out, "ndata=%u:undef=%u:mean=%lg:min=%g:max=%g", ndata, ndata - n, sum, mn, mx);
  if (wt > 0)
  {
    sum_wt = sum_wt / wt;
    inv_out += strlen(inv_out);
    sprintf(inv_out, ":cos_wt_mean=%lg", sum_wt);
  }

  return 0;
}

