int MATRIX_SIZE;
volatile float COEFFICIENT[20000][20000];
volatile float VECTOR[20000];
volatile float RESULT[20000];
void gaussianEliminationUsingOpenMp()
{
  int iterator;
  int row;
  int column;
  float multiplier;
  for (iterator = 0; iterator < (MATRIX_SIZE - 1); iterator++)
  {
    #pragma omp parallel for schedule(static) shared(COEFFICIENT, VECTOR, iterator, MATRIX_SIZE)
    for (row = iterator + 1; row < MATRIX_SIZE; row++)
    {
      multiplier = COEFFICIENT[row][iterator] / COEFFICIENT[iterator][iterator];
      for (column = iterator; column < MATRIX_SIZE; column++)
      {
        COEFFICIENT[row][column] = COEFFICIENT[row][column] - (COEFFICIENT[iterator][column] * multiplier);
      }

      VECTOR[row] = VECTOR[row] - (VECTOR[iterator] * multiplier);
    }

  }

  for (row = MATRIX_SIZE - 1; row >= 0; row--)
  {
    RESULT[row] = VECTOR[row];
    for (column = MATRIX_SIZE - 1; column > row; column--)
    {
      RESULT[row] = RESULT[row] - (COEFFICIENT[row][column] * RESULT[column]);
    }

    RESULT[row] = RESULT[row] / COEFFICIENT[row][row];
  }


  long lower;
  long upper;
  sscanf(argv[1], "%ld", &lower);
  sscanf(argv[2], "%ld", &upper);
  int i;
  long result = 0.0;
  if (lower == 1)
  {
    result = 1.0;
    lower = 2;
  }

  #pragma omp parallel for default(shared) private(i) schedule(auto) reduction(+:result) num_threads(2)
  for (i = lower; i <= upper; i++)
  {
    result = result + getTotient(i);
  }

  printf("Sum of Totients between [%ld..%ld] is %ld \n", lower, upper, result);
  return 0;
}

