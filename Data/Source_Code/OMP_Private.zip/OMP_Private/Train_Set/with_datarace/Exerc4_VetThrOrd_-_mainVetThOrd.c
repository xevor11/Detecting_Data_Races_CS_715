int mainVetThOrd()
{
  int i;
  int tid;
  int n;
  int chunk;
  int v[10];
  for (i = 0; i < 10; i++)
    v[i] = i;

  n = 10;
  #pragma omp paralell for default(shared) schedule(static, chunk) ORDER
  {
    for (i = 0; i < n; i++)
      printf("%d, %d\n", i, v[i]);

  }
  return 0;
}

