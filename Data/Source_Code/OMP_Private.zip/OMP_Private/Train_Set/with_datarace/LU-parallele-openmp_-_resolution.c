double a_mat[10][10];
double b_mat[10];
double l_mat[10][10];
double u_mat[10][10];
double y_mat[10];
double x_mat[10];
double lu_mat[10][10];
void resolution(void)
{
  int i;
  int j = 1;
  y_mat[0] = b_mat[0];
  double tmp;
  while (j < 10)
  {
    tmp = 0.0;
    #pragma omp parallel for shared(y_mat, l_mat,j,tmp)
    for (i = 0; i < j; i++)
    {
      tmp = tmp + (y_mat[i] * l_mat[j][i]);
    }

    y_mat[j] = b_mat[j] - tmp;
    j++;
  }

  j = 10 - 2;
  x_mat[10 - 1] = y_mat[10 - 1] / u_mat[10 - 1][10 - 1];
  tmp = 0.0;
  while (j >= 0)
  {
    tmp = 0.0;
    #pragma omp parallel for shared(y_mat, l_mat,j,tmp)
    for (i = j + 1; i <= (10 - 1); i++)
    {
      tmp = tmp + (x_mat[i] * u_mat[j][i]);
    }

    x_mat[j] = (y_mat[j] - tmp) / u_mat[j][j];
    j--;
  }

}

