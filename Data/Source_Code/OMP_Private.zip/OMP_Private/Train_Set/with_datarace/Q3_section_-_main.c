int main()
{
  int N = 1000;
  int x[N];
  int i = 0;
  int max_x = 0;
  int min_x = 100;
  int sum = 0;
  int sum2 = 0;
  float mean = 0.0;
  float mean2 = 0.0;
  long double var = 0.0;
  srand(1.0);
  #pragma omp parallel for
  for (i = 0; i < N; i++)
  {
    x[i] = rand();
  }

  #pragma omp parallel shared (x)
  {
    #pragma omp sections
    {
      #pragma omp section
      {
        for (i = 0; i < N; i++)
        {
          if (x[i] > max_x)
          {
            max_x = x[i];
          }

          if (x[i] < min_x)
          {
            min_x = x[i];
          }

        }

        printf("\nThe max of x = %d", max_x);
        printf("\nThe min of x = %d", min_x);
      }
      #pragma omp section
      {
        for (i = 0; i < N; i++)
        {
          sum = sum + x[i];
        }

        mean = sum / N;
        printf("\nMean of x = %f", mean);
      }
      #pragma omp section
      {
        for (i = 0; i < N; i++)
        {
          sum2 = sum2 + (x[i] * x[i]);
        }

        mean2 = sum2 / N;
        printf("\nMean2 of x = %f", mean2);
      }
    }
  }
  var = ((long double) mean2) - ((long double) (mean * mean));
  printf("\nVarience of x = %llf\n", var);
  return 0;
}

