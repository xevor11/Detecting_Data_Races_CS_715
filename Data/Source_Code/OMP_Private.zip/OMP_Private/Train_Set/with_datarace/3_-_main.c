int main(int argc, char **argv)
{
  double a[1000][1000];
  int i;
  int j;
  FILE *ff;
  int nThreads = 1;
  if (argc != 2)
  {
    nThreads = 1;
  }
  else
  {
    nThreads = atoi(argv[1]);
  }

  for (i = 0; i < 1000; ++i)
  {
    for (j = 0; j < 1000; ++j)
    {
      a[i][j] = (10 * i) + j;
    }

  }

  double t1;
  double t2;
  t1 = omp_get_wtime();
  #pragma omp parallel num_threads(nThreads) shared(a)
  {
    for (i = 0; i < (1000 - 1); ++i)
    {
      #pragma omp for
      for (j = 1; j < 1000; ++j)
      {
        a[i][j] = sin(0.00001 * a[i + 1][j - 1]);
      }

    }

  }
  t2 = omp_get_wtime();
  printf("Time elapsed: %f\n", t2 - t1);
  ff = fopen("3.out", "w");
  for (i = 0; i < 1000; ++i)
  {
    for (j = 0; j < 1000; ++j)
    {
      fprintf(ff, "%f ", a[i][j]);
    }

    fprintf(ff, "\n");
  }

  fclose(ff);
  return 0;
}

