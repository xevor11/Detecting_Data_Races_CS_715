struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
void meshgrid(double *x, double *y, double **X, double **Y, int nt)
{
  int i;
  int j;
  #pragma omp parallel shared(x,X,y,Y, nt)
  {
    #pragma omp sections nowait
    {
      #pragma omp section
      for (int i = 0; i < nt; i++)
      {
        for (int j = 0; j < nt; j++)
        {
          X[i][j] = x[j];
        }

      }

      #pragma omp section
      for (int i = 0; i < nt; i++)
      {
        for (int j = 0; j < nt; j++)
        {
          Y[j][i] = y[j];
        }

      }

    }
  }
}

