{
  double x;
  double y;
} coord;
{
  int ID;
  coord co;
  coord vel;
  coord fo;
  double massa;
} corpo;
int numeroCorpi(char *nomeFile);
int numeroPassi(char *nomeFile);
void memorizzaCorpi(corpo *pianeti, int numCorpi, char *nomeFile);
void stampaCorpo(corpo *c);
void stampaCorpi(corpo *pianeti, int numCorpi);
double ritornaDistanza(corpo c1, corpo c2);
void modificaForza(corpo *c1, corpo c2);
void modificaPosizione(corpo *c, double dt);
void modificaVelocita(corpo *c, double dt);
void stampaFilePosizione(char *nomeFile, corpo c);
void pulisciFile(char *nomeFile);
void stampaHeaderFilePosizione(char *nomeFile, int numCorpi, int numPassi);
void pulisciForza(corpo *c);
void stampaFileTempi(char *nomeFile, int numCorpi, int numPassi, double t);
int main(int argc, char **argv)
{
  int i;
  int j;
  int k;
  int l;
  int numPassi;
  int numCorpi;
  corpo *pianeti;
  double tin;
  double tout;
  printf("Simulazione parallela 1 n corpi: \n");
  numCorpi = numeroCorpi("file/input.txt");
  numPassi = numeroPassi("file/input.txt");
  printf("Numero corpi: %d\n", numCorpi);
  printf("Numero passi: %d\n", numPassi);
  pianeti = (corpo *) malloc((sizeof(corpo)) * numCorpi);
  memorizzaCorpi(pianeti, numCorpi, "file/input.txt");
  pulisciFile("file/output.txt");
  stampaHeaderFilePosizione("file/output.txt", numCorpi, numPassi);
  tin = omp_get_wtime();
  #pragma omp parallel shared(numPassi,numCorpi,pianeti)
  {
    #pragma omp for
    for (i = 0; i < numPassi; i++)
    {
      for (j = 0; j < numCorpi; j++)
      {
        stampaFilePosizione("file/output.txt", pianeti[j]);
      }

      for (k = 0; k < numCorpi; k++)
      {
        for (l = 0; l < numCorpi; l++)
        {
          if (k != l)
          {
            modificaForza(&pianeti[k], pianeti[l]);
          }

        }

      }

      for (j = 0; j < numCorpi; j++)
      {
        modificaVelocita(&pianeti[j], 1);
      }

      for (j = 0; j < numCorpi; j++)
      {
        modificaPosizione(&pianeti[j], 1);
      }

      for (j = 0; j < numCorpi; j++)
      {
        pulisciForza(&pianeti[j]);
      }

    }

  }
  tout = omp_get_wtime();
  printf("Tempo di esecuzione: %lf\n", tout - tin);
  stampaFileTempi("file/exeTime.txt", numCorpi, numPassi, tout - tin);
  free(pianeti);
  system("cp file/output.txt PlotNbodyCApplication/file/outputP1.txt");
  return 0;
}

