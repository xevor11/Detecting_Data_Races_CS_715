void compute_single_region(int n, int *niters)
{
  const int NSAMPLES = data[0].NSAMPLES;
  double NORM = 1.0;
  switch (data[0].restype)
  {
    case RAWDATA:
      NORM = 1.0 / ((double) (NSAMPLES * (NSAMPLES - 1.0)));
      break;

    case JACKDATA:
      NORM = (NSAMPLES - 1.0) / ((double) NSAMPLES);
      break;

    case BOOTDATA:
      NORM = 1.0 / ((double) NSAMPLES);
      break;

  }

  size_t i;
  #pragma omp parallel for private(i)
  for (i = 0; i < NDATA; i++)
  {
    size_t j;
    for (j = 0; j < NDATA; j++)
    {
      correlation[i][j] = 0.0;
    }

  }

  if (diagonal == 1)
  {
    #pragma omp parallel for private(i)
    for (i = 0; i < NDATA; i++)
    {
      register const double ave = data[i].avg;
      register double sum = 0.0;
      size_t k;
      for (k = 0; k < NSAMPLES; k++)
      {
        sum += (data[i].resampled[k] - ave) * (data[i].resampled[k] - ave);
      }

      correlation[i][i] = sum * NORM;
    }

  }
  else
  {
    #pragma omp parallel for private(i)
    for (i = 0; i < NDATA; i++)
    {
      const double avei = data[i].avg;
      size_t j;
      for (j = i; j < NDATA; j++)
      {
        const double avej = data[j].avg;
        register double sum = 0.0;
        size_t k;
        for (k = 0; k < NSAMPLES; k++)
        {
          sum += (data[i].resampled[k] - avei) * (data[j].resampled[k] - avej);
        }

        correlation[i][j] = sum * NORM;
      }

    }

  }

  return;

  double *phi_cur;
  double *phi_next;
  double *tmp;
  int conv;
  int i;
  int j;
  phi_cur = (double *) malloc((n * n) * (sizeof(double)));
  phi_next = (double *) malloc((n * n) * (sizeof(double)));
  init_phi(phi_cur, n);
  init_phi(phi_next, n);
  *niters = 0;
  while (1)
  {
    (*niters)++;
    conv = 1;
    #pragma omp parallel reduction(&&:conv)
    {
      #pragma omp for
      for (j = 1; j < (n - 1); j++)
        for (i = 1; i < (n - 1); i++)
        phi_next[(j * n) + i] = (((phi_cur[((j - 1) * n) + i] + phi_cur[(j * n) + (i - 1)]) + phi_cur[(j * n) + (i + 1)]) + phi_cur[((j + 1) * n) + i]) / 4;


      #pragma omp for
      for (j = 1; j < (n - 1); j++)
        for (i = 1; i < (n - 1); i++)
        if (fabs(phi_next[(j * n) + i] - phi_cur[(j * n) + i]) > 5e-3)
        conv = 0;



    }
    if (conv)
      break;

    tmp = phi_cur;
    phi_cur = phi_next;
    phi_next = tmp;
  }

  free(phi_cur);
  free(phi_next);
}

