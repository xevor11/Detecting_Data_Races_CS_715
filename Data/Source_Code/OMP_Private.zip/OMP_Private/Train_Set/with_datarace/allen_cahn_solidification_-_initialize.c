double inv_delta_x2 = (1.0 / 1.0) * (1.0 / 1.0);
void initialize(double *, double *);
void compute_laplacian(double *, double *);
void update(double *, double *, double *, double *);
void apply_boundary_condt(double *, double *);
void write2file(double *, double *, long);
double compute_surface_energy(double *);
void initialize(double *T, double *phi)
{
  long x;
  long y;
  long index;
  #pragma omp parallel for
  for (index = 0; index < (100 * 100); index++)
  {
    x = index / 100;
    if (x < (100 * 0.33))
    {
      phi[index] = 1.0;
    }
    else
    {
      phi[index] = 0.0;
    }

  }

  #pragma omp parallel for
  for (index = 0; index < (100 * 100); index++)
  {
    T[index] = 1.0;
  }

}

