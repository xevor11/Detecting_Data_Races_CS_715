int **curr;
int **next;
int **tem;
int dx[] = {-1, 0, 1, -1, 1, -1, 0, 1};
int dy[] = {-1, -1, -1, 0, 0, 1, 1, 1};
void change(int row, int col)
{
  int x;
  int y;
  #pragma omp parallel for
  for (x = 0; x < row; x++)
  {
    for (y = 0; y < col; y++)
    {
      int alive = tem[x][y];
      int state = curr[x][y];
      if ((state == 1) && ((alive > 3) || (alive < 2)))
      {
        update_neighbours(x, y, row, col, -1);
        curr[x][y] = 0;
      }
      else
        if ((state == 0) && (alive == 3))
      {
        update_neighbours(x, y, row, col, 1);
        curr[x][y] = 1;
      }


    }

  }

  #pragma omp parallel for
  for (x = 0; x < row; x++)
  {
    for (y = 0; y < col; y++)
    {
      tem[x][y] = next[x][y];
    }

  }

}

