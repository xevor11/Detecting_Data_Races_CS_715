const float epsilon_pp = 0.1;
const float epsilon = 10;
int A_ad_num = 0;
int B_ad_num = 0;
int P1 = 0;
int P2 = 0;
int C_num = 0;
int *list;
int list_size = 0;
int C_tran;
float angle_rand_N[500][2];
int main(void)
{
  int i;
  int *v = (int *) malloc(size * (sizeof(int)));
  unsigned int a = 0;
  if (v == 0)
  {
    printf("Out Of Memory: could not allocate space for the array.\n");
    return 0;
  }

  struct timespec start;
  struct timespec end;
  #pragma omp parallel for schedule(static)
  for (i = 0; i < size; i++)
  {
    v[i] = KISS;
  }

  a = KISS;
  clock_gettime(CLOCK, &start);
  #pragma omp parallel for schedule(static) default(none) shared(a,v,size) private(i)
  for (i = 0; i < size; i++)
  {
    v[i] = a * v[i];
  }

  clock_gettime(CLOCK, &end);
  printf("Scalar product result: %d\n", v[0]);
  elapsed_time_hr(start, end, "Int scalar multiplication.");
  free(v);
  return 0;

  const float dt = 1e-5;
  const float evolu = sqrt(2 * dt);
  const float t = 2e2;
  const int Nstep = ceil(t / dt);
  float D_ad = 1;
  float dt_ad = dt / D_ad;
  float evolu_ad = sqrt(2 * dt_ad);
  int loop = 1;
  int sampling_freq = 1000;
  int i;
  int j;
  int k;
  int l;
  int g;
  int h;
  int o;
  int p;
  int q;
  int m;
  int c;
  int cl;
  int co;
  int target;
  int lcxyz;
  int lcyz;
  int lc[3];
  int mcl[3];
  lc[0] = 2 * 5.5;
  lc[1] = lc[0];
  lc[2] = lc[1];
  lcyz = lc[1] * lc[2];
  lcxyz = lc[0] * lcyz;
  float angle[2];
  int buff_l = 100;
  int ls_buff[buff_l];
  int mc[3];
  int rc[3];
  rc[0] = 1;
  rc[1] = 1;
  rc[2] = 1;
  C_tran = 0;
  int label[500];
  float P_C = 1;
  float r_ad = 2 + (1.1122 * 0.35);
  float r_escape = 2 + (2.5 * 0.35);
  int *ls = malloc(((sizeof(int)) * lcxyz) * buff_l);
  int *head = malloc((sizeof(int)) * lcxyz);
  float *ra = malloc(((sizeof(float)) * 500) * 3);
  float *rb = malloc(((sizeof(float)) * 500) * 3);
  float *r = malloc((sizeof(float)) * 500);
  float *f = malloc(((sizeof(float)) * 500) * 3);
  float r_temp;
  float rd_temp[3];
  float f_buff;
  float fd_buff[3];
  for (g = 0; g < loop; g++)
  {
    l = 0;
    char filename1[128];
    char filename2[128];
    char filename3[128];
    snprintf(filename1, (sizeof(char)) * 128, "traj_%fkT.txt", epsilon);
    FILE *traj;
    traj = fopen(filename1, "w");
    snprintf(filename2, (sizeof(char)) * 128, "particle_num_%fkT.txt", epsilon);
    FILE *particle_num;
    particle_num = fopen(filename2, "w");
    #pragma omp parallel for
    for (i = 0; i < 500; i++)
    {
      if ((i % 2) == 0)
        label[i] = 1;
      else
        label[i] = 2;

    }

    srand(time(0));
    int n_temp = 0;
    int mci[3];
    int lci = 5.5 + 1;
    float lsd = 0.9;
    float ld = 0.5;
    for (mci[0] = 0; mci[0] < ((2 * lci) + 1); mci[0]++)
    {
      for (mci[1] = 0; mci[1] < ((2 * lci) + 1); mci[1]++)
      {
        for (mci[2] = 0; mci[2] < ((2 * lci) + 1); mci[2]++)
        {
          if (n_temp > (500 - 1))
            goto bd;

          for (k = 0; k < 3; k++)
            ra[(n_temp * 3) + k] = (((-1) * lci) + mci[k]) * lsd;

          r[n_temp] = sqrt(dot_product(ra + (n_temp * 3), ra + (n_temp * 3)));
          if ((r[n_temp] < (5.5 - ld)) && (r[n_temp] > (2 + ld)))
          {
            n_temp++;
          }
          else
            continue;

        }

      }

    }

    bd:
    while (l < Nstep)
    {
      memset(f, 0, ((sizeof(float)) * 500) * 3);
      memset(head, 0, (sizeof(int)) * lcxyz);
      memset(ls, -1, ((sizeof(int)) * lcxyz) * buff_l);
      #pragma omp parallel for
      for (i = 0; i < 500; i++)
      {
        int mct[3];
        for (k = 0; k < 3; k++)
          mct[k] = floor(ra[(i * 3) + k] / rc[k]) + 5.5;

        c = ((mct[2] * lcyz) + (mct[1] * lc[0])) + mct[0];
        ls[(c * buff_l) + head[c]] = i;
        head[c]++;
      }

      #pragma parallel for
      for (mc[0] = 0; mc[0] < lc[0]; mc[0]++)
      {
        for (mc[1] = 0; mc[1] < lc[1]; mc[1]++)
        {
          for (mc[2] = 0; mc[2] < lc[2]; mc[2]++)
          {
            c = ((mc[2] * lcyz) + (mc[1] * lc[0])) + mc[0];
            for (mcl[0] = mc[0] - 1; mcl[0] <= (mc[0] + 1); mcl[0]++)
              for (mcl[1] = mc[1] - 1; mcl[1] <= (mc[1] + 1); mcl[1]++)
              for (mcl[2] = mc[2] - 1; mcl[2] <= (mc[2] + 1); mcl[2]++)
            {
              cl = ((((mcl[2] + lc[2]) % lc[2]) * lcyz) + (((mcl[1] + lc[1]) % lc[1]) * lc[2])) + ((mcl[0] + lc[0]) % lc[0]);
              for (o = 0; o < head[c]; o++)
              {
                i = ls[(c * buff_l) + o];
                for (p = 0; p < head[cl]; p++)
                {
                  j = ls[(cl * buff_l) + p];
                  if (i < j)
                  {
                    float LJ_buff;
                    if (((((((((((((((((label[i] == 1) && (label[j] == 5)) || ((label[i] == 5) && (label[j] == 1))) || ((label[i] == 1) && (label[j] == 6))) || ((label[i] == 6) && (label[j] == 1))) || ((label[i] == 2) && (label[j] == 5))) || ((label[i] == 5) && (label[j] == 2))) || ((label[i] == 2) && (label[j] == 6))) || ((label[i] == 6) && (label[j] == 2))) || ((label[i] == 3) && (label[j] == 5))) || ((label[i] == 5) && (label[j] == 3))) || ((label[i] == 3) && (label[j] == 6))) || ((label[i] == 6) && (label[j] == 3))) || ((label[i] == 4) && (label[j] == 5))) || ((label[i] == 5) && (label[j] == 4))) || ((label[i] == 4) && (label[j] == 6))) || ((label[i] == 6) && (label[j] == 4)))
                    {
                      LJ_buff = 0;
                      for (k = 0; k < 3; k++)
                        rd_temp[k] = 0;

                    }
                    else
                    {
                      for (k = 0; k < 3; k++)
                        rd_temp[k] = ra[(i * 3) + k] - ra[(j * 3) + k];

                      r_temp = sqrt(dot_product(rd_temp, rd_temp));
                      LJ_buff = LJ(r_temp, epsilon_pp);
                    }

                    for (k = 0; k < 3; k++)
                    {
                      fd_buff[k] = LJ_buff * rd_temp[k];
                      f[(i * 3) + k] += fd_buff[k];
                      f[(j * 3) + k] -= fd_buff[k];
                    }

                  }

                }

              }

            }



          }

        }

      }

      #pragma omp parallel for
      for (j = 0; j < 500; j++)
      {
        switch (label[j])
        {
          case 1:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt)) + (evolu * randn(0, 1));

            break;

          case 2:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt)) + (evolu * randn(0, 1));

            break;

          case 3:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt_ad)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt_ad)) + (evolu_ad * randn(0, 1));

            break;

          case 4:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt_ad)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt_ad)) + (evolu_ad * randn(0, 1));

            break;

          case 5:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt)) + (evolu * randn(0, 1));

            break;

          case 6:
            for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ((ra[(j * 3) + k] + (f[(j * 3) + k] * dt)) + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt)) + (evolu * randn(0, 1));

            break;

        }

        r[j] = sqrt(dot_product(rb + (j * 3), rb + (j * 3)));
        if (r[j] > 5.5)
        {
          if ((label[j] == 5) || (label[j] == 6))
          {
            int scan = 0;
            int mcx[3];
            for (k = 0; k < 3; k++)
              mcx[k] = floor(ra[(j * 3) + k] / rc[k]) + 5.5;

            co = ((mcx[2] * lcyz) + (mcx[1] * lc[0])) + mcx[0];
            for (h = 0; h < buff_l; h++)
            {
              if (ls[(co * buff_l) + h] == j)
              {
                target = h;
                break;
              }

            }

            for (k = 0; k < 3; k++)
              rb[(j * 3) + k] = ra[(j * 3) + k];

            r[j] = sqrt(dot_product(rb + (j * 3), rb + (j * 3)));
            memcpy(ls_buff, ((ls + (co * buff_l)) + target) + 1, (sizeof(int)) * (head[co] - (target + 1)));
            memcpy((ls + (co * buff_l)) + target, ls_buff, (sizeof(int)) * (head[co] - (target + 1)));
            head[co]--;
            memset((ls + (co * buff_l)) + head[co], -1, (sizeof(int)) * (buff_l - head[co]));
            reinsert:
            ;

            if (scan == 1)
            {
              angle[0] = ((2 * 3.141593) * ((double) rand())) / 32767;
              angle[1] = acos(((2 * ((double) rand())) / 32767) - 1);
              rb[j * 3] = (5.5 * sin(angle[0])) * cos(angle[1]);
              rb[(j * 3) + 1] = (5.5 * sin(angle[0])) * sin(angle[1]);
              rb[(j * 3) + 2] = 5.5 * cos(angle[0]);
              ls[((c * buff_l) + head[c]) - 1] = -1;
              head[c]--;
            }

            for (k = 0; k < 3; k++)
              mc[k] = floor(rb[(j * 3) + k] / rc[k]) + 5.5;

            c = ((mc[2] * lcyz) + (mc[1] * lc[0])) + mc[0];
            head[c]++;
            ls[((c * buff_l) + head[c]) - 1] = j;
            for (mcl[0] = mc[0] - 1; mcl[0] <= (mc[0] + 1); mcl[0]++)
              for (mcl[1] = mc[1] - 1; mcl[1] <= (mc[1] + 1); mcl[1]++)
              for (mcl[2] = mc[2] - 1; mcl[2] <= (mc[2] + 1); mcl[2]++)
            {
              cl = ((((mcl[2] + lc[2]) % lc[2]) * lcyz) + (((mcl[1] + lc[1]) % lc[1]) * lc[2])) + ((mcl[0] + lc[0]) % lc[0]);
              scan = 1;
              for (p = 0; p < head[cl]; p++)
              {
                q = ls[(cl * buff_l) + p];
                if (q == j)
                  continue;
                else
                {
                  for (k = 0; k < 3; k++)
                    rd_temp[k] = rb[(j * 3) + k] - rb[(q * 3) + k];

                  r_temp = sqrt(dot_product(rd_temp, rd_temp));
                  if (r_temp < 0.35)
                  {
                    goto reinsert;
                  }

                }

              }

            }



            relabel:
            ;

            switch (label[j])
            {
              case 5:
                label[j] = 1;
                P1--;
                break;

              case 6:
                label[j] = 2;
                P2--;
                break;

            }

          }
          else
          {
            for (k = 0; k < 3; k++)
              rb[(j * 3) + k] = ra[(j * 3) + k];

          }

        }

        switch (label[j])
        {
          case 1:
            if (r[j] < r_ad)
          {
            label[j] = 3;
            A_ad_num++;
          }

            break;

          case 2:
            if (r[j] < r_ad)
          {
            label[j] = 4;
            B_ad_num++;
          }

            break;

          case 3:
            if (r[j] > r_escape)
          {
            label[j] = 1;
            A_ad_num--;
            P1++;
          }

            break;

          case 4:
            if (r[j] > r_escape)
          {
            label[j] = 2;
            B_ad_num--;
            P2++;
          }

            break;

        }

      }

      for (i = 0; i < 500; i++)
      {
        if ((label[i] == 3) || (label[i] == 4))
        {
          int mct[3];
          for (k = 0; k < 3; k++)
            mct[k] = floor(rb[(i * 3) + k] / rc[k]) + 5.5;

          for (mcl[0] = mct[0] - 1; mcl[0] <= (mct[0] + 1); mcl[0]++)
            for (mcl[1] = mct[1] - 1; mcl[1] <= (mct[1] + 1); mcl[1]++)
            for (mcl[2] = mct[2] - 1; mcl[2] <= (mct[2] + 1); mcl[2]++)
          {
            cl = ((((mcl[2] + lc[2]) % lc[2]) * lcyz) + (((mcl[1] + lc[1]) % lc[1]) * lc[2])) + ((mcl[0] + lc[0]) % lc[0]);
            for (p = 0; p < head[cl]; p++)
            {
              j = ls[(cl * buff_l) + p];
              if (((label[i] == 3) && (label[j] == 4)) || ((label[i] == 4) && (label[j] == 3)))
              {
                for (k = 0; k < 3; k++)
                  rd_temp[k] = rb[(i * 3) + k] - rb[(j * 3) + k];

                r_temp = sqrt(dot_product(rd_temp, rd_temp));
                if ((r_temp < (1.1122 * 0.35)) && ((((float) rand()) / 32767) <= P_C))
                {
                  C_tran++;
                  switch (label[i])
                  {
                    case 3:
                      label[i] = 5;
                      label[j] = 6;
                      A_ad_num--;
                      B_ad_num--;
                      P1++;
                      P2++;
                      break;

                    case 4:
                      label[i] = 6;
                      label[j] = 5;
                      A_ad_num--;
                      B_ad_num--;
                      P1++;
                      P2++;
                      break;

                  }

                }

              }

            }

          }



        }

      }

      if ((l % sampling_freq) == 0)
      {
        for (j = 0; j < 500; j++)
          r[j] = sqrt(dot_product(rb + (j * 3), rb + (j * 3)));

        fprintf(traj, "%d\n\n", 500);
        for (j = 0; j < 500; j++)
          fprintf(traj, "type%d %f %f %f id=%d> \n", label[j], rb[j * 3], rb[(j * 3) + 1], rb[(j * 3) + 2], j);

      }

      if ((l % 10) == 0)
        fprintf(particle_num, "%d %d %d %d %d\n", A_ad_num, B_ad_num, C_tran, P1, P2);

      memcpy(ra, rb, (500 * (sizeof(float))) * 3);
      l++;
    }


    fclose(traj);
    fclose(particle_num);
  }

  free(ls);
  free(head);
  free(ra);
  free(rb);
  free(r);
  free(f);
  return 0;
}

