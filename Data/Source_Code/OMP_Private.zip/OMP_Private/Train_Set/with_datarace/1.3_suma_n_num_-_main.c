int main(int argc, char **argv)
{
  int opt;
  int nflag;
  int num;
  int i;
  int j;
  int k;
  double c;
  double **eqns;
  double *ans;
  double sum;
  srand48(time(0));
  while ((opt = getopt(argc, argv, "n:")) != (-1))
  {
    switch (opt)
    {
      case 'n':
        num = atoi(optarg);
        nflag = 1;
        break;

      case '?':
        if (optopt == 'n')
        printf("Need an argument for -%c\n", optopt);
      else
        if (isprint(optopt))
        printf("Unknown option '-%c'\n", optopt);
      else
        printf("What's going on here?\n");


        return 1;

      default:
        abort();

    }

  }

  if (nflag != 1)
    num = 10;

  eqns = (double **) malloc(num * (sizeof(double *)));
  ans = (double *) malloc(num * (sizeof(double)));
  for (i = 0; i < num; i++)
  {
    eqns[i] = (double *) malloc((num + 1) * (sizeof(double)));
    for (j = 0; j < (num + 1); j++)
    {
      eqns[i][j] = drand48();
    }

  }

  printf("The system of equations is written in matrix form as:\n");
  for (i = 0; i < num; i++)
  {
    for (j = 0; j < (num + 1); j++)
    {
      printf("%f ", eqns[i][j]);
    }

    printf("\n");
  }

  printf("\n");
  for (i = 0; i < num; i++)
  {
    #pragma omp parallel for private(j,k) schedule(dynamic,1)
    for (j = 0; j < num; j++)
    {
      if (j > i)
      {
        c = eqns[j][i] / eqns[i][i];
        for (k = 0; k < (num + 1); k++)
        {
          eqns[j][k] = eqns[j][k] - (c * eqns[i][k]);
        }

      }

    }

  }

  for (i = 0; i < num; i++)
  {
    for (j = 0; j < (num + 1); j++)
    {
      printf("%f ", eqns[i][j]);
    }

    printf("\n");
  }

  printf("\n");
  ans[num - 1] = eqns[num - 1][num] / eqns[num - 1][num - 1];
  for (i = num - 2; i >= 0; i--)
  {
    sum = 0;
    for (j = i + 1; j < num; j++)
    {
      sum += eqns[i][j] * ans[j];
    }

    ans[i] = (eqns[i][num] - sum) / eqns[i][i];
  }

  printf("The solution to the system of equations is:\n");
  for (i = 0; i < num; i++)
    printf("%f\n", ans[i]);

  return 0;

  int v[5];
  int i;
  int suma;
  for (i = 0; i < 5; i++)
  {
    v[i] = i;
  }

  omp_set_num_threads(4);
  printf("Private\n");
  #pragma omp parallel
  {
    suma = 0;
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nShared\n");
  #pragma omp parallel shared(suma)
  {
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nIf\n");
  #pragma omp parallel if(suma < 10)
  {
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nFirstprivate\n");
  #pragma omp parallel firstprivate(suma)
  {
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nParallel reduction\n");
  #pragma omp parallel
  {
    #pragma omp for reduction(+:suma)
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nParallel for con nowait\n");
  #pragma omp parallel shared(suma)
  {
    #pragma omp for nowait
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  printf("\nParallel for sin nowait\n");
  #pragma omp parallel shared(suma)
  {
    #pragma omp for
    for (i = 0; i < 5; i++)
    {
      suma += v[i];
    }

    printf("Hilo %d. Suma %d\n", omp_get_thread_num(), suma);
  }
  return 0;
}

