int main(int argc, char *argv[])
{
  struct timespec start_e2e;
  struct timespec end_e2e;
  struct timespec start_alg;
  struct timespec end_alg;
  struct timespec e2e;
  struct timespec alg;
  clock_gettime(CLOCK_MONOTONIC, &start_e2e);
  if (argc < 3)
  {
    printf("Usage: %s n p\np=0 for serial code.", argv[0]);
    return -1;
  }

  char *problem_name = "matrix_multiplication";
  char *approach_name = "middle";
  int n = atoi(argv[1]);
  int nthr = atoi(argv[2]);
  char *fname = argv[3];
  FILE *fp;
  FILE *fpo;
  fp = fopen(fname, "r");
  fpo = fopen("output.txt", "w");
  char buffer[10];
  int i;
  int j;
  int k;
  double **mat1 = (double **) malloc(n * (sizeof(double *)));
  for (i = 0; i < n; i++)
    mat1[i] = (double *) malloc(n * (sizeof(double)));

  double **mat2 = (double **) malloc(n * (sizeof(double *)));
  for (i = 0; i < n; i++)
    mat2[i] = (double *) malloc(n * (sizeof(double)));

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      fscanf(fp, "%s", buffer);
      mat1[i][j] = atof(buffer);
    }

  }

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      fscanf(fp, "%s", buffer);
      mat2[i][j] = atof(buffer);
    }

  }

  double **product = (double **) malloc(n * (sizeof(double *)));
  double x;
  for (i = 0; i < n; i++)
    product[i] = (double *) malloc(n * (sizeof(double)));

  clock_gettime(CLOCK_MONOTONIC, &start_alg);
  for (i = 0; i < n; i++)
  {
    #pragma omp parallel for num_threads(nthr) schedule(static,4)
    for (j = 0; j < n; j++)
    {
      x = 0;
      for (k = 0; k < n; k++)
      {
        x += mat1[i][k] * mat2[k][j];
      }

      product[i][j] = x;
    }

  }

  clock_gettime(CLOCK_MONOTONIC, &end_alg);
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
      fprintf(fpo, "%.6f ", product[i][j]);

    fprintf(fpo, "\n");
  }

  for (i = 0; i < n; i++)
  {
    free(mat1[i]);
    free(mat2[i]);
    free(product[i]);
  }

  free(mat1);
  free(mat2);
  fclose(fp);
  fclose(fpo);
  clock_gettime(CLOCK_MONOTONIC, &end_e2e);
  e2e = diff(start_e2e, end_e2e);
  alg = diff(start_alg, end_alg);
  printf("%s,%s,%d,%d,%d,%ld,%d,%ld\n", problem_name, approach_name, n, nthr, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
  return 0;
}

