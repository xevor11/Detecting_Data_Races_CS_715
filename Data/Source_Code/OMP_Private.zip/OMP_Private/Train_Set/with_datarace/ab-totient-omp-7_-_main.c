int main(int argc, char **argv)
{
  long lower;
  long upper;
  sscanf(argv[1], "%ld", &lower);
  sscanf(argv[2], "%ld", &upper);
  int i;
  long result = 0.0;
  if (lower == 1)
  {
    result = 1.0;
    lower = 2;
  }

  #pragma omp parallel for default(shared) schedule(auto) reduction(+:result) num_threads(7)
  for (i = lower; i <= upper; i++)
  {
    result = result + getTotient(i);
  }

  printf("Sum of Totients between [%ld..%ld] is %ld \n", lower, upper, result);
  return 0;
}

