void papi_print_helper(const char *msg, long long *values);
void compare(int n, double wref[n], double w[n]);
double m[4096][4096];
double x[4096];
double y[4096];
double z[4096];
double yy[4096];
double zz[4096];
int main(int argc, char *argv[])
{
  int nThreads;
  double rtclock(void);
  double clkbegin;
  double clkend;
  double t1;
  double t2;
  int i;
  int j;
  int t;
  if (argc != 2)
  {
    printf("Number of threads not specified\n");
    exit(-1);
  }

  nThreads = atoi(argv[1]);
  if (nThreads <= 0)
  {
    printf("Num threads <= 0\n");
    exit(-1);
  }

  printf("Num threads = %d\n", nThreads);
  omp_set_num_threads(nThreads);
  printf("Matrix Size = %d\n", 4096);
  for (i = 0; i < 4096; i++)
  {
    x[i] = 1.0 / (i + 1);
    y[i] = (z[i] = 0.0);
    for (j = 0; j < 4096; j++)
    {
      m[i][j] = drand48();
    }

  }

  t1 = rtclock();
  for (t = 0; t < 10; t++)
  {
    for (i = 0; i < 4096; i++)
      for (j = 0; j < 4096; j++)
    {
      y[j] = y[j] + (m[i][j] * x[i]);
      z[j] = z[j] + (m[j][i] * x[i]);
    }


    for (i = 0; i < 4096; i++)
    {
      x[i] += 1e-8;
    }

  }

  t2 = rtclock();
  printf("Base version: %.2f GFLOPs; Time = %.2f\n", (((4.0e-9 * 10) * 4096) * 4096) / (t2 - t1), t2 - t1);
  for (i = 0; i < 4096; i++)
  {
    x[i] = 1.0 / (i + 1);
    yy[i] = y[i];
    zz[i] = z[i];
    y[i] = (z[i] = 0.0);
  }

  omp_set_num_threads(nThreads);
  t1 = rtclock();
  #pragma omp parallel
  {
    int num_threads = omp_get_num_threads();
    int thread_id = omp_get_thread_num();
    double block_size_dbl = 4096 / ((double) num_threads);
    int block_size = ceil(block_size_dbl);
    for (t = 0; t < 10; t++)
    {
      for (i = 0; i < 4096; i++)
        for (j = thread_id * block_size; (j < ((thread_id + 1) * block_size)) && (j < 4096); j++)
      {
        y[j] = y[j] + (m[i][j] * x[i]);
      }


      for (j = thread_id * block_size; (j < ((thread_id + 1) * block_size)) && (j < 4096); j++)
        for (i = 0; i < 4096; i++)
      {
        z[j] = z[j] + (m[j][i] * x[i]);
      }


      #pragma omp barrier
      for (i = thread_id * block_size; (i < ((thread_id + 1) * block_size)) && (i < 4096); i++)
      {
        x[i] += 1e-8;
      }

      #pragma omp barrier
    }

  }
  t2 = rtclock();
  printf("Optimized version: %.2f GFLOPs; Time = %.2f\n", (((4.0e-9 * 10) * 4096) * 4096) / (t2 - t1), t2 - t1);
  printf("Comparing y: ");
  compare(4096, yy, y);
  printf("Comparing z: ");
  compare(4096, zz, z);
}

