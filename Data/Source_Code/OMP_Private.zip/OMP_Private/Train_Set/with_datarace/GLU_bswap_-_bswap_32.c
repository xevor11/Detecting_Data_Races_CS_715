void bswap_32(const int n, void *u)
{
  char *key = (char *) keys;
  int i;
  int j;
  int k;
  int index;
  int start;
  int end;
  int middle;
  int blks = 2;
  int lsize = 1;
  int rsize = 1;
  int groups = n / blks;
  char *larr;
  char *rarr;
  while (groups > 0)
  {
    #pragma omp parallel
    {
      #pragma omp for private(end, middle, index, i, j, k, larr, rarr)
      for (start = 0; start <= (n - blks); start += blks)
      {
        char *larr = (char *) calloc(blks, (sizeof(char)) * size);
        char *rarr = (char *) calloc(blks, (sizeof(char)) * size);
        end = start + blks;
        middle = (start + end) / 2;
        index = 0;
        for (i = start; i < middle; i++)
          memcpy(&larr[(index++) * size], &key[i * size], size);

        index = 0;
        for (i = middle; i < end; i++)
          memcpy(&rarr[(index++) * size], &key[i * size], size);

        i = (j = 0);
        k = start;
        while ((i < lsize) && (j < rsize))
        {
          if (compare(&larr[i * size], &rarr[j * size]) < 0)
            memcpy(&key[(k++) * size], &larr[(i++) * size], size);
          else
            memcpy(&key[(k++) * size], &rarr[(j++) * size], size);

        }

        while (i < lsize)
          memcpy(&key[(k++) * size], &larr[(i++) * size], size);

        while (j < rsize)
          memcpy(&key[(k++) * size], &rarr[(j++) * size], size);

        free(larr);
        free(rarr);
      }

    }
    rsize = (lsize = blks);
    blks = blks * 2;
    groups = n / blks;
  }


  uint32_t *T = u;
  int i;
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    *(T + i) = SwapByteOrder_32(*(T + i));
  }

  return;
}

