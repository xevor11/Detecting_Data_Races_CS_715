int main()
{
  int i;
  int n = 9;
  #pragma omp parallel default(none) shared(n)
  {
    #pragma omp for
    for (i = 0; i < n; i++)
      printf("El hilo %d ejecuta la iteracion %d\n", 0, i);

  }
  return 0;
}

