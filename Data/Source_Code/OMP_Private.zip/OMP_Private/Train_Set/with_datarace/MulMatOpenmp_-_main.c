void ini_mat(double **a, double **b, double **c);
int main(int argc, char *argv[])
{
  int tid;
  int nthreads;
  int i;
  int j;
  int k;
  int chunk;
  double startT;
  double stopT;
  double **a;
  double **b;
  double **c;
  int nt = 4;
  int p;
  if (isdigit(argv[1]))
  {
    p = atoi(argv[1]);
    if ((p < 1) || (p > 20))
      printf("# of threads should be between 1 and 20 - it runs 4 threads -> default");
    else
      nt = p;

  }

  omp_set_num_threads(nt);
  a = (double **) malloc(1000 * (sizeof(double *)));
  b = (double **) malloc(1000 * (sizeof(double *)));
  c = (double **) malloc(1000 * (sizeof(double *)));
  for (i = 0; i < 1000; i++)
  {
    a[i] = (double *) malloc(1000 * (sizeof(double)));
    b[i] = (double *) malloc(1000 * (sizeof(double)));
    c[i] = (double *) malloc(1000 * (sizeof(double)));
  }

  chunk = 10;
  printf("Initializing matrix\n");
  ini_mat(a, b, c);
  startT = clock();
  #pragma omp parallel shared(a,b,c,nthreads,chunk)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Starting matrix multiple with %d threads\n", nthreads);
    }

    printf("Thread %d starting matrix multiply...\n", tid);
    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 1000; i++)
    {
      for (j = 0; j < 1000; j++)
        for (k = 0; k < 1000; k++)
        c[i][j] += a[i][k] * b[k][j];


    }

  }
  stopT = clock();
  printf("%d processors; %f secs\n", nthreads, (stopT - startT) / CLOCKS_PER_SEC);
  return 0;
}

