struct object3D *object_list;
struct textureNode *texture_list;
unsigned long int NUM_RAYS;
int MAX_DEPTH;
int main(int argc, char *argv[])
{
  struct image *im;
  struct view *cam;
  int sx;
  int num_samples;
  char output_name[1024];
  struct point3D e;
  struct point3D g;
  struct point3D up;
  double du;
  double dv;
  struct point3D pc;
  struct point3D d;
  struct ray3D *ray;
  struct colourRGB col;
  int i;
  int j;
  int k;
  double *rgbIm;
  struct object3D *obj;
  double *wght;
  double pct;
  double wt;
  time_t t1;
  time_t t2;
  FILE *f;
  if (argc < 5)
  {
    fprintf(stderr, "PathTracer: Can not parse input parameters\n");
    fprintf(stderr, "USAGE: PathTracer size rec_depth num_samples output_name\n");
    fprintf(stderr, "   size = Image size (both along x and y)\n");
    fprintf(stderr, "   rec_depth = Recursion depth\n");
    fprintf(stderr, "   num_samples = Number of samples per pixel\n");
    fprintf(stderr, "   output_name = Name of the output file, e.g. MyRender.ppm\n");
    exit(0);
  }

  sx = atoi(argv[1]);
  MAX_DEPTH = atoi(argv[2]);
  num_samples = atoi(argv[3]);
  strcpy(&output_name[0], argv[4]);
  fprintf(stderr, "Rendering image at %d x %d\n", sx, sx);
  fprintf(stderr, "Recursion depth = %d\n", MAX_DEPTH);
  fprintf(stderr, "NUmber of samples = %d\n", num_samples);
  fprintf(stderr, "Output file name: %s\n", output_name);
  object_list = 0;
  texture_list = 0;
  im = newImage(sx, sx);
  wght = (double *) calloc(sx * sx, sizeof(double));
  if ((!im) || (!wght))
  {
    fprintf(stderr, "Unable to allocate memory for image\n");
    exit(0);
  }
  else
    rgbIm = (double *) im->rgbdata;

  for (i = 0; i < (sx * sx); i++)
    *(wght + i) = 1.0;

  buildScene();
  e.px = 0;
  e.py = 0;
  e.pz = -15;
  e.pw = 1;
  g.px = 0 - e.px;
  g.py = 0 - e.py;
  g.pz = 0 - e.pz;
  g.pw = 1;
  up.px = 0;
  up.py = 1;
  up.pz = 0;
  up.pw = 1;
  cam = setupView(&e, &g, &up, -3, -2, 2, 4);
  if (cam == 0)
  {
    fprintf(stderr, "Unable to set up the view and camera parameters. Our of memory!\n");
    cleanup(object_list, texture_list);
    deleteImage(im);
    exit(0);
  }

  du = cam->wsize / (sx - 1);
  dv = (-cam->wsize) / (sx - 1);
  fprintf(stderr, "View parameters:\n");
  fprintf(stderr, "Left=%f, Top=%f, Width=%f, f=%f\n", cam->wl, cam->wt, cam->wsize, cam->f);
  fprintf(stderr, "Camera to world conversion matrix (make sure it makes sense!):\n");
  printmatrix(cam->C2W);
  fprintf(stderr, "World to camera conversion matrix:\n");
  printmatrix(cam->W2C);
  fprintf(stderr, "\n");
  obj = object_list;
  pct = 0;
  while (obj != 0)
  {
    if (obj->isLightSource)
      pct += obj->LSweight;

    obj = obj->next;
  }

  obj = object_list;
  while (obj != 0)
  {
    if (obj->isLightSource)
    {
      obj->LSweight /= pct;
    }

    obj = obj->next;
  }

  fprintf(stderr, "\n");
  NUM_RAYS = 0;
  t1 = time(0);
  fprintf(stderr, "Rendering pass... ");
  for (k = 0; k < num_samples; k++)
  {
    fprintf(stderr, "%d/%d, ", k, num_samples);
    #pragma omp parallel for schedule(dynamic,1)
    for (j = 0; j < sx; j++)
    {
      for (i = 0; i < sx; i++)
      {
        pc.px = cam->wl + ((i + (drand48() - .5)) * du);
        pc.py = cam->wt + ((j + (drand48() - .5)) * dv);
        pc.pz = cam->f;
        pc.pw = 1;
        matVecMult(cam->C2W, &pc);
        memcpy(&d, &pc, sizeof(struct point3D));
        subVectors(&cam->e, &d);
        normalize(&d);
        ray = newRay(&pc, &d);
        if (ray != 0)
        {
          wt = *((wght + i) + (j * sx));
          PathTrace(ray, 1, &col, 0, 1);
          *((rgbIm + ((i + (j * sx)) * 3)) + 0) += col.R * pow(2, -log(wt));
          *((rgbIm + ((i + (j * sx)) * 3)) + 1) += col.G * pow(2, -log(wt));
          *((rgbIm + ((i + (j * sx)) * 3)) + 2) += col.B * pow(2, -log(wt));
          wt += col.R;
          wt += col.G;
          wt += col.B;
          *((wght + i) + (j * sx)) = wt;
          free(ray);
        }

      }

    }

    if ((k % 25) == 0)
      dataOutput(rgbIm, sx, &output_name[0]);

  }

  t2 = time(0);
  fprintf(stderr, "\nDone!\n");
  dataOutput(rgbIm, sx, &output_name[0]);
  fprintf(stderr, "Total number of rays created: %ld\n", NUM_RAYS);
  fprintf(stderr, "Rays per second: %f\n", ((double) NUM_RAYS) / ((double) difftime(t2, t1)));
  cleanup(object_list, texture_list);
  deleteImage(im);
  free(cam);
  free(wght);
  exit(0);
}

