int main(int argc, char *argv[])
{
  float a[2160][2160];
  float b[2160][2160];
  float c[2160][2160];
  int i;
  int j;
  int k;
  float error = 0;
  int numOfThreads = 1;
  int chunk = 10;
  double w0;
  double w1;
  double w2;
  double w3;
  double setupInt;
  double multInt;
  double totalInt;
  double errorInt;
  w0 = omp_get_wtime();
  printf("Parallel Implementation\n");
  if (argc == 2)
    numOfThreads = atoi(argv[1]);
  else
    if (argc == 3)
    numOfThreads = atoi(argv[1]);


  chunk = atoi(argv[2]);
  printf("Number of Threads: %d\n", numOfThreads);
  printf("Static Scheduling, Chunk Size: %d\n", chunk);
  omp_set_num_threads(numOfThreads);
  #pragma omp parallel shared(a,b,c,chunk,error)
  {
    #pragma omp for schedule(static,chunk)
    for (i = 0; i < 2160; i++)
      for (j = 0; j < 2160; j++)
      a[i][j] = ((i + 1.0) * (j + 1.0)) / 2160;


    #pragma omp for schedule(static,chunk)
    for (i = 0; i < 2160; i++)
      for (j = 0; j < 2160; j++)
      b[i][j] = (j + 1.0) / (i + 1.0);


    #pragma omp for schedule(static,chunk)
    for (i = 0; i < 2160; i++)
      for (j = 0; j < 2160; j++)
      c[i][j] = 0;


    w1 = omp_get_wtime();
    #pragma omp for schedule(static,chunk)
    for (i = 0; i < 2160; i++)
      for (j = 0; j < 2160; j++)
      for (k = 0; k < 2160; k++)
      c[i][j] += a[i][k] * b[k][j];



    w2 = omp_get_wtime();
    #pragma omp for reduction(+:error)
    for (i = 0; i < 2160; i++)
      for (j = 0; j < 2160; j++)
      error += abs(c[i][j] - ((i + 1.0) * (j + 1.0)));


  }
  w3 = omp_get_wtime();
  setupInt = w1 - w0;
  multInt = w2 - w1;
  totalInt = w3 - w0;
  errorInt = w3 - w2;
  printf("Total Execution Time:\t%e\n", totalInt);
  printf("Matrix Creation Time:\t%e\n", setupInt);
  printf("Multiplication Time:\t%e\n", multInt);
  printf("Error Checking Time:\t%e\n", errorInt);
  printf("error = %f\n", error);
}

