void main()
{
  int j;
  int k;
  int a;
  #pragma omp parallel num_threads(2)
  {
    #pragma omp for ordered schedule(static,3)
    for (k = 1; k <= 3; k++)
      for (j = 1; j <= 2; j++)
    {
      #pragma omp ordered
      printf("%d %d %d\n", omp_get_thread_num(), k, j);
    }


  }
}

