int main()
{
  int i;
  int n;
  int chunk;
  int a[2];
  int b[2];
  int c[2];
  n = 2;
  chunk = 2;
  for (i = 0; i < n; i++)
  {
    a[i] = i * 2;
    b[i] = i * 3;
  }

  #pragma omp parallel for default(shared) schedule(guided,chunk)
  for (i = 0; i < n; i++)
  {
    c[i] = a[i] + b[i];
    printf("Thread id= %d i=%d,c[%d]=%d\n", omp_get_thread_num(), i, i, c[i]);
  }

}

