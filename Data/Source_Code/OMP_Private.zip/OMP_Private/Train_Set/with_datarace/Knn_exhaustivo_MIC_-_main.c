FILE *Salida;
struct _Elem
{
  printf("argc %d\n", argc);
  int64_t n;
  int64_t num_threads;
  if (argc <= 1)
  {
    n = 1024;
  }

  if (argc <= 2)
  {
    num_threads = 4;
  }
  else
  {
    sscanf(argv[1], "%lld", &n);
    sscanf(argv[2], "%lld", &num_threads);
  }

  printf("n %lld\n", n);
  printf("num_threads %lld (for parallel run)\n", num_threads);
  double t;
  double t1;
  double t2;
  omp_set_num_threads(num_threads);
  t1 = omp_get_wtime();
  double *A = malloc(n * (sizeof(double)));
  double *B = malloc(n * (sizeof(double)));
  if ((A == 0) || (B == 0))
    exit(0);

  int id = omp_get_thread_num();
  uint32_t seed = id;
  #pragma omp parallel for private(id, seed) shared(A, B)
  for (int64_t i = 0; i < n; i++)
  {
    A[i] = ((double) rand_r(&seed)) / ((double) 32767);
    B[i] = A[i];
  }

  t2 = omp_get_wtime();
  t = t2 - t1;
  printf("time to create the lists, in seconds: %g\n", t);
  omp_set_num_threads(1);
  t1 = omp_get_wtime();
  quicksort(A, n);
  t2 = omp_get_wtime();
  t = t2 - t1;
  printf("time to sort   the list, in seconds (seq): %g\n", t);
  omp_set_num_threads(num_threads);
  t1 = omp_get_wtime();
  quicksort_parallel(B, n);
  t2 = omp_get_wtime();
  t = t2 - t1;
  printf("time to sort   the list, in seconds (par): %g\n", t);
  t1 = omp_get_wtime();
  bool ok = 1;
  #pragma omp parallel for shared(ok, A, B)
  for (int64_t i = 0; i < (n - 1); i++)
  {
    ok = ok && (A[i] <= A[i + 1]);
    ok = ok && (A[i] == B[i]);
  }

  t2 = omp_get_wtime();
  t = t2 - t1;
  printf("time to check  the list, in seconds: %g\n", t);
  printf("ok: %d\n", ok);

  double dist;
  int ind;
};
int leedato(double *dato, FILE *file, int DIM, int dimaux);
void copiavalor(double *a, double *b, int DIM, int dimaux);
void scanFile(char *ruta, double **datos, int DIM, int numElement, int dimaux);
void matrixToVector(double **matrix, int num_cols, int num_rows, double *vector);
void inserta2(Elem *heap, Elem *elem, int *n_elem);
void extrae2(Elem *heap, int *n_elem, Elem *elem_extraido);
void popush2(Elem *heap, int *n_elem, Elem *elem);
double topH(Elem *heap, int *n_elem);
double distancia(double *p1, double *p2, int DIM);
int main(int argc, char *argv[])
{
  char *ruta_db;
  char *ruta_queries;
  double **db;
  double **queries;
  double *db_vector;
  double *queries_vector;
  int num_db;
  int num_queries;
  int dim;
  int k;
  int i;
  int j;
  int num_threads;
  int thread_num;
  Elem *answer;
  struct rusage r1;
  struct rusage r2;
  double user_time;
  double sys_time;
  double real_time;
  struct timeval t1;
  struct timeval t2;
  if (argc != 8)
  {
    printf("Error :: Ejecutar como : main.out archivo_BD Num_elem archivo_queries Num_queries dim k nombre_usuario\n");
    return 1;
  }

  ruta_db = (char *) malloc((sizeof(char)) * (strlen(argv[1]) + 1));
  strcpy(ruta_db, argv[1]);
  num_db = atoi(argv[2]);
  ruta_queries = (char *) malloc((sizeof(char)) * (strlen(argv[3]) + 1));
  strcpy(ruta_queries, argv[3]);
  num_queries = atoi(argv[4]);
  int dimaux = 0;
  int add = 0;
  dim = atoi(argv[5]);
  k = atoi(argv[6]);
  char path[256];
  sprintf(path, "/home/%s/Salida.txt", argv[7]);
  printf("%s\n", path);
  int validamod = dim % 16;
  if (validamod != 0)
  {
    if (dim < 16)
    {
      dimaux = 16;
    }
    else
    {
      add = 16 - validamod;
      dimaux = dim + add;
    }

  }
  else
  {
    dimaux = 0;
  }

  fflush(stdout);
  db = (double **) malloc((sizeof(double *)) * num_db);
  for (i = 0; i < num_db; i++)
    db[i] = (double *) malloc((sizeof(double)) * dimaux);

  queries = (double **) malloc((sizeof(double *)) * num_queries);
  for (i = 0; i < num_queries; i++)
    queries[i] = (double *) malloc((sizeof(double)) * dimaux);

  answer = (Elem *) malloc(((sizeof(Elem)) * num_queries) * k);
  scanFile(ruta_db, db, dim, num_db, dimaux);
  scanFile(ruta_queries, queries, dim, num_queries, dimaux);
  db_vector = (double *) _mm_malloc(((sizeof(double)) * dimaux) * num_db, 64);
  for (i = 0; i < (dimaux * num_db); i++)
    db_vector[i] = 0.0;

  if ((((sizeof(double)) * dimaux) * num_queries) < 64)
  {
    queries_vector = (double *) _mm_malloc((sizeof(double)) * 16, 64);
    for (i = 0; i < 16; i++)
      queries_vector[i] = 0.0;

  }
  else
  {
    queries_vector = (double *) _mm_malloc(((sizeof(double)) * dimaux) * num_queries, 64);
    for (i = 0; i < (dimaux * num_queries); i++)
      queries_vector[i] = 0.0;

  }

  matrixToVector(db, dimaux, num_db, db_vector);
  matrixToVector(queries, dimaux, num_queries, queries_vector);
  fflush(stdout);
  getrusage(RUSAGE_SELF, &r1);
  gettimeofday(&t1, 0);
  #pragma offload target(mic:0) in(dim) in(db_vector:length(num_db*dimaux)) in(queries_vector:length(num_queries*dimaux)) out(answer:length(k*num_queries))
  {
    #pragma omp parallel shared(db_vector, num_db, queries_vector, num_queries, dimaux, k, answer, num_threads)
    {
      Elem *heap;
      heap = (Elem *) malloc((sizeof(Elem)) * k);
      #pragma omp master
      {
        num_threads = omp_get_num_threads();
        printf("run with %d threads\n", num_threads);
      }
      #pragma omp barrier
      thread_num = omp_get_thread_num();
      int n_elem;
      Elem e_temp;
      double d;
      for (i = thread_num * dimaux; i < (num_queries * dimaux); i += num_threads * dimaux)
      {
        n_elem = 0;
        for (j = 0; j < k; j++)
        {
          e_temp.dist = distancia(&queries_vector[i], &db_vector[j * dimaux], dimaux);
          e_temp.ind = j;
          inserta2(heap, &e_temp, &n_elem);
        }

        for (j = k; j < num_db; j++)
        {
          d = distancia(&queries_vector[i], &db_vector[j * dimaux], dimaux);
          if (d < topH(heap, &n_elem))
          {
            e_temp.dist = d;
            e_temp.ind = j;
            popush2(heap, &n_elem, &e_temp);
          }

        }

        for (j = 0; j < k; j++)
        {
          extrae2(heap, &n_elem, &e_temp);
          answer[((i / dimaux) * k) + j].ind = e_temp.ind;
          answer[((i / dimaux) * k) + j].dist = e_temp.dist;
        }

      }

      free(heap);
    }
  }
  gettimeofday(&t2, 0);
  getrusage(RUSAGE_SELF, &r2);
  Salida = fopen(path, "w");
  for (i = 0; i < num_queries; ++i)
  {
    fprintf(Salida, "Consulta id:: %d\n", i);
    for (j = 0; j < k; ++j)
    {
      fprintf(Salida, "ind = %d :: dist = %f\n", answer[(i * k) + j].ind, answer[(i * k) + j].dist);
    }

    fprintf(Salida, "---------------------------------\n");
  }

  fclose(Salida);
  user_time = (r2.ru_utime.tv_sec - r1.ru_utime.tv_sec) + ((r2.ru_utime.tv_usec - r1.ru_utime.tv_usec) / 1000000.0);
  sys_time = (r2.ru_stime.tv_sec - r1.ru_stime.tv_sec) + ((r2.ru_stime.tv_usec - r1.ru_stime.tv_usec) / 1000000.0);
  real_time = (t2.tv_sec - t1.tv_sec) + (((double) (t2.tv_usec - t1.tv_usec)) / 1000000);
  printf("\nCPU Time = %lf", sys_time + user_time);
  printf("\nReal Time = %lf\n", real_time);
  return 0;
}

