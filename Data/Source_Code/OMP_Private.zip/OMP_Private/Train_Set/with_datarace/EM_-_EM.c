void EM(int **train_images, int *train_labels, int **test_images, int *test_labels, double mu[K][D], double *pi, double z[N][K])
{
  srand(time(0));
  double normalizationFactor;
  #pragma omp parallel for
  for (int w = 0; w < K; w++)
  {
    normalizationFactor = 0;
    #pragma omp parallel for reduction(+:normalizationFactor)
    for (int g = 0; g < D; g++)
    {
      mu[w][g] = rand() / ((double) 32767);
      normalizationFactor = normalizationFactor + mu[w][g];
    }

    #pragma omp parallel for
    for (int g = 0; g < D; g++)
    {
      mu[w][g] = mu[w][g] / normalizationFactor;
    }

  }

  for (int i = 0; i < 3; i++)
  {
    ExpectationStep(z, pi, mu, train_images);
    MaximizationStep(z, pi, mu, train_images);
  }

}

