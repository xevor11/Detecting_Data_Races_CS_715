{
  int y;
  int x;
} Antena;
{
  int valor;
  int x;
  int y;
} Registro;
int calcular_max(int *mapa, int rows, int cols, Registro *registros, int num_hilos)
{
  int maximo = 0;
  int i;
  int j;
  #pragma omp parallel for shared(mapa,registros) firstprivate(maximo)
  for (i = 0; i < rows; i++)
  {
    for (j = 0; j < cols; j++)
    {
      if (mapa[(i * cols) + j] > maximo)
      {
        maximo = mapa[(i * cols) + j];
        registros[omp_get_thread_num()].x = i;
        registros[omp_get_thread_num()].y = j;
        registros[omp_get_thread_num()].valor = mapa[(i * cols) + j];
      }

    }

  }

  maximo = 0;
  for (i = 0; i < num_hilos; i++)
    if (registros[i].valor > registros[maximo].valor)
    maximo = i;


  registros[num_hilos].valor = registros[maximo].valor;
  registros[num_hilos].x = registros[maximo].x;
  registros[num_hilos].y = registros[maximo].y;
  return registros[num_hilos].valor;
}

