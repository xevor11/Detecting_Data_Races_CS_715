int thread_count;
double Trap(double a, double b, int n);
double f(double x);
double Trap(double a, double b, int n)
{
  double h;
  double x;
  double integral = 0.0;
  int i;
  int k;
  h = (b - a) / n;
  integral += (f(a) + f(b)) / 2.0;
  int NUM_THREADS = thread_count;
  int iteraciones = n;
  int B[NUM_THREADS + 1][(iteraciones / NUM_THREADS) + 1];
  for (i = 0; i < (NUM_THREADS + 1); i++)
    for (k = 0; k < ((iteraciones / NUM_THREADS) + 1); k++)
    B[i][k] = -1;


  #pragma omp parallel for schedule(static,1) default(none) shared(B,a, h, n,thread_count) reduction(+: integral) num_threads(thread_count)
  for (i = 1; i < n; i++)
  {
    B[omp_get_thread_num()][i % thread_count] = i;
    x = a + (i * h);
    integral += f(x);
  }

  for (i = 0; i < NUM_THREADS; i++)
  {
    printf("\nThread %d = ", i);
    for (k = 0; k < ((iteraciones / NUM_THREADS) + 1); k++)
      if (B[i][k] > (-1))
      printf(" %d", B[i][k]);


  }

  printf("\n");
  integral = integral * h;
  return integral;
}

