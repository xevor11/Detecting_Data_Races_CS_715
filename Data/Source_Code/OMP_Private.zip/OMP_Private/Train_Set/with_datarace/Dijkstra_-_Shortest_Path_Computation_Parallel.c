struct timeval initial;
struct timeval final;
void Initialize_Array(int *Input_Array, int Value);
void Initialize_Dist_Array(float *Input_Array, float Value);
void Initialize_Graph(float *Graph, float Value);
void Set_Graph_Dist_Random(float *Graph, int *Edges_Per_Vertex);
int32_t Shortest_Distance_Node(float *Node_Shortest_Dist, uint32_t *Completed_Node);
void Shortest_Path_Computation_Serial(float *Graph, float *Node_Shortest_Dist, uint32_t *Parent_Node, uint32_t *Completed_Node, uint32_t Source);
double timetaken();
int32_t Shortest_Distance_Node_OPENMP(float *Node_Shortest_Dist, uint32_t *Completed_Node);
void Shortest_Path_Computation_Parallel(float *Graph, float *Node_Shortest_Dist, uint32_t *Parent_Node, uint32_t *Completed_Node, uint32_t Source);
void Shortest_Path_Computation_Parallel(float *Graph, float *Node_Shortest_Dist, uint32_t *Parent_Node, uint32_t *Completed_Node, uint32_t Source)
{
  int i;
  int j;
  int k;
  float sum;
  float matrix_a[200][200];
  float matrix_b[200][200];
  float matrix_c[200][200];
  printf("\nInitializing Matrixes A[%d][%d] , B[%d][%d] ...\n", 200, 200, 200, 200);
  for (i = 0; i < 200; i++)
    for (j = 0; j < 200; j++)
    matrix_a[i][j] = (j * i) % 100;


  for (i = 0; i < 200; i++)
    for (j = 0; j < 200; j++)
    matrix_b[i][j] = (j * i) % 100;


  printf("\nStarting Multiplication MatrixA * MatrixB ...\n");
  double start = omp_get_wtime();
  #pragma omp parallel shared(matrix_a,matrix_b,matrix_c) private(i,j,k)
  {
    for (i = 0; i < 200; i++)
      for (j = 0; j < 200; j++)
    {
      for (k = 0; k < 200; k++)
        sum = sum + (matrix_a[i][k] * matrix_b[k][j]);

      matrix_c[i][j] = sum;
      sum = 0;
    }


  }
  double end = omp_get_wtime();
  printf("\nMultiplication Vector * Matrix has FINISHED\n");
  printf("\nExecution Time = %f\n", end - start);
  return 0;

  Initialize_Array(Parent_Node, (int) (-1));
  Initialize_Array(Completed_Node, (int) 0);
  Initialize_Dist_Array(Node_Shortest_Dist, 10000000);
  Node_Shortest_Dist[Source] = 0;
  uint32_t i;
  uint32_t j;
  for (i = 0; i < 1000; i++)
  {
    int32_t current_node = Shortest_Distance_Node_OPENMP(Node_Shortest_Dist, Completed_Node);
    Completed_Node[current_node] = 1;
    uint32_t new_distance;
    #pragma omp parallel shared(Graph,Node_Shortest_Dist)
    {
      #pragma omp for
      for (j = 0; j < 1000; j++)
      {
        new_distance = Node_Shortest_Dist[current_node] + Graph[(current_node * 1000) + j];
        if (((Completed_Node[j] != 1) && (Graph[(current_node * 1000) + j] != ((float) 0))) && (new_distance < Node_Shortest_Dist[j]))
        {
          Node_Shortest_Dist[j] = new_distance;
          Parent_Node[j] = current_node;
        }

      }

      #pragma omp barrier
    }
  }

}

