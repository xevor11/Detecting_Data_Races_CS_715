const double ACCELERATION = -9.81;
const double VELOCITY_0 = 0.0;
const double FACTOR = 1e6;
const int MPI_TAG = 0;
int main(int argc, char **argv)
{
  int mpi_rank;
  int mpi_size;
  int num_threads;
  double velocity;
  double position;
  int t;
  int i;
  int j;
  int *final_times;
  int ncid;
  int init_pos_dimid;
  int init_pos_varid;
  int final_time_varid;
  int dimids[1];
  size_t start[1];
  size_t count[1];
  int *final_time_out;
  double *init_pos_coords;
  int retval;
  if (MPI_Init(&argc, &argv) != MPI_SUCCESS)
  {
    fprintf(stderr, "Rank %d returned error for %s, exiting!\n", 0, "MPI_Init");
    exit(1);
  }

  ;
  if (MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank) != MPI_SUCCESS)
  {
    fprintf(stderr, "Rank %d returned error for %s, exiting!\n", 0, "MPI_Comm_rank");
    exit(1);
  }

  ;
  if (MPI_Comm_size(MPI_COMM_WORLD, &mpi_size) != MPI_SUCCESS)
  {
    fprintf(stderr, "Rank %d returned error for %s, exiting!\n", mpi_rank, "MPI_Comm_size");
    exit(1);
  }

  ;
  #pragma omp parallel
  {
    #pragma omp single
    {
      num_threads = omp_get_num_threads();
    }
  }
  if ((final_times = malloc(num_threads * (sizeof(int)))) == 0)
  {
    fprintf(stderr, "Rank %d returned error for malloc, exiting!\n", mpi_rank);
    exit(1);
  }

  velocity = VELOCITY_0;
  #pragma omp parallel
  {
    position = FACTOR * ((mpi_rank * num_threads) + omp_get_thread_num());
    while (position > 0)
    {
      velocity += ACCELERATION;
      position += velocity;
      t++;
    }

    final_times[omp_get_thread_num()] = t;
  }
  if (MPI_Send(final_times, num_threads, MPI_INT, 0, MPI_TAG, MPI_COMM_WORLD) != MPI_SUCCESS)
  {
    fprintf(stderr, "Rank %d returned error for %s, exiting!\n", mpi_rank, "MPI_Send");
    exit(1);
  }

  ;
  if (mpi_rank == 0)
  {
    if ((final_time_out = malloc((mpi_size * num_threads) * (sizeof(int)))) == 0)
    {
      fprintf(stderr, "Rank 0 returned error for final_time_out malloc, exiting!\n", mpi_rank);
      exit(1);
    }

    if ((init_pos_coords = malloc((mpi_size * num_threads) * (sizeof(double)))) == 0)
    {
      fprintf(stderr, "Rank 0 returned error for init_pos_coords malloc, exiting!\n", mpi_rank);
      exit(1);
    }

    if (retval = nc_create("accel-data.nc", NC_CLOBBER, &ncid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    if (retval = nc_def_dim(ncid, "initial_position", mpi_size * num_threads, &init_pos_dimid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    if (retval = nc_def_var(ncid, "initial_position", NC_DOUBLE, 1, &init_pos_dimid, &init_pos_varid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    if (retval = nc_put_att_text(ncid, init_pos_varid, "units", strlen("units"), "units"))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    dimids[0] = init_pos_dimid;
    if (retval = nc_def_var(ncid, "final_time", NC_INT, 1, dimids, &final_time_varid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    if (retval = nc_put_att_text(ncid, final_time_varid, "units", strlen("units"), "units"))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    if (retval = nc_enddef(ncid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    for (i = 0; i < mpi_size; i++)
    {
      for (j = 0; j < num_threads; j++)
      {
        init_pos_coords[(i * num_threads) + j] = FACTOR * ((i * num_threads) + j);
      }

    }

    if (retval = nc_put_var_double(ncid, init_pos_varid, &init_pos_coords[0]))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    count[0] = mpi_size * num_threads;
    start[0] = 0;
    for (i = 0; i < mpi_size; i++)
    {
      if (MPI_Recv(final_times, num_threads, MPI_INT, i, MPI_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE) != MPI_SUCCESS)
      {
        fprintf(stderr, "Rank %d returned error for %s, exiting!\n", mpi_rank, "MPI_Recv");
        exit(1);
      }

      ;
      for (j = 0; j < num_threads; j++)
      {
        final_time_out[(i * num_threads) + j] = final_times[j];
        if (retval = nc_put_vara_int(ncid, final_time_varid, start, count, &final_time_out[0]))
        {
          printf("Error: %s\n", nc_strerror(retval));
          exit(1);
        }

        ;
        printf("%f %d\n", FACTOR * ((i * num_threads) + j), final_times[j]);
      }

    }

    if (retval = nc_close(ncid))
    {
      printf("Error: %s\n", nc_strerror(retval));
      exit(1);
    }

    ;
    free(init_pos_coords);
    free(final_time_out);
  }

  free(final_times);
  if (MPI_Finalize() != MPI_SUCCESS)
  {
    fprintf(stderr, "Rank %d returned error for %s, exiting!\n", mpi_rank, "MPI_Finalize");
    exit(1);
  }

  ;
  return 0;
}

