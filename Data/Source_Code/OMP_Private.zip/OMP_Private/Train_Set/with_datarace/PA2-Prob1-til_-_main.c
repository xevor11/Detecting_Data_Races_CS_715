double rtclock();
void compare();
double A[2048][2048];
double B[2048][2048];
double RefOut[2048][2048];
int main()
{
  double clkbegin;
  double clkend;
  double t;
  int nt;
  int maxthr;
  int i;
  int j;
  int k;
  int l;
  printf("Matrix Size = %d\n", 2048);
  for (i = 0; i < 2048; i++)
    for (j = 0; j < 2048; j++)
  {
    A[i][j] = (1.0 * (i + (0.25 * j))) / (2048 + 1);
    B[i][j] = (1.0 * (i - (0.5 * j))) / (2048 + 1);
  }


  clkbegin = rtclock();
  for (i = 0; i < 2048; i++)
    for (j = 0; j < 2048; j++)
    for (k = i; k < 2048; k++)
    B[i][j] += A[i][k] * B[k][j];



  clkend = rtclock();
  t = clkend - clkbegin;
  if ((B[2048 / 2][2048 / 2] * B[2048 / 2][2048 / 2]) < (-1000.0))
    printf("To foil dead-code elimination by compiler: should never get here\n");

  printf("Base Sequential Symm-MatMult: %.1f GFLOPS; Time = %.3f sec; \n", ((((1.0 * 2048) * 2048) * (2048 + 1)) / t) / 1.0e9, t);
  for (i = 0; i < 2048; i++)
    for (j = 0; j < 2048; j++)
    RefOut[i][j] = B[i][j];


  maxthr = omp_get_max_threads();
  printf("Maximum threads allowed by system is: %d\n", maxthr);
  for (nt = 1; nt <= maxthr; nt++)
  {
    printf("\n number of threads:%d\n", nt);
    omp_set_num_threads(nt);
    for (i = 0; i < 2048; i++)
      for (j = 0; j < 2048; j++)
    {
      A[i][j] = (1.0 * (i + (0.25 * j))) / (2048 + 1);
      B[i][j] = (1.0 * (i - (0.5 * j))) / (2048 + 1);
    }


    printf("Requesting thrds=%d\n", nt);
    clkbegin = rtclock();
    int ii;
    int jj;
    int kk;
    #pragma omp parallel
    {
      if ((omp_get_thread_num() == 0) && (omp_get_num_threads() != nt))
        printf("Warning: Actual #threads %d differs from requested number %d\n", omp_get_num_threads(), nt);

      for (ii = 0; ii < 2048; ii = ii + 256)
        for (kk = 0; kk < 2048; kk = kk + 256)
        for (i = ii; i < (ii + 256); i++)
        for (k = (i > kk) ? (i) : (kk); k < (kk + 256); k++)
        #pragma omp for




      for (j = 0; j < 2048; j++)
      {
        B[i][j] += A[i][k] * B[k][j];
      }

    }
    clkend = rtclock();
    t = clkend - clkbegin;
    if ((B[2048 / 2][2048 / 2] * B[2048 / 2][2048 / 2]) < (-1000.0))
      printf("To foil dead-code elimination by compiler: should never get here\n");

    printf("%.1f GFLOPS with %d threads; Time = %.3f sec; \n", ((((1.0 * 2048) * 2048) * (2048 + 1)) / t) / 1.0e9, nt, t);
    compare();
  }

}

