void multiplyMatrix(double **matrixA, double **matrixB, double **matrixC, int rowsA, int colsA, int colsB)
{
  int i;
  int j;
  int k;
  #pragma omp parallel for
  for (i = 0; i < rowsA; i++)
    for (j = 0; j < colsB; j++)
  {
    matrixC[i][j] = 0;
    for (k = 0; k < colsA; k++)
      matrixC[i][j] += matrixA[i][k] * matrixB[k][j];

  }


}

