double min_QR_method(double _alpha[], double _beta[], const int size);
int main(void)
{
  int n;
  int n_temp;
  int i;
  int k;
  int m;
  int NSYSTEM = (2 * 0.5) + 1;
  long int NSTATE = pow(NSYSTEM, 18);
  int NSTATE_2d = pow(NSYSTEM, 18 / 2);
  int nud;
  int ndu;
  int mud;
  int mdu;
  double S1;
  double S2;
  double M;
  double Wud;
  double Wdu;
  long PS1;
  long PS2;
  static long LIST1[5000000];
  static int LIST2a[200000];
  static int LIST2b[200000];
  int ia;
  int ib;
  int ja = 0;
  int jb = 0;
  int pib = -1;
  printf("NSTATE=%ld, NSTATE_2d=%d\n", NSTATE, NSTATE_2d);
  m = 0;
  for (n = 0; n < NSTATE; n++)
  {
    M = 0;
    n_temp = n;
    for (i = 0; i < 18; i++)
    {
      M += (n_temp % NSYSTEM) - 0.5;
      n_temp /= NSYSTEM;
    }

    if (M == 0.0)
    {
      m++;
      ia = n % NSTATE_2d;
      ib = n / NSTATE_2d;
      if (ib == pib)
      {
        ja++;
      }
      else
      {
        jb = jb + ja;
        ja = 1;
        pib = ib;
        LIST2b[ib] = jb;
      }

      LIST2a[ia] = ja;
      LIST1[m] = n;
    }

  }

  int dim_subspace = m;
  printf("dim_subspace = %d\n", dim_subspace);
  static double v0[5000000];
  static double v1[5000000];
  static double v2[5000000];
  static double alpha[300 + 1];
  static double beta[300 + 1];
  double VNORM;
  if (0.5 == 1.0)
  {
    #pragma omp parallel for reduction(+:VNORM)
    for (m = 1; m <= dim_subspace; m++)
    {
      v1[m] = 1.0;
      VNORM += v1[m] * v1[m];
    }

    VNORM = sqrt(VNORM);
    for (m = 1; m <= dim_subspace; m++)
    {
      v1[m] /= VNORM;
    }

  }
  else
  {
    v1[2] = 1;
  }

  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    n_temp = LIST1[m];
    for (i = 1; i < (18 + 1); i++)
    {
      PS1 = pow(NSYSTEM, i - 1);
      S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
      if ((1 == 1) && (i == 18))
      {
        PS2 = 1;
      }
      else
      {
        PS2 = pow(NSYSTEM, i);
      }

      S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
      Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
      Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
      if (Wud < 0.0000001)
      {
        nud = n_temp;
      }
      else
      {
        nud = (n_temp + PS1) - PS2;
      }

      if (Wdu < 0.0000001)
      {
        ndu = n_temp;
      }
      else
      {
        ndu = (n_temp - PS1) + PS2;
      }

      ia = nud % NSTATE_2d;
      ib = nud / NSTATE_2d;
      mud = LIST2a[ia] + LIST2b[ib];
      ia = ndu % NSTATE_2d;
      ib = ndu / NSTATE_2d;
      mdu = LIST2a[ia] + LIST2b[ib];
      v0[m] += (S1 * S2) * v1[m];
      v0[m] += Wud * v1[mud];
      v0[m] += Wdu * v1[mdu];
    }

  }

  alpha[1] = 0;
  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    alpha[1] += v1[m] * v0[m];
  }

  beta[1] = 0;
  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    v2[m] = v0[m] - (alpha[1] * v1[m]);
    beta[1] += v2[m] * v2[m];
  }

  beta[1] = sqrt(beta[1]);
  printf("a[1]=%lf, b[1]=%lf\n", alpha[1], beta[1]);
  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    v2[m] = v2[m] / beta[1];
  }

  int I;
  double E0;
  double Emin = 0;
  double E_before = 0;
  for (I = 2; I < 300; I++)
  {
    for (m = 1; m <= dim_subspace; m++)
    {
      v0[m] = 0;
    }

    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      for (i = 1; i < (18 + 1); i++)
      {
        PS1 = pow(NSYSTEM, i - 1);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        if ((1 == 1) && (i == 18))
        {
          PS2 = 1;
        }
        else
        {
          PS2 = pow(NSYSTEM, i);
        }

        S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
        Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
        Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
        if (Wud < 0.0000001)
        {
          nud = n_temp;
        }
        else
        {
          nud = (n_temp + PS1) - PS2;
        }

        if (Wdu < 0.0000001)
        {
          ndu = n_temp;
        }
        else
        {
          ndu = (n_temp - PS1) + PS2;
        }

        ia = nud % NSTATE_2d;
        ib = nud / NSTATE_2d;
        mud = LIST2a[ia] + LIST2b[ib];
        ia = ndu % NSTATE_2d;
        ib = ndu / NSTATE_2d;
        mdu = LIST2a[ia] + LIST2b[ib];
        v0[m] += (S1 * S2) * v2[m];
        v0[m] += Wud * v2[mud];
        v0[m] += Wdu * v2[mdu];
      }

    }

    alpha[I] = 0;
    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      alpha[I] += v2[m] * v0[m];
    }

    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      v0[m] = (v0[m] - (alpha[I] * v2[m])) - (beta[I - 1] * v1[m]);
      v1[m] = v2[m];
    }

    beta[I] = 0;
    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      beta[I] += v0[m] * v0[m];
    }

    beta[I] = sqrt(beta[I]);
    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      v2[m] = v0[m] / beta[I];
    }

    if (((I % 5) == 0) && (5 < I))
    {
      Emin = min_QR_method(alpha, beta, I);
      printf("Emin = %lf(I=%d)(Emin-E_before=%lf)\n", Emin, I, fabs(Emin - E_before));
      if (fabs(Emin - E_before) < 0.00001)
      {
        E0 = Emin;
        printf("break call(I=%d)\n", I);
        printf("%lf\n", E0);
        break;
      }

      E_before = Emin;
    }

  }

  printf("\nSPIN=%.1f NSITE=%d dim_subspace=%d(SZ=%4.2f)\n", 0.5, 18, dim_subspace, 0.0);
  printf("E0 = %lf\n", E0);
  static double B[5000000];
  static double R[5000000];
  static double PP[5000000];
  static double X[5000000];
  static double XX[5000000];
  static double Y[5000000];
  double alphaj;
  double betaj;
  int II;
  int ii;
  double BNORM;
  double RNORM;
  double RNORM2;
  double XNORM;
  double RP;
  double YP;
  double XB;
  if (0.5 == 1.0)
  {
    #pragma omp parallel for reduction(+:VNORM)
    for (m = 1; m <= dim_subspace; m++)
    {
      v1[m] = 1.0;
      VNORM += v1[m] * v1[m];
    }

    VNORM = sqrt(VNORM);
    for (m = 1; m <= dim_subspace; m++)
    {
      v1[m] /= VNORM;
    }

  }
  else
  {
    v1[2] = 1;
  }

  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    B[m] = v1[m];
  }

  for (II = 1; II <= 300; II++)
  {
    BNORM = 0.0;
    #pragma omp parallel for reduction(+:BNORM)
    for (m = 1; m <= dim_subspace; m++)
    {
      BNORM += B[m] * B[m];
      R[m] = B[m];
      PP[m] = B[m];
      X[m] = 0.0;
    }

    for (ii = 1; ii <= 50; ii++)
    {
      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        Y[m] = (-PP[m]) * E0;
      }

      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        n_temp = LIST1[m];
        for (i = 1; i < (18 + 1); i++)
        {
          PS1 = pow(NSYSTEM, i - 1);
          S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
          if ((1 == 1) && (i == 18))
          {
            PS2 = 1;
          }
          else
          {
            PS2 = pow(NSYSTEM, i);
          }

          S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
          Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
          Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
          if (Wud < 0.0000001)
          {
            nud = n_temp;
          }
          else
          {
            nud = (n_temp + PS1) - PS2;
          }

          if (Wdu < 0.0000001)
          {
            ndu = n_temp;
          }
          else
          {
            ndu = (n_temp - PS1) + PS2;
          }

          ia = nud % NSTATE_2d;
          ib = nud / NSTATE_2d;
          mud = LIST2a[ia] + LIST2b[ib];
          ia = ndu % NSTATE_2d;
          ib = ndu / NSTATE_2d;
          mdu = LIST2a[ia] + LIST2b[ib];
          Y[m] += (S1 * S2) * PP[m];
          Y[m] += Wud * PP[mud];
          Y[m] += Wdu * PP[mdu];
        }

      }

      RP = 0.0;
      YP = 0.0;
      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        RP += PP[m] * R[m];
        YP += PP[m] * Y[m];
      }

      alphaj = RP / YP;
      RNORM = 0.0;
      #pragma omp parallel for reduction(+:RNORM)
      for (m = 1; m <= dim_subspace; m++)
      {
        X[m] += alphaj * PP[m];
        RNORM += R[m] * R[m];
      }

      RNORM2 = 0.0;
      #pragma omp parallel for reduction(+:RNORM2)
      for (m = 1; m <= dim_subspace; m++)
      {
        R[m] += (-alphaj) * Y[m];
        RNORM2 += R[m] * R[m];
      }

      betaj = RNORM2 / RNORM;
      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        PP[m] = R[m] + (betaj * PP[m]);
      }

      if ((sqrt(RNORM2) / sqrt(BNORM)) < 0.00001)
      {
        break;
      }

    }

    XNORM = 0.0;
    #pragma omp parallel for reduction(+:XNORM)
    for (m = 1; m <= dim_subspace; m++)
    {
      XNORM += X[m] * X[m];
    }

    XNORM = sqrt(XNORM);
    XB = 0.0;
    #pragma omp parallel for reduction(+:XB)
    for (m = 1; m <= dim_subspace; m++)
    {
      X[m] /= XNORM;
      XB += X[m] * B[m];
    }

    printf("delta[%d]=%lf\n", II, fabs(fabs(XB) - 1.0));
    if (fabs(fabs(XB) - 1.0) < 0.00001)
    {
      for (m = 1; m <= dim_subspace; m++)
      {
        XX[m] = X[m];
      }

      printf("XB = %lf break(II=%d) \n", XB, II);
      break;
    }

    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      B[m] = X[m];
    }

  }

  Wud = 0;
  #pragma omp parallel for reduction(+:Wud)
  for (m = 1; m <= dim_subspace; m++)
  {
    Wud += XX[m] * XX[m];
  }

  Wud = sqrt(Wud);
  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    XX[m] /= Wud;
  }

  double output_E = 0.0;
  #pragma omp parallel for
  for (m = 1; m <= dim_subspace; m++)
  {
    PP[m] = 0;
  }

  #pragma omp parallel for reduction(+:output_E)
  for (m = 1; m <= dim_subspace; m++)
  {
    n_temp = LIST1[m];
    for (i = 1; i < (18 + 1); i++)
    {
      PS1 = pow(NSYSTEM, i - 1);
      S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
      if ((1 == 1) && (i == 18))
      {
        PS2 = 1;
      }
      else
      {
        PS2 = pow(NSYSTEM, i);
      }

      S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
      Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
      Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
      if (Wud < 0.0000001)
      {
        nud = n_temp;
      }
      else
      {
        nud = (n_temp + PS1) - PS2;
      }

      if (Wdu < 0.0000001)
      {
        ndu = n_temp;
      }
      else
      {
        ndu = (n_temp - PS1) + PS2;
      }

      ia = nud % NSTATE_2d;
      ib = nud / NSTATE_2d;
      mud = LIST2a[ia] + LIST2b[ib];
      ia = ndu % NSTATE_2d;
      ib = ndu / NSTATE_2d;
      mdu = LIST2a[ia] + LIST2b[ib];
      PP[m] += (S1 * S2) * XX[m];
      PP[m] += Wud * XX[mud];
      PP[m] += Wdu * XX[mdu];
    }

    output_E += PP[m] * XX[m];
  }

  printf("\nSPIN=%.1f NSITE=%d dim_subspace=%d(SZ=%4.2f)\n", 0.5, 18, dim_subspace, 0.0);
  printf("E0_Lanczos = %lf\n", E0);
  printf("E0_exp = %lf\n", output_E);
  double Siz_exp[18 + 1] = {0};
  printf("(site,<Siz>)\n");
  for (i = 1; i <= (18 + 1); i++)
  {
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      PS1 = pow(NSYSTEM, i - 1);
      S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
      Siz_exp[i] += (S1 * XX[m]) * XX[m];
    }

    printf("%d, %lf\n", i, Siz_exp[i]);
  }

  printf("(site, <Siz*Si+1z>)\n");
  for (i = 1; i < (18 + 1); i++)
  {
    Siz_exp[i] = 0;
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      PS1 = pow(NSYSTEM, i - 1);
      S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
      if ((1 == 1) && (i == 18))
      {
        PS2 = 1;
      }
      else
      {
        PS2 = PS1 * NSYSTEM;
      }

      S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
      Siz_exp[i] += ((S1 * S2) * XX[m]) * XX[m];
    }

    printf("%d, %lf\n", i, Siz_exp[i]);
  }

  return 0;
}

