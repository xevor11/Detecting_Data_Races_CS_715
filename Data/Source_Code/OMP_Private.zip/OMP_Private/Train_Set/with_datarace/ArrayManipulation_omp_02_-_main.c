int main(int argc, char **argv)
{
  int num_procs;
  int max_threads;
  int thread_id;
  int N = pow(2, 30);
  int array_chunk;
  int array_llimit;
  int array_ulimit;
  int i;
  double A[N];
  double B[N];
  double C[N];
  double wall_time = 0.00;
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  array_chunk = N / max_threads;
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  if (thread_id == 0)
  {
    printf("\n");
    printf("  OpenMP C program to demonstrate parallelization and \n");
    printf("  master-worker division of labor via array manipulation.\n\n");
    printf("  Total number of processors available : %d\n", num_procs);
    printf("  Maximum number of usable threads     : %d\n", max_threads);
    printf("  Size of the array                    : %d\n\n", N);
    for (i = 0; i < N; i++)
    {
      A[i] = i;
      B[i] = i + 1;
      C[i] = 0.00;
    }

  }

  #pragma omp parallel shared(max_threads, N, array_chunk)
  {
    thread_id = omp_get_thread_num();
    array_llimit = thread_id * array_chunk;
    array_ulimit = (array_llimit + array_chunk) - 1;
    for (i = array_llimit; i <= array_ulimit; i++)
    {
      C[i] = A[i] + B[i];
    }

  }
  wall_time = omp_get_wtime() - wall_time;
  if (thread_id == 0)
  {
    printf("\n");
    printf("  Total time taken : %f seconds\n\n", wall_time);
  }

  return 0;
}

