struct elem
{
  double Length;
  double *PolynomA;
  double *PolynomB;
  int MaxOrder;
  int NumIntSteps;
  double BendingAngle;
  double EntranceAngle;
  double ExitAngle;
  double Energy;
  double FringeInt1;
  double FringeInt2;
  double FullGap;
  double h1;
  double h2;
  double *R1;
  double *R2;
  double *T1;
  double *T2;
  double *RApertures;
  double *EApertures;
};
void edge(double *r, double inv_rho, double edge_angle);
void edge_fringe(double *r, double inv_rho, double edge_angle, double fint, double gap);
void edge_fringe2A(double *r, double inv_rho, double edge_angle, double fint, double gap, double h1, double K1);
void edge_fringe2B(double *r, double inv_rho, double edge_angle, double fint, double gap, double h2, double K1);
void ATmultmv(double *r, const double *A);
void ATaddvv(double *r, const double *dr);
void ATdrift6(double *r, double L);
void BndMPoleSymplectic4E2RadPass(double *r, double le, double irho, double *A, double *B, int max_order, int num_int_steps, double entrance_angle, double exit_angle, double fint1, double fint2, double gap, double h1, double h2, double *T1, double *T2, double *R1, double *R2, double *RApertures, double *EApertures, double E0, int num_particles)
{
  int c;
  int m;
  double *r6;
  double SL;
  double L1;
  double L2;
  double K1;
  double K2;
  bool useT1;
  bool useT2;
  bool useR1;
  bool useR2;
  bool useFringe1;
  bool useFringe2;
  SL = le / num_int_steps;
  L1 = SL * 0.6756035959798286638;
  L2 = SL * (-0.1756035959798286639);
  K1 = SL * 1.351207191959657328;
  K2 = SL * (-1.702414383919314656);
  if (T1 == 0)
    useT1 = 0;
  else
    useT1 = 1;

  if (T2 == 0)
    useT2 = 0;
  else
    useT2 = 1;

  if (R1 == 0)
    useR1 = 0;
  else
    useR1 = 1;

  if (R2 == 0)
    useR2 = 0;
  else
    useR2 = 1;

  if ((fint1 == 0) || (gap == 0))
    useFringe1 = 0;
  else
    useFringe1 = 1;

  if ((fint2 == 0) || (gap == 0))
    useFringe2 = 0;
  else
    useFringe2 = 1;

  #pragma omp parallel for if (num_particles > OMP_PARTICLE_THRESHOLD) default(shared) shared(r,num_particles)
  for (c = 0; c < num_particles; c++)
  {
    r6 = r + (c * 6);
    if (!atIsNaN(r6[0]))
    {
      if (useT1)
        ATaddvv(r6, T1);

      if (useR1)
        ATmultmv(r6, R1);

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (useFringe1)
      {
        edge_fringe2A(r6, irho, entrance_angle, fint1, gap, h1, B[1]);
      }
      else
      {
        edge_fringe2A(r6, irho, entrance_angle, 0, 0, h1, B[1]);
      }

      for (m = 0; m < num_int_steps; m++)
      {
        r6 = r + (c * 6);
        ATbendhxdrift6(r6, L1, irho);
        bndthinkickrad(r6, A, B, K1, irho, E0, max_order);
        ATbendhxdrift6(r6, L2, irho);
        bndthinkickrad(r6, A, B, K2, irho, E0, max_order);
        ATbendhxdrift6(r6, L2, irho);
        bndthinkickrad(r6, A, B, K1, irho, E0, max_order);
        ATbendhxdrift6(r6, L1, irho);
      }

      if (useFringe2)
      {
        edge_fringe2B(r6, irho, exit_angle, fint2, gap, h2, B[1]);
      }
      else
      {
        edge_fringe2B(r6, irho, exit_angle, 0, 0, h2, B[1]);
      }

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (useR2)
        ATmultmv(r6, R2);

      if (useT2)
        ATaddvv(r6, T2);

    }

  }

}

