void Set_XC_Grid(int XC_P_switch, int XC_switch, double *Den0, double *Den1, double *Den2, double *Den3, double *Vxc0, double *Vxc1, double *Vxc2, double *Vxc3)
{
  static int firsttime = 1;
  int MN;
  int MN1;
  int MN2;
  int i;
  int j;
  int k;
  int ri;
  int ri1;
  int ri2;
  int i1;
  int i2;
  int j1;
  int j2;
  int k1;
  int k2;
  int n;
  int nmax;
  int Ng1;
  int Ng2;
  int Ng3;
  double den_min = 1.0e-14;
  double Ec_unif[1];
  double Vc_unif[2];
  double Exc[2];
  double Vxc[2];
  double Ex_unif[1];
  double Vx_unif[2];
  double tot_den;
  double ED[2];
  double GDENS[3][2];
  double DEXDD[2];
  double DECDD[2];
  double DEXDGD[3][2];
  double DECDGD[3][2];
  double ***dEXC_dGD;
  double ***dDen_Grid;
  double up_x_a;
  double up_x_b;
  double up_x_c;
  double up_y_a;
  double up_y_b;
  double up_y_c;
  double up_z_a;
  double up_z_b;
  double up_z_c;
  double dn_x_a;
  double dn_x_b;
  double dn_x_c;
  double dn_y_a;
  double dn_y_b;
  double dn_y_c;
  double dn_z_a;
  double dn_z_b;
  double dn_z_c;
  double up_a;
  double up_b;
  double up_c;
  double dn_a;
  double dn_b;
  double dn_c;
  double tmp0;
  double tmp1;
  double cot;
  double sit;
  double sip;
  double cop;
  double phi;
  double theta;
  double detA;
  double igtv[4][4];
  int numprocs;
  int myid;
  int OMPID;
  int Nthrds;
  MPI_Comm_size(mpi_comm_level1, &numprocs);
  MPI_Comm_rank(mpi_comm_level1, &myid);
  if (XC_switch == 4)
  {
    dDen_Grid = (double ***) malloc((sizeof(double **)) * 2);
    for (k = 0; k <= 1; k++)
    {
      dDen_Grid[k] = (double **) malloc((sizeof(double *)) * 3);
      for (i = 0; i < 3; i++)
      {
        dDen_Grid[k][i] = (double *) malloc((sizeof(double)) * My_NumGridD);
        for (j = 0; j < My_NumGridD; j++)
          dDen_Grid[k][i][j] = 0.0;

      }

    }

    if (XC_P_switch != 0)
    {
      dEXC_dGD = (double ***) malloc((sizeof(double **)) * 2);
      for (k = 0; k <= 1; k++)
      {
        dEXC_dGD[k] = (double **) malloc((sizeof(double *)) * 3);
        for (i = 0; i < 3; i++)
        {
          dEXC_dGD[k][i] = (double *) malloc((sizeof(double)) * My_NumGridD);
          for (j = 0; j < My_NumGridD; j++)
            dEXC_dGD[k][i][j] = 0.0;

        }

      }

    }

    if (firsttime)
    {
      PrintMemory("Set_XC_Grid: dDen_Grid", ((sizeof(double)) * 6) * My_NumGridD, 0);
      PrintMemory("Set_XC_Grid: dEXC_dGD", ((sizeof(double)) * 6) * My_NumGridD, 0);
      firsttime = 0;
    }

    detA = ((((((gtv[1][1] * gtv[2][2]) * gtv[3][3]) + ((gtv[1][2] * gtv[2][3]) * gtv[3][1])) + ((gtv[1][3] * gtv[2][1]) * gtv[3][2])) - ((gtv[1][3] * gtv[2][2]) * gtv[3][1])) - ((gtv[1][2] * gtv[2][1]) * gtv[3][3])) - ((gtv[1][1] * gtv[2][3]) * gtv[3][2]);
    igtv[1][1] = ((gtv[2][2] * gtv[3][3]) - (gtv[2][3] * gtv[3][2])) / detA;
    igtv[2][1] = (-((gtv[2][1] * gtv[3][3]) - (gtv[2][3] * gtv[3][1]))) / detA;
    igtv[3][1] = ((gtv[2][1] * gtv[3][2]) - (gtv[2][2] * gtv[3][1])) / detA;
    igtv[1][2] = (-((gtv[1][2] * gtv[3][3]) - (gtv[1][3] * gtv[3][2]))) / detA;
    igtv[2][2] = ((gtv[1][1] * gtv[3][3]) - (gtv[1][3] * gtv[3][1])) / detA;
    igtv[3][2] = (-((gtv[1][1] * gtv[3][2]) - (gtv[1][2] * gtv[3][1]))) / detA;
    igtv[1][3] = ((gtv[1][2] * gtv[2][3]) - (gtv[1][3] * gtv[2][2])) / detA;
    igtv[2][3] = (-((gtv[1][1] * gtv[2][3]) - (gtv[1][3] * gtv[2][1]))) / detA;
    igtv[3][3] = ((gtv[1][1] * gtv[2][2]) - (gtv[1][2] * gtv[2][1])) / detA;
    #pragma omp parallel shared(My_NumGridD,Min_Grid_Index_D,Max_Grid_Index_D,igtv,dDen_Grid,PCCDensity_Grid_D,PCC_switch,Den0,Den1,Den2,Den3,den_min)
    {
      OMPID = omp_get_thread_num();
      Nthrds = omp_get_num_threads();
      Ng1 = (Max_Grid_Index_D[1] - Min_Grid_Index_D[1]) + 1;
      Ng2 = (Max_Grid_Index_D[2] - Min_Grid_Index_D[2]) + 1;
      Ng3 = (Max_Grid_Index_D[3] - Min_Grid_Index_D[3]) + 1;
      for (MN = OMPID; MN < My_NumGridD; MN += Nthrds)
      {
        i = MN / (Ng2 * Ng3);
        j = (MN - ((i * Ng2) * Ng3)) / Ng3;
        k = (MN - ((i * Ng2) * Ng3)) - (j * Ng3);
        if ((((((i == 0) || (i == (Ng1 - 1))) || (j == 0)) || (j == (Ng2 - 1))) || (k == 0)) || (k == (Ng3 - 1)))
        {
          dDen_Grid[0][0][MN] = 0.0;
          dDen_Grid[0][1][MN] = 0.0;
          dDen_Grid[0][2][MN] = 0.0;
          dDen_Grid[1][0][MN] = 0.0;
          dDen_Grid[1][1][MN] = 0.0;
          dDen_Grid[1][2][MN] = 0.0;
        }
        else
        {
          i1 = i - 1;
          i2 = i + 1;
          j1 = j - 1;
          j2 = j + 1;
          k1 = k - 1;
          k2 = k + 1;
          if (den_min < (Den0[MN] + Den1[MN]))
          {
            MN1 = (((i1 * Ng2) * Ng3) + (j * Ng3)) + k;
            MN2 = (((i2 * Ng2) * Ng3) + (j * Ng3)) + k;
            if (PCC_switch == 0)
            {
              up_a = Den0[MN2] - Den0[MN1];
              dn_a = Den1[MN2] - Den1[MN1];
            }
            else
              if (PCC_switch == 1)
            {
              up_a = ((Den0[MN2] + PCCDensity_Grid_D[MN2]) - Den0[MN1]) - PCCDensity_Grid_D[MN1];
              dn_a = ((Den1[MN2] + PCCDensity_Grid_D[MN2]) - Den1[MN1]) - PCCDensity_Grid_D[MN1];
            }


            MN1 = (((i * Ng2) * Ng3) + (j1 * Ng3)) + k;
            MN2 = (((i * Ng2) * Ng3) + (j2 * Ng3)) + k;
            if (PCC_switch == 0)
            {
              up_b = Den0[MN2] - Den0[MN1];
              dn_b = Den1[MN2] - Den1[MN1];
            }
            else
              if (PCC_switch == 1)
            {
              up_b = ((Den0[MN2] + PCCDensity_Grid_D[MN2]) - Den0[MN1]) - PCCDensity_Grid_D[MN1];
              dn_b = ((Den1[MN2] + PCCDensity_Grid_D[MN2]) - Den1[MN1]) - PCCDensity_Grid_D[MN1];
            }


            MN1 = (((i * Ng2) * Ng3) + (j * Ng3)) + k1;
            MN2 = (((i * Ng2) * Ng3) + (j * Ng3)) + k2;
            if (PCC_switch == 0)
            {
              up_c = Den0[MN2] - Den0[MN1];
              dn_c = Den1[MN2] - Den1[MN1];
            }
            else
              if (PCC_switch == 1)
            {
              up_c = ((Den0[MN2] + PCCDensity_Grid_D[MN2]) - Den0[MN1]) - PCCDensity_Grid_D[MN1];
              dn_c = ((Den1[MN2] + PCCDensity_Grid_D[MN2]) - Den1[MN1]) - PCCDensity_Grid_D[MN1];
            }


            dDen_Grid[0][0][MN] = 0.5 * (((igtv[1][1] * up_a) + (igtv[1][2] * up_b)) + (igtv[1][3] * up_c));
            dDen_Grid[0][1][MN] = 0.5 * (((igtv[2][1] * up_a) + (igtv[2][2] * up_b)) + (igtv[2][3] * up_c));
            dDen_Grid[0][2][MN] = 0.5 * (((igtv[3][1] * up_a) + (igtv[3][2] * up_b)) + (igtv[3][3] * up_c));
            dDen_Grid[1][0][MN] = 0.5 * (((igtv[1][1] * dn_a) + (igtv[1][2] * dn_b)) + (igtv[1][3] * dn_c));
            dDen_Grid[1][1][MN] = 0.5 * (((igtv[2][1] * dn_a) + (igtv[2][2] * dn_b)) + (igtv[2][3] * dn_c));
            dDen_Grid[1][2][MN] = 0.5 * (((igtv[3][1] * dn_a) + (igtv[3][2] * dn_b)) + (igtv[3][3] * dn_c));
          }
          else
          {
            dDen_Grid[0][0][MN] = 0.0;
            dDen_Grid[0][1][MN] = 0.0;
            dDen_Grid[0][2][MN] = 0.0;
            dDen_Grid[1][0][MN] = 0.0;
            dDen_Grid[1][1][MN] = 0.0;
            dDen_Grid[1][2][MN] = 0.0;
          }

        }

      }

      #pragma omp flush(dDen_Grid)
    }
  }

  #pragma omp parallel shared(dDen_Grid,dEXC_dGD,den_min,Vxc0,Vxc1,Vxc2,Vxc3,My_NumGridD,XC_P_switch,XC_switch,Den0,Den1,Den2,Den3,PCC_switch,PCCDensity_Grid_D)
  {
    OMPID = omp_get_thread_num();
    Nthrds = omp_get_num_threads();
    for (MN = OMPID; MN < My_NumGridD; MN += Nthrds)
    {
      switch (XC_switch)
      {
        case 1:
          tot_den = Den0[MN] + Den1[MN];
          if (PCC_switch == 1)
        {
          tot_den += PCCDensity_Grid_D[MN] * 2.0;
        }

          tmp0 = XC_Ceperly_Alder(tot_den, XC_P_switch);
          Vxc0[MN] = tmp0;
          Vxc1[MN] = tmp0;
          break;

        case 2:
          ED[0] = Den0[MN];
          ED[1] = Den1[MN];
          if (PCC_switch == 1)
        {
          ED[0] += PCCDensity_Grid_D[MN];
          ED[1] += PCCDensity_Grid_D[MN];
        }

          XC_CA_LSDA(ED[0], ED[1], Exc, XC_P_switch);
          Vxc0[MN] = Exc[0];
          Vxc1[MN] = Exc[1];
          break;

        case 3:
          ED[0] = Den0[MN];
          ED[1] = Den1[MN];
          if (PCC_switch == 1)
        {
          ED[0] += PCCDensity_Grid_D[MN];
          ED[1] += PCCDensity_Grid_D[MN];
        }

          if ((ED[0] + ED[1]) < den_min)
        {
          Vxc0[MN] = 0.0;
          Vxc1[MN] = 0.0;
        }
        else
        {
          if (XC_P_switch == 0)
          {
            XC_PW92C(ED, Ec_unif, Vc_unif);
            Vxc[0] = Vc_unif[0];
            Vxc[1] = Vc_unif[1];
            Exc[0] = Ec_unif[0];
            XC_EX(1, 2.0 * ED[0], ED, Ex_unif, Vx_unif);
            Vxc[0] = Vxc[0] + Vx_unif[0];
            Exc[1] = (2.0 * ED[0]) * Ex_unif[0];
            XC_EX(1, 2.0 * ED[1], ED, Ex_unif, Vx_unif);
            Vxc[1] += Vx_unif[0];
            Exc[1] += (2.0 * ED[1]) * Ex_unif[0];
            Exc[1] = (0.5 * Exc[1]) / (ED[0] + ED[1]);
            Vxc0[MN] = Exc[0] + Exc[1];
            Vxc1[MN] = Exc[0] + Exc[1];
          }
          else
            if (XC_P_switch == 1)
          {
            XC_PW92C(ED, Ec_unif, Vc_unif);
            Vxc0[MN] = Vc_unif[0];
            Vxc1[MN] = Vc_unif[1];
            XC_EX(1, 2.0 * ED[0], ED, Ex_unif, Vx_unif);
            Vxc0[MN] = Vxc0[MN] + Vx_unif[0];
            XC_EX(1, 2.0 * ED[1], ED, Ex_unif, Vx_unif);
            Vxc1[MN] = Vxc1[MN] + Vx_unif[0];
          }
          else
            if (XC_P_switch == 2)
          {
            XC_PW92C(ED, Ec_unif, Vc_unif);
            Vxc[0] = Vc_unif[0];
            Vxc[1] = Vc_unif[1];
            Exc[0] = Ec_unif[0];
            XC_EX(1, 2.0 * ED[0], ED, Ex_unif, Vx_unif);
            Vxc[0] = Vxc[0] + Vx_unif[0];
            Exc[1] = (2.0 * ED[0]) * Ex_unif[0];
            XC_EX(1, 2.0 * ED[1], ED, Ex_unif, Vx_unif);
            Vxc[1] += Vx_unif[0];
            Exc[1] += (2.0 * ED[1]) * Ex_unif[0];
            Exc[1] = (0.5 * Exc[1]) / (ED[0] + ED[1]);
            Vxc0[MN] = (Exc[0] + Exc[1]) - Vxc[0];
            Vxc1[MN] = (Exc[0] + Exc[1]) - Vxc[1];
          }



        }

          break;

        case 4:
          ED[0] = Den0[MN];
          ED[1] = Den1[MN];
          if ((ED[0] + ED[1]) < den_min)
        {
          Vxc0[MN] = 0.0;
          Vxc1[MN] = 0.0;
          if (XC_P_switch != 0)
          {
            dEXC_dGD[0][0][MN] = 0.0;
            dEXC_dGD[0][1][MN] = 0.0;
            dEXC_dGD[0][2][MN] = 0.0;
            dEXC_dGD[1][0][MN] = 0.0;
            dEXC_dGD[1][1][MN] = 0.0;
            dEXC_dGD[1][2][MN] = 0.0;
          }

        }
        else
        {
          GDENS[0][0] = dDen_Grid[0][0][MN];
          GDENS[1][0] = dDen_Grid[0][1][MN];
          GDENS[2][0] = dDen_Grid[0][2][MN];
          GDENS[0][1] = dDen_Grid[1][0][MN];
          GDENS[1][1] = dDen_Grid[1][1][MN];
          GDENS[2][1] = dDen_Grid[1][2][MN];
          if (PCC_switch == 1)
          {
            ED[0] += PCCDensity_Grid_D[MN];
            ED[1] += PCCDensity_Grid_D[MN];
          }

          XC_PBE(ED, GDENS, Exc, DEXDD, DECDD, DEXDGD, DECDGD);
          if (XC_P_switch == 0)
          {
            Vxc0[MN] = Exc[0] + Exc[1];
            Vxc1[MN] = Exc[0] + Exc[1];
          }
          else
            if (XC_P_switch == 1)
          {
            Vxc0[MN] = DEXDD[0] + DECDD[0];
            Vxc1[MN] = DEXDD[1] + DECDD[1];
          }
          else
            if (XC_P_switch == 2)
          {
            Vxc0[MN] = ((Exc[0] + Exc[1]) - DEXDD[0]) - DECDD[0];
            Vxc1[MN] = ((Exc[0] + Exc[1]) - DEXDD[1]) - DECDD[1];
          }



          if (XC_P_switch != 0)
          {
            dEXC_dGD[0][0][MN] = DEXDGD[0][0] + DECDGD[0][0];
            dEXC_dGD[0][1][MN] = DEXDGD[1][0] + DECDGD[1][0];
            dEXC_dGD[0][2][MN] = DEXDGD[2][0] + DECDGD[2][0];
            dEXC_dGD[1][0][MN] = DEXDGD[0][1] + DECDGD[0][1];
            dEXC_dGD[1][1][MN] = DEXDGD[1][1] + DECDGD[1][1];
            dEXC_dGD[1][2][MN] = DEXDGD[2][1] + DECDGD[2][1];
          }

        }

          break;

        case 5:
          ED[0] = Den0[MN];
          ED[1] = Den1[MN];
          if (PCC_switch == 1)
        {
          ED[0] += PCCDensity_Grid_D[MN];
          ED[1] += PCCDensity_Grid_D[MN];
        }

          EXX_XC_CA_LSDA(ED[0], ED[1], Exc, XC_P_switch);
          Vxc0[MN] = Exc[0];
          Vxc1[MN] = Exc[1];
          break;

      }

    }

    #pragma omp flush(dEXC_dGD)
  }
  if ((XC_switch == 4) && (XC_P_switch != 0))
  {
    #pragma omp parallel shared(My_NumGridD,XC_P_switch,Vxc0,Vxc1,Vxc2,Vxc3,igtv,dEXC_dGD,Den0,Den1,Den2,Den3,den_min)
    {
      OMPID = omp_get_thread_num();
      Nthrds = omp_get_num_threads();
      Ng1 = (Max_Grid_Index_D[1] - Min_Grid_Index_D[1]) + 1;
      Ng2 = (Max_Grid_Index_D[2] - Min_Grid_Index_D[2]) + 1;
      Ng3 = (Max_Grid_Index_D[3] - Min_Grid_Index_D[3]) + 1;
      for (MN = OMPID; MN < My_NumGridD; MN += Nthrds)
      {
        i = MN / (Ng2 * Ng3);
        j = (MN - ((i * Ng2) * Ng3)) / Ng3;
        k = (MN - ((i * Ng2) * Ng3)) - (j * Ng3);
        if ((((((i <= 1) || ((Ng1 - 2) <= i)) || (j <= 1)) || ((Ng2 - 2) <= j)) || (k <= 1)) || ((Ng3 - 2) <= k))
        {
          Vxc0[MN] = 0.0;
          Vxc1[MN] = 0.0;
        }
        else
        {
          i1 = i - 1;
          i2 = i + 1;
          j1 = j - 1;
          j2 = j + 1;
          k1 = k - 1;
          k2 = k + 1;
          if (den_min < (Den0[MN] + Den1[MN]))
          {
            MN1 = (((i1 * Ng2) * Ng3) + (j * Ng3)) + k;
            MN2 = (((i2 * Ng2) * Ng3) + (j * Ng3)) + k;
            up_x_a = dEXC_dGD[0][0][MN2] - dEXC_dGD[0][0][MN1];
            up_y_a = dEXC_dGD[0][1][MN2] - dEXC_dGD[0][1][MN1];
            up_z_a = dEXC_dGD[0][2][MN2] - dEXC_dGD[0][2][MN1];
            dn_x_a = dEXC_dGD[1][0][MN2] - dEXC_dGD[1][0][MN1];
            dn_y_a = dEXC_dGD[1][1][MN2] - dEXC_dGD[1][1][MN1];
            dn_z_a = dEXC_dGD[1][2][MN2] - dEXC_dGD[1][2][MN1];
            MN1 = (((i * Ng2) * Ng3) + (j1 * Ng3)) + k;
            MN2 = (((i * Ng2) * Ng3) + (j2 * Ng3)) + k;
            up_x_b = dEXC_dGD[0][0][MN2] - dEXC_dGD[0][0][MN1];
            up_y_b = dEXC_dGD[0][1][MN2] - dEXC_dGD[0][1][MN1];
            up_z_b = dEXC_dGD[0][2][MN2] - dEXC_dGD[0][2][MN1];
            dn_x_b = dEXC_dGD[1][0][MN2] - dEXC_dGD[1][0][MN1];
            dn_y_b = dEXC_dGD[1][1][MN2] - dEXC_dGD[1][1][MN1];
            dn_z_b = dEXC_dGD[1][2][MN2] - dEXC_dGD[1][2][MN1];
            MN1 = (((i * Ng2) * Ng3) + (j * Ng3)) + k1;
            MN2 = (((i * Ng2) * Ng3) + (j * Ng3)) + k2;
            up_x_c = dEXC_dGD[0][0][MN2] - dEXC_dGD[0][0][MN1];
            up_y_c = dEXC_dGD[0][1][MN2] - dEXC_dGD[0][1][MN1];
            up_z_c = dEXC_dGD[0][2][MN2] - dEXC_dGD[0][2][MN1];
            dn_x_c = dEXC_dGD[1][0][MN2] - dEXC_dGD[1][0][MN1];
            dn_y_c = dEXC_dGD[1][1][MN2] - dEXC_dGD[1][1][MN1];
            dn_z_c = dEXC_dGD[1][2][MN2] - dEXC_dGD[1][2][MN1];
            tmp0 = ((((((((igtv[1][1] * up_x_a) + (igtv[1][2] * up_x_b)) + (igtv[1][3] * up_x_c)) + (igtv[2][1] * up_y_a)) + (igtv[2][2] * up_y_b)) + (igtv[2][3] * up_y_c)) + (igtv[3][1] * up_z_a)) + (igtv[3][2] * up_z_b)) + (igtv[3][3] * up_z_c);
            tmp0 = 0.5 * tmp0;
            tmp1 = ((((((((igtv[1][1] * dn_x_a) + (igtv[1][2] * dn_x_b)) + (igtv[1][3] * dn_x_c)) + (igtv[2][1] * dn_y_a)) + (igtv[2][2] * dn_y_b)) + (igtv[2][3] * dn_y_c)) + (igtv[3][1] * dn_z_a)) + (igtv[3][2] * dn_z_b)) + (igtv[3][3] * dn_z_c);
            tmp1 = 0.5 * tmp1;
            if (XC_P_switch == 1)
            {
              Vxc0[MN] -= tmp0;
              Vxc1[MN] -= tmp1;
            }
            else
              if (XC_P_switch == 2)
            {
              Vxc0[MN] += tmp0;
              Vxc1[MN] += tmp1;
            }


          }

        }

      }

      #pragma omp flush(Vxc0,Vxc1,Vxc2,Vxc3)
    }
  }

  if ((SpinP_switch == 3) && (XC_P_switch != 0))
  {
    #pragma omp parallel shared(Den0,Den1,Den2,Den3,Vxc0,Vxc1,Vxc2,Vxc3,My_NumGridD)
    {
      OMPID = omp_get_thread_num();
      Nthrds = omp_get_num_threads();
      for (MN = OMPID; MN < My_NumGridD; MN += Nthrds)
      {
        tmp0 = 0.5 * (Vxc0[MN] + Vxc1[MN]);
        tmp1 = 0.5 * (Vxc0[MN] - Vxc1[MN]);
        theta = Den2[MN];
        phi = Den3[MN];
        sit = sin(theta);
        cot = cos(theta);
        sip = sin(phi);
        cop = cos(phi);
        Vxc3[MN] = ((-tmp1) * sit) * sip;
        Vxc2[MN] = (tmp1 * sit) * cop;
        Vxc1[MN] = tmp0 - (cot * tmp1);
        Vxc0[MN] = tmp0 + (cot * tmp1);
      }

      #pragma omp flush(Vxc0,Vxc1,Vxc2,Vxc3)
    }
  }

  if (XC_switch == 4)
  {
    for (k = 0; k <= 1; k++)
    {
      for (i = 0; i < 3; i++)
      {
        free(dDen_Grid[k][i]);
      }

      free(dDen_Grid[k]);
    }

    free(dDen_Grid);
    if (XC_P_switch != 0)
    {
      for (k = 0; k <= 1; k++)
      {
        for (i = 0; i < 3; i++)
        {
          free(dEXC_dGD[k][i]);
        }

        free(dEXC_dGD[k]);
      }

      free(dEXC_dGD);
    }

  }

}

