int numthreads;
float ***image;
int cshape[13][4] = {{64, 3, 3, 3}, {64, 64, 3, 3}, {128, 64, 3, 3}, {128, 128, 3, 3}, {256, 128, 3, 3}, {256, 256, 3, 3}, {256, 256, 3, 3}, {512, 256, 3, 3}, {512, 512, 3, 3}, {512, 512, 3, 3}, {512, 512, 3, 3}, {512, 512, 3, 3}, {512, 512, 3, 3}};
float *****wc;
float **bc;
int dshape[3][2] = {{25088, 4096}, {4096, 4096}, {4096, 1000}};
float ***wd;
float **bd;
int mem_block_shape[3] = {512, 224, 224};
float ***mem_block1;
float ***mem_block2;
int mem_block_dense_shape = {(512 * 7) * 7};
float *mem_block1_dense;
float *mem_block2_dense;
void dense(float *in, float **weights, float *out, int sh_in, int sh_out)
{
  int i;
  int j;
  #pragma omp parallel for schedule(dynamic,1) num_threads(numthreads)
  for (i = 0; i < sh_out; i++)
  {
    float sum = 0.0;
    for (j = 0; j < sh_in; j++)
    {
      sum += in[j] * weights[j][i];
    }

    out[i] = sum;
  }

}

