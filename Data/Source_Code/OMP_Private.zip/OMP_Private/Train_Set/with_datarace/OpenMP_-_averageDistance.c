extern int N;
extern double x[1000000];
extern double move();
double averageDistance()
{
  int i;
  double distance;
  distance = 0.0;
  #pragma omp parallel
  {
    #pragma omp for reduction(+: distance)
    for (i = 1; i < N; i++)
    {
      distance += x[i] - x[i - 1];
    }

  }
  distance = distance / (N - 1);
  return distance;
}

