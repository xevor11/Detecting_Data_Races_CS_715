void printMat(float A[1000][1000]);
void initMat(float A[1000][1000]);
int main()
{
  static float A[1000][1000];
  static float B[1000][1000];
  static float C[1000][1000] = {{0}};
  double start_time;
  double end_time;
  start_time = MPI_Wtime();
  int i;
  int j;
  int k;
  initMat(A);
  initMat(B);
  #pragma omp parallel for
  for (i = 0; i < 1000; i++)
  {
    for (j = 0; j < 1000; j++)
    {
      for (k = 0; k < 1000; k++)
      {
        C[i][j] = C[i][j] + (A[i][k] * B[k][j]);
      }

    }

  }

  end_time = MPI_Wtime();
  printf("\n Time taken is %f \n", (float) (end_time - start_time));
  return 0;
}

