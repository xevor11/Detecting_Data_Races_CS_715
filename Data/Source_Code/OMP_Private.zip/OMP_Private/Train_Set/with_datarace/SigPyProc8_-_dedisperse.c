void dedisperse(unsigned char *inbuffer, float *outbuffer, int *delays, int maxdelay, int nchans, int nsamps, int index)
{
  int i;
  int j;
  #pragma omp parallel for num_threads(N_Threads) schedule(dynamic,16) default(none) shared(a,b) private(i,j)
  for (i = 0; i < 729; i++)
  {
    for (j = 729 - 1; j > i; j--)
    {
      a[i][j] += cos(b[i][j]);
    }

  }


  int ii;
  int jj;
  int var1;
  #pragma omp parallel for default(shared)
  for (ii = 0; ii < (nsamps - maxdelay); ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[index + ii] += inbuffer[((ii * nchans) + (delays[jj] * nchans)) + jj];
    }

  }

}

