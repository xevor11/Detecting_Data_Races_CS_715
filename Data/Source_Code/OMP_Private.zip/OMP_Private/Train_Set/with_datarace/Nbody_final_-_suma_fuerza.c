void calcula_fuerza(double *Fx, double *Fy, double *Fz, double *xi, double *xj, double *yi, double *yj, double *zi, double *zj, double eps);
void kick(double *p1, double *p2, double *p3, double *v1, double *v2, double *v3, double *a1, double *a2, double *a3, int n, double delta_t);
void drift(double *p1, double *p2, double *p3, double *v1, double *v2, double *v3, double *a1, double *a2, double *a3, int n, double delta_t);
void suma_fuerza(double *F1, double *F2, double *F3, double *X, double *Y, double *Z, int n, double epsi);
void Energia_k(double *Ek, double *v1, double *v2, double *v3, int n);
void Energia_P(double *UP, double *x1, double *y1, double *z1, int n);
double calcula_tiempo_total(int n);
double calcula_time_step(int n, double epsilon);
void recibe_input(int argc, char **argv, int *n, double *e);
void escribe_estado(double *xo, double *yo, double *zo, double *x, double *y, double *z, double *vo1, double *vo2, double *vo3, double *v1, double *v2, double *v3, double *Ek1, double *Ek2, double *UP1, double *UP2, int n, int id);
void suma_fuerza(double *F1, double *F2, double *F3, double *X, double *Y, double *Z, int n, double epsi)
{
  double xi;
  double xj;
  double yi;
  double yj;
  double zi;
  double zj;
  double Fx;
  double Fy;
  double Fz;
  int j;
  int l;
  #pragma omp parallel for
  for (j = 0; j < n; j++)
  {
    for (l = 0; l < n; l++)
    {
      if (j != l)
      {
        xi = X[j];
        xj = X[l];
        yi = Y[j];
        yj = Y[l];
        zi = Z[j];
        zj = Z[l];
        calcula_fuerza(&Fx, &Fy, &Fz, &xi, &xj, &yi, &yj, &zi, &zj, epsi);
        F1[l] -= Fx;
        F2[l] -= Fy;
        F3[l] -= Fz;
      }

    }

  }

}

