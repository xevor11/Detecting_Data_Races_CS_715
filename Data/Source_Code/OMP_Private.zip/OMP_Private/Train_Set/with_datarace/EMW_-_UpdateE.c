double Ex[230][102][200];
double Ey[230][102][200];
double Ez[230][102][200];
double oldEx[230][102][4];
double oldEy[230][102][4];
double oldEz[230][102][4];
double Hx[230][102][200];
double Hy[230][102][200];
double Hz[230][102][200];
double ip[230][102][200];
double seedips = 90.0;
void UpdateE();
void UpdateH();
void Mur();
double B = ((((4 * M_PI) * 1e-7) / 1.92e-13) - (0 / 2)) / ((((4 * M_PI) * 1e-7) / 1.92e-13) + (0 / 2));
float Amp = 1;
void UpdateE()
{
  int k;
  int j;
  int nt;
  int lim;
  int index;
  int thisIndex;
  int A[8] = {1, 0, 0, 0, 1, 1, 0, 1};
  int B[4][8] = {0};
  int C[4][8] = {0};
  int D[8] = {-1, -1, -1, -1, -1, -1, -1, -1};
  omp_set_num_threads(8);
  #pragma omp parallel private(j)
  {
    j = omp_get_thread_num();
    B[3][j] = A[j];
  }
  nt = 4;
  for (k = 2; k >= 0; k--)
  {
    omp_set_num_threads(nt);
    #pragma omp parallel private(j)
    {
      j = omp_get_thread_num();
      B[k][j] = B[k + 1][2 * j] + B[k + 1][(2 * j) + 1];
    }
    nt /= 2;
  }

  for (k = 0; k <= 3; k++)
  {
    lim = 8 / pow(2, 3 - k);
    #pragma omp parallel for private(j)
    for (j = 0; j < lim; j++)
    {
      if (j == 0)
      {
        C[k][j] = B[k][j];
      }
      else
        if ((j % 2) == 1)
      {
        C[k][j] = C[k - 1][j / 2];
      }
      else
      {
        C[k][j] = C[k - 1][(j / 2) - 1] + B[k][j];
      }


    }

  }

  for (j = 0; j <= 3; j++)
  {
    for (k = 0; k < 8; k++)
    {
      printf("%d ", B[j][k]);
    }

    printf("\n");
  }

  printf("-----\nprefix sum tree\n");
  for (j = 0; j <= 3; j++)
  {
    for (k = 0; k < 8; k++)
    {
      printf("%d ", C[j][k]);
    }

    printf("\n");
  }

  printf("-----\ncompacted array\n");
  index = 0;
  for (k = 0; k < 8; k++)
  {
    if (A[k] == 1)
    {
      D[index++] = k;
    }

  }

  for (k = 0; k < 8; k++)
  {
    printf("%d ", D[k]);
  }

  printf("\n-----\nnearest 1\n");
  #pragma omp parallel for private(k, index)
  for (k = 1; k < 8; k++)
  {
    printf("k = %d --> ", k);
    thisIndex = k;
    for (index = k; index >= 0; index--)
    {
      if ((D[index] < thisIndex) && (D[index] >= 0))
      {
        printf("%d\n", D[index]);
        break;
      }

    }

  }


  int i;
  int j;
  int k;
  #pragma omp parallel for
  for (i = 1; i < (230 - 1); i++)
  {
    for (j = 1; j < (102 - 1); j++)
    {
      for (k = 1; k < (200 - 1); k++)
      {
        if ((j == 1) || (j == (102 - 2)))
          Ex[i][j][k] = 0;
        else
          Ex[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ex[i][j][k]) + ((Hz[i][j + 1][k] - Hz[i][j - 1][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hy[i][j][k + 1] - Hy[i][j][k - 1]) / (100e-6 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));

      }

    }

  }

  #pragma omp parallel for
  for (i = 1; i < (230 - 1); i++)
  {
    for (j = 1; j < (102 - 1); j++)
    {
      for (k = 1; k < (200 - 1); k++)
      {
        if ((i == 1) || (i == (230 - 2)))
          Ey[i][j][k] = 0;
        else
          Ey[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ey[i][j][k]) + ((Hx[i][j][k + 1] - Hx[i][j][k - 1]) / (100e-6 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hz[i + 1][j][k] - Hz[i - 1][j][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));

      }

    }

  }

  #pragma omp parallel for
  for (i = 1; i < (230 - 1); i++)
  {
    for (j = 1; j < (102 - 1); j++)
    {
      for (k = 1; k < (200 - 1); k++)
      {
        if ((((i == 1) || (i == (230 - 2))) || (j == 1)) || (j == (102 - 2)))
          Ez[i][j][k] = 0;
        else
          Ez[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ez[i][j][k]) + ((Hy[i + 1][j][k] - Hy[i - 1][j][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hx[i][j + 1][k] - Hx[i][j - 1][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));

      }

    }

  }

  Mur();
}

