void init_array(int *a, const int size);
void tick(int (*reduction)(const int *, const int), char *, const int *a, const int size);
int seq_reduction(const int *a, const int size);
int omp_parallel_reduction(const int *a, const int size);
int omp_builtin_reduction(const int *a, const int size);
int omp_parallel_reduction(const int *a, const int size)
{
  int nt = omp_get_num_procs();
  int array_size = nt * 8;
  int *res = (int *) calloc(array_size, sizeof(int));
  if (res == 0)
    exit(-1);

  int i;
  int tid;
  #pragma omp parallel for
  for (i = 0; i < size; ++i)
  {
    tid = omp_get_thread_num();
    res[tid * 8] += a[i];
  }

  int sum = 0;
  int j;
  for (j = 0; j < array_size; ++j)
  {
    sum += res[j];
  }

  free(res);
  return sum;
}

