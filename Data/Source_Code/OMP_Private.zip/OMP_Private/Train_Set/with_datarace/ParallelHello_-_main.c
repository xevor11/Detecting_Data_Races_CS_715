int main()
{
  int id = 1;
  int threads = 10;
  omp_set_num_threads(5000);
  #pragma omp parallel, shared(threads)
  {
    threads = omp_get_num_threads();
    id = omp_get_thread_num();
    printf("Hello from thread %d out of threads %d\n", id, threads);
  }
  printf("%s\n", "Done!");
}

