int main(int argc, char *argv[])
{
  int i;
  double *x;
  double *y;
  double *z;
  int numthreads;
  int tid;
  #pragma omp parallel
  {
    numthreads = omp_get_num_threads();
    int tid = omp_get_thread_num();
    if (tid == 0)
      printf("Running addition with %d threads\n", numthreads);

  }
  x = (double *) malloc((sizeof(double)) * 5000000);
  y = (double *) malloc((sizeof(double)) * 5000000);
  z = (double *) malloc((sizeof(double)) * 5000000);
  srand(0);
  int sum = 0;
  for (i = 0; i < 5000000; i++)
  {
    x[i] = rand() % 1000;
    y[i] = rand() % 1000;
  }

  #pragma omp parallel for default(none) shared(x,y,z ) reduction(+: sum)
  for (i = 0; i < 5000000; i++)
  {
    z[i] = x[i] + y[i];
    sum += z[i];
  }

  free(x);
  free(y);
  free(z);
  return 0;
}

