int omp_parallel_for()
{
  int i;
  int tid = 0;
  int numThreads = 0;
  double j;
  double pi;
  double *temp;
  pi = 0;
  double start = omp_get_wtime();
  #pragma omp parallel private(i, j, tid)
  {
    numThreads = omp_get_num_threads();
    #pragma omp single
    temp = (double *) malloc(numThreads * (sizeof(double)));
    #pragma omp for
    for (i = 0; i < 0x10000000; i++)
    {
      tid = omp_get_thread_num();
      j = (double) i;
      if ((i % 2) == 0)
        temp[tid] += 1. / (1. + (j * 2));
      else
        temp[tid] += (-1.) / (1. + (j * 2));

    }

  }
  #pragma omp parallel for reduction (+:pi)
  for (i = 0; i < numThreads; i++)
  {
    pi += temp[i];
  }

  printf("%lf\n", pi * 4);
  double end = omp_get_wtime();
  printf("Time = %lf\n", end - start);
  return 0;

  int i;
  int tid;
  int counter = 0;
  int nt = omp_get_num_procs();
  int *counters = (int *) calloc(nt, sizeof(int));
  if (counters == 0)
    exit(-1);

  #pragma omp parallel for
  for (i = 0; i < 10000; ++i)
  {
    #pragma omp critical
    {
      tid = omp_get_thread_num();
      counters[tid]++;
    }
  }

  for (i = 0; i < nt; ++i)
  {
    counter += counters[i];
  }

  return counter;
}

