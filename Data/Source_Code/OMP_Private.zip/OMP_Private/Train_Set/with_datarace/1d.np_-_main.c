int main(int argc, char *argv[])
{
  struct timeval start;
  struct timeval end;
  long int i;
  int N = atoi(argv[1]);
  int T = atoi(argv[2]);
  int Bx = atoi(argv[3]);
  int tb = atoi(argv[4]);
  if (((Bx < ((2 * 1) + 1)) || (Bx > N)) || (tb > (((Bx - 1) / 2) / 1)))
  {
    return 0;
  }

  double (*A)[N + (2 * 1)] = (double (*)[N + (2 * 1)]) malloc(((sizeof(double)) * (N + (2 * 1))) * 2);
  srand(100);
  for (i = 0; i < (N + (2 * 1)); i++)
  {
    A[0][i] = 1.0 * (rand() % 1024);
    A[1][i] = 0;
  }

  int ix = (Bx + Bx) - ((2 * tb) * 1);
  int xright[2] = {Bx + 1, (Bx + 1) - (ix / 2)};
  int nb0[2] = {((((N + Bx) - (xright[0] - 1)) - 1) / ix) + 1, ((((N + Bx) - (xright[1] - 1)) - 1) / ix) + 1};
  int level = 0;
  int x;
  int xx;
  int t;
  int tt;
  register int xmin;
  register int xmax;
  gettimeofday(&start, 0);
  for (tt = -tb; tt < T; tt += tb)
  {
    #pragma omp parallel for
    for (xx = 0; xx < nb0[level]; xx++)
    {
      for (t = (tt > 0) ? (tt) : (0); t < (((tt + (2 * tb)) < T) ? (tt + (2 * tb)) : (T)); t++)
      {
        xmin = (1 > (((xright[level] - Bx) + (xx * ix)) + ((((tt + tb) > (t + 1)) ? ((tt + tb) - (t + 1)) : ((t + 1) - (tt + tb))) * 1))) ? (1) : (((xright[level] - Bx) + (xx * ix)) + ((((tt + tb) > (t + 1)) ? ((tt + tb) - (t + 1)) : ((t + 1) - (tt + tb))) * 1));
        xmax = ((N + 1) < ((xright[level] + (xx * ix)) - ((((tt + tb) > (t + 1)) ? ((tt + tb) - (t + 1)) : ((t + 1) - (tt + tb))) * 1))) ? (N + 1) : ((xright[level] + (xx * ix)) - ((((tt + tb) > (t + 1)) ? ((tt + tb) - (t + 1)) : ((t + 1) - (tt + tb))) * 1));
        #pragma simd
        for (x = xmin; x < xmax; x++)
        {
          A[(t + 1) % 2][x] = 0.25 * ((A[t % 2][x + 1] + (2.0 * A[t % 2][x])) + A[t % 2][x - 1]);
        }

      }

    }

    level = 1 - level;
  }

  gettimeofday(&end, 0);
  printf("MStencil/s = %f\n", ((((double) N) * T) / ((double) ((end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec) * 1.0e-6)))) / 1000000L);
}

