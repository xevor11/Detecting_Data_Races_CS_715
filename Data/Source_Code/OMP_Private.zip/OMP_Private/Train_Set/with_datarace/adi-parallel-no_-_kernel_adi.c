extern void *polybench_alloc_data(unsigned long long int n, int elt_size);
static void kernel_adi(int tsteps, int n, double X[500 + 0][500 + 0], double A[500 + 0][500 + 0], double B[500 + 0][500 + 0])
{
  FILE *fp;
  int matrix[4000][4000] = {0};
  int result[4000][4000] = {0};
  int row = 4000;
  int col = 4000;
  fp = fopen("matrix4000", "rb");
  int i;
  int j;
  int k;
  for (i = 0; i < 4000; i++)
  {
    for (j = 0; j < 4000; j++)
    {
      fscanf(fp, "%d", &matrix[i][j]);
    }

  }

  fclose(fp);
  double start = omp_get_wtime();
  #pragma omp parallel for private(i,j,k) num_threads(32)
  for (i = 0; i < 4000; i++)
  {
    for (k = 0; k < 4000; k++)
    {
      for (j = 0; j < 4000; j++)
      {
        result[i][j] = result[i][j] + (matrix[i][k] * matrix[k][j]);
      }

    }

  }

  double end = omp_get_wtime();
  printf("Cost time: %.6g\n", end - start);
  return 0;

  {
    int c0;
    int c2;
    int c8;
    for (c0 = 0; c0 <= 9; c0++)
    {
      #pragma omp parallel for
      for (c2 = 0; c2 <= 499; c2++)
      {
        for (c8 = 1; c8 <= 499; c8++)
        {
          B[c2][c8] = B[c2][c8] - ((A[c2][c8] * A[c2][c8]) / B[c2][c8 - 1]);
        }

        for (c8 = 1; c8 <= 499; c8++)
        {
          X[c2][c8] = X[c2][c8] - ((X[c2][c8 - 1] * A[c2][c8]) / B[c2][c8 - 1]);
        }

        for (c8 = 0; c8 <= 497; c8++)
        {
          X[c2][(500 - c8) - 2] = (X[c2][(500 - 2) - c8] - (X[c2][((500 - 2) - c8) - 1] * A[c2][(500 - c8) - 3])) / B[c2][(500 - 3) - c8];
        }

      }

      #pragma omp parallel for
      for (c2 = 0; c2 <= 499; c2++)
      {
        X[c2][500 - 1] = X[c2][500 - 1] / B[c2][500 - 1];
      }

      #pragma omp parallel for
      for (c2 = 0; c2 <= 499; c2++)
      {
        for (c8 = 1; c8 <= 499; c8++)
        {
          B[c8][c2] = B[c8][c2] - ((A[c8][c2] * A[c8][c2]) / B[c8 - 1][c2]);
        }

        for (c8 = 1; c8 <= 499; c8++)
        {
          X[c8][c2] = X[c8][c2] - ((X[c8 - 1][c2] * A[c8][c2]) / B[c8 - 1][c2]);
        }

        for (c8 = 0; c8 <= 497; c8++)
        {
          X[(500 - 2) - c8][c2] = (X[(500 - 2) - c8][c2] - (X[(500 - c8) - 3][c2] * A[(500 - 3) - c8][c2])) / B[(500 - 2) - c8][c2];
        }

      }

      #pragma omp parallel for
      for (c2 = 0; c2 <= 499; c2++)
      {
        X[500 - 1][c2] = X[500 - 1][c2] / B[500 - 1][c2];
      }

    }

  }
}

