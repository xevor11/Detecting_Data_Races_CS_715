void splitToChans(unsigned char *inbuffer, float *outbuffer, int nchans, int nsamps, int gulp)
{
  int ii;
  int jj;
  #pragma omp parallel for default(shared)
  for (ii = 0; ii < nsamps; ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[(jj * gulp) + ii] = inbuffer[(ii * nchans) + jj];
    }

  }

}

