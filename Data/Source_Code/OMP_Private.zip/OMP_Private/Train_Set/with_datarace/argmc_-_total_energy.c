{
  float x;
  float y;
  float z;
  uint8_t atomic_number;
} atom;
atom old_argons[343];
atom new_argons[343];
float L = 0;
float first_L = 0;
float energies[343 * 343];
float avg_E = 0.0;
float avg_L = 0.0;
float accepted_trans_moves = 0.0;
float accepted_vol_moves = 0.0;
float total_trans_moves = 0.0;
float total_vol_moves = 0.0;
float bins[100];
float currdensity = 0.0;
float total_energy(atom a[])
{
  float total = 0.0;
  float r;
  float frac;
  float lj6;
  float lj12;
  #pragma omp parallel
  {
    #pragma omp for reduction(+:total)
    for (size_t i = 343; i > 0; i--)
    {
      for (size_t j = i - 1; j > 0; j--)
      {
        r = minimum_image_argon(a[i - 1].x, a[i - 1].y, a[i - 1].z, a[j - 1].x, a[j - 1].y, a[j - 1].z);
        frac = 3.4E-10 / r;
        lj6 = ((((frac * frac) * frac) * frac) * frac) * frac;
        lj12 = lj6 * lj6;
        total += ((4 * 120.0) * 1.38064852E-23) * (lj12 - lj6);
      }

    }

  }
  return total;
}

