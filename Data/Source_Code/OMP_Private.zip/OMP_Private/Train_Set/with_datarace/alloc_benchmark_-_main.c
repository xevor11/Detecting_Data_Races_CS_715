double ctimer(void);
void usage(char *name);
int main(int argc, char *argv[])
{
  int nthr = 1;
  long N;
  long SIZE;
  size_t alloc_size;
  unsigned long i;
  double dt;
  double t_start;
  double t_end;
  double t_malloc;
  double t_free;
  double t_first_malloc;
  double t_first_free;
  double malloc_time = 0.0;
  double free_time = 0.0;
  double first_malloc_time;
  double first_free_time;
  void *ptr;
  if (argc == 3)
  {
    N = atol(argv[1]);
    SIZE = atol(argv[2]);
  }

  if ((((argc != 3) || (N < 0)) || (SIZE < 0)) || (SIZE > (LONG_MAX >> 10)))
  {
    usage(argv[0]);
    return 1;
  }

  alloc_size = ((size_t) SIZE) * 1024;
  const size_t page_size = sysconf(_SC_PAGESIZE);
  const size_t page_mask = ~(page_size - 1);
  t_first_malloc = ctimer();
  ptr = malloc(alloc_size);
  first_malloc_time = ctimer() - t_first_malloc;
  if (ptr == 0)
  {
    printf("Error: first allocation failed\n");
    return 1;
  }

  t_first_free = ctimer();
  free(ptr);
  first_free_time = ctimer() - t_first_free;
  ptr = 0;
  t_start = ctimer();
  #pragma omp parallel reduction(max:malloc_time,free_time)
  {
    malloc_time = 0.0;
    free_time = 0.0;
    for (i = 0; i < N; i++)
    {
      t_malloc = ctimer();
      ptr = (void *) malloc(alloc_size);
      malloc_time += ctimer() - t_malloc;
      #pragma omp critical
      {
        if (ptr == 0)
        {
          printf("Error: allocation failed\n");
          exit(1);
        }

      }
      char *end = ptr + alloc_size;
      char *aligned_beg = (char *) (((uintptr_t) ptr) & page_mask);
      while (aligned_beg < end)
      {
        char *temp_ptr = (char *) aligned_beg;
        char value = temp_ptr[0];
        temp_ptr[0] = value;
        aligned_beg += page_size;
      }

      t_free = ctimer();
      free(ptr);
      free_time += ctimer() - t_free;
      ptr = 0;
    }

  }
  t_end = ctimer();
  dt = t_end - t_start;
  printf("%d %lu %8.6f %8.6f  %8.6f  %8.6f  %8.6f\n", nthr, SIZE, dt / N, malloc_time / N, free_time / N, first_malloc_time, first_free_time);
  return 0;
}

