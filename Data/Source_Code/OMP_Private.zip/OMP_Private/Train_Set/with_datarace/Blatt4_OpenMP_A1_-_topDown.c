int i;
double A[8];
double B[8];
{
  double sum;
  double fromLeft;
} treeNode;
treeNode sumTree[4][8];
double C[8];
double D[8];
double E[8];
double c = 1;
double x = 1;
double y;
double sum = 0;
void topDown()
{
  int layer;
  int i;
  sumTree[0][0].fromLeft = 0;
  for (layer = 0; layer < (4 - 1); layer++)
  {
    int k = pow(2, layer);
    #pragma omp parallel for shared(sumTree, layer)
    for (i = 0; i < k; i++)
    {
      #pragma omp parallel sections
      {
        #pragma omp section
        {
          sumTree[layer + 1][(2 * i) + 1].fromLeft = sumTree[layer + 1][2 * i].sum + sumTree[layer][i].fromLeft;
        }
        #pragma omp section
        {
          sumTree[layer + 1][2 * i].fromLeft = sumTree[layer][i].fromLeft;
        }
      }
    }

  }

}

