int main(int argc, char *argv[])
{
  int tid;
  int i;
  int ii;
  int j;
  int jj;
  int k;
  int kk;
  int r;
  int s;
  int ths;
  int rc;
  int n;
  int h;
  int M;
  int K;
  int BLOCK_SIZE = 500;
  int alg;
  double **a;
  double **b;
  double **c;
  a = (double **) malloc(10000 * (sizeof(double)));
  c = (double **) malloc(10000 * (sizeof(double)));
  b = (double **) malloc(10000 * (sizeof(double)));
  for (i = 0; i < 10000; i++)
  {
    a[i] = (double *) malloc(10000 * (sizeof(double)));
    c[i] = (double *) malloc(10000 * (sizeof(double)));
  }

  for (i = 0; i < 10000; i++)
  {
    b[i] = (double *) malloc(10000 * (sizeof(double)));
  }

  double tini;
  double tfin;
  if (argc > 4)
  {
    alg = atoi(argv[1]);
    ths = atoi(argv[2]);
    K = atoi(argv[3]);
    M = atoi(argv[4]);
    BLOCK_SIZE = atoi(argv[5]);
  }
  else
  {
    alg = 1;
    ths = 1;
    K = 1;
    M = 1;
  }

  for (i = 0; i < 10000; i++)
  {
    for (j = 0; j < 10000; j++)
    {
      a[j][i] = 1.0;
      c[j][i] = 0.0;
    }

  }

  for (i = 0; i < 10000; i++)
  {
    for (j = 0; j < 10000; j++)
    {
      b[i][j] = 1.0;
    }

  }

  omp_set_num_threads(ths);
  switch (alg)
  {
    case 1:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (i = 0; i < 10000; i++)
    {
      for (j = 0; j < 10000; j++)
      {
        for (k = 0; k < 10000; k++)
        {
          c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 2:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (i = 0; i < 10000; i++)
    {
      for (k = 0; k < 10000; k++)
      {
        for (j = 0; j < 10000; j++)
        {
          c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 3:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (j = 0; j < 10000; j++)
    {
      for (i = 0; i < 10000; i++)
      {
        for (k = 0; k < 10000; k++)
        {
          c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 4:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (j = 0; j < 10000; j++)
    {
      for (k = 0; k < 10000; k++)
      {
        for (i = 0; i < 10000; i++)
        {
          c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 5:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
    {
      for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
      {
        for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
        {
          for (ii = 0; ii < BLOCK_SIZE; ii++)
          {
            for (jj = 0; jj < BLOCK_SIZE; jj++)
            {
              for (kk = 0; kk < BLOCK_SIZE; kk++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 6:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
    {
      for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
      {
        for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
        {
          for (ii = 0; ii < BLOCK_SIZE; ii++)
          {
            for (kk = 0; kk < BLOCK_SIZE; kk++)
            {
              for (jj = 0; jj < BLOCK_SIZE; jj++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 7:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
    {
      for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
      {
        for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
        {
          for (kk = 0; kk < BLOCK_SIZE; kk++)
          {
            for (ii = 0; ii < BLOCK_SIZE; ii++)
            {
              for (jj = 0; jj < BLOCK_SIZE; jj++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 8:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      #pragma omp parallel for
      for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
    {
      for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
      {
        for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
        {
          for (ii = 0; ii < BLOCK_SIZE; ii++)
          {
            for (kk = 0; kk < BLOCK_SIZE; kk++)
            {
              for (jj = 0; jj < BLOCK_SIZE; jj++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 9:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
    {
      for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
      {
        #pragma omp parallel for
        for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
        {
          for (ii = 0; ii < BLOCK_SIZE; ii++)
          {
            for (kk = 0; kk < BLOCK_SIZE; kk++)
            {
              for (jj = 0; jj < BLOCK_SIZE; jj++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;

    case 10:
      tini = omp_get_wtime();
      tid = omp_get_thread_num();
      for (i = 0; i <= (10000 - BLOCK_SIZE); i = i + BLOCK_SIZE)
    {
      #pragma omp parallel for
      for (j = 0; j <= (10000 - BLOCK_SIZE); j = j + BLOCK_SIZE)
      {
        for (k = 0; k <= (10000 - BLOCK_SIZE); k = k + BLOCK_SIZE)
        {
          for (ii = 0; ii < BLOCK_SIZE; ii++)
          {
            for (kk = 0; kk < BLOCK_SIZE; kk++)
            {
              for (jj = 0; jj < BLOCK_SIZE; jj++)
              {
                c[i + ii][j + jj] = c[i + ii][j + jj] + (a[i + ii][k + kk] * b[k + kk][j + jj]);
              }

            }

          }

        }

      }

    }

      tfin = omp_get_wtime();
      printf("\nEl computo demoro  %f segs\n", tfin - tini);
      break;
      break;

  }

  for (i = 0; i < 10000; i++)
  {
    for (j = 0; j < 10000; j++)
    {
      if (c[i][j] != (10000 * 1.0))
      {
        printf("Error en fila %d col %d %f \n", i, j, c[i][j]);
      }

    }

  }

}

