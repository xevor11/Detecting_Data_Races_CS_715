clock_t start;
clock_t stop;
double s_time;
double p_time;
int parallel(int NTHREADS);
int getDiv(int n);
int parallel(int NTHREADS)
{
  int i;
  int temp;
  int sum = 0;
  omp_set_num_threads(NTHREADS);
  #pragma omp parallel for reduction(+:sum) schedule(dynamic, 10)
  for (i = 1; i < 100000; i++)
  {
    temp = getDiv(i);
    if ((temp > i) && (getDiv(temp) == i))
    {
      sum += i + temp;
    }

  }

  return sum;
}

