void FreeGrid(double **u, int m)
{
  int i;
  #pragma omp parallel for shared (m)
  for (i = 0; i < m; i++)
    free(u[i]);

  free(u);
}

