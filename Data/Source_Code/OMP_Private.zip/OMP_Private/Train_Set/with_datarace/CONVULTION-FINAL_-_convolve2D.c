struct imagenppm
{
  int altura;
  int ancho;
  char *comentario;
  int maxcolor;
  int P;
  int *R;
  int *G;
  int *B;
};
struct structkernel
{
  int kernelX;
  int kernelY;
  float *vkern;
};
ImagenData initimage(char *nombre, FILE **fp, int partitions, int halo);
ImagenData duplicateImageData(ImagenData src, int partitions, int halo);
int readImage(ImagenData Img, FILE **fp, int dim, int halosize, long int *position);
int duplicateImageChunk(ImagenData src, ImagenData dst, int dim);
int initfilestore(ImagenData img, FILE **fp, char *nombre, long *position);
int savingChunk(ImagenData img, FILE **fp, int dim, int offset);
int convolve2D(int *inbuf, int *outbuf, int sizeX, int sizeY, float *kernel, int ksizeX, int ksizeY);
void freeImagestructure(ImagenData *src);
int convolve2D(int *in, int *out, int dataSizeX, int dataSizeY, float *kernel, int kernelSizeX, int kernelSizeY)
{
  int i;
  int j;
  int m;
  int n;
  int *inPtr;
  int *inPtr2;
  int *outPtr;
  float *kPtr;
  int kCenterX;
  int kCenterY;
  int rowMin;
  int rowMax;
  int colMin;
  int colMax;
  float sum;
  if (((!in) || (!out)) || (!kernel))
    return -1;

  if ((dataSizeX <= 0) || (kernelSizeX <= 0))
    return -1;

  kCenterX = ((int) kernelSizeX) / 2;
  kCenterY = ((int) kernelSizeY) / 2;
  #pragma omp parallel num_threads(4)
  {
    int idThread = omp_get_thread_num();
    int myStart = (dataSizeY / omp_get_num_threads()) * idThread;
    int myEnd = 0;
    if (idThread == (omp_get_num_threads() - 1))
    {
      myEnd = dataSizeY;
    }
    else
    {
      myEnd = (dataSizeY / omp_get_num_threads()) * (idThread + 1);
    }

    kPtr = kernel;
    inPtr = (inPtr2 = &in[(dataSizeX * kCenterY) + kCenterX]);
    outPtr = out;
    int *auxOptr = outPtr + (myStart * dataSizeX);
    int *auxInptr = inPtr + (myStart * dataSizeX);
    int *auxInptr2 = auxInptr;
    for (i = myStart; i < myEnd; ++i)
    {
      rowMax = i + kCenterY;
      rowMin = (i - myEnd) + kCenterY;
      for (j = 0; j < dataSizeX; ++j)
      {
        colMax = j + kCenterX;
        colMin = (j - dataSizeX) + kCenterX;
        sum = 0;
        for (m = 0; m < kernelSizeY; ++m)
        {
          if ((m <= rowMax) && (m > rowMin))
          {
            for (n = 0; n < kernelSizeX; ++n)
            {
              if ((n <= colMax) && (n > colMin))
              {
                sum += (*(auxInptr - n)) * (*kPtr);
              }

              ++kPtr;
            }

          }
          else
            kPtr += kernelSizeX;

          auxInptr -= dataSizeX;
        }

        if (sum >= 0)
          *auxOptr = (int) (sum + 0.5f);
        else
          *auxOptr = (int) (sum - 0.5f);

        kPtr = kernel;
        ++auxOptr;
        auxInptr = ++auxInptr2;
      }

    }

  }
  return 0;
}

