int main(int argc, char *argv[])
{
  int *a;
  int *b;
  int *c;
  int n = 8;
  int n_per_thread;
  int total_threads = 4;
  int i;
  a = (int *) malloc((sizeof(int)) * n);
  b = (int *) malloc((sizeof(int)) * n);
  c = (int *) malloc((sizeof(int)) * n);
  for (i = 0; i < n; i++)
  {
    a[i] = i;
  }

  for (i = 0; i < n; i++)
  {
    b[i] = i;
  }

  omp_set_num_threads(total_threads);
  n_per_thread = n / total_threads;
  #pragma omp parallel for shared(a, b, c) schedule(static, n_per_thread)
  for (i = 0; i < n; i++)
  {
    c[i] = a[i] + b[i];
    printf("Thread %d works on element%d\n", omp_get_thread_num(), i);
  }

  printf("i\ta[i]\t+\tb[i]\t=\tc[i]\n");
  for (i = 0; i < n; i++)
  {
    printf("%d\t%d\t\t%d\t\t%d\n", i, a[i], b[i], c[i]);
  }

  free(a);
  free(b);
  free(c);
  return 0;

  int i;
  int j;
  int k;
  int zdim = dims[0];
  int ydim = dims[1];
  int xdim = dims[2];
  int oldindex;
  int newindex;
  int power = pow(2, factor);
  #pragma omp parallel num_threads(omp_get_max_threads())
  {
    #pragma omp for private(i,j,k) schedule(dynamic)
    for (i = 0; i < zdim; i++)
      for (j = 0; j < ydim; j++)
      for (k = 0; k < xdim; k++)
    {
      newindex = (((i * xdim) * ydim) + (j * xdim)) + k;
      oldindex = (((i * (xdim * power)) * (ydim * power)) + ((j * power) * (xdim * power))) + (k * power);
      newdata[newindex] = olddata[oldindex];
    }



  }
}

