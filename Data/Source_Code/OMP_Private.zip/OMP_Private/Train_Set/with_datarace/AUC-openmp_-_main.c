int main(int argc, char **argv)
{
  int i;
  double cgt1;
  double cgt2;
  double ncgt;
  if (argc < 2)
  {
    printf("Faltan nº componentes del vector\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  if (N > 100000000)
    N = 100000000;

  #pragma omp parallel private (i)
  {
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < (N / 4); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = N / 4; i < (N / 2); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = N / 2; i < ((3 * N) / 4); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = (3 * N) / 4; i < N; i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

    }
  }
  cgt1 = omp_get_wtime();
  #pragma omp parallel
  {
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < (N / 4); i++)
        v3[i] = v1[i] + v2[i];

      #pragma omp section
      for (i = N / 4; i < (N / 2); i++)
        v3[i] = v1[i] + v2[i];

      #pragma omp section
      for (i = N / 2; i < ((3 * N) / 4); i++)
        v3[i] = v1[i] + v2[i];

      #pragma omp section
      for (i = (3 * N) / 4; i < N; i++)
        v3[i] = v1[i] + v2[i];

    }
  }
  cgt2 = omp_get_wtime();
  ncgt = cgt2 - cgt1;
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\t/ V1[0]+V2[0]=V3[0](%8.6f+%8.6f=%8.6f) / V1[%d]+V2[%d]=V3[%d](%8.6f+%8.6f=%8.6f) /\n", ncgt, N, v1[0], v2[0], v3[0], N - 1, N - 1, N - 1, v1[N - 1], v2[N - 1], v3[N - 1]);
  return 0;

  int recs = 100000000;
  int num_threads = 1;
  const char *name = argv[0];
  int c;
  while ((c = getopt(argc, argv, "n:t:")) != (-1))
  {
    switch (c)
    {
      case 'n':
        recs = atoi(optarg);
        break;

      case 't':
        num_threads = atoi(optarg);
        break;

      case '?':

      default:
        fprintf(stderr, "Usage: %s -n [NUMBER_OF_RECTANGLES] -t [OMP_NUM_THREADS]\n", name);
        return -1;

    }

  }

  argc - (+optind);
  argv += optind;
  double width;
  width = 1.0 / recs;
  int first = 0;
  int last = recs;
  double sum = 0.0;
  int i = 0;
  omp_set_num_threads(num_threads);
  #pragma omp parallel for reduction(+:sum) shared(first,last,width)
  for (i = first; i < last; i++)
  {
    sum += (func(width * i) * width) * 4.0;
  }

  printf(" --- %s --- \n", name);
  printf("Number of processes: %d\n", 1);
  printf("Threads per process: %d\n", num_threads);
  printf("Rectangles         : %d\n", recs);
  printf("pi is approximately: %f\n", sum);
  return 0;
}

