int main(int argc, char **argv)
{
  long lower;
  long upper;
  sscanf(argv[1], "%ld", &lower);
  sscanf(argv[2], "%ld", &upper);
  int i;
  long result = 0.0;
  if (lower == 1)
  {
    result = 1.0;
    lower = 2;
  }

  #pragma omp parallel for default(shared) schedule(auto) reduction(+:result) num_threads(4)
  for (i = lower; i <= upper; i++)
  {
    result = result + getTotient(i);
  }

  printf("Sum of Totients between [%ld..%ld] is %ld \n", lower, upper, result);
  return 0;

  int i;
  int j;
  int xx;
  int yy;
  dx = 2.0 / (n - 1);
  dy = 2.0 / (m - 1);
  #pragma omp parallel for private(xx,yy,j,i)
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
  {
    xx = (int) ((-1.0) + (dx * (i - 1)));
    yy = (int) ((-1.0) + (dy * (j - 1)));
    u[i][j] = 0.0;
    f[i][j] = (((((-1.0) * alpha) * (1.0 - (xx * xx))) * (1.0 - (yy * yy))) - (2.0 * (1.0 - (xx * xx)))) - (2.0 * (1.0 - (yy * yy)));
  }


}

