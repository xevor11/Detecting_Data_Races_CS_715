void ProcessRoute(int *, int, const int *);
void TSPSwapRun(int *, const int *);
struct indexesSend
{
  long max;
  int cityIndex;
};
void ProcessRoute(int *localPopulation, int numberOfTours, const int *coords)
{
  int tour;
  int city;
  int prevX = 0;
  int prevY = 0;
  int i = 0;
  int j;
  int populationStartIndex;
  long distance = 0;
  struct indexesSend firstTourIndex;
  struct indexesSend secondTourIndex;
  firstTourIndex.max = 32767, secondTourIndex.max = 32767;
  int numCities = NUM_CITIES;
  omp_set_num_threads(numberOfTours);
  long distanceArray[numberOfTours];
  int tempTours[NUM_CITIES];
  for (i = 0; i < numberOfTours; i++)
  {
    distanceArray[i] = 0;
  }

  #pragma omp parallel default(shared) shared(localPopulation, numCities, numberOfTours , coords , distanceArray)
  {
    #pragma omp for
    for (tour = 0; tour < numberOfTours; tour++)
    {
      distance = 0;
      TSPSwapRun((int *) (localPopulation + (numCities * tour)), (const int *) coords);
      prevX = (coords + (2 * ((localPopulation + (numCities * tour))[0] - 1)))[0];
      prevY = (coords + (2 * ((localPopulation + (numCities * tour))[0] - 1)))[1];
      for (int i = 1; i < numCities; i++)
      {
        city = (localPopulation + (numCities * tour))[i] - 1;
        distance += (((coords + (city * 2))[1] - prevY) * ((coords + (city * 2))[1] - prevY)) + (((coords + (city * 2))[0] - prevX) * ((coords + (city * 2))[0] - prevX));
        prevX = *(coords + (city * 2));
        prevY = *((coords + (city * 2)) + 1);
      }

      prevX = (coords + (2 * ((localPopulation + (numCities * tour))[0] - 1)))[0];
      prevY = (coords + (2 * ((localPopulation + (numCities * tour))[0] - 1)))[1];
      distance += (((coords + (city * 2))[1] - prevY) * ((coords + (city * 2))[1] - prevY)) + (((coords + (city * 2))[0] - prevX) * ((coords + (city * 2))[0] - prevX));
      distanceArray[tour] = distance;
    }

  }
  for (i = 0; i < numberOfTours; i++)
  {
    if (distanceArray[i] < firstTourIndex.max)
    {
      secondTourIndex.max = firstTourIndex.max;
      secondTourIndex.cityIndex = firstTourIndex.cityIndex;
      firstTourIndex.max = distanceArray[i];
      firstTourIndex.cityIndex = i;
    }
    else
      if (distanceArray[i] < secondTourIndex.max)
    {
      secondTourIndex.max = distanceArray[i];
      secondTourIndex.cityIndex = i;
    }


  }

  populationStartIndex = 0;
  for (i = 0; i < numCities; i++)
  {
    tempTours[i] = (localPopulation + (numCities * firstTourIndex.cityIndex))[i];
    (localPopulation + (numCities * (populationStartIndex + 1)))[i] = (localPopulation + (numCities * secondTourIndex.cityIndex))[i];
  }

  for (i = 0; i < numCities; i++)
  {
    (localPopulation + (numCities * populationStartIndex))[i] = tempTours[i];
  }


  long i;
  long Ncirc = 0;
  double pi;
  double x;
  double y;
  double test;
  double r = 1.0;
  seed(-r, r);
  for (i = 0; i < num_trials; i++)
  {
    #pragma omp parallel shared(x, y) private(i)
    {
      #pragma omp sections nowait
      {
        #pragma omp section
        x = random();
        #pragma omp section
        y = random();
      }
    }
    test = (x * x) + (y * y);
    if (test <= (r * r))
      Ncirc++;

  }

  pi = 4.0 * (((double) Ncirc) / ((double) num_trials));
  printf("\n %d trials, pi is %f \n", num_trials, pi);
  return 0;
}

