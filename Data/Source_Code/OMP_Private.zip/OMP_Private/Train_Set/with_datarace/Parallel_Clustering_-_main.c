int n;
int k;
double dunn = 0.0;
int no_of_clusters;
double **data;
double **center_array;
int *output;
void main(int argc, char **argv)
{
  if (argc < 2)
  {
    printf("Usage: p1-gomp.o [nthreads]\n");
    return 0;
  }

  int i;
  int id = 0;
  int threads = atoi(argv[1]);
  int total = 0;
  int *array = (int *) malloc((sizeof(int)) * (threads + 1));
  srand(time(0));
  array[0] = 0;
  for (int i = 1; i < (threads + 1); i++)
  {
    array[i] = (rand() % ((threads + 1) - 1)) + 1;
  }

  printf("array: [ ");
  for (int i = 0; i < (threads + 1); i++)
  {
    printf("%d, ", array[i]);
  }

  printf("]\n");
  printf("apply: ");
  #pragma omp parallel private(id) shared(total) num_threads(threads)
  {
    id = omp_get_thread_num() + 1;
    printf("%c %d ", (!(id % 2)) ? ('+') : ('-'), array[id]);
    #pragma omp critical
    total += (!(id % 2)) ? (array[id]) : (-array[id]);
  }
  printf("\ntotal: %d\n", total);
  free(array);
  return 0;

  no_of_clusters = 22;
  int iterations = 10;
  int i;
  int j;
  int x;
  double input_start = omp_get_wtime();
  takeDataInput();
  double input_stop = omp_get_wtime();
  double center_start = omp_get_wtime();
  chooseCenterPointsRandom();
  double center_stop = omp_get_wtime();
  double distance;
  double min_distance;
  int rank;
  int max_threads;
  double cluster_start = omp_get_wtime();
  do
  {
    #pragma omp parallel shared(output,no_of_clusters,center_array,max_threads,data,k,n) default(none)
    {
      rank = omp_get_thread_num();
      max_threads = omp_get_num_threads();
      for (i = rank; i < n; i += max_threads)
      {
        min_distance = 32767;
        for (x = 0; x < no_of_clusters; x++)
        {
          distance = 0.0;
          for (j = 0; j < k; j++)
          {
            distance += (center_array[x][j] - data[i][j]) * (center_array[x][j] - data[i][j]);
          }

          distance = sqrt(distance);
          if (distance < min_distance)
          {
            min_distance = distance;
            output[i] = x;
          }

        }

        #pragma omp critical
        for (j = 0; j < k; j++)
        {
          center_array[output[i]][j] = (center_array[output[i]][j] + data[i][j]) / 2.0;
        }

      }

    }
    iterations--;
  }
  while (iterations > 0);
  #pragma omp for
  for (i = 0; i < n; i++)
    output[i]++;

  double cluster_stop = omp_get_wtime();
  dunn = Dunn_index();
  for (i = 0; i < n; i++)
  {
    if (i != (n - 1))
      printf("%d, ", output[i]);
    else
      printf("%d\n", output[i]);

  }

}

