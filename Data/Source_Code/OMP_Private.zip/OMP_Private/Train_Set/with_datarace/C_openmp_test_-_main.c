int main(int argc, char *argv[])
{
  double a[1024];
  double b[1024];
  double c;
  double sum;
  int nthreads;
  int n;
  int i;
  nthreads = (argc > 1) ? (atoi(argv[1])) : (1);
  printf("# threads: %d\n", nthreads);
  omp_set_num_threads(nthreads);
  #pragma omp parallel
  {
    #pragma omp master
    n = omp_get_num_threads();
  }
  if (n != nthreads)
  {
    printf("\nERROR: %d thread(s) detected != %d\n", n, nthreads);
    return -1;
  }

  sum = (c = 0.0);
  for (i = 0; i < 1024; i++)
    sum += (i * i) * 2.0;

  #pragma omp parallel
  {
    #pragma omp for nowait
    for (i = 0; i < 1024; i++)
      a[i] = i * 1.0;

    #pragma omp for nowait
    for (i = 0; i < 1024; i++)
      b[i] = a[i] * 2.0;

    #pragma omp for reduction(+:c)
    for (i = 0; i < 1024; i++)
      c += a[i] * b[i];

  }
  if (c != sum)
  {
    printf("\nERROR: computed sum %.2lf != %.2lf\n", c, sum);
    return -1;
  }

  printf("final sum: %.2lf\n", c);
  return 0;
}

