int useless;
{
  int length;
  int *array;
} int_array;
{
  int_array *arreglo;
  string cadena;
  int potencia;
  int tamano;
} witness;
string cadena;
witness *w;
{
  int x;
  int y;
} par;
{
  string *array;
  int length;
} string_array;
int get_min(int_array *arreglo)
{
  int n = sqrt(arreglo->length);
  int_array *arreglo_i = init_int_array(n);
  omp_set_num_threads(n);
  #pragma omp parallel
  {
    int id = omp_get_thread_num();
    if (id == (n - 1))
      arreglo_i->array[id] = get_min_aux(arreglo, id * n, arreglo->length);
    else
      arreglo_i->array[id] = get_min_aux(arreglo, id * n, (id * n) + n);

  }
  int min = minimum(arreglo_i);
  return min;
}

