float calcE(int *m, int row, int col)
{
  int i;
  int j;
  int nx;
  int ny;
  float J = 1;
  float E = 0;
  #pragma omp parallel num_threads(12)
  #pragma omp for,reduction(+:E)
  for (i = 0; i < row; i++)
  {
    for (j = 0; j < col; j++)
    {
      nx = i;
      ny = (j + 1) % col;
      E += ((-J) * m[(i * row) + j]) * m[(nx * row) + ny];
      nx = (i + 1) % row;
      ny = j;
      E += ((-J) * m[(i * row) + j]) * m[(nx * row) + ny];
      nx = i;
      ny = (((j - 1) % col) != (-1)) ? (j - 1) : (col - 1);
      E += ((-J) * m[(i * row) + j]) * m[(nx * row) + ny];
      nx = (((i - 1) % row) != (-1)) ? (i - 1) : (row - 1);
      ny = j;
      E += ((-J) * m[(i * row) + j]) * m[(nx * row) + ny];
    }

  }

  return E;
}

