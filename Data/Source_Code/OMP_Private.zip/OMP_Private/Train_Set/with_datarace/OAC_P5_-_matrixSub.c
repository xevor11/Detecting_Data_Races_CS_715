void printR(double *v, double **m, double *r);
void printMatrix(double **matrix, int noLines, int noColumns);
int p_main(double **matrix1, double **matrix2, int noLines, int noColumns);
void matrixPow2(double **matrix, int noLines, int noColumns);
double **matrixSub(double **matrix1, double **matrix2, int noLines, int noColumns);
double matrixAccumulate(double **matrix, int noLines, int noColumns);
double **matrixSub(double **matrix1, double **matrix2, int noLines, int noColumns)
{
  double start_time;
  double run_time;
  start_time = omp_get_wtime();
  int i;
  int j;
  double **newMatrix = (double **) malloc(noLines * (sizeof(double *)));
  #pragma omp parallel for shared(i, newMatrix)
  for (i = 0; i < noLines; i++)
  {
    newMatrix[i] = (double *) malloc(noColumns * (sizeof(double)));
  }

  #pragma omp parallel for shared(i, matrix1, matrix2, newMatrix)
  for (i = 0; i < noLines; i++)
    for (j = 0; j < noColumns; j++)
    newMatrix[i][j] = matrix1[i][j] - matrix2[i][j];


  run_time = omp_get_wtime() - start_time;
  printf("Tempo para alocar matriz e subtrair: %lf s\n", run_time);
  return newMatrix;

  #pragma omp parallel private(Xstep,Ystep) num_threads(16)
  #pragma omp for
  for (Xstep = 1; Xstep < (Nx + 1); Xstep++)
  {
    for (Ystep = 1; Ystep < (Ny + 1); Ystep++)
    {
      double ax1;
      double bx1;
      double tx1;
      double dx1dt;
      double am;
      double bm;
      double tm;
      double dmdt;
      double ah;
      double bh;
      double th;
      double dhdt;
      double ad;
      double bd;
      double td;
      double dddt;
      double af;
      double bf;
      double tf;
      double dfdt;
      double dCaidt;
      double IK1t1;
      double IK1t2;
      double IK1t3;
      double IK1t4;
      double Ix1t1;
      double Ix1t2;
      int jj;
      ax1 = ((0.0005 * exp(0.083 * (datarr[1][0][Xstep][Ystep] + 50))) + (0 * (datarr[1][0][Xstep][Ystep] + 0))) / (1 + exp(0.057 * (datarr[1][0][Xstep][Ystep] + 50)));
      bx1 = ((0.0013 * exp((-0.06) * (datarr[1][0][Xstep][Ystep] + 20))) + (0 * (datarr[1][0][Xstep][Ystep] + 0))) / (1 + exp((-0.04) * (datarr[1][0][Xstep][Ystep] + 20)));
      tx1 = 1 / (ax1 + bx1);
      dx1dt = ((ax1 * tx1) - datarr[1][4][Xstep][Ystep]) / tx1;
      am = (0 + ((-0.9) * (datarr[1][0][Xstep][Ystep] + 42.65))) / ((-1) + exp((-0.22) * (datarr[1][0][Xstep][Ystep] + 42.65)));
      bm = ((1.437 * exp((-0.085) * (datarr[1][0][Xstep][Ystep] + 39.75))) + 0) / (0 + exp(0 * (datarr[1][0][Xstep][Ystep] + 39.75)));
      tm = 1 / (am + bm);
      dmdt = ((am * tm) - datarr[1][6][Xstep][Ystep]) / tm;
      ah = ((0.1 * exp((-0.193) * (datarr[1][0][Xstep][Ystep] + 79.65))) + 0) / (0 + exp(0 * (datarr[1][0][Xstep][Ystep] + 79.65)));
      bh = ((1.7 * exp(0 * (datarr[1][0][Xstep][Ystep] + 20.5))) + 0) / (1 + exp((-0.095) * (datarr[1][0][Xstep][Ystep] + 20.5)));
      th = 1 / (ah + bh);
      dhdt = ((ah * th) - datarr[1][7][Xstep][Ystep]) / th;
      ad = ((0.095 * exp((-0.01) * (datarr[1][0][Xstep][Ystep] - 5))) + 0) / (1 + exp((-0.072) * (datarr[1][0][Xstep][Ystep] - 5)));
      bd = ((0.07 * exp((-0.017) * (datarr[1][0][Xstep][Ystep] + 44))) + 0) / (1 + exp(0.05 * (datarr[1][0][Xstep][Ystep] + 44)));
      td = (1 / (ad + bd)) * constarr[11];
      dddt = ((ad * td) - datarr[1][9][Xstep][Ystep]) / td;
      af = ((0.012 * exp((-0.008) * (datarr[1][0][Xstep][Ystep] + 28))) + 0) / (1 + exp(0.15 * (datarr[1][0][Xstep][Ystep] + 28)));
      bf = ((0.0065 * exp((-0.02) * (datarr[1][0][Xstep][Ystep] + 30))) + 0) / (1 + exp((-0.2) * (datarr[1][0][Xstep][Ystep] + 30)));
      tf = (1 / (af + bf)) * constarr[11];
      dfdt = ((af * tf) - datarr[1][10][Xstep][Ystep]) / tf;
      dCaidt = ((-0.0000001) * datarr[1][8][Xstep][Ystep]) + (constarr[6] * (0.0000001 - datarr[1][11][Xstep][Ystep]));
      for (jj = 0; jj < (15 - 2); jj++)
      {
        datarr[0][jj][Xstep][Ystep] = datarr[1][jj][Xstep][Ystep];
      }

      IK1t1 = 4 * (exp(0.04 * (datarr[0][0][Xstep][Ystep] + 85)) - 1);
      IK1t2 = exp(0.08 * (datarr[0][0][Xstep][Ystep] + 53)) + exp(0.04 * (datarr[0][0][Xstep][Ystep] + 53));
      IK1t3 = 0.2 * (datarr[0][0][Xstep][Ystep] + 23);
      IK1t4 = 1 - exp((-0.04) * (datarr[0][0][Xstep][Ystep] + 23));
      datarr[0][2][Xstep][Ystep] = (Afield[Xstep - 1][Ystep - 1] * constarr[0]) * ((IK1t1 / IK1t2) + (IK1t3 / IK1t4));
      datarr[0][4][Xstep][Ystep] += dx1dt * dt;
      Ix1t1 = exp(0.04 * (datarr[0][0][Xstep][Ystep] + 77)) - 1;
      Ix1t2 = exp(0.04 * (datarr[0][0][Xstep][Ystep] + 35));
      datarr[0][3][Xstep][Ystep] = ((constarr[3] * Ix1t1) / Ix1t2) * datarr[0][4][Xstep][Ystep];
      datarr[0][6][Xstep][Ystep] += dmdt * dt;
      datarr[0][7][Xstep][Ystep] += dhdt * dt;
      datarr[0][5][Xstep][Ystep] = (((constarr[1] * block[Xstep][Ystep]) * pow(datarr[0][6][Xstep][Ystep], 3.0)) * datarr[0][7][Xstep][Ystep]) * (datarr[0][0][Xstep][Ystep] - constarr[2]);
      datarr[0][11][Xstep][Ystep] += dCaidt * dt;
      datarr[0][9][Xstep][Ystep] += dddt * dt;
      datarr[0][10][Xstep][Ystep] += dfdt * dt;
      datarr[0][8][Xstep][Ystep] = (((constarr[4] * block[Xstep][Ystep]) * datarr[0][9][Xstep][Ystep]) * datarr[0][10][Xstep][Ystep]) * (datarr[0][0][Xstep][Ystep] - ((-82.3) - (13.0287 * log(datarr[0][11][Xstep][Ystep]))));
      datarr[0][12][Xstep][Ystep] = ((datarr[0][2][Xstep][Ystep] + datarr[0][3][Xstep][Ystep]) + datarr[0][5][Xstep][Ystep]) + datarr[0][8][Xstep][Ystep];
      datarr[0][1][Xstep][Ystep] = datarr[0][13][Xstep][Ystep] - ((1 / constarr[5]) * (datarr[0][12][Xstep][Ystep] - datarr[0][14][Xstep][Ystep]));
      datarr[0][0][Xstep][Ystep] += datarr[0][1][Xstep][Ystep] * dt;
      datarr[0][13][Xstep][Ystep] = 0.0;
    }

  }

}

