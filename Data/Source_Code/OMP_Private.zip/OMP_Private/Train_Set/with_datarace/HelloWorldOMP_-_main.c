int main(int argc, char *argv[])
{
  float c1;
  float c2;
  float dth;
  int slice_1;
  int slice_2;
  int yline_1;
  int yline_2;
  int i;
  int j;
  int k;
  slice_1 = (nyt + 8) * (nzt + (2 * 0));
  slice_2 = ((nyt + 8) * (nzt + (2 * 0))) * 2;
  yline_1 = nzt + (2 * 0);
  yline_2 = (nzt + (2 * 0)) * 2;
  c1 = 9.0 / 8.0;
  c2 = (-1.0) / 24.0;
  dth = DT / DH;
  #pragma omp parallel for private (i, j, k)
  for (i = 4; i <= (nxt + 3); i++)
    for (j = 8; j <= (nyt - 1); j++)
    for (k = 0; k <= ((nzt + 0) - 1); k++)
  {
    register int dcrj;
    register int d_1;
    register int d_2;
    register int d_3;
    register int pos;
    register int pos_ip1;
    register int pos_ip2;
    register int pos_im1;
    register int pos_im2;
    register int pos_jm1;
    register int pos_jm2;
    register int pos_jp1;
    register int pos_jp2;
    register int pos_km1;
    register int pos_km2;
    register int pos_kp1;
    register int pos_kp2;
    register int pos_jk1;
    register int pos_ik1;
    register int pos_ij1;
    pos = ((i * slice_1) + (j * yline_1)) + k;
    pos_km2 = pos - 2;
    pos_km1 = pos - 1;
    pos_kp1 = pos + 1;
    pos_kp2 = pos + 2;
    pos_jm2 = pos - yline_2;
    pos_jm1 = pos - yline_1;
    pos_jp1 = pos + yline_1;
    pos_jp2 = pos + yline_2;
    pos_im1 = pos - slice_1;
    pos_im2 = pos - slice_2;
    pos_ip1 = pos + slice_1;
    pos_ip2 = pos + slice_2;
    pos_jk1 = (pos - yline_1) - 1;
    pos_ik1 = (pos + slice_1) - 1;
    pos_ij1 = (pos + slice_1) - yline_1;
    dcrj = (dcrjx[i] * dcrjy[j]) * dcrjz[k];
    d_1 = 0.25 * ((d1[pos] + d1[pos_jm1]) + (d1[pos_km1] + d1[pos_jk1]));
    d_2 = 0.25 * ((d1[pos] + d1[pos_ip1]) + (d1[pos_km1] + d1[pos_ik1]));
    d_3 = 0.25 * ((d1[pos] + d1[pos_ip1]) + (d1[pos_jm1] + d1[pos_ij1]));
    u1[pos] = (u1[pos] + ((dth / d_1) * ((((((c1 * (xx[pos] - xx[pos_im1])) + (c2 * (xx[pos_ip1] - xx[pos_im2]))) + (c1 * (xy[pos] - xy[pos_jm1]))) + (c2 * (xy[pos_jp1] - xy[pos_jm2]))) + (c1 * (xz[pos] - xz[pos_km1]))) + (c2 * (xz[pos_kp1] - xz[pos_km2]))))) * dcrj;
    v1[pos] = (v1[pos] + ((dth / d_2) * ((((((c1 * (xy[pos_ip1] - xy[pos])) + (c2 * (xy[pos_ip2] - xy[pos_im1]))) + (c1 * (yy[pos_jp1] - yy[pos]))) + (c2 * (yy[pos_jp2] - yy[pos_jm1]))) + (c1 * (yz[pos] - yz[pos_km1]))) + (c2 * (yz[pos_kp1] - yz[pos_km2]))))) * dcrj;
    w1[pos] = (w1[pos] + ((dth / d_3) * ((((((c1 * (xz[pos_ip1] - xz[pos])) + (c2 * (xz[pos_ip2] - xz[pos_im1]))) + (c1 * (yz[pos] - yz[pos_jm1]))) + (c2 * (yz[pos_jp1] - yz[pos_jm2]))) + (c1 * (zz[pos_kp1] - zz[pos]))) + (c2 * (zz[pos_kp2] - zz[pos_km1]))))) * dcrj;
  }



  return;

  int nthreads;
  int tid;
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }

  }
  exit(0);
}

