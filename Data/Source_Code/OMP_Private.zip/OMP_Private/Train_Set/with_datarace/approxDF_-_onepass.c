{
  unsigned s;
  unsigned t;
  double a;
} edge;
{
  unsigned n;
  double r;
} node;
{
  unsigned n;
  unsigned long long e;
  unsigned *map;
  edge *edges;
  node *nodes;
  node *nodes2;
  double *ne;
  unsigned *cd;
  unsigned *cuts;
  unsigned iter;
} optim;
void onepass(optim *opt)
{
  unsigned i;
  unsigned j;
  unsigned long long k;
  double gamma;
  opt->iter++;
  gamma = 2. / (2. + opt->iter);
  #pragma omp parallel for
  for (k = 0; k < opt->e; k++)
  {
    i = opt->edges[k].s;
    j = opt->edges[k].t;
    if (opt->nodes[i].r < opt->nodes[j].r)
    {
      #pragma omp atomic update
      opt->nodes[i].r += gamma * (1. - opt->edges[k].a);
      #pragma omp atomic update
      opt->nodes[j].r -= gamma * (1. - opt->edges[k].a);
      opt->edges[k].a = ((1. - gamma) * opt->edges[k].a) + gamma;
    }
    else
      if (opt->nodes[i].r > opt->nodes[j].r)
    {
      #pragma omp atomic update
      opt->nodes[i].r -= gamma * opt->edges[k].a;
      #pragma omp atomic update
      opt->nodes[j].r += gamma * opt->edges[k].a;
      opt->edges[k].a *= 1. - gamma;
    }


  }

}

