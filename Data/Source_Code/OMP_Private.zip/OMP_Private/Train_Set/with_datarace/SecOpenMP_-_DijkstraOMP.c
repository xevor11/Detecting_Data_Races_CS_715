{
  int u;
  int v;
} Edge;
{
  int title;
  bool visited;
} Vertex;
void DijkstraOMP(Vertex *vertices, Edge *edges, int *weights, Vertex *root)
{
  double start;
  double end;
  root->visited = 1;
  int len[24];
  len[(int) root->title] = 0;
  int i;
  int j;
  for (i = 0; i < 24; i++)
  {
    if (vertices[i].title != root->title)
    {
      len[(int) vertices[i].title] = findEdge(*root, vertices[i], edges, weights);
    }
    else
    {
      vertices[i].visited = 1;
    }

  }

  start = omp_get_wtime();
  for (j = 0; j < 24; j++)
  {
    Vertex u;
    int h = minPath(vertices, len);
    u = vertices[h];
    #pragma omp parallel for schedule(runtime)
    for (i = 0; i < 24; i++)
    {
      if (vertices[i].visited == 0)
      {
        int c = findEdge(u, vertices[i], edges, weights);
        len[vertices[i].title] = minimum(len[vertices[i].title], len[u.title] + c);
      }

    }

  }

  end = omp_get_wtime();
  printArray(len);
  printf("Running time: %f ms\n", (end - start) * 1000);
}

