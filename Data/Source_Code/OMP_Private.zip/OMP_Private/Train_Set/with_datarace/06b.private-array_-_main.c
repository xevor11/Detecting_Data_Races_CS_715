int main(void)
{
  int N = 5;
  int a[N];
  printf("Before parallel region: ");
  print_array(a, N);
  #pragma omp parallel num_threads(2)
  {
    int id = omp_get_thread_num();
    a[id] = id + 1;
    printf("Thread %d: ", id);
    print_array(a, N);
  }
  printf("After parallel region: ");
  print_array(a, N);
  return 0;

  int num_procs;
  int max_threads;
  int thread_id;
  double wall_time = 0.00;
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  printf("\n");
  printf("  Total number of processors available : %d\n", num_procs);
  printf("  Maximum number of usable threads     : %d\n\n", max_threads);
  #pragma omp parallel shared(max_threads) private(thread_id)
  {
    thread_id = omp_get_thread_num();
    printf("  Hello, World! from thread %d out of %d\n", thread_id, max_threads);
  }
  wall_time = omp_get_wtime() - wall_time;
  printf("\n");
  printf("  Total time taken : %f seconds\n\n", wall_time);
  return 0;
}

