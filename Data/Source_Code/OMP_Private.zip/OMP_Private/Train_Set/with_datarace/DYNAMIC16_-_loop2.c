double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void loop2(void)
{
  int i;
  int j;
  int k;
  double rN2;
  rN2 = 1.0 / ((double) (729 * 729));
  #pragma omp parallel for default(none) shared(a,b,c,jmax,rN2) schedule( dynamic, 16)
  for (i = 0; i < 729; i++)
  {
    for (j = 0; j < jmax[i]; j++)
    {
      for (k = 0; k < j; k++)
      {
        c[i] += ((k + 1) * log(b[i][j])) * rN2;
      }

    }

  }


  int num_threads;
  int num_iterations;
  int iter;
  int i;
  int j;
  int v;
  int u;
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <num threads> <num iterations>\n", argv[0]);
    exit(1);
  }

  if (sscanf(argv[1], "%d", &num_threads) != 1)
  {
    fprintf(stderr, "Invalid number of threads\n");
    exit(1);
  }

  if (sscanf(argv[2], "%d", &num_iterations) != 1)
  {
    fprintf(stderr, "Invalid number of iterations\n");
    exit(1);
  }

  omp_set_num_threads(num_threads);
  t = ((12000 % 300) == 0) ? ((12000 - 300) + 1) : (((12000 / 300) * 300) + 1);
  for (i = 0; i < (12000 + 2); i++)
  {
    for (j = 0; j < (12000 + 2); j++)
    {
      A[i][j] = i + j;
    }

  }

  for (iter = 0; iter < num_iterations; iter++)
  {
    for (i = 1 + 1; i <= (t + 1); i += 300)
    {
      #pragma omp parallel shared(A, i) private(j, v, u)
      {
        #pragma omp for
        for (j = i - 1; j >= 1; j -= 300)
        {
          for (v = j; (v < (j + 300)) && (v < (12000 + 1)); v++)
          {
            for (u = i - j; (u < ((i - j) + 300)) && (u < (12000 + 1)); u++)
            {
              A[v][u] = ((((3 * A[v - 1][u]) + A[v + 1][u]) + (3 * A[v][u - 1])) + A[v][u + 1]) / 4;
            }

          }

        }

      }
    }

    for (i = 300 + 1; i <= t; i += 300)
    {
      #pragma omp parallel shared(A, i, t) private(j, v, u)
      {
        #pragma omp for
        for (j = t; j >= i; j -= 300)
        {
          for (v = j; (v < (j + 300)) && (v < (12000 + 1)); v++)
          {
            for (u = (t - j) + i; (u < (((t - j) + i) + 300)) && (u < (12000 + 1)); u++)
            {
              A[v][u] = ((((3 * A[v - 1][u]) + A[v + 1][u]) + (3 * A[v][u - 1])) + A[v][u + 1]) / 4;
            }

          }

        }

      }
    }

  }

  exit(0);
}

