double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void loop2(void)
{
  int i;
  int j;
  int k;
  double t1;
  double t2;
  double t3;
  double ac;
  double xvel;
  double yvel;
  double zvel;
  double r1;
  double r2;
  double r3;
  double r4;
  double r5;
  double btuz;
  double ac2u;
  double uzik1;
  #pragma omp parallel for default(shared) private(i,j,k,t1,t2,t3,ac,xvel,yvel,zvel,r1,r2,r3,r4,r5,btuz,ac2u,uzik1)
  for (k = 1; k <= nz2; k++)
  {
    for (j = 1; j <= ny2; j++)
    {
      for (i = 1; i <= nx2; i++)
      {
        xvel = us[k][j][i];
        yvel = vs[k][j][i];
        zvel = ws[k][j][i];
        ac = speed[k][j][i];
        ac2u = ac * ac;
        r1 = rhs[k][j][i][0];
        r2 = rhs[k][j][i][1];
        r3 = rhs[k][j][i][2];
        r4 = rhs[k][j][i][3];
        r5 = rhs[k][j][i][4];
        uzik1 = u[k][j][i][0];
        btuz = bt * uzik1;
        t1 = (btuz / ac) * (r4 + r5);
        t2 = r3 + t1;
        t3 = btuz * (r4 - r5);
        rhs[k][j][i][0] = t2;
        rhs[k][j][i][1] = ((-uzik1) * r2) + (xvel * t2);
        rhs[k][j][i][2] = (uzik1 * r1) + (yvel * t2);
        rhs[k][j][i][3] = (zvel * t2) + t3;
        rhs[k][j][i][4] = (((uzik1 * (((-xvel) * r2) + (yvel * r1))) + (qs[k][j][i] * t2)) + ((c2iv * ac2u) * t1)) + (zvel * t3);
      }

    }

  }


  int i;
  int j;
  int k;
  double rN2;
  rN2 = 1.0 / ((double) (729 * 729));
  #pragma omp parallel for default(none) shared(a,b,c,jmax,rN2) schedule(guided, 32)
  for (i = 0; i < 729; i++)
  {
    for (j = 0; j < jmax[i]; j++)
    {
      for (k = 0; k < j; k++)
      {
        c[i] += ((k + 1) * log(b[i][j])) * rN2;
      }

    }

  }

}

