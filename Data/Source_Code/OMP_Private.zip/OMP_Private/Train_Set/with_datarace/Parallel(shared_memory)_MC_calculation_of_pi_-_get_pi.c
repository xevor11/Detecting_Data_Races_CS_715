float get_pi(int N)
{
  int i;
  int j;
  int g;
  int idx;
  int idg;
  const int *gidx;
  float ngp;
  void (*add_pow)(float *, const float, const float, const float, const float *, const int);
  float (*radical)(const float, const float);
  float invp = 1.f / p;
  if (p == 1.f)
  {
    add_pow = (W == 0) ? (add_pow_l11_cplx_single) : (add_pow_wl11_cplx_single);
    radical = radical_1_single;
  }
  else
    if (p == 2.f)
  {
    add_pow = (W == 0) ? (add_pow_l12_cplx_single) : (add_pow_wl12_cplx_single);
    radical = radical_2_single;
  }
  else
    if (p == INFINITY)
  {
    add_pow = add_pow_l1inf_cplx_single;
    radical = radical_1_single;
  }
  else
  {
    add_pow = (W == 0) ? (add_pow_l1p_cplx_single) : (add_pow_wl1p_cplx_single);
    radical = radical_p_single;
  }



  #pragma omp parallel for private(i, j, g, idx, idg, gidx, ngp)
  for (g = 0; g < G[0][0]; g++)
  {
    gidx = G[g + 1];
    for (idg = I * g, i = 0; i < I; i++, idg++)
    {
      ngp = 0.f;
      for (j = 1; j <= gidx[0]; j++)
      {
        idx = i + (I * gidx[j]);
        add_pow(&ngp, Xr[idx], Xi[idx], p, W, idx);
      }

      Nb[idg] = radical(ngp, invp);
    }

  }


  int pi = 0;
  int n;
  float x;
  float y;
  #pragma omp parallelreduction(+:pi)
  {
    #pragma omp for schedule(static)
    for (n = 0; n < N; ++n)
    {
      x = ((float) rand()) / ((float) 32767);
      y = ((float) rand()) / ((float) 32767);
      if (((x * x) + (y * y)) <= 1.0)
      {
        ++pi;
      }

    }

  }
  return (4.0 * ((float) pi)) / ((float) N);
}

