double walltime(double *);
int array2(int argc, char *argv[])
{
  double *x;
  double *y;
  int arraySize;
  int i;
  int privIndx;
  double privDbl;
  int globalCount;
  double startTime;
  double elapsedTime;
  double clockZero = 0.0;
  arraySize = (int) atof(argv[1]);
  if (argc != 2)
  {
    fprintf(stdout, "usage:  %s  arraySize\n", argv[0]);
    exit(-1);
  }

  x = (double *) malloc((size_t) (arraySize * (sizeof(double))));
  y = (double *) malloc((size_t) (arraySize * (sizeof(double))));
  for (i = 0; i < arraySize; i++)
  {
    x[i] = ((double) i) / (i + 1000);
  }

  globalCount = 0;
  startTime = walltime(&clockZero);
  #pragma omp parallel for
  for (i = 0; i < arraySize; i++)
  {
    for (privIndx = 0; privIndx < 16; privIndx++)
    {
      privDbl = ((double) privIndx) / 16;
      y[i] = sin(exp(cos(-exp(sin(x[i]))))) + cos(privDbl);
      globalCount = globalCount + 1;
    }

  }

  elapsedTime = walltime(&startTime);
  fprintf(stdout, "\nthe global counter should equal %d\n", arraySize * 16);
  fprintf(stdout, "globalCount = %d\n", globalCount);
  fprintf(stdout, "\nwall time = %.2fs for array size = %.0e\n", elapsedTime, (double) arraySize);
  fprintf(stdout, "\nProgram successfully terminated.\n\n\a");
  return 0;

  long long int i;
  long long int j;
  long long int sqrt = 0;
  if ((n / 2) < (stripesize + 1))
    stripesize = 1;

  for (i = 1; i <= (((n / 2) - stripesize) + 1); i += stripesize)
  {
    #pragma omp parallel for private(j) shared(i, sqrt, n)
    for (j = i; j < (i + stripesize); j++)
    {
      if ((j * j) == n)
        sqrt = j;

    }

    if (sqrt != 0)
      break;

  }

  return sqrt;
}

