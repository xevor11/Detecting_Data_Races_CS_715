double Ex[230 + 1][102 + 1][200 + 1];
double Ey[230 + 1][102 + 1][200 + 1];
double Ez[230 + 1][102 + 1][200 + 1];
double oldEy0[230][102];
double oldEy1[230][102];
double oldEyNZ1[230][102];
double oldEyNZ2[230][102];
double Hx[230 + 1][102 + 1][200 + 1];
double Hy[230 + 1][102 + 1][200 + 1];
double Hz[230 + 1][102 + 1][200 + 1];
double ip[230][102][200];
double seedips = 90.0;
void UpdateE();
void UpdateH();
void Mur();
double B = ((((4 * M_PI) * 1e-7) / 1.92e-13) - (0 / 2)) / ((((4 * M_PI) * 1e-7) / 1.92e-13) + (0 / 2));
float Amp = 1;
void UpdateE()
{
  int i;
  int j;
  int k;
  #pragma omp parallel for
  for (i = 0; i < 230; i++)
  {
    for (j = 1; j < 102; j++)
    {
      for (k = 1; k < 200; k++)
      {
        Ex[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ex[i][j][k]) + ((Hz[i][j][k] - Hz[i][j - 1][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hy[i][j][k] - Hy[i][j][k - 1]) / (100e-6 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));
      }

    }

  }

  #pragma omp parallel for
  for (i = 1; i < 230; i++)
  {
    for (j = 0; j < (102 - 1); j++)
    {
      for (k = 1; k < 200; k++)
      {
        Ey[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ey[i][j][k]) + ((Hx[i][j][k] - Hx[i][j][k - 1]) / (100e-6 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hz[i][j][k] - Hz[i - 1][j][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));
      }

    }

  }

  #pragma omp parallel for
  for (i = 1; i < 230; i++)
  {
    for (j = 1; j < 102; j++)
    {
      for (k = 0; k < (200 - 1); k++)
      {
        Ez[i][j][k] = (((((ip[i][j][k] / 1.92e-13) - (0 / 2)) / ((ip[i][j][k] / 1.92e-13) + (0 / 2))) * Ez[i][j][k]) + ((Hy[i][j][k] - Hy[i - 1][j][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))))) - ((Hx[i][j][k] - Hx[i][j - 1][k]) / (0.0001 * ((ip[i][j][k] / 1.92e-13) + (0 / 2))));
      }

    }

  }

  Mur();
}

