int buyer = 1;
int seller = 0;
int MaxNumberOfTrades = 100000000;
int numberOfBuyers = 1200000;
int numberOfSellers = 1200000;
int maxBuyerValue = 30;
int maxSellerValue = 30;
int numThreads = 32;
{
  int buyerOrSeller;
  int quantityHeld;
  int value;
  int price;
} Agent;
Agent *Buyers;
Agent *Sellers;
int agentsPerThread;
int tradesPerThread;
unsigned int *seeds;
void OpenMarket()
{
  clock_t startTime1;
  clock_t endTime1;
  time_t startTime2;
  time_t endTime2;
  startTime1 = clock();
  time(&startTime2);
  int i;
  #pragma omp parallel num_threads(numThreads)
  {
    #pragma omp for
    for (i = 0; i < numThreads; i++)
      DoTrades(i);

  }
  endTime1 = clock();
  time(&endTime2);
  ComputeStatistics(endTime1 - startTime1);
  endTime2 = endTime2 - startTime2;
  printf("Wall time: %d seconds\n", (int) endTime2);
}

