double maxeps = 0.1e-7;
int itmax = 100;
int i;
int j;
int k;
double eps;
double A[225][225][225];
void relax();
void init();
void verify();
void verify()
{
  double s;
  s = 0.;
  #pragma omp parallel for reduction(+:s)
  for (i = 0; i <= (225 - 1); i++)
    for (j = 0; j <= (225 - 1); j++)
    for (k = 0; k <= (225 - 1); k++)
  {
    s = s + ((((A[i][j][k] * (i + 1)) * (j + 1)) * (k + 1)) / ((225 * 225) * 225));
  }



}

