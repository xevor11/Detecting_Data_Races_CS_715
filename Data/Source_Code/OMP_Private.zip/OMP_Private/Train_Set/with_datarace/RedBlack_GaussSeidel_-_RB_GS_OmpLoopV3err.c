double RB_GS_OmpLoopV3err(double **black, double **red, int m, int n, double eps, int maxit, int iterations_print, int *iterations)
{
  int i;
  int j;
  double v;
  double *my_error;
  int tid;
  int nthreads;
  int my_iterations = *iterations;
  double error = 10.0 * eps;
  nthreads = omp_get_max_threads();
  my_error = malloc((sizeof(double)) * nthreads);
  #pragma omp parallel firstprivate(my_iterations)
  {
    tid = omp_get_thread_num();
    while ((error >= eps) && (my_iterations < maxit))
    {
      my_error[tid] = 0.0;
      #pragma omp for schedule(OMP_SCHED)
      for (i = 1; i < (m - 1); i++)
        for (j = i % 2; j < ((n / 2) - ((i + 1) % 2)); j++)
      {
        v = 0.25 * (((red[i - 1][j] + red[i + 1][j]) + red[i][j - (i % 2)]) + red[i][j + ((i + 1) % 2)]);
        my_error[tid] += (v - black[i][j]) * (v - black[i][j]);
        black[i][j] = v;
      }


      #pragma omp for schedule(OMP_SCHED)
      for (i = 1; i < (m - 1); i++)
        for (j = (i + 1) % 2; j < ((n / 2) - (i % 2)); j++)
      {
        v = 0.25 * (((black[i - 1][j] + black[i + 1][j]) + black[i][j - ((i + 1) % 2)]) + black[i][j + (i % 2)]);
        my_error[tid] += (v - red[i][j]) * (v - red[i][j]);
        red[i][j] = v;
      }


      #pragma omp single
      {
        for (j = 0; j < nthreads; j++)
          error += my_error[j];

        error = sqrt(error) / (n * m);
      }
      my_iterations++;
    }

    #pragma omp master
    *iterations = my_iterations;
  }
  free(my_error);
  return error;
}

