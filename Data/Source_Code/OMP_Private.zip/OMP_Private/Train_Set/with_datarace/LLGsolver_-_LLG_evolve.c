int LLG_dim;
int skyrmion_transits;
void LLG_ini(int Nx_in, int Ny_in, double bapp_in, double dmi_in, double alpha_in, double beta_in, double K_in, double jx_in, double jy_in, double J0value_in);
void LLG_evolve(double *mag, double *mag_new, double dt);
void normalize(double *mag_new);
void reset_corners(double *mag_new);
void find_max(double *mag, int *skcoord, int sign);
double find_skyrmion_max(double *mag, int sign);
void monitor_transits(double *mag, int sign);
void monitor_new_record(double *mag, int sign);
double magenergy(double *mag);
void open_bc(double *mag);
void periodic_bc(double *mag);
void notch_bc(double *mag, double notch_x0, double notch_x1, double notch_y0);
void notch_zero_bc(double *mag, double notch_x0, double notch_x1, double notch_y0);
void zero_bc(double *mag);
void x_dwall_bc(double *mag);
void y_dwall_bc(double *mag);
void z_dwall_bc(double *mag);
static int Nx;
static int Ny;
static double dmi;
static double bapp;
static double alpha;
static double alpha2;
static double beta;
static double K;
static double jx;
static double jy;
static double J0value;
static double dmi_renorm;
static const double th_prev = 0.5 * (THETA - 1.);
static const double th = -THETA;
static const double th_next = 0.5 * (THETA + 1.);
static double grad;
int ind(int i, int j);
int indx(int i, int j);
int indy(int i, int j);
int indz(int i, int j);
void add_exchange(double *mag, int i, int j, double *beff);
void add_anisotropy_x(double *mag, int i, int j, double *beff);
void add_anisotropy_y(double *mag, int i, int j, double *beff);
void add_anisotropy_z(double *mag, int i, int j, double *beff);
void add_DMI(double *mag, int i, int j, double *beff);
void add_DMI_DY(double *mag, int i, int j, double *beff);
void add_DMI_renorm_J0value(double *mag, int i, int j, double *beff);
void cross(const double *a, const double *b, double *axb);
void dj(double *mag, int i, int j, double jx, double jy, double *result);
void sst_torque(double *mag, int i, int j, double jx, double jy, double *tsst);
void sst_torque_inplane(double *mag, int i, int j, double jx, double jy, double *tsst);
void sst_torque_debug(double *mag, int i, int j, double jx, double jy, double *tsst);
void normalize(double *mag_new);
double find_smz_max(double *mag, int sign, int isec);
void LLG_evolve(double *mag, double *mag_new, double dt)
{
  int i;
  int j;
  int n;
  #pragma omp parallel default(none) shared(Nx,Ny,bapp,mag,mag_new,dt,alpha,jx,jy)
  {
    #pragma omp for schedule(static)
    for (i = 1; i <= Nx; i++)
      for (j = 1; j <= Ny; j++)
    {
      double beff[3] = {0., 0., bapp};
      double magxbeff[3];
      double magxmagxbeff[3];
      double rhs[3];
      add_exchange(mag, i, j, beff);
      add_DMI_renorm_J0value(mag, i, j, beff);
      cross(&mag[ind(i, j)], beff, magxbeff);
      cross(&mag[ind(i, j)], magxbeff, magxmagxbeff);
      double tsst[3];
      double magxtsst[3];
      sst_torque(mag, i, j, jx, jy, tsst);
      cross(&mag[ind(i, j)], tsst, magxtsst);
      for (n = 0; n < 3; n++)
        rhs[n] = (((-magxbeff[n]) - (alpha * magxmagxbeff[n])) + tsst[n]) + (alpha * magxtsst[n]);

      for (n = 0; n < 3; n++)
        mag_new[ind(i, j) + n] = mag[ind(i, j) + n] + (dt * rhs[n]);

    }


  }
}

