void main()
{
  int n;
  long i;
  double x;
  double a;
  double z;
  double pi16ds = 3.1415926535897932;
  double sum = 0.0;
  printf("Introduce la precision del calculo (número de intervalos > 0): ");
  scanf("%d", &n);
  a = omp_get_wtime();
  double h = 1.0 / ((double) n);
  #pragma omp parallel num_threads(NH) reduction(+:sum)
  #pragma omp for schedule(dynamic, n/NH)
  for (i = 0; i < n; i++)
  {
    x = h * (0.5 + ((double) i));
    sum += 4.0 / (1.0 + (x * x));
  }

  double pi = sum * h;
  printf("\nEl valor aproximado de PI es %0.9f con un error de %0.9f\n", pi, fabs(pi - pi16ds));
  z = omp_get_wtime();
  printf("El programa ha tardado %0.9f segundos \n", z - a);
}

