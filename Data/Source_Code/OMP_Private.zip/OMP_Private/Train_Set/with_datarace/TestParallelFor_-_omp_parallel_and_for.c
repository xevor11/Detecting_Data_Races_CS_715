int omp_parallel_and_for()
{
  int i;
  int tid;
  int counter = 0;
  int nt = omp_get_num_procs();
  int *counters = (int *) calloc(nt, sizeof(int));
  if (counters == 0)
    exit(-1);

  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    for (i = 0; i < 10000; ++i)
    {
      counters[tid]++;
    }

  }
  for (i = 0; i < nt; ++i)
  {
    counter += counters[i];
  }

  return counter;
}

