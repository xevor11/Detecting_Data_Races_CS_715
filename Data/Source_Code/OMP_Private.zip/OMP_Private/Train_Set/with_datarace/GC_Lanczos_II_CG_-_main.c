double min_QR_method(double _alpha[], double _beta[], int MAX);
double SSD_function(int l, int i);
int main(void)
{
  int n;
  int n_temp;
  int i;
  int k;
  int m;
  int NSYSTEM = (2 * 0.5) + 1;
  int NSTATE = pow(NSYSTEM, 20);
  int NSTATE_2d = pow(NSYSTEM, 20 / 2);
  int nud;
  int ndu;
  int mud;
  int mdu;
  double S1;
  double S2;
  double M;
  double Wud;
  double Wdu;
  long PS1;
  long PS2;
  static long LIST1[7000000];
  static int LIST2a[200000];
  static int LIST2b[200000];
  int ia;
  int ib;
  int ja = 0;
  int jb = 0;
  int pib = -1;
  double dd = 1.0;
  double h = 0.0;
  double h_var[20];
  double stz[20];
  double SZVAL;
  FILE *fp;
  int dim_subspace;
  static double v0[7000000];
  static double v1[7000000];
  static double v2[7000000];
  static double alpha[300 + 1];
  static double beta[300 + 1];
  static double B[7000000 + 1] = {0};
  static double R[7000000 + 1] = {0};
  static double PP[7000000 + 1] = {0};
  static double X[7000000 + 1] = {0};
  static double XX[7000000 + 1] = {0};
  static double Y[7000000 + 1] = {0};
  double alphaj;
  double betaj;
  int II;
  int ii;
  double BNORM;
  double RNORM;
  double RNORM2;
  double XNORM;
  double RP;
  double YP;
  double XB;
  printf(" SPIN=%.1f NSITE=%d\n", 0.5, 20);
  printf("dd=%lf h=%lf \n", dd, h);
  printf("(h	m0)\n");
  for (h = 0.0; h < 0.01; h += 0.1)
  {
    SZVAL = 1.0;
    m = 0;
    ja = 0, jb = 0, pib = -1;
    for (n = 0; n < NSTATE; n++)
    {
      M = 0;
      n_temp = n;
      for (i = 0; i < 20; i++)
      {
        M += (n_temp % NSYSTEM) - 0.5;
        n_temp /= NSYSTEM;
      }

      if (M == SZVAL)
      {
        m++;
        ia = n % NSTATE_2d;
        ib = n / NSTATE_2d;
        if (ib == pib)
        {
          ja++;
        }
        else
        {
          jb = jb + ja;
          ja = 1;
          pib = ib;
          LIST2b[ib] = jb;
        }

        LIST2a[ia] = ja;
        LIST1[m] = n;
      }

    }

    dim_subspace = m;
    for (m = 1; m <= dim_subspace; m++)
    {
      v0[m] = 0;
      v1[m] = 0;
      v2[m] = 0;
    }

    v1[4] = 1;
    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      for (i = 1; i <= 20; i++)
      {
        PS1 = pow(NSYSTEM, i - 1);
        PS2 = pow(NSYSTEM, i);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
        Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1.0))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1.0));
        Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1.0))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1.0));
        if (Wud < 0.0000001)
        {
          nud = n_temp;
        }
        else
        {
          nud = (n_temp + PS1) - PS2;
        }

        if (Wdu < 0.0000001)
        {
          ndu = n_temp;
        }
        else
        {
          ndu = (n_temp - PS1) + PS2;
        }

        ia = nud % NSTATE_2d;
        ib = nud / NSTATE_2d;
        mud = LIST2a[ia] + LIST2b[ib];
        ia = ndu % NSTATE_2d;
        ib = ndu / NSTATE_2d;
        mdu = LIST2a[ia] + LIST2b[ib];
        v0[m] += ((S1 * S2) * SSD_function(1, i)) * v1[m];
        v0[m] += ((dd * SSD_function(1, i)) * Wud) * v1[mud];
        v0[m] += ((dd * SSD_function(1, i)) * Wdu) * v1[mdu];
        v0[m] += (((-h) * SSD_function(0, i)) * S1) * v1[m];
      }

    }

    alpha[1] = 0;
    for (k = 1; k <= dim_subspace; k++)
    {
      alpha[1] += v1[k] * v0[k];
    }

    double sum = 0;
    for (k = 1; k <= dim_subspace; k++)
    {
      v2[k] = v0[k] - (alpha[1] * v1[k]);
      sum += v2[k] * v2[k];
    }

    beta[1] = sqrt(sum);
    for (k = 1; k <= dim_subspace; k++)
    {
      v2[k] = v2[k] / beta[1];
    }

    int I;
    double E0 = 0;
    double Emin = 0;
    double E_before = 0;
    for (I = 2; I <= 300; I++)
    {
      for (m = 1; m <= dim_subspace; m++)
      {
        v0[m] = 0;
      }

      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        n_temp = LIST1[m];
        for (i = 1; i <= 20; i++)
        {
          PS1 = pow(NSYSTEM, i - 1);
          PS2 = pow(NSYSTEM, i);
          S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
          S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
          Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
          Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
          if (Wud < 0.0000001)
          {
            nud = n_temp;
          }
          else
          {
            nud = (n_temp + PS1) - PS2;
          }

          if (Wdu < 0.0000001)
          {
            ndu = n_temp;
          }
          else
          {
            ndu = (n_temp - PS1) + PS2;
          }

          ia = nud % NSTATE_2d;
          ib = nud / NSTATE_2d;
          mud = LIST2a[ia] + LIST2b[ib];
          ia = ndu % NSTATE_2d;
          ib = ndu / NSTATE_2d;
          mdu = LIST2a[ia] + LIST2b[ib];
          v0[m] += ((S1 * S2) * SSD_function(1, i)) * v2[m];
          v0[m] += ((dd * SSD_function(1, i)) * Wud) * v2[mud];
          v0[m] += ((dd * SSD_function(1, i)) * Wdu) * v2[mdu];
          v0[m] += (((-h) * SSD_function(0, i)) * S1) * v2[m];
        }

      }

      alpha[I] = 0;
      for (k = 1; k <= dim_subspace; k++)
      {
        alpha[I] += v2[k] * v0[k];
      }

      for (k = 1; k <= dim_subspace; k++)
      {
        v0[k] = (v0[k] - (alpha[I] * v2[k])) - (beta[I - 1] * v1[k]);
        v1[k] = v2[k];
      }

      beta[I] = 0;
      sum = 0;
      for (k = 1; k <= dim_subspace; k++)
      {
        sum += v0[k] * v0[k];
      }

      beta[I] = sqrt(sum);
      for (k = 1; k <= dim_subspace; k++)
      {
        v2[k] = v0[k] / beta[I];
      }

      if (((I % 2) == 0) && (5 < I))
      {
        Emin = min_QR_method(alpha, beta, I);
        if ((fabs(Emin - E_before) < 0.00001) || (I == 300))
        {
          E0 = Emin;
          break;
        }

        E_before = Emin;
      }

    }

    for (m = 1; m <= dim_subspace; m++)
    {
      B[m] = 0;
      R[m] = 0;
      PP[m] = 0;
      X[m] = 0;
      XX[m] = 0;
      Y[m] = 0;
    }

    B[4] = 1.0;
    for (II = 1; II <= 300; II++)
    {
      BNORM = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        BNORM += B[m] * B[m];
        R[m] = B[m];
        PP[m] = B[m];
        X[m] = 0.0;
      }

      for (ii = 1; ii <= 50; ii++)
      {
        for (m = 1; m <= dim_subspace; m++)
        {
          Y[m] = (-PP[m]) * E0;
        }

        #pragma omp parallel for
        for (m = 1; m <= dim_subspace; m++)
        {
          n_temp = LIST1[m];
          for (i = 1; i <= 20; i++)
          {
            PS1 = pow(NSYSTEM, i - 1);
            PS2 = pow(NSYSTEM, i);
            S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
            S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
            Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
            Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
            if (Wud < 0.0000001)
            {
              nud = n_temp;
            }
            else
            {
              nud = (n_temp + PS1) - PS2;
            }

            if (Wdu < 0.0000001)
            {
              ndu = n_temp;
            }
            else
            {
              ndu = (n_temp - PS1) + PS2;
            }

            ia = nud % NSTATE_2d;
            ib = nud / NSTATE_2d;
            mud = LIST2a[ia] + LIST2b[ib];
            ia = ndu % NSTATE_2d;
            ib = ndu / NSTATE_2d;
            mdu = LIST2a[ia] + LIST2b[ib];
            Y[m] += ((S1 * S2) * SSD_function(1, i)) * PP[m];
            Y[m] += ((dd * SSD_function(1, i)) * Wud) * PP[mud];
            Y[m] += ((dd * SSD_function(1, i)) * Wdu) * PP[mdu];
            Y[m] += (((-h) * SSD_function(0, i)) * S1) * PP[m];
          }

        }

        RP = 0.0;
        YP = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          RP += PP[m] * R[m];
          YP += PP[m] * Y[m];
        }

        alphaj = RP / YP;
        RNORM = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          X[m] += alphaj * PP[m];
          RNORM += R[m] * R[m];
        }

        RNORM2 = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          R[m] += (-alphaj) * Y[m];
          RNORM2 += R[m] * R[m];
        }

        betaj = RNORM2 / RNORM;
        for (m = 1; m <= dim_subspace; m++)
        {
          PP[m] = R[m] + (betaj * PP[m]);
        }

        if ((sqrt(RNORM2) / sqrt(BNORM)) < 0.00001)
        {
          break;
        }

      }

      XNORM = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        XNORM += X[m] * X[m];
      }

      XNORM = sqrt(XNORM);
      XB = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        X[m] /= XNORM;
        XB += X[m] * B[m];
      }

      if (fabs(fabs(XB) - 1.0) < 0.00001)
      {
        for (m = 1; m <= dim_subspace; m++)
        {
          XX[m] = X[m];
        }

        break;
      }

      for (m = 1; m <= dim_subspace; m++)
      {
        B[m] = X[m];
      }

    }

    Wud = 0;
    for (m = 1; m <= dim_subspace; m++)
    {
      Wud += XX[m] * XX[m];
    }

    Wud = sqrt(Wud);
    for (m = 1; m <= dim_subspace; m++)
    {
      XX[m] /= Wud;
    }

    double output_E = 0.0;
    for (m = 1; m <= dim_subspace; m++)
    {
      PP[m] = 0;
    }

    #pragma omp paralell for reduction(+:output_E)
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      for (i = 1; i < 20; i++)
      {
        PS1 = pow(NSYSTEM, i - 1);
        PS2 = pow(NSYSTEM, i);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
        Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
        Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
        if (Wud < 0.0000001)
        {
          nud = n_temp;
        }
        else
        {
          nud = (n_temp + PS1) - PS2;
        }

        if (Wdu < 0.0000001)
        {
          ndu = n_temp;
        }
        else
        {
          ndu = (n_temp - PS1) + PS2;
        }

        ia = nud % NSTATE_2d;
        ib = nud / NSTATE_2d;
        mud = LIST2a[ia] + LIST2b[ib];
        ia = ndu % NSTATE_2d;
        ib = ndu / NSTATE_2d;
        mdu = LIST2a[ia] + LIST2b[ib];
        PP[m] += ((S1 * S2) * SSD_function(1, i)) * XX[m];
        PP[m] += ((dd * SSD_function(1, i)) * Wud) * XX[mud];
        PP[m] += ((dd * SSD_function(1, i)) * Wdu) * XX[mdu];
        PP[m] += (((-h) * SSD_function(0, i)) * S1) * XX[m];
      }

      PP[m] += (((-h) * SSD_function(0, 20)) * S2) * XX[m];
      output_E += PP[m] * XX[m];
    }

    printf("SPIN=%.1f NSITE=%d dim_subspace=%d(SZ=%4.2f) H=%.2lf dd=%.1lf\n", 0.5, 20, dim_subspace, SZVAL, h, dd);
    printf("E0_Lanczos = %lf\n", E0);
    printf("E0_exp = %lf\n", output_E);
    double Siz_exp[20 + 1] = {0};
    printf("Siz_exp\n");
    for (i = 1; i <= 20; i++)
    {
      for (m = 1; m <= dim_subspace; m++)
      {
        n_temp = LIST1[m];
        PS1 = pow(NSYSTEM, i - 1);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        Siz_exp[i] += (S1 * XX[m]) * XX[m];
      }

      printf("%d %lf\n", i, Siz_exp[i]);
    }

    double Or[20 + 1];
    int r;
    for (r = 1; r < (20 / 2); r++)
    {
      Or[r] = 0;
      for (i = -r; i < r; i++)
      {
        Or[r] += Siz_exp[i + (20 / 2)];
      }

      Or[r] /= 2 * r;
    }

    int data_num = (20 / 2) - 2;
    double m0;
    for (i = 2; i <= data_num; i++)
    {
      double sum_x4 = 0;
      double sum_x2 = 0;
      double sum_xxy = 0;
      double sum_y = 0;
      for (r = 1; r <= i; r++)
      {
        sum_x4 += pow(r, 4);
        sum_x2 += pow(r, 2);
        sum_xxy += (r * r) * Or[r];
        sum_y += Or[r];
      }

      m0 = ((sum_x2 * sum_xxy) - (sum_x4 * sum_y)) / ((sum_x2 * sum_x2) - (i * sum_x4));
    }

    printf("%lf %lf\n", h, m0);
  }

  return 0;
}

