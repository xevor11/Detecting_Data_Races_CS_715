double simpsons(double a, double b, long n);
double f(double x);
double simpsons(double a, double b, long n)
{
  double h = (b - a) / n;
  double result;
  double p;
  int i;
  p = 0;
  #pragma omp parallel
  {
    printf("%d\n", omp_get_num_threads());
  }
  #pragma omp parallel for reduction (+:p)
  for (i = 1; i < n; i++)
  {
    if ((i % 2) == 0)
    {
      p += f(a + (i * h)) * 2;
    }
    else
    {
      p += f(a + (i * h)) * 4;
    }

  }

  #pragma omp single
  result = (h / 3) * ((f(a) + f(b)) + p);
  return result;
}

