double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void loop1(void)
{
  int i;
  int j;
  #pragma omp parallel for default(none) shared(a,b) schedule(guided, 1)
  for (i = 0; i < 729; i++)
  {
    for (j = 729 - 1; j > i; j--)
    {
      a[i][j] += cos(b[i][j]);
    }

  }


  int i;
  int j;
  int k;
  struct timeval srun;
  struct timeval scalc;
  struct timeval ecalc;
  gettimeofday(&srun, 0);
  for (i = 0; i < 1500; i++)
  {
    for (j = 0; j < 2000; j++)
    {
      a[i][j] = (double) (i + j);
    }

  }

  for (i = 0; i < 2000; i++)
  {
    for (j = 0; j < 1000; j++)
    {
      b[i][j] = (double) (i * j);
    }

  }

  gettimeofday(&scalc, 0);
  float sum;
  #pragma omp parallel for private(sum,i,k,j)
  for (i = 0; i < 1500; i++)
  {
    for (k = 0; k < 1000; k++)
    {
      sum = 0.0;
      for (j = 0; j < 2000; j++)
      {
        sum = sum + (a[i][j] * b[j][k]);
      }

      c[i][k] = sum;
    }

  }

  gettimeofday(&ecalc, 0);
  printf("OPENMP-MM: Init time: %3.02f   Calc time: %3.02f   GFlop/s: %3.02f\n", (scalc.tv_sec - srun.tv_sec) + ((1 / 1000000.0) * (scalc.tv_usec - srun.tv_usec)), (ecalc.tv_sec - scalc.tv_sec) + ((1 / 1000000.0) * (ecalc.tv_usec - scalc.tv_usec)), ((((1e-9 * 2.0) * 1500) * 2000) * 1000) / ((ecalc.tv_sec - scalc.tv_sec) + ((1 / 1000000.0) * (ecalc.tv_usec - scalc.tv_usec))));
  exit(0);
}

