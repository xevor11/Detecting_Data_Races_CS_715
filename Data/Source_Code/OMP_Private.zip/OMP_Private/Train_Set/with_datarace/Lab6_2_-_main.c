int main(void)
{
  int count;
  int i;
  count = 0;
  #pragma omp parallel for
  for (i = 0; i < 1000000; i++)
    if (no_problem_with_digits(i))
  {
    #pragma omp atomic
    count++;
  }


  printf("There are %d acceptable ID numbers\n", count);
  return 0;
}

