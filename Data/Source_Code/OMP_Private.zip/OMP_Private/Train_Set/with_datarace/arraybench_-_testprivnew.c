double btest[IDA];
double atest[IDA];
#pragma omp threadprivate (btest);
void testprivnew()
{
  int j;
  for (j = 0; j < innerreps; j++)
  {
    #pragma omp parallel
    {
      array_delay(delaylength, atest);
    }
  }

}

