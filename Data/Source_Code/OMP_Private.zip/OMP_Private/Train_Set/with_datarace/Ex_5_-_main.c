void main(int x, char **args)
{
  int Tam_Thread = 2;
  int turn = 1;
  int VarComp = 0;
  int i;
  bool wantp = 0;
  bool wantq = 0;
  le_entrada(args, &Tam_Thread);
  omp_set_num_threads(Tam_Thread);
  #pragma omp
  #pragma omp sections
  {
    #pragma omp section
    {
      for (i = 0; i < 100; i++)
      {
        wantp = 1;
        while (wantq)
        {
          if (turn == 2)
          {
            wantp = 0;
            while (turn == 1)
            {
            }

            wantp = 1;
          }

        }

        VarComp++;
        #pragma omp atomic
        turn++;
        wantp = 0;
      }

    }
    #pragma omp section
    {
      for (i = 0; i < 100; i++)
      {
        wantq = 1;
        while (wantp)
        {
          if (turn == 1)
          {
            wantq = 0;
            while (turn == 2)
            {
            }

            wantq = 1;
          }

        }

        VarComp += 10;
        #pragma omp atomic
        turn--;
        wantq = 0;
      }

    }
  }
  printf("%d\n", VarComp);
}

