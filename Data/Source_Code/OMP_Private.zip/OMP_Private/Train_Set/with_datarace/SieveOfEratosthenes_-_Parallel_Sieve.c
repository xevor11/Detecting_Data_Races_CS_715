void Sieve_Of_Eratosthenes(unsigned long long p, char *NumberList, long MaxNumber);
double Serial_Sieve(char *NumberList, long MaxNumber);
double Parallel_Sieve(char *NumberList, long MaxNumber, int ThreadCount, int Scheduling);
void Print_Serial_Header();
void Print_Parallel_Header(int num_threads, int Dynamic_Scheduling);
void Print_Speedup(double SerialExecutionTime, double ParallelExecutionTime, int Scheduling, int ThreadCount);
void Print_Primes_To_File(char *NumberList, long MaxNumber, char *FileName);
void itoa(int number, char *Buffer, int base, int bufferLen);
double Parallel_Sieve(char *NumberList, long MaxNumber, int ThreadCount, int Scheduling)
{
  unsigned long long p;
  double Start = omp_get_wtime();
  double ExecutionTime;
  for (long i = 0; i <= MaxNumber; i++)
  {
    NumberList[i] = 0;
  }

  if (Scheduling == 1)
  {
    int i;
    #pragma omp parallel for num_threads(ThreadCount) schedule( dynamic, 1)
    for (p = 2; p <= MaxNumber; p++)
    {
      if (NumberList[p] == 1)
      {
        continue;
      }
      else
      {
        Sieve_Of_Eratosthenes(p, NumberList, MaxNumber);
      }

    }

  }
  else
    if (Scheduling == 0)
  {
    #pragma omp parallel for num_threads(ThreadCount) schedule( static, 1)
    for (p = 2; p <= MaxNumber; p++)
    {
      if (NumberList[p] == 1)
      {
        continue;
      }
      else
      {
        Sieve_Of_Eratosthenes(p, NumberList, MaxNumber);
      }

    }

  }


  ExecutionTime = omp_get_wtime() - Start;
  printf("Serial Execution Time: %f6 seconds\n\n", ExecutionTime);
  return ExecutionTime;
}

