void getChan(unsigned char *inbuffer, float *outbuffer, int chan, int nchans, int nsamps, int index)
{
  int ii;
  #pragma omp parallel for default(shared)
  for (ii = 0; ii < nsamps; ii++)
    outbuffer[index + ii] = inbuffer[(ii * nchans) + chan];

}

