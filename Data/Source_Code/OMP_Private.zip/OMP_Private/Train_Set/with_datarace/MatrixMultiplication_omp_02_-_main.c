int main(int argc, char **argv)
{
  int num_procs;
  int max_threads;
  int thread_id;
  int NRA;
  int NCA;
  int NRB;
  int NCB;
  int i;
  int j;
  int k;
  double wall_time = 0.00;
  if (argc != 5)
  {
    printf("\n    OMP_NUM_THREADS=2\n");
    printf("\n    Usage   : %s NROWS_A NCOLS_A NROWS_B NCOLS_B", argv[0]);
    printf("\n    Example : %s 1024 1024 1024 1024", argv[0]);
    printf("\n              %s 1024 1024 1024 1\n\n", argv[0]);
    exit(1);
  }

  NRA = atoi(argv[1]);
  NCA = atoi(argv[2]);
  NRB = atoi(argv[3]);
  NCB = atoi(argv[4]);
  int A[NRA][NCA];
  int B[NRB][NCB];
  int C[NRA][NCB];
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  if (thread_id == 0)
  {
    printf("\n");
    printf("  OpenMP C program to perform matrix multiplication.\n\n");
    printf("  Total number of processors available : %d\n", num_procs);
    printf("  Maximum number of usable threads     : %d\n", max_threads);
    printf("  Number of rows in A (and C)          : %d\n", NRA);
    printf("  Number of columns in A               : %d\n", NCA);
    printf("  Number of rows in B                  : %d\n", NRB);
    printf("  Number of columns in B (and C)       : %d\n", NCB);
    if (NCA != NRB)
    {
      printf("\n    Number of columns in A does not equal the number of rows in B.");
      printf("\n    Exiting.\n\n");
      exit(1);
    }

    for (i = 0; i < NRA; i++)
    {
      for (j = 0; j < NCA; j++)
      {
        A[i][j] = ((i * ((NRA - i) - 1)) * j) * ((NCA - j) - 1);
      }

    }

    for (i = 0; i < NRB; i++)
    {
      for (j = 0; j < NCB; j++)
      {
        B[i][j] = (i + j) + 2;
      }

    }

    for (i = 0; i < NRA; i++)
    {
      for (j = 0; j < NCB; j++)
      {
        C[i][j] = 0;
      }

    }

  }

  #pragma omp parallel shared(A, B, C, NRA, NCA, NRB, NCB)
  {
    #pragma omp for
    for (i = 0; i < NRA; i++)
    {
      for (j = 0; j < NCB; j++)
      {
        for (k = 0; k < NCA; k++)
        {
          C[i][j] = C[i][j] + (A[i][k] * B[k][j]);
        }

      }

    }

  }
  wall_time = omp_get_wtime() - wall_time;
  if (thread_id == 0)
  {
    printf("  Total time taken                     : %f seconds\n\n", wall_time);
  }

  return 0;
}

