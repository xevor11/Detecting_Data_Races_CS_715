void delay();
void delay()
{
  int i;
  int j;
  int k;
  float sum = 0.0;
  #pragma omp parallel for
  for (i = 0; i < 100; i++)
    for (j = 0; j < 100; j++)
    for (k = 0; k < 100; k++)
    if (k % 2)
  {
    sum += (i * j) * 9.77;
  }
  else
  {
    sum -= (i / (j + 1)) * 7.99;
  }




  sum += 1.0;
}

