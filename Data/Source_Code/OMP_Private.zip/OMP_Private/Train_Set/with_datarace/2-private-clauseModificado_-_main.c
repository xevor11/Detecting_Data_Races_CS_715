int main(int argc, char **argv)
{
  int a[5000];
  int i;
  int j;
  int sum;
  int lock_index;
  for (i = 0; i < 5000; i++)
    a[i] = 0;

  #pragma omp parallel private (i,j,lock_index)
  {
    #pragma omp for schedule(dynamic,1)
    for (i = 0; i < 5000; i++)
    {
      j = (i * i) % 5000;
      #pragma omp critical
      {
        a[j] = a[j] + 5;
      }
    }

    #pragma omp for schedule(dynamic,1)
    for (i = 0; i < 5000; i++)
    {
      j = (i * i) % 5000;
      a[j] = a[j] - 5;
    }

    sum = 0;
    #pragma omp for reduction (+:sum)
    for (i = 0; i < 5000; i++)
    {
      sum += a[i];
    }

  }
  printf("sum of a[] = %d\n", sum);

  int i;
  int n = 7;
  int a[n];
  int suma;
  for (i = 0; i < n; i++)
    a[i] = i;

  suma = 0;
  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      suma = suma + a[i];
      printf("thread %d suma a[%d] / ", 0, i);
    }

    printf("\n* thread %d suma= %d", 0, suma);
  }
  printf("\n* Fuera de la region Parallel: thread %d suma= %d", 0, suma);
  printf("\n");
}

