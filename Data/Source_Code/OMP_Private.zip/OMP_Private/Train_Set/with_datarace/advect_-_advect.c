void advect(t2, t3, u1, v1, w1, u2, v2, w2, u3, v3, w3, dx, dy, dz, dt, tstep, i1, i2x, i2y, i2z, i2x_u, i2y_v, i2z_w, nx, ny, nz)
float t2[NXDIM][NYDIM][NZDIM];
float t3[NXDIM][NYDIM][NZDIM];
float u1[NXDIM_U][NYDIM][NZDIM];
float v1[NXDIM][NYDIM_V][NZDIM];
float w1[NXDIM][NYDIM][NZDIM_W];
float u2[NXDIM_U][NYDIM][NZDIM];
float v2[NXDIM][NYDIM_V][NZDIM];
float w2[NXDIM][NYDIM][NZDIM_W];
float u3[NXDIM_U][NYDIM][NZDIM];
float v3[NXDIM][NYDIM_V][NZDIM];
float w3[NXDIM][NYDIM][NZDIM_W];
float dx;
float dy;
float dz;
float dt;
float tstep;
int i1;
int i2x;
int i2y;
int i2z;
int i2x_u;
int i2y_v;
int i2z_w;
int nx;
int ny;
int nz;
{
  void advect1D();
  int i;
  int j;
  int k;
  float temp1[NXDIM];
  float temp2[NXDIM];
  float vel1D[NX + 1];
  #pragma omp parallel for shared(u1, u2, v2, w2, u3)
  for (i = i1 + 1; i <= (i2x_u - 1); i++)
    for (j = i1; j <= i2y; j++)
    for (k = i1; k <= i2z; k++)
    u3[i][j][k] = u1[i][j][k] - ((tstep / 4.0) * (((((u2[i + 1][j][k] * u2[i + 1][j][k]) - (u2[i - 1][j][k] * u2[i - 1][j][k])) / dx) + ((((v2[i][j + 1][k] + v2[i - 1][j + 1][k]) * (u2[i][j + 1][k] - u2[i][j][k])) + ((v2[i][j][k] + v2[i - 1][j][k]) * (u2[i][j][k] - u2[i][j - 1][k]))) / dy)) + ((((w2[i][j][k + 1] + w2[i - 1][j][k + 1]) * (u2[i][j][k + 1] - u2[i][j][k])) + ((w2[i][j][k] + w2[i - 1][j][k]) * (u2[i][j][k] - u2[i][j][k - 1]))) / dz)));



  #pragma omp parallel for shared(v1, u2, v2, w2, v3)
  for (i = i1; i <= i2x; i++)
    for (j = i1; j <= (i2y_v - 1); j++)
    for (k = i1; k <= i2z; k++)
    v3[i][j][k] = v1[i][j][k] - ((tstep / 4.0) * ((((((u2[i + 1][j][k] + u2[i + 1][j - 1][k]) * (v2[i + 1][j][k] - v2[i][j][k])) + ((u2[i][j][k] + u2[i][j - 1][k]) * (v2[i][j][k] - v2[i - 1][j][k]))) / dx) + (((v2[i][j + 1][k] * v2[i][j + 1][k]) - (v2[i][j - 1][k] * v2[i][j - 1][k])) / dy)) + ((((w2[i][j][k + 1] + w2[i][j - 1][k + 1]) * (v2[i][j][k + 1] - v2[i][j][k])) + ((w2[i][j][k] + w2[i][j - 1][k]) * (v2[i][j][k] - v2[i][j][k - 1]))) / dz)));



  #pragma omp parallel for shared(w1, u2, v2, w2, w3)
  for (i = i1; i <= i2x; i++)
    for (j = i1; j <= i2y; j++)
    for (k = i1 + 1; k <= (i2z_w - 1); k++)
    w3[i][j][k] = w1[i][j][k] - ((tstep / 4.0) * ((((((u2[i + 1][j][k] + u2[i + 1][j][k - 1]) * (w2[i + 1][j][k] - w2[i][j][k])) + ((u2[i][j][k] + u2[i][j][k - 1]) * (w2[i][j][k] - w2[i - 1][j][k]))) / dx) + ((((v2[i][j + 1][k] + v2[i][j + 1][k - 1]) * (w2[i][j + 1][k] - w2[i][j][k])) + ((v2[i][j][k] + v2[i][j][k - 1]) * (w2[i][j][k] - w2[i][j - 1][k]))) / dy)) + (((w2[i][j][k + 1] * w2[i][j][k + 1]) - (w2[i][j][k - 1] * w2[i][j][k - 1])) / dz)));



  for (j = i1; j <= i2y; j++)
    for (k = i1; k <= i2z; k++)
  {
    #pragma omp parallel for shared(temp1, temp2, t2)
    for (i = 0; i < NXDIM; i++)
    {
      temp1[i] = t2[i][j][k];
      temp2[i] = 0.0;
    }

    #pragma omp parallel for shared(vel1D, u2)
    for (i = i1; i <= i2x_u; i++)
      vel1D[i - i1] = u2[i][j][k];

    advect1D(temp1, temp2, vel1D, dx, dt / 2.0, i1, i2x, nx, 'P');
    #pragma omp parallel for shared(temp2, t3)
    for (i = i1; i <= i2x; i++)
      t3[i][j][k] = temp2[i];

  }


  bc(t3, t3, u1, v1, w1, i1, i2x, i2y, i2z, i2x_u, i2y_v, i2z_w, nx, ny, nz);
  for (i = i1; i <= i2x; i++)
    for (k = i1; k <= i2z; k++)
  {
    #pragma omp parallel for shared(temp1, temp2, t3)
    for (j = 0; j < NYDIM; j++)
    {
      temp1[j] = t3[i][j][k];
      temp2[j] = 0.0;
    }

    #pragma omp parallel for shared(vel1D, v2)
    for (j = i1; j <= i2y_v; j++)
      vel1D[j - i1] = v2[i][j][k];

    advect1D(temp1, temp2, vel1D, dy, dt / 2.0, i1, i2y, ny, 'P');
    #pragma omp parallel for shared(temp2, t3)
    for (j = i1; j <= i2y; j++)
      t3[i][j][k] = temp2[j];

  }


  bc(t3, t3, u1, v1, w1, i1, i2x, i2y, i2z, i2x_u, i2y_v, i2z_w, nx, ny, nz);
  for (i = i1; i <= i2x; i++)
    for (j = i1; j <= i2y; j++)
  {
    #pragma omp parallel for shared(temp1, temp2, t3)
    for (k = 0; k < NZDIM; k++)
    {
      temp1[k] = t3[i][j][k];
      temp2[k] = 0.0;
    }

    #pragma omp parallel for shared(vel1D, w2)
    for (k = i1; k <= i2z_w; k++)
      vel1D[k - i1] = w2[i][j][k];

    advect1D(temp1, temp2, vel1D, dz, dt, i1, i2z, nz, 'P');
    #pragma omp parallel for shared(temp2, t3)
    for (k = i1; k <= i2z; k++)
      t3[i][j][k] = temp2[k];

  }


  bc(t3, t3, u1, v1, w1, i1, i2x, i2y, i2z, i2x_u, i2y_v, i2z_w, nx, ny, nz);
  for (i = i1; i <= i2x; i++)
    for (k = i1; k <= i2z; k++)
  {
    #pragma omp parallel for shared(temp1, temp2, t3)
    for (j = 0; j < NYDIM; j++)
    {
      temp1[j] = t3[i][j][k];
      temp2[j] = 0.0;
    }

    #pragma omp parallel for shared(vel1D, v2)
    for (j = i1; j <= i2y_v; j++)
      vel1D[j - i1] = v2[i][j][k];

    advect1D(temp1, temp2, vel1D, dy, dt / 2.0, i1, i2y, ny, 'P');
    #pragma omp parallel for shared(temp2, t3)
    for (j = i1; j <= i2y; j++)
      t3[i][j][k] = temp2[j];

  }


  bc(t3, t3, u1, v1, w1, i1, i2x, i2y, i2z, i2x_u, i2y_v, i2z_w, nx, ny, nz);
  for (j = i1; j <= i2y; j++)
    for (k = i1; k <= i2z; k++)
  {
    #pragma omp parallel for shared(temp1, temp2, t3)
    for (i = 0; i < NXDIM; i++)
    {
      temp1[i] = t3[i][j][k];
      temp2[i] = 0.0;
    }

    #pragma omp parallel for shared(vel1D, u2)
    for (i = i1; i <= i2x_u; i++)
      vel1D[i - i1] = u2[i][j][k];

    advect1D(temp1, temp2, vel1D, dx, dt / 2.0, i1, i2x, nx, 'P');
    #pragma omp parallel for shared(temp2, t3)
    for (i = i1; i <= i2x; i++)
      t3[i][j][k] = temp2[i];

  }


  return;

  int tCount;
  int threadsMax;
  int tid;
  printf("Running on HOST\n---------------\n");
  threadsMax = omp_get_max_threads();
  #pragma omp parallel default(none) private(tid) shared(tCount,threadsMax)
  {
    tid = omp_get_thread_num();
    #pragma omp critical
    printf("Hello from thread %d\n", tid);
    #pragma omp barrier
    #pragma omp master
    {
      tCount = omp_get_num_threads();
      printf("Total number of threads used is %d\n", tCount);
      printf("Maximum number of threads available is %d\n", threadsMax);
      printf("================================\n");
    }
  }
}

