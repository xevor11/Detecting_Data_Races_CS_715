extern int B[NMAX];
extern int B2[NMAX];
extern int C[2 * NMAX];
extern int AA[NMAX / LOG2_NMAX];
extern int BB[NMAX / LOG2_NMAX];
extern int S[NMAX];
extern pthread_barrier_t internal_barr;
void omp_function(int n, int log_n, int threads)
{
  int i;
  #pragma omp parallel for schedule(static, threads) shared(B,B2,C,AA,BB) num_threads(threads)
  for (i = 0; i < (n / log_n); i++)
  {
    int pos = i * log_n;
    int val_a = B[pos] - 1;
    AA[i] = rank(val_a, B2, n);
    int rank_a = AA[i] + pos;
    C[rank_a] = B[pos];
    int val_b = B2[pos];
    BB[i] = rank(val_b, B, n);
    int rank_b = BB[i] + pos;
    C[rank_b] = B2[pos];
  }

  #pragma omp parallel for schedule(static, threads) shared(B,B2,C,AA,BB) num_threads(threads)
  for (i = 0; i < (n / log_n); i++)
  {
    int pos = i * log_n;
    int rank = AA[i];
    seq_merge(n, pos, rank);
    rank = BB[i];
    seq_merge(n, rank, pos);
  }

}

