{
  int id;
  int x;
  int y;
  int height;
  int width;
  int top_n;
  int *top_n_ids;
  int bottom_n;
  int *bottom_n_ids;
  int left_n;
  int *left_n_ids;
  int right_n;
  int *right_n_ids;
  double dsv;
} box;
box *boxes;
double *weighted_avg_adjacent_temp;
double AFFECT_RATE = 0;
double EPSILON = 0;
int NUMBER_OF_THREADS = 0;
int NUM_OMP_THREAD = 0;
int num_grid_boxes = 0;
int numberOfIterations;
double maxDSV;
double minDSV;
bool convergenceAchieved = 0;
void computeDSV()
{
  bool flag = 0;
  #pragma omp parallel num_threads(NUMBER_OF_THREADS)
  {
    int threadID = omp_get_thread_num();
    if ((!flag) && (threadID == 0))
    {
      flag = 1;
      NUM_OMP_THREAD = omp_get_num_threads();
    }

    do
    {
      int index;
      int i;
      #pragma omp for
      for (i = 0; i < num_grid_boxes; i++)
      {
        weighted_avg_adjacent_temp[i] = calculateAvgWeightedAdjecentTemp(i);
      }

      #pragma omp barrier
      int t_id = omp_get_thread_num();
      if (t_id == 0)
      {
        commitNewWeightedAvg();
        ++numberOfIterations;
        convergenceAchieved = isConvergenceAchieved();
      }

      #pragma omp barrier
    }
    while (!convergenceAchieved);
  }
}

