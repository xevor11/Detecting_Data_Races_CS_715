{DO_NOT_ADD, ADD_TO_LIST} list_creation;
void j0_eval(double **xavg, struct resampled **bootavg, struct mom_info **mominfo, struct input_params *INPARAMS, const int NSLICES, const int LT, const bool renormalise)
{
  const char *proj[3] = {"Long", "Trans", "TransPLong"};
  size_t j;
  size_t i;
  printf("\n--> J0 evaluation <--\n");
  printf("\n--> Recylinder <--\n");
  const double widths[3] = {0.32, 0.32, 0.32};
  recylinder(INPARAMS, bootavg, mominfo, xavg, NSLICES, LT, 4, widths);
  struct mom_info **mavg;
  struct resampled **bavg = momentum_average(&mavg, INPARAMS, (const struct mom_info **) mominfo, (const struct resampled **) bootavg, NSLICES, PSQ_AVERAGE);
  double **x = malloc(NSLICES * (sizeof(double *)));
  for (i = 0; i < NSLICES; i++)
  {
    x[i] = (double *) malloc(INPARAMS->NDATA[i] * (sizeof(double)));
    int k;
    for (k = 0; k < INPARAMS->NDATA[i]; k++)
    {
      x[i][k] = mavg[i][k].p2;
    }

  }

  printf("\n--> Converting to physical momenta <--\n");
  for (j = 0; j < NSLICES; j++)
  {
    const double aI = INPARAMS->quarks[j].ainverse;
    const double aI2 = pow(INPARAMS->quarks[j].ainverse, 2);
    const double aI4 = pow(INPARAMS->quarks[j].ainverse, 4);
    const double aI6 = pow(INPARAMS->quarks[j].ainverse, 6);
    #pragma omp parallel for private(i)
    for (i = 0; i < INPARAMS->NDATA[j]; i++)
    {
      x[j][i] = aI * sqrt(x[j][i]);
      mavg[j][i].p2 *= aI2;
      mavg[j][i].p4 *= aI4;
      mavg[j][i].p6 *= aI6;
      if (fabs(mavg[j][i].p2 - (x[j][i] * x[j][i])) > 1E-12)
      {
        printf("P2 Broken !! %e \n", mavg[j][i].p2 - (x[j][i] * x[j][i]));
        exit(1);
      }

    }

  }

  printf("\n--> Renormalising <--\n");
  {
    for (j = 0; j < NSLICES; j++)
    {
      char str[256];
      sprintf(str, "m%g_m%g.%s.dat", INPARAMS->quarks[j].ml, INPARAMS->quarks[j].ms, proj[j]);
      FILE *file = fopen(str, "w");
      const double ZV = INPARAMS->quarks[j].ZV;
      fprintf(file, "ZV :: %f\n", ZV);
      fprintf(file, "a^{-1} :: %f GeV\n", INPARAMS->quarks[j].ainverse);
      fprintf(file, "q [GeV]        Pi(q^2)             Err\n");
      for (i = 0; i < INPARAMS->NDATA[j]; i++)
      {
        fprintf(file, "%f %1.12E %1.12E \n", x[j][i], bavg[j][i].avg, bavg[j][i].err);
      }

      fclose(file);
    }

  }
  {
    for (i = 0; i < NSLICES; i++)
    {
      char str[256];
      sprintf(str, "m%g_m%g.%s.cov", INPARAMS->quarks[i].ml, INPARAMS->quarks[i].ms, proj[i]);
      FILE *file = fopen(str, "w");
      double **correlation = malloc(INPARAMS->NDATA[i] * (sizeof(double *)));
      for (j = 0; j < INPARAMS->NDATA[i]; j++)
      {
        correlation[j] = malloc(INPARAMS->NDATA[i] * (sizeof(double)));
      }

      correlations(correlation, bavg[i], INPARAMS->NDATA[i]);
      write_corrmatrix_to_file(file, correlation, INPARAMS->NDATA[i]);
      free_double_dp(correlation, INPARAMS->NDATA[i]);
      fclose(file);
    }

  }
  struct resampled *fitparams = fit_data_plot_data((const struct resampled **) bavg, (const double **) x, (const struct mom_info **) mavg, *INPARAMS, NSLICES, LT);
  free(fitparams);
  free_resampled_dp(bavg, NSLICES, INPARAMS->NDATA);
  free_double_dp(x, NSLICES);
  return;

  int *x;
  int *y;
  int pri;
} q_elem_t;
{
  q_elem_t *buf;
  int n;
  int alloc;
} pri_queue_t;
{
  q_elem_t *buf;
  int n;
  int alloc;
} *pri_queue;
struct list_s
{
  int x;
  int y;
  int f;
} path[10000];
struct NODE
{
  int onopen;
  int onclosed;
  int walkable;
  int x;
  int y;
  int g;
  int h;
  int f;
  int parentx;
  int parenty;
} node[16][12];
int count;
struct list_s *findpath(int startx, int starty, int endx, int endy)
{
  int x = 0;
  int y = 0;
  int dx;
  int dy;
  int p;
  int cx = startx;
  int cy = starty;
  int lowestf = 10000;
  int entered_while = 0;
  q_elem_t c;
  int tentg;
  pri_queue q = priq_new(0);
  node[startx][starty].g = 0;
  node[startx][starty].h = (abs(endx - cx) + abs(endy - cy)) * 10;
  node[startx][starty].f = node[startx][starty].g + node[startx][starty].h;
  priq_push(q, &node[startx][starty].x, &node[startx][starty].y, node[startx][starty].f);
  c = priq_pop(q, &p);
  printf("top of list is %d,%d with f=%d\n", *c.x, *c.y, c.pri);
  while (entered_while < 100)
  {
    printf("cx=%d and cy=%d\n", cx, cy);
    entered_while += 1;
    if ((cx == endx) && (cy == endy))
    {
      printf("hurray\n");
      break;
    }
    else
    {
      node[cx][cy].onopen = 0;
      node[cx][cy].onclosed = 1;
      int tid;
      #pragma omp parallel shared(node,q)
      {
        #pragma omp for
        for (dx = -1; dx <= 1; dx++)
        {
          for (dy = -1; dy <= 1; dy++)
          {
            tid = omp_get_thread_num();
            printf("cx=%d: cy=%d: dx = %d:dy = %d:thread=%d\n", cx, cy, dx, dy, tid);
            if ((dx != 0) || (dy != 0))
            {
              if (((((cx + dx) < 16) && ((cx + dx) > (-1))) && ((cy + dy) < 12)) && ((cy + dy) > (-1)))
              {
                if ((node[cx + dx][cy + dy].walkable == 0) && (node[cx + dx][cy + dy].onclosed == 0))
                {
                  if ((dx != 0) && (dy != 0))
                    tentg = node[cx][cy].g + 14;
                  else
                    tentg = node[cx][cy].g + 10;

                  if ((node[cx + dx][cy + dy].onopen == 0) || (tentg < node[cx + dx][cy + dy].g))
                  {
                    node[cx + dx][cy + dy].parentx = node[cx][cy].x;
                    node[cx + dx][cy + dy].parenty = node[cx][cy].y;
                    node[cx + dx][cy + dy].g = tentg;
                    node[cx + dx][cy + dy].h = (abs(endx - (cx + dx)) + abs(endy - (cy + dy))) * 10;
                    node[cx + dx][cy + dy].f = node[cx + dx][cy + dy].g + node[cx + dx][cy + dy].h;
                    if (node[cx + dx][cy + dy].onopen == 0)
                    {
                      priq_push(q, &node[cx + dx][cy + dy].x, &node[cx + dx][cy + dy].y, node[cx + dx][cy + dy].f);
                      node[cx + dx][cy + dy].onopen == 1;
                    }

                  }

                }

              }

            }

          }

        }

        #pragma omp barrier
      }
    }

    c = priq_pop(q, &p);
    cx = *c.x;
    cy = *c.y;
  }

  printf("entered while %d times\n", entered_while);
  count = 0;
  cx = endx;
  cy = endy;
  printf("endx is %d and endy is %d\n", endx, endy);
  while ((cx != startx) || (cy != starty))
  {
    path[count].x = node[cx][cy].parentx;
    path[count].y = node[cx][cy].parenty;
    path[count].f = node[cx][cy].f;
    cx = path[count].x;
    cy = path[count].y;
    printf("final path is %d:%d\n", path[count].x, path[count].y);
    count++;
    if (count > 100)
      break;

  }

  printf("length of path is %d\n", count);
  return path;
}

