struct timeval tv;
void matrixVectorMult(int m, int n, double M[m][n], double V[n], double R[n])
{
  int i;
  int j;
  #pragma omp parallel for
  for (i = 0; i < m; i++)
  {
    for (j = 0; j < n; j++)
    {
      R[i] += M[i][j] * V[j];
    }

  }

}

