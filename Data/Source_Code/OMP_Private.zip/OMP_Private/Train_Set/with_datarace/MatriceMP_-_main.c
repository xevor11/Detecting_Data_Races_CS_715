int main(int argc, char *argv[])
{
  int tid;
  int nthreads;
  int i;
  int j;
  int k;
  double a[23][14];
  double b[14][8];
  double c[23][8];
  #pragma omp parallel shared(a,b,c,nthreads)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Starting matrix with %d threads\n", nthreads);
      printf("Initializing matrices...\n");
    }

    #pragma omp for schedule (static)
    for (i = 0; i < 23; i++)
      for (j = 0; j < 14; j++)
      a[i][j] = i + j;


    #pragma omp for schedule (static)
    for (i = 0; i < 14; i++)
      for (j = 0; j < 8; j++)
      b[i][j] = i * j;


    #pragma omp for schedule (static)
    for (i = 0; i < 23; i++)
      for (j = 0; j < 8; j++)
      c[i][j] = 0;


    printf("Thread %d starting matrix multiply...\n", tid);
    #pragma omp for schedule (static)
    for (i = 0; i < 23; i++)
    {
      printf("Thread=%d did row=%d\n", tid, i);
      for (j = 0; j < 8; j++)
        for (k = 0; k < 14; k++)
        c[i][j] += a[i][k] * b[k][j];


    }

  }
  printf("Result Matrix:\n");
  for (i = 0; i < 23; i++)
  {
    for (j = 0; j < 8; j++)
      printf("%6.2f   ", c[i][j]);

    printf("\n");
  }

  printf("Done.\n");

  int *a;
  int *b;
  int i;
  int Nid;
  int id;
  int sid;
  int eid;
  int T = 10;
  int max;
  a = (int *) malloc((sizeof(int)) * 1000);
  for (i = 0; i < 1000; i++)
  {
    *(a + i) = (rand() % 1000) - 300;
    printf("%d ", *(a + i));
  }

  for (i = 0; i < 1000; i++)
  {
    if (a[i] > max)
      max = a[i];

  }

  printf("\n[chay 1 luong] Phan tu max cua a[] = %d \n", max);
  max = 0;
  omp_set_num_threads(T);
  b = (int *) malloc((sizeof(int)) * T);
  #pragma omp parallel private(id, sid, eid,i)
  {
    id = omp_get_thread_num();
    Nid = 1000 / T;
    sid = id * Nid;
    eid = sid + Nid;
    b[id] = findMax(a, sid, eid);
  }
  do
  {
    T = T / 2;
    omp_set_num_threads(T);
    #pragma omp parallel private(id)
    {
      id = omp_get_thread_num();
      b[id] = (b[id] > b[id + T]) ? (b[id]) : (b[id + T]);
    }
  }
  while (T > 1);
  printf("\n[chay da luong] Phan tu max cua a[] = %d \n", b[0]);
  return 0;
}

