void HPL_dlaswp01N(M, N, A, LDA, U, LDU, LINDXA, LINDXAU)
const int M;
const int N;
double *A;
const int LDA;
double *U;
const int LDU;
const int *LINDXA;
const int *LINDXAU;
{
  double *a0;
  double *a1;
  const int incA = (int) (((unsigned int) LDA) << 5);
  const int incU = (int) (((unsigned int) LDU) << 5);
  int lda1;
  int nu;
  int nr;
  register int i;
  register int j;
  register int k;
  if ((M <= 0) || (N <= 0))
    return;

  nr = N - (nu = (int) ((((unsigned int) N) >> 5) << 5));
  int nthreads;
  double *tmpA;
  double *tmpU;
  #pragma omp parallel
  {
    k = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    tmpA = A + (k * incA);
    tmpU = U + (k * incU);
    for (j = k * 32; j < nu; j += nthreads * 32, tmpA += nthreads * incA, tmpU += nthreads * incU)
    {
      for (i = 0; i < M; i++)
      {
        a0 = tmpA + ((size_t) LINDXA[i]);
        if (LINDXAU[i] >= 0)
        {
          a1 = tmpU + ((size_t) LINDXAU[i]);
          lda1 = LDU;
        }
        else
        {
          a1 = tmpA - ((size_t) LINDXAU[i]);
          lda1 = LDA;
        }

        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
        *a1 = *a0;
        a1 += lda1;
        a0 += LDA;
      }

    }

  }
  tmpA = A + (((size_t) nu) * ((size_t) LDA));
  tmpU = U + (((size_t) nu) * ((size_t) LDU));
  if (nr)
  {
    for (i = 0; i < M; i++)
    {
      a0 = tmpA + ((size_t) LINDXA[i]);
      if (LINDXAU[i] >= 0)
      {
        a1 = tmpU + ((size_t) LINDXAU[i]);
        lda1 = LDU;
      }
      else
      {
        a1 = tmpA - ((size_t) LINDXAU[i]);
        lda1 = LDA;
      }

      for (j = 0; j < nr; j++, a1 += lda1, a0 += LDA)
      {
        *a1 = *a0;
      }

    }

  }

}

