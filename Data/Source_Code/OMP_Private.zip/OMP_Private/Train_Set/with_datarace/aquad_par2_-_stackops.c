struct interval
{
  double left;
  double right;
  double epsilon;
};
double stackops(int stackpointer, Interval *stack, double (*func)(double))
{
  double result;
  double abserror;
  double l;
  double r;
  double m;
  double est1;
  double est2;
  double eps;
  int stacksize = 1000;
  int stackpointer_g = stackpointer;
  result = 0.0;
  #pragma omp parallel shared(stackpointer_g)
  {
    while (stackpointer_g >= 1)
    {
      stackpointer = stackpointer_g;
      l = stack[stackpointer].left;
      r = stack[stackpointer].right;
      eps = stack[stackpointer].epsilon;
      stackpointer--;
      m = 0.5 * (l + r);
      est1 = (0.5 * (r - l)) * (func(l) + func(r));
      est2 = 0.5 * (((m - l) * (func(l) + func(m))) + ((r - m) * (func(m) + func(r))));
      abserror = fabs(est2 - est1) / 3.0;
      if (abserror <= eps)
      {
        #pragma omp critical
        {
          result += est2;
          stackpointer_g = stackpointer;
        }
      }
      else
      {
        if ((stackpointer + 2) > stacksize)
        {
          printf("Stack too small, track doubling stacksize");
          exit(0);
        }

        stackpointer++;
        stackpointer++;
        #pragma omp critical
        {
          stack[stackpointer].left = m;
          stack[stackpointer].right = r;
          stack[stackpointer].epsilon = eps * 0.5;
          stackpointer_g = stackpointer;
        }
        stackpointer--;
        stack[stackpointer].left = l;
        stack[stackpointer].right = m;
        stack[stackpointer].epsilon = eps * 0.5;
      }

    }

  }
  return result;
}

