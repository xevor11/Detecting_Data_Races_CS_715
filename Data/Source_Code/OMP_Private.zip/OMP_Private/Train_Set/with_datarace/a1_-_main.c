int main(int argc, char **argv)
{
  int i;
  int j;
  int k;
  struct timeval start_time;
  struct timeval stop_time;
  struct timeval elapsed_time;
  init_matrix();
  gettimeofday(&start_time, 0);
  for (k = 0; k < 2000; k++)
  {
    #pragma omp parallel for
    for (i = 0; i < 2000; i++)
      row_mat[i] = mat[i][k];

    #pragma omp parallel for
    for (i = 0; i < 2000; i++)
      col_mat[i] = mat[k][j];

    #pragma omp parallel for private(j, row_mat, col_mat)
    for (i = 0; i < 2000; i++)
    {
      for (j = 0; j < 2000; j++)
      {
        mat[i][i] = (mat[i][j] < (row_mat[i] + col_mat[j])) ? (mat[i][j]) : (row_mat[i] + col_mat[j]);
      }

    }

  }

  gettimeofday(&stop_time, 0);
  timersub(&stop_time, &start_time, &elapsed_time);
  printf("Total time was %f seconds.\n", elapsed_time.tv_sec + (elapsed_time.tv_usec / 1000000.0));
  return 0;

  int i;
  int k;
  int count = 0;
  int *iVector;
  printf("Enter array dimension: ");
  scanf("%d", &k);
  iVector = (int *) malloc(k * (sizeof(int)));
  printf("\nk=%d\n", k);
  printf("\nArray:\n");
  #pragma omp parallel for
  for (i = 0; i < k; i++)
  {
    iVector[i] = rand() % 10;
    printf(" %i", iVector[i]);
    if (((i + 1) % 20) == 0)
      printf("\n");

  }

  printf("\n");
  #pragma omp parallel for reduction(+:count) schedule(auto)
  for (i = 0; i < k; i++)
  {
    if (iVector[i] == 0)
      count++;

  }

  printf("\nNumber of zeros: %d \n\n", count);
  free(iVector);
  return 0;
}

