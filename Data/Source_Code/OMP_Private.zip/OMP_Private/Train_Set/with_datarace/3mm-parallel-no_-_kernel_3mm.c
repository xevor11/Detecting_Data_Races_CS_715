extern void *polybench_alloc_data(unsigned long long int n, int elt_size);
static void kernel_3mm(int ni, int nj, int nk, int nl, int nm, double E[128 + 0][128 + 0], double A[128 + 0][128 + 0], double B[128 + 0][128 + 0], double F[128 + 0][128 + 0], double C[128 + 0][128 + 0], double D[128 + 0][128 + 0], double G[128 + 0][128 + 0])
{
  {
    int c1;
    int c2;
    int c5;
    #pragma omp parallel for
    for (c1 = 0; c1 <= 127; c1++)
    {
      for (c2 = 0; c2 <= 127; c2++)
      {
        G[c1][c2] = 0;
        F[c1][c2] = 0;
      }

    }

    #pragma omp parallel for
    for (c1 = 0; c1 <= 127; c1++)
    {
      for (c2 = 0; c2 <= 127; c2++)
      {
        for (c5 = 0; c5 <= 127; c5++)
        {
          F[c1][c2] += C[c1][c5] * D[c5][c2];
        }

      }

    }

    #pragma omp parallel for
    for (c1 = 0; c1 <= 127; c1++)
    {
      for (c2 = 0; c2 <= 127; c2++)
      {
        E[c1][c2] = 0;
      }

    }

    #pragma omp parallel for
    for (c1 = 0; c1 <= 127; c1++)
    {
      for (c2 = 0; c2 <= 127; c2++)
      {
        for (c5 = 0; c5 <= 127; c5++)
        {
          E[c1][c2] += A[c1][c5] * B[c5][c2];
        }

        for (c5 = 0; c5 <= 127; c5++)
        {
          G[c1][c5] += E[c1][c2] * F[c2][c5];
        }

      }

    }

  }
}

