void MaximizationStep(double z[N][K], double *pi, double mu[K][D], int **x)
{
  double timeStart1;
  double timeEnd1;
  double Texec1;
  double timeStart2;
  double timeEnd2;
  double Texec2;
  struct timeval tp;
  int i;
  int j;
  int chunk;
  int x;
  int matrix_par[10][10];
  int matrix_seq[10][10];
  int start_value;
  int nb_iteration;
  int probleme;
  probleme = atoi(argv[1]);
  start_value = atoi(argv[2]);
  nb_iteration = atoi(argv[3]);
  chunk = 10;
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      matrix_seq[i][j] = start_value;

  }

  if (probleme == 1)
  {
    gettimeofday(&tp, 0);
    timeStart1 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    for (x = 1; x <= nb_iteration; x++)
    {
      for (i = 0; i < 10; i++)
      {
        for (j = 0; j < 10; j++)
        {
          spinWait(50);
          matrix_seq[i][j] = (matrix_seq[i][j] + i) + j;
        }

      }

    }

    gettimeofday(&tp, 0);
    timeEnd1 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    Texec1 = timeEnd1 - timeStart1;
    gettimeofday(&tp, 0);
    timeStart2 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    #pragma omp parallel shared(matrix_par,chunk,x,i) private(j)
    {
      #pragma omp for schedule (dynamic, chunk) collapse(2)
      for (i = 0; i < 10; i++)
        for (j = 0; j < 10; j++)
        matrix_par[i][j] = start_value;


      #pragma omp for schedule(static,1) collapse(3)
      for (x = 1; x <= nb_iteration; x++)
      {
        for (i = 0; i < 10; i++)
        {
          for (j = 0; j < 10; j++)
          {
            spinWait(50);
            matrix_par[i][j] = (matrix_par[i][j] + i) + j;
          }

        }

      }

    }
    gettimeofday(&tp, 0);
    timeEnd2 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    Texec2 = timeEnd2 - timeStart2;
  }
  else
    if (probleme == 2)
  {
    gettimeofday(&tp, 0);
    timeStart1 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    for (x = 1; x <= nb_iteration; x++)
    {
      for (i = 0; i < 10; i++)
      {
        for (j = 9; j >= 0; j--)
        {
          spinWait(50);
          if (j == 9)
            matrix_seq[i][j] = matrix_seq[i][j] + i;
          else
            matrix_seq[i][j] = matrix_seq[i][j] + matrix_seq[i][j + 1];

        }

      }

    }

    gettimeofday(&tp, 0);
    timeEnd1 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    Texec1 = timeEnd1 - timeStart1;
    gettimeofday(&tp, 0);
    timeStart2 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    #pragma omp parallel shared(matrix_par,chunk,x,j) private(i)
    {
      #pragma omp for schedule (dynamic, chunk) collapse(2)
      for (i = 0; i < 10; i++)
        for (j = 0; j < 10; j++)
        matrix_par[i][j] = start_value;


      #pragma omp for schedule(dynamic,chunk) collapse(3)
      for (x = 1; x <= nb_iteration; x++)
      {
        for (i = 0; i < 10; i++)
        {
          for (j = 9; j >= 0; j--)
          {
            spinWait(50);
            if (j == 9)
            {
              matrix_par[i][j] = matrix_par[i][j] + i;
            }
            else
            {
              matrix_par[i][j] = matrix_par[i][j] + matrix_par[i][j + 1];
            }

          }

        }

      }

    }
    gettimeofday(&tp, 0);
    timeEnd2 = ((double) tp.tv_sec) + (((double) tp.tv_usec) / 1e6);
    Texec2 = timeEnd2 - timeStart2;
  }


  printf("******************************************************\n");
  printf("Resultat matrice en séquentiel:\n");
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      printf("%d   ", matrix_seq[i][j]);

    printf("\n");
  }

  printf("******************************************************\n");
  printf("Resultat matrice en parallele:\n");
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      printf("%d   ", matrix_par[i][j]);

    printf("\n");
  }

  printf("******************************************************\n");
  printf("durée d'exécution séquentiel: %lf\n", Texec1);
  printf("durée d'exécution parallele : %lf\n", Texec2);
  printf("******************************************************\n");
  return 0;

  #pragma omp parallel for
  for (int k = 0; k < K; k++)
  {
    pi[k] = Nm(k, z) / ((double) N);
  }

  double *average;
  #pragma omp parallel for
  for (int k = 0; k < K; k++)
  {
    average = Average(k, x, z);
    #pragma omp parallel for
    for (int i = 0; i < D; i++)
    {
      mu[k][i] = average[i];
    }

  }

  free(average);
}

