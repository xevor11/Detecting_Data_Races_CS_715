enum type {original = 1, shared, openmp};
void main(int argc, char *argv[])
{
  int comm_size;
  int rank;
  int rank1 = 0;
  int i;
  int j;
  char st[30];
  welcome();
  int **shared_var;
  shared_var = (int **) malloc(3 * (sizeof(int *)));
  for (i = 0; i < 3; i++)
    shared_var[i] = (int *) malloc(12 * (sizeof(int)));

  for (j = 0; j < 3; j++)
    for (i = 0; i < 12; i++)
    shared_var[j][i] = 500;


  #pragma omp parallel num_threads(3) shared(shared_var)
  {
    rank = omp_get_thread_num();
    comm_size = omp_get_num_threads();
    printf("Hello world from %d of %d!\n", rank, comm_size);
    int *send_countbuf = (int *) malloc(3 * (sizeof(int)));
    int *send_offsetbuf = (int *) malloc(3 * (sizeof(int)));
    int *rec_countbuf = (int *) malloc(3 * (sizeof(int)));
    int *rec_offsetbuf = (int *) malloc(3 * (sizeof(int)));
    int *sharedint;
    int *sharedint_local = (int *) malloc(12 * (sizeof(int)));
    int k;
    for (k = 0; k < 12; k++)
    {
      shared_var[rank][k] = rank;
      sharedint_local[k] = 500;
    }

    #pragma omp barrier
    if (rank == 0)
    {
      update(send_countbuf, 4, 2, 2);
      update(send_offsetbuf, 0, 0, 0);
      update(rec_countbuf, 4, 2, 2);
      update(rec_offsetbuf, 0, 4, 6);
    }
    else
    {
      update(send_countbuf, 2, 2, 2);
      update(send_offsetbuf, 0, 0, 0);
      update(rec_countbuf, 2, 2, 2);
      update(rec_offsetbuf, 0, 2, 4);
    }

    #pragma omp barrier
    #pragma omp parallel for ordered
    for (i = 0; i < comm_size; i++)
    {
      sharedint = shared_var[i];
      for (k = send_offsetbuf[i]; k < (send_offsetbuf[i] + send_countbuf[i]); k++)
      {
        sharedint_local[k + rec_offsetbuf[i]] = sharedint[k];
      }

    }

    print_final(rank, sharedint_local);
    free(send_countbuf);
    free(send_offsetbuf);
    free(rec_countbuf);
    free(rec_offsetbuf);
    free(sharedint_local);
    free(shared_var[rank]);
  }
  free(shared_var);
}

