int main(void)
{
  printf("At the beginning\n");
  int result_size = (((unsigned short) 1960) - ((unsigned short) 32)) * (((unsigned short) 1080) - ((unsigned short) 32));
  unsigned int SAD_Result1[(((unsigned short) 1960) - ((unsigned short) 32)) * (((unsigned short) 1080) - ((unsigned short) 32))];
  unsigned short mainSourceImg[((unsigned short) 1960) * ((unsigned short) 1080)];
  unsigned short referenceImg[((unsigned short) 32) * ((unsigned short) 32)];
  int row;
  int col;
  int i;
  int j;
  struct timeval start;
  struct timeval end;
  for (i = 0; i < (((unsigned short) 1960) * ((unsigned short) 1080)); i++)
  {
    mainSourceImg[i] = i;
  }

  for (i = 0; i < (((unsigned short) 32) * ((unsigned short) 32)); i++)
  {
    referenceImg[i] = i;
  }

  gettimeofday(&start, 0);
  #pragma omp parallel shared(mainSourceImg, referenceImg, SAD_Result1)
  {
    #pragma omp for schedule(static)
    for (row = 0; row < (((unsigned short) 1080) - ((unsigned short) 32)); row++)
    {
      for (col = 0; col < (((unsigned short) 1960) - ((unsigned short) 32)); col++)
        for (i = 0; i < ((unsigned short) 32); i++)
        for (j = 0; j < ((unsigned short) 32); j++)
        SAD_Result1[((((unsigned short) 1960) - ((unsigned short) 32)) * row) + col] += abs(mainSourceImg[(((row + i) * ((unsigned short) 1960)) + col) + j] - referenceImg[(i * ((unsigned short) 32)) + j]);



    }

  }
  gettimeofday(&end, 0);
  printf(" took %0.6f seconds.\n", (end.tv_sec + (end.tv_usec / 1.e6)) - (start.tv_sec + (start.tv_usec / 1.e6)));
  gettimeofday(&start, 0);
  for (row = 0; row < (((unsigned short) 1080) - ((unsigned short) 32)); row++)
  {
    for (col = 0; col < (((unsigned short) 1960) - ((unsigned short) 32)); col++)
      for (i = 0; i < ((unsigned short) 32); i++)
      for (j = 0; j < ((unsigned short) 32); j++)
      SAD_Result1[((((unsigned short) 1960) - ((unsigned short) 32)) * row) + col] += abs(mainSourceImg[(((row + i) * ((unsigned short) 1960)) + col) + j] - referenceImg[(i * ((unsigned short) 32)) + j]);



  }

  gettimeofday(&end, 0);
  printf(" took %0.6f seconds.\n", (end.tv_sec + (end.tv_usec / 1.e6)) - (start.tv_sec + (start.tv_usec / 1.e6)));
  return 0;
}

