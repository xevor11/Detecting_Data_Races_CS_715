void update(double *f, double *f_old, double (*g)(int, int, int), double *norm, double gamma, int N)
{
  int i = 1;
  int j;
  int k = 0;
  double lnorm = 0;
  if (0 != norm)
  {
    #pragma omp parallel for reduction(max:lnorm) shared(f,f_old) schedule(static,chunk)
    for (j = 1; j < (N - 1); j++)
    {
      k = (j + 1) % 2;
      for (i = 1 + k; i < (N - 1); i += 2)
      {
        f[i + (j * N)] = f_old[i + (j * N)] + ((gamma * (((((f_old[(i - 1) + (j * N)] + f_old[(i + 1) + (j * N)]) + f_old[i + ((j - 1) * N)]) + f_old[i + ((j + 1) * N)]) - (4. * f_old[i + (j * N)])) - ((g(i, j, N) / N) / N))) / 4.);
        lnorm = fmax(lnorm, fabs(f_old[i + (j * N)] - f[i + (j * N)]));
      }

    }

    #pragma omp parallel for reduction(max:lnorm) shared(f,f_old) schedule(static,chunk)
    for (j = 1; j < (N - 1); j++)
    {
      k = j % 2;
      for (i = 1 + k; i < (N - 1); i += 2)
      {
        f[i + (j * N)] = f_old[i + (j * N)] + ((gamma * (((((f[(i - 1) + (j * N)] + f[(i + 1) + (j * N)]) + f[i + ((j - 1) * N)]) + f[i + ((j + 1) * N)]) - (4. * f_old[i + (j * N)])) - ((g(i, j, N) / N) / N))) / 4.);
        lnorm = fmax(lnorm, fabs(f_old[i + (j * N)] - f[i + (j * N)]));
      }

    }

    *norm = lnorm;
  }
  else
  {
    #pragma omp parallel for shared(f,f_old) schedule(static,chunk)
    for (j = 1; j < (N - 1); j++)
    {
      k = (j + 1) % 2;
      for (i = 1 + k; i < (N - 1); i += 2)
      {
        f[i + (j * N)] = f_old[i + (j * N)] + ((gamma * (((((f_old[(i - 1) + (j * N)] + f_old[(i + 1) + (j * N)]) + f_old[i + ((j - 1) * N)]) + f_old[i + ((j + 1) * N)]) - (4. * f_old[i + (j * N)])) - ((g(i, j, N) / N) / N))) / 4.);
      }

    }

    #pragma omp parallel for shared(f,f_old) schedule(static,chunk)
    for (j = 1; j < (N - 1); j++)
    {
      k = j % 2;
      for (i = 1 + k; i < (N - 1); i += 2)
      {
        f[i + (j * N)] = f_old[i + (j * N)] + ((gamma * (((((f[(i - 1) + (j * N)] + f[(i + 1) + (j * N)]) + f[i + ((j - 1) * N)]) + f[i + ((j + 1) * N)]) - (4. * f_old[i + (j * N)])) - ((g(i, j, N) / N) / N))) / 4.);
      }

    }

  }


  int i;
  #pragma omp parallel for private(i)
  for (i = 0; i < N; i++)
  {
    bottomAdjacent_to(board, newboard, bottom, i, M, N);
  }

}

