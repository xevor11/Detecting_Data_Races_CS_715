void promediador(unsigned char *imagen, long TX, long TY, int tam, unsigned char *copia, float DesE)
{
  int i;
  int j;
  int mi;
  int mj;
  float acum = 0;
  acum = 0;
  #pragma omp parallel shared(copia,imagen,tam)
  {
    #pragma omp for
    for (i = 0; i <= (TY - tam); i++)
      for (j = 0; j <= (TX - tam); j++)
    {
      for (mi = i; mi < (i + tam); mi++)
        for (mj = j; mj < (j + tam); mj++)
      {
        acum += imagen[(mi * TX) + mj];
      }


      acum = acum / ((tam * tam) - 1);
      if (acum > DesE)
        copia[((i + (tam / 2)) * TX) + (j + (tam / 2))] = (unsigned char) acum;

      acum = 0;
    }


  }
}

