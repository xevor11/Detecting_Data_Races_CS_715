int main(int argc, char *argv[])
{
  int count;
  int first;
  int i;
  int index;
  char *marked;
  int n;
  int N;
  int prime;
  if (argc != 2)
  {
    printf("Command line: %s <m>\n", argv[0]);
    exit(1);
  }

  n = atoi(argv[1]);
  N = n + 1;
  marked = (char *) malloc(N);
  if (marked == 0)
  {
    printf("Cannot allocate enough memory\n");
    exit(1);
  }

  #pragma omp parallel for
  for (i = 0; i < N; i++)
  {
    printf("Tid is %d\n", omp_get_thread_num());
  }

  marked[i] = 1;
  marked[0] = 0;
  marked[1] = 0;
  index = 2;
  prime = 2;
  do
  {
    first = 2 * prime;
    #pragma omp parallel for
    for (i = first; i < N; i += prime)
    {
      printf("Tid is %d\n", omp_get_thread_num());
    }

    marked[i] = 0;
    while (!marked[++index])
      ;

    prime = index;
  }
  while ((prime * prime) <= n);
  count = 0;
  #pragma omp parallel for reduction(+:count)
  for (i = 0; i < N; i++)
    count += marked[i];

  printf("\nThere are %d primes less than or equal to %d\n\n", count, n);
  return 0;
}

