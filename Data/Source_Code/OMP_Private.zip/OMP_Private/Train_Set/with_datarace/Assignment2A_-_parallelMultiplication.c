double *matA = 0;
double *matB = 0;
double *matC = 0;
clock_t begin_seq = 0;
clock_t end_seq = 0;
double time_spent_seq = 0;
double begin = 0;
double end = 0;
double time_spent = 0;
int numThreads = 1;
int chunk;
int threadId;
void allocateMemory();
void fillMatrix();
void parallelMultiplication();
void collectResults();
void parallelMultiplication()
{
  int i;
  int j;
  int k;
  int this_thread;
  int my_start;
  int my_end;
  begin = omp_get_wtime();
  #pragma omp parallel shared(matA,matB,matC,numThreads) num_threads(numThreads)
  {
    this_thread = omp_get_thread_num();
    my_start = (this_thread * 5000) / numThreads;
    my_end = ((this_thread + 1) * 5000) / numThreads;
    printf("This_thread =  %d Num_threads = %d my_start =  %d my_end = %d\n", this_thread, numThreads, my_start, my_end);
    for (i = my_start; i < my_end; i++)
    {
      for (j = 0; j < 2500; j++)
      {
        for (k = 0; k < 2000; k++)
        {
          *(matC + ((i * 2000) + j)) += (*(matA + ((i * 5000) + k))) * (*(matB + ((k * 2500) + j)));
        }

      }

    }

  }
  end = omp_get_wtime();
  time_spent = (double) (end - begin);
  printf("The time spent is : %1.5f\n", time_spent);
}

