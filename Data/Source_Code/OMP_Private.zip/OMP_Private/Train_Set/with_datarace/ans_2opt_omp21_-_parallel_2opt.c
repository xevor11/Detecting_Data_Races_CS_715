struct City
{
  int index;
  int x;
  int y;
};
struct Thread_Param
{
  int rank;
  int start_depth;
  int skip_depth;
  int max_depth;
};
void print_route();
void *read_coord(void *fp);
void *read_route(void *fp);
inline dist_type distance(dist_type x1, dist_type y1, dist_type x2, dist_type y2);
void parallel_2opt();
void check_time();
dist_type get_city_distance(int index_1, int index_2);
dist_type get_total_route_distance(int *);
dist_type get_partial_route_distance(int *, int, int);
inline dist_type get_swapped_total_route_distance(int *route_index_list, int start, int end);
inline dist_type get_swapped_partial_route_distance(int *route_index_list, int start, int end);
void two_opt_swap(int start, int end);
dist_type two_opt_check(int start, int end);
int available_threads = 12;
int num_city;
dist_type default_distance;
int *route_index_list;
struct City *city_list;
int go_flag = 1;
time_t start_time;
long long *opt_check_counter_list;
long long *opt_swap_counter_list;
long long *contention_counter_list;
int depth_reached = 0;
int round_reached = 0;
int race_cond_counter = 0;
double total_swap_length = 0;
double total_reduced_distance = 0;
void parallel_2opt()
{
  int i;
  int start;
  int depth;
  int max_depth = num_city - 1;
  int threads_to_use = available_threads;
  if (max_depth < available_threads)
    threads_to_use = max_depth;

  omp_set_num_threads(threads_to_use);
  printf("Using %3d threads\n", threads_to_use);
  opt_check_counter_list = (long long *) malloc(available_threads * (sizeof(long long)));
  opt_swap_counter_list = (long long *) malloc(available_threads * (sizeof(long long)));
  contention_counter_list = (long long *) malloc(available_threads * (sizeof(long long)));
  int *thread_process_start_list = (int *) malloc(available_threads * (sizeof(int)));
  for (i = 0; i < available_threads; ++i)
    thread_process_start_list[i] = num_city + 1;

  while (go_flag)
  {
    round_reached++;
    for (depth = 1; go_flag && (depth < max_depth); ++depth)
    {
      int starting_pos_count = (num_city - depth) - 1;
      int omp_chunk_size = (int) ceil(((double) starting_pos_count) / available_threads);
      #pragma omp parallel for default(none) shared(depth, go_flag, route_index_list, num_city, omp_chunk_size, stdout, available_threads, thread_process_start_list, contention_counter_list, depth_reached) schedule(static, omp_chunk_size)
      for (start = 1; start < (num_city - depth); ++start)
      {
        #pragma omp flush(go_flag)
        if (go_flag)
        {
          thread_process_start_list[omp_get_thread_num()] = start;
          #pragma omp flush(thread_process_start_list)
          if ((omp_get_thread_num() < (available_threads - 1)) && (thread_process_start_list[omp_get_thread_num() + 1] <= ((start + depth) + 1)))
          {
            contention_counter_list[omp_get_thread_num()]++;
            do
            {
              #pragma omp flush(thread_process_start_list)
            }
            while (thread_process_start_list[omp_get_thread_num() + 1] < ((start + depth) + 1));
          }

          #pragma omp flush(route_index_list)
          if (two_opt_check(start, start + depth) > 0)
            two_opt_swap(start, start + depth);

          int thread_chunk_end_final_pos = ((omp_get_thread_num() + 1) * omp_chunk_size) + depth;
          if (thread_chunk_end_final_pos >= num_city)
            thread_chunk_end_final_pos = num_city - 1;

          if ((start + depth) == thread_chunk_end_final_pos)
          {
            thread_process_start_list[omp_get_thread_num()] = num_city + 1;
            #pragma omp flush(thread_process_start_list)
          }

          if (omp_get_thread_num() == 0)
          {
            depth_reached = depth;
            check_time();
          }

        }

      }

    }

  }

}

