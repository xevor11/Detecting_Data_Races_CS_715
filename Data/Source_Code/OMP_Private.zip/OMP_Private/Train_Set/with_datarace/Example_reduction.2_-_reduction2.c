void reduction2(float *x, int *y, int n)
{
  int i;
  int b;
  int b_p;
  int c;
  int c_p;
  float a;
  float a_p;
  float d;
  float d_p;
  a = 0.0f;
  b = 0;
  c = y[0];
  d = x[0];
  #pragma omp parallel shared(a, b, c, d, x, y, n)
  {
    a_p = 0.0f;
    b_p = 0;
    c_p = 32767;
    d_p = -HUGE_VALF;
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      a_p += x[i];
      b_p ^= y[i];
      if (c_p > y[i])
        c_p = y[i];

      d_p = fmaxf(d_p, x[i]);
    }

    #pragma omp critical
    {
      a += a_p;
      b ^= b_p;
      if (c > c_p)
        c = c_p;

      d = fmaxf(d, d_p);
    }
  }

  int i;
  int k;
  for (k = n - 1; k > (-1); k--)
  {
    #pragma omp parallel for schedule(static) num_threads(thread_count) default(none) private(i) shared(n, U, x, y, k)
    for (i = k - 1; i > (-1); i--)
    {
      y[i] -= x[k] * U[(i * n) + k];
    }

  }

}

