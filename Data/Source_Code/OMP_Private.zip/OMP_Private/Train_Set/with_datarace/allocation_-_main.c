void init_data(int **data, int n);
void process_data(int *data, int n);
void check_data(int *data, int n, int num_threads, int count);
int main(int argc, char *argv[])
{
  const int n = 1000000;
  const int nr_steps = 1000;
  int num_threads = 1;
  int step;
  int *data;
  #pragma omp parallel
  {
    init_data(&data, n);
  }
  printf("initialized with %d threads\n", num_threads);
  printf("processing...\n");
  #pragma omp parallel
  {
    {
      for (step = 0; step < nr_steps; step++)
      {
        process_data(data, n);
      }

    }
  }
  printf("processed with %d threads\n", num_threads);
  printf("testing...\n");
  check_data(data, n, num_threads, 1 + nr_steps);
  printf("tested\n");
  return 0;
}

