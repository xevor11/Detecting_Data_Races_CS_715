void advance2d(const float *v, const float *rho, float *u3, float *sxx, float *szz, int nx, int nz, int ne, float dtpdx, float dtpdz, float * const par_cpml, float *memory_dp, float *memory_ds)
{
  int i;
  int j;
  int k;
  int m;
  double aux;
  double rho_inv;
  double uijk;
  double up1;
  double um1;
  double vijk;
  double vp1;
  double vm1;
  double wijk;
  double wp1;
  double wm1;
  #pragma omp parallel default(shared) private(i,j,k,m,rho_inv,aux,uijk, up1,um1,vijk,vp1,vm1,wijk,wp1,wm1)
  {
    #pragma omp for schedule(static) nowait
    for (k = 0; k <= (grid_points[2] - 1); k++)
    {
      for (j = 0; j <= (grid_points[1] - 1); j++)
      {
        for (i = 0; i <= (grid_points[0] - 1); i++)
        {
          rho_inv = 1.0 / u[k][j][i][0];
          rho_i[k][j][i] = rho_inv;
          us[k][j][i] = u[k][j][i][1] * rho_inv;
          vs[k][j][i] = u[k][j][i][2] * rho_inv;
          ws[k][j][i] = u[k][j][i][3] * rho_inv;
          square[k][j][i] = (0.5 * (((u[k][j][i][1] * u[k][j][i][1]) + (u[k][j][i][2] * u[k][j][i][2])) + (u[k][j][i][3] * u[k][j][i][3]))) * rho_inv;
          qs[k][j][i] = square[k][j][i] * rho_inv;
          aux = (c1c2 * rho_inv) * (u[k][j][i][4] - square[k][j][i]);
          speed[k][j][i] = sqrt(aux);
        }

      }

    }

    #pragma omp for schedule(static)
    for (k = 0; k <= (nz2 + 1); k++)
    {
      for (j = 0; j <= (ny2 + 1); j++)
      {
        for (i = 0; i <= (nx2 + 1); i++)
        {
          for (m = 0; m < 5; m++)
          {
            rhs[k][j][i][m] = forcing[k][j][i][m];
          }

        }

      }

    }

    #pragma omp for schedule(static) nowait
    for (k = 1; k <= nz2; k++)
    {
      for (j = 1; j <= ny2; j++)
      {
        for (i = 1; i <= nx2; i++)
        {
          uijk = us[k][j][i];
          up1 = us[k][j][i + 1];
          um1 = us[k][j][i - 1];
          rhs[k][j][i][0] = (rhs[k][j][i][0] + (dx1tx1 * ((u[k][j][i + 1][0] - (2.0 * u[k][j][i][0])) + u[k][j][i - 1][0]))) - (tx2 * (u[k][j][i + 1][1] - u[k][j][i - 1][1]));
          rhs[k][j][i][1] = ((rhs[k][j][i][1] + (dx2tx1 * ((u[k][j][i + 1][1] - (2.0 * u[k][j][i][1])) + u[k][j][i - 1][1]))) + ((xxcon2 * con43) * ((up1 - (2.0 * uijk)) + um1))) - (tx2 * (((u[k][j][i + 1][1] * up1) - (u[k][j][i - 1][1] * um1)) + ((((u[k][j][i + 1][4] - square[k][j][i + 1]) - u[k][j][i - 1][4]) + square[k][j][i - 1]) * c2)));
          rhs[k][j][i][2] = ((rhs[k][j][i][2] + (dx3tx1 * ((u[k][j][i + 1][2] - (2.0 * u[k][j][i][2])) + u[k][j][i - 1][2]))) + (xxcon2 * ((vs[k][j][i + 1] - (2.0 * vs[k][j][i])) + vs[k][j][i - 1]))) - (tx2 * ((u[k][j][i + 1][2] * up1) - (u[k][j][i - 1][2] * um1)));
          rhs[k][j][i][3] = ((rhs[k][j][i][3] + (dx4tx1 * ((u[k][j][i + 1][3] - (2.0 * u[k][j][i][3])) + u[k][j][i - 1][3]))) + (xxcon2 * ((ws[k][j][i + 1] - (2.0 * ws[k][j][i])) + ws[k][j][i - 1]))) - (tx2 * ((u[k][j][i + 1][3] * up1) - (u[k][j][i - 1][3] * um1)));
          rhs[k][j][i][4] = ((((rhs[k][j][i][4] + (dx5tx1 * ((u[k][j][i + 1][4] - (2.0 * u[k][j][i][4])) + u[k][j][i - 1][4]))) + (xxcon3 * ((qs[k][j][i + 1] - (2.0 * qs[k][j][i])) + qs[k][j][i - 1]))) + (xxcon4 * (((up1 * up1) - ((2.0 * uijk) * uijk)) + (um1 * um1)))) + (xxcon5 * (((u[k][j][i + 1][4] * rho_i[k][j][i + 1]) - ((2.0 * u[k][j][i][4]) * rho_i[k][j][i])) + (u[k][j][i - 1][4] * rho_i[k][j][i - 1])))) - (tx2 * ((((c1 * u[k][j][i + 1][4]) - (c2 * square[k][j][i + 1])) * up1) - (((c1 * u[k][j][i - 1][4]) - (c2 * square[k][j][i - 1])) * um1)));
        }

      }

      for (j = 1; j <= ny2; j++)
      {
        i = 1;
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((5.0 * u[k][j][i][m]) - (4.0 * u[k][j][i + 1][m])) + u[k][j][i + 2][m]));
        }

        i = 2;
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((((-4.0) * u[k][j][i - 1][m]) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j][i + 1][m])) + u[k][j][i + 2][m]));
        }

      }

      for (j = 1; j <= ny2; j++)
      {
        for (i = 3; i <= (nx2 - 2); i++)
        {
          for (m = 0; m < 5; m++)
          {
            rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((((u[k][j][i - 2][m] - (4.0 * u[k][j][i - 1][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j][i + 1][m])) + u[k][j][i + 2][m]));
          }

        }

      }

      for (j = 1; j <= ny2; j++)
      {
        i = nx2 - 1;
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((u[k][j][i - 2][m] - (4.0 * u[k][j][i - 1][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j][i + 1][m])));
        }

        i = nx2;
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((u[k][j][i - 2][m] - (4.0 * u[k][j][i - 1][m])) + (5.0 * u[k][j][i][m])));
        }

      }

    }

    #pragma omp for schedule(static)
    for (k = 1; k <= nz2; k++)
    {
      for (j = 1; j <= ny2; j++)
      {
        for (i = 1; i <= nx2; i++)
        {
          vijk = vs[k][j][i];
          vp1 = vs[k][j + 1][i];
          vm1 = vs[k][j - 1][i];
          rhs[k][j][i][0] = (rhs[k][j][i][0] + (dy1ty1 * ((u[k][j + 1][i][0] - (2.0 * u[k][j][i][0])) + u[k][j - 1][i][0]))) - (ty2 * (u[k][j + 1][i][2] - u[k][j - 1][i][2]));
          rhs[k][j][i][1] = ((rhs[k][j][i][1] + (dy2ty1 * ((u[k][j + 1][i][1] - (2.0 * u[k][j][i][1])) + u[k][j - 1][i][1]))) + (yycon2 * ((us[k][j + 1][i] - (2.0 * us[k][j][i])) + us[k][j - 1][i]))) - (ty2 * ((u[k][j + 1][i][1] * vp1) - (u[k][j - 1][i][1] * vm1)));
          rhs[k][j][i][2] = ((rhs[k][j][i][2] + (dy3ty1 * ((u[k][j + 1][i][2] - (2.0 * u[k][j][i][2])) + u[k][j - 1][i][2]))) + ((yycon2 * con43) * ((vp1 - (2.0 * vijk)) + vm1))) - (ty2 * (((u[k][j + 1][i][2] * vp1) - (u[k][j - 1][i][2] * vm1)) + ((((u[k][j + 1][i][4] - square[k][j + 1][i]) - u[k][j - 1][i][4]) + square[k][j - 1][i]) * c2)));
          rhs[k][j][i][3] = ((rhs[k][j][i][3] + (dy4ty1 * ((u[k][j + 1][i][3] - (2.0 * u[k][j][i][3])) + u[k][j - 1][i][3]))) + (yycon2 * ((ws[k][j + 1][i] - (2.0 * ws[k][j][i])) + ws[k][j - 1][i]))) - (ty2 * ((u[k][j + 1][i][3] * vp1) - (u[k][j - 1][i][3] * vm1)));
          rhs[k][j][i][4] = ((((rhs[k][j][i][4] + (dy5ty1 * ((u[k][j + 1][i][4] - (2.0 * u[k][j][i][4])) + u[k][j - 1][i][4]))) + (yycon3 * ((qs[k][j + 1][i] - (2.0 * qs[k][j][i])) + qs[k][j - 1][i]))) + (yycon4 * (((vp1 * vp1) - ((2.0 * vijk) * vijk)) + (vm1 * vm1)))) + (yycon5 * (((u[k][j + 1][i][4] * rho_i[k][j + 1][i]) - ((2.0 * u[k][j][i][4]) * rho_i[k][j][i])) + (u[k][j - 1][i][4] * rho_i[k][j - 1][i])))) - (ty2 * ((((c1 * u[k][j + 1][i][4]) - (c2 * square[k][j + 1][i])) * vp1) - (((c1 * u[k][j - 1][i][4]) - (c2 * square[k][j - 1][i])) * vm1)));
        }

      }

      j = 1;
      for (i = 1; i <= nx2; i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((5.0 * u[k][j][i][m]) - (4.0 * u[k][j + 1][i][m])) + u[k][j + 2][i][m]));
        }

      }

      j = 2;
      for (i = 1; i <= nx2; i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((((-4.0) * u[k][j - 1][i][m]) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j + 1][i][m])) + u[k][j + 2][i][m]));
        }

      }

      for (j = 3; j <= (ny2 - 2); j++)
      {
        for (i = 1; i <= nx2; i++)
        {
          for (m = 0; m < 5; m++)
          {
            rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((((u[k][j - 2][i][m] - (4.0 * u[k][j - 1][i][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j + 1][i][m])) + u[k][j + 2][i][m]));
          }

        }

      }

      j = ny2 - 1;
      for (i = 1; i <= nx2; i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((u[k][j - 2][i][m] - (4.0 * u[k][j - 1][i][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k][j + 1][i][m])));
        }

      }

      j = ny2;
      for (i = 1; i <= nx2; i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((u[k][j - 2][i][m] - (4.0 * u[k][j - 1][i][m])) + (5.0 * u[k][j][i][m])));
        }

      }

    }

    #pragma omp for schedule(static)
    for (k = 1; k <= (grid_points[2] - 2); k++)
    {
      for (j = 1; j <= (grid_points[1] - 2); j++)
      {
        for (i = 1; i <= (grid_points[0] - 2); i++)
        {
          wijk = ws[k][j][i];
          wp1 = ws[k + 1][j][i];
          wm1 = ws[k - 1][j][i];
          rhs[k][j][i][0] = (rhs[k][j][i][0] + (dz1tz1 * ((u[k + 1][j][i][0] - (2.0 * u[k][j][i][0])) + u[k - 1][j][i][0]))) - (tz2 * (u[k + 1][j][i][3] - u[k - 1][j][i][3]));
          rhs[k][j][i][1] = ((rhs[k][j][i][1] + (dz2tz1 * ((u[k + 1][j][i][1] - (2.0 * u[k][j][i][1])) + u[k - 1][j][i][1]))) + (zzcon2 * ((us[k + 1][j][i] - (2.0 * us[k][j][i])) + us[k - 1][j][i]))) - (tz2 * ((u[k + 1][j][i][1] * wp1) - (u[k - 1][j][i][1] * wm1)));
          rhs[k][j][i][2] = ((rhs[k][j][i][2] + (dz3tz1 * ((u[k + 1][j][i][2] - (2.0 * u[k][j][i][2])) + u[k - 1][j][i][2]))) + (zzcon2 * ((vs[k + 1][j][i] - (2.0 * vs[k][j][i])) + vs[k - 1][j][i]))) - (tz2 * ((u[k + 1][j][i][2] * wp1) - (u[k - 1][j][i][2] * wm1)));
          rhs[k][j][i][3] = ((rhs[k][j][i][3] + (dz4tz1 * ((u[k + 1][j][i][3] - (2.0 * u[k][j][i][3])) + u[k - 1][j][i][3]))) + ((zzcon2 * con43) * ((wp1 - (2.0 * wijk)) + wm1))) - (tz2 * (((u[k + 1][j][i][3] * wp1) - (u[k - 1][j][i][3] * wm1)) + ((((u[k + 1][j][i][4] - square[k + 1][j][i]) - u[k - 1][j][i][4]) + square[k - 1][j][i]) * c2)));
          rhs[k][j][i][4] = ((((rhs[k][j][i][4] + (dz5tz1 * ((u[k + 1][j][i][4] - (2.0 * u[k][j][i][4])) + u[k - 1][j][i][4]))) + (zzcon3 * ((qs[k + 1][j][i] - (2.0 * qs[k][j][i])) + qs[k - 1][j][i]))) + (zzcon4 * (((wp1 * wp1) - ((2.0 * wijk) * wijk)) + (wm1 * wm1)))) + (zzcon5 * (((u[k + 1][j][i][4] * rho_i[k + 1][j][i]) - ((2.0 * u[k][j][i][4]) * rho_i[k][j][i])) + (u[k - 1][j][i][4] * rho_i[k - 1][j][i])))) - (tz2 * ((((c1 * u[k + 1][j][i][4]) - (c2 * square[k + 1][j][i])) * wp1) - (((c1 * u[k - 1][j][i][4]) - (c2 * square[k - 1][j][i])) * wm1)));
        }

      }

    }

    k = 1;
    #pragma omp for schedule(static) nowait
    for (j = 1; j <= (grid_points[1] - 2); j++)
    {
      for (i = 1; i <= (grid_points[0] - 2); i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((5.0 * u[k][j][i][m]) - (4.0 * u[k + 1][j][i][m])) + u[k + 2][j][i][m]));
        }

      }

    }

    k = 2;
    #pragma omp for schedule(static) nowait
    for (j = 1; j <= (grid_points[1] - 2); j++)
    {
      for (i = 1; i <= (grid_points[0] - 2); i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((((-4.0) * u[k - 1][j][i][m]) + (6.0 * u[k][j][i][m])) - (4.0 * u[k + 1][j][i][m])) + u[k + 2][j][i][m]));
        }

      }

    }

    #pragma omp for schedule(static) nowait
    for (k = 3; k <= (grid_points[2] - 4); k++)
    {
      for (j = 1; j <= (grid_points[1] - 2); j++)
      {
        for (i = 1; i <= (grid_points[0] - 2); i++)
        {
          for (m = 0; m < 5; m++)
          {
            rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((((u[k - 2][j][i][m] - (4.0 * u[k - 1][j][i][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k + 1][j][i][m])) + u[k + 2][j][i][m]));
          }

        }

      }

    }

    k = grid_points[2] - 3;
    #pragma omp for schedule(static) nowait
    for (j = 1; j <= (grid_points[1] - 2); j++)
    {
      for (i = 1; i <= (grid_points[0] - 2); i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * (((u[k - 2][j][i][m] - (4.0 * u[k - 1][j][i][m])) + (6.0 * u[k][j][i][m])) - (4.0 * u[k + 1][j][i][m])));
        }

      }

    }

    k = grid_points[2] - 2;
    #pragma omp for schedule(static)
    for (j = 1; j <= (grid_points[1] - 2); j++)
    {
      for (i = 1; i <= (grid_points[0] - 2); i++)
      {
        for (m = 0; m < 5; m++)
        {
          rhs[k][j][i][m] = rhs[k][j][i][m] - (dssp * ((u[k - 2][j][i][m] - (4.0 * u[k - 1][j][i][m])) + (5.0 * u[k][j][i][m])));
        }

      }

    }

    #pragma omp for schedule(static) nowait
    for (k = 1; k <= nz2; k++)
    {
      for (j = 1; j <= ny2; j++)
      {
        for (i = 1; i <= nx2; i++)
        {
          for (m = 0; m < 5; m++)
          {
            rhs[k][j][i][m] = rhs[k][j][i][m] * dt;
          }

        }

      }

    }

  }

  int nxe = nx + 8;
  int nze = nz + 8;
  int nzxe = nze * nxe;
  int npml = ne - 4;
  int npmlx = npml * nze;
  int npmlz = npml * nxe;
  float a1x = 1.1962890625f * dtpdx;
  float a2x = (-0.07975260416f) * dtpdx;
  float a3x = 0.0095703125f * dtpdx;
  float a4x = (-0.00069754464f) * dtpdx;
  float a1z = 1.1962890625f * dtpdz;
  float a2z = (-0.07975260416f) * dtpdz;
  float a3z = 0.0095703125f * dtpdz;
  float a4z = (-0.00069754464f) * dtpdz;
  int i = 0;
  int j = 0;
  int l = 0;
  int it = 0;
  int iter = 0;
  int ipmlx = 0;
  int ipmlz = 0;
  float delp;
  float dsxxm;
  float dszzm;
  float dp_dx = 0.0;
  float dp_dz = 0.0;
  float d = 0.0;
  float b = 0.0;
  float a = 0.0;
  float c = 0.0;
  int disp1 = 1;
  int disp2 = 1;
  float coeff = 2.5;
  #pragma omp parallel default(shared)
  {
    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        delp = 1.0 / rho[iter];
        ipmlx = j + ((i + 4) * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j + npml];
        b = par_cpml[j + (5 * npml)] * exp(-d);
        d = par_cpml[j + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        sxx[iter] += dp_dx * delp;
        ipmlz = ((2 * npmlx) + i) + ((j + 4) * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i + npml];
        b = par_cpml[i + (5 * npml)] * exp(-d);
        d = par_cpml[i + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        ipmlx = j + (i * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j + npml];
        b = par_cpml[j + (5 * npml)] * exp(-d);
        d = par_cpml[j + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        delp = (1.0 / rho[iter + nze]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        sxx[iter] += dp_dx * delp;
        delp = (1.0 / rho[iter + 1]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        szz[iter] += ((((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]))) * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        delp = 1.0 / rho[iter];
        ipmlx = j + (((i + nze) - ne) * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j + npml];
        b = par_cpml[j + (5 * npml)] * exp(-d);
        d = par_cpml[j + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        sxx[iter] += dp_dx * delp;
        ipmlz = ((npmlz + (2 * npmlx)) + i) + ((j + 4) * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        l = ((npml - i) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdz) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        delp = 1.0 / rho[iter];
        ipmlz = ((2 * npmlx) + i) + (j * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i + npml];
        b = par_cpml[i + (5 * npml)] * exp(-d);
        d = par_cpml[i + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        sxx[iter] += ((((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]))) * delp;
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        delp = 1.0 / rho[iter];
        ipmlz = ((npmlz + (2 * npmlx)) + i) + (j * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        l = ((npml - i) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdz) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        sxx[iter] += ((((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]))) * delp;
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        delp = 1.0 / rho[iter];
        ipmlx = (npmlx + j) + ((i + 4) * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        l = ((npml - j) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdx) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        sxx[iter] += dp_dx * delp;
        ipmlz = ((2 * npmlx) + i) + (((j + nxe) - ne) * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i + npml];
        b = par_cpml[i + (5 * npml)] * exp(-d);
        d = par_cpml[i + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        ipmlx = (npmlx + j) + (i * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        l = ((npml - j) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdx) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        delp = (1.0 / rho[iter + nze]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        sxx[iter] += dp_dx * delp;
        delp = (1.0 / rho[iter + 1]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        szz[iter] += ((((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]))) * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        delp = 1.0 / rho[iter];
        ipmlx = (npmlx + j) + (((i + nze) - ne) * npml);
        dp_dx = (((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]));
        l = ((npml - j) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdx) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlx] = (b * memory_dp[ipmlx]) + (a * dp_dx);
        dp_dx = dp_dx + memory_dp[ipmlx];
        sxx[iter] += dp_dx * delp;
        ipmlz = ((npmlz + (2 * npmlx)) + i) + (((j + nxe) - ne) * npml);
        dp_dz = (((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]));
        l = ((npml - i) - 1) - 1;
        if (l < 0)
        {
          l = 0;
        }

        c = v[iter];
        d = (c * dtpdz) * par_cpml[l + npml];
        b = par_cpml[l + (5 * npml)] * exp(-d);
        d = par_cpml[l + (7 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (3 * npml)]);
        memory_dp[ipmlz] = (b * memory_dp[ipmlz]) + (a * dp_dz);
        dp_dz = dp_dz + memory_dp[ipmlz];
        szz[iter] += dp_dz * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        delp = (1.0 / rho[iter + nze]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        sxx[iter] += ((((a1x * (u3[iter + nze] - u3[iter])) + (a2x * (u3[iter + (2 * nze)] - u3[iter - nze]))) + (a3x * (u3[iter + (3 * nze)] - u3[iter - (2 * nze)]))) + (a4x * (u3[iter + (4 * nze)] - u3[iter - (3 * nze)]))) * delp;
        delp = (1.0 / rho[iter + 1]) + (1.0 / rho[iter]);
        delp = 0.5 * delp;
        szz[iter] += ((((a1z * (u3[iter + 1] - u3[iter])) + (a2z * (u3[iter + 2] - u3[iter - 1]))) + (a3z * (u3[iter + 3] - u3[iter - 2]))) + (a4z * (u3[iter + 4] - u3[iter - 3]))) * delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlx = j + ((i + 4) * npml);
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j];
        b = par_cpml[j + (4 * npml)] * exp(-d);
        d = par_cpml[j + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        ipmlz = ((2 * npmlx) + i) + ((j + 4) * npml);
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i];
        b = par_cpml[i + (4 * npml)] * exp(-d);
        d = par_cpml[i + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        ipmlx = j + (i * npml);
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j];
        b = par_cpml[j + (4 * npml)] * exp(-d);
        d = par_cpml[j + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = (j + 4) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlx = j + (((i + nze) - ne) * npml);
        c = v[iter];
        d = (c * dtpdx) * par_cpml[j];
        b = par_cpml[j + (4 * npml)] * exp(-d);
        d = par_cpml[j + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[j + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        ipmlz = ((npmlz + (2 * npmlx)) + i) + ((j + 4) * npml);
        l = (npml - i) - 1;
        c = v[iter];
        d = (c * dtpdz) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlz = ((2 * npmlx) + i) + (j * npml);
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i];
        b = par_cpml[i + (4 * npml)] * exp(-d);
        d = par_cpml[i + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlz = ((npmlz + (2 * npmlx)) + i) + (j * npml);
        l = (npml - i) - 1;
        c = v[iter];
        d = (c * dtpdz) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = (it + i) + 4;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlx = (npmlx + j) + ((i + 4) * npml);
        l = (npml - j) - 1;
        c = v[iter];
        d = (c * dtpdx) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        ipmlz = ((2 * npmlx) + i) + (((j + nxe) - ne) * npml);
        c = v[iter];
        d = (c * dtpdz) * par_cpml[i];
        b = par_cpml[i + (4 * npml)] * exp(-d);
        d = par_cpml[i + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[i + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        ipmlx = (npmlx + j) + (i * npml);
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        l = (npml - j) - 1;
        c = v[iter];
        d = (c * dtpdx) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = 0; j < npml; j++)
    {
      it = ((j + nxe) - ne) * nze;
      for (i = 0; i < npml; i++)
      {
        iter = ((it + i) + nze) - ne;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        ipmlx = (npmlx + j) + (((i + nze) - ne) * npml);
        l = (npml - j) - 1;
        c = v[iter];
        d = (c * dtpdx) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlx] = (b * memory_ds[ipmlx]) + (a * dsxxm);
        dsxxm = dsxxm + memory_ds[ipmlx];
        ipmlz = ((npmlz + (2 * npmlx)) + i) + (((j + nxe) - ne) * npml);
        l = (npml - i) - 1;
        c = v[iter];
        d = (c * dtpdz) * par_cpml[l];
        b = par_cpml[l + (4 * npml)] * exp(-d);
        d = par_cpml[l + (6 * npml)] * c;
        a = (d * (b - 1.0)) / (d + par_cpml[l + (2 * npml)]);
        memory_ds[ipmlz] = (b * memory_ds[ipmlz]) + (a * dszzm);
        dszzm = dszzm + memory_ds[ipmlz];
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

    #pragma omp for schedule(guided) nowait
    for (j = ne; j < (nxe - ne); j++)
    {
      it = j * nze;
      for (i = ne; i < (nze - ne); i++)
      {
        iter = it + i;
        dsxxm = (((a1x * (sxx[iter] - sxx[iter - nze])) + (a2x * (sxx[iter + nze] - sxx[iter - (2 * nze)]))) + (a3x * (sxx[iter + (2 * nze)] - sxx[iter - (3 * nze)]))) + (a4x * (sxx[iter + (3 * nze)] - sxx[iter - (4 * nze)]));
        dszzm = (((a1z * (szz[iter] - szz[iter - 1])) + (a2z * (szz[iter + 1] - szz[iter - 2]))) + (a3z * (szz[iter + 2] - szz[iter - 3]))) + (a4z * (szz[iter + 3] - szz[iter - 4]));
        delp = ((rho[iter] * v[iter]) * v[iter]) * (dsxxm + dszzm);
        u3[iter] += delp;
      }

    }

  }
}

