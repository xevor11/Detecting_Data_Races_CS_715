int main(int argc, const char *argv[])
{
  int n = 4;
  int a[n][n];
  int b[n][n];
  int c[n][n];
  int i;
  int j;
  int k;
  int chunk;
  omp_set_num_threads(4);
  chunk = n / 4;
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
  {
    a[i][j] = 1;
    b[i][j] = 1;
    c[i][j] = 0;
  }


  #pragma omp parallel shared(a,b,c)
  {
    #pragma for schedule(static, chunk)
    for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
      {
        for (k = 0; k < n; k++)
        {
          c[i][j] += a[i][k] * a[k][j];
        }

      }

      printf("%d row * %d col by thread %d\n", i, j, omp_get_thread_num());
    }

  }
  return 0;
}

