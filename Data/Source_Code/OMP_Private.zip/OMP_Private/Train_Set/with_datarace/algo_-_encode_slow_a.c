struct cs
{
  uint64_t checksum;
};
int encode_slow_a(struct chunk *chunk)
{
  int i;
  int j;
  uint64_t checksum = 0;
  #pragma omp parallel for reduction(+:checksum)
  for (i = 0; i < chunk->height; i++)
  {
    for (j = 0; j < chunk->width; j++)
    {
      int index = (i * chunk->width) + j;
      chunk->data[index] = chunk->data[index] + chunk->key;
      checksum += chunk->data[index];
    }

  }

  chunk->checksum = checksum;
  return 0;
}

