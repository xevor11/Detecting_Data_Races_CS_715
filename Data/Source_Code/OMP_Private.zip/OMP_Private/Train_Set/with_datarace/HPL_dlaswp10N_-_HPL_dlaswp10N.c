void HPL_dlaswp10N(M, N, A, LDA, IPIV)
const int M;
const int N;
double *A;
const int LDA;
const int *IPIV;
{
  double r;
  double *a0;
  double *a1;
  const int incA = 1 << 5;
  int jp;
  int mr;
  int mu;
  register int i;
  register int j;
  register int k;
  if ((M <= 0) || (N <= 0))
    return;

  mr = M - (mu = (int) ((((unsigned int) M) >> 5) << 5));
  int nthreads;
  #pragma omp parallel
  {
    k = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    for (j = 0; j < N; j++)
    {
      if (j != (jp = IPIV[j]))
      {
        a0 = (A + (j * LDA)) + (k * 32);
        a1 = (A + (jp * LDA)) + (k * 32);
        for (i = k * 32; i < mu; i += nthreads * 32, a0 += nthreads * 32, a1 += nthreads * 32)
        {
          r = *a0;
          *a0 = *a1;
          *a1 = r;
          r = a0[1];
          a0[1] = a1[1];
          a1[1] = r;
          r = a0[2];
          a0[2] = a1[2];
          a1[2] = r;
          r = a0[3];
          a0[3] = a1[3];
          a1[3] = r;
          r = a0[4];
          a0[4] = a1[4];
          a1[4] = r;
          r = a0[5];
          a0[5] = a1[5];
          a1[5] = r;
          r = a0[6];
          a0[6] = a1[6];
          a1[6] = r;
          r = a0[7];
          a0[7] = a1[7];
          a1[7] = r;
          r = a0[8];
          a0[8] = a1[8];
          a1[8] = r;
          r = a0[9];
          a0[9] = a1[9];
          a1[9] = r;
          r = a0[10];
          a0[10] = a1[10];
          a1[10] = r;
          r = a0[11];
          a0[11] = a1[11];
          a1[11] = r;
          r = a0[12];
          a0[12] = a1[12];
          a1[12] = r;
          r = a0[13];
          a0[13] = a1[13];
          a1[13] = r;
          r = a0[14];
          a0[14] = a1[14];
          a1[14] = r;
          r = a0[15];
          a0[15] = a1[15];
          a1[15] = r;
          r = a0[16];
          a0[16] = a1[16];
          a1[16] = r;
          r = a0[17];
          a0[17] = a1[17];
          a1[17] = r;
          r = a0[18];
          a0[18] = a1[18];
          a1[18] = r;
          r = a0[19];
          a0[19] = a1[19];
          a1[19] = r;
          r = a0[20];
          a0[20] = a1[20];
          a1[20] = r;
          r = a0[21];
          a0[21] = a1[21];
          a1[21] = r;
          r = a0[22];
          a0[22] = a1[22];
          a1[22] = r;
          r = a0[23];
          a0[23] = a1[23];
          a1[23] = r;
          r = a0[24];
          a0[24] = a1[24];
          a1[24] = r;
          r = a0[25];
          a0[25] = a1[25];
          a1[25] = r;
          r = a0[26];
          a0[26] = a1[26];
          a1[26] = r;
          r = a0[27];
          a0[27] = a1[27];
          a1[27] = r;
          r = a0[28];
          a0[28] = a1[28];
          a1[28] = r;
          r = a0[29];
          a0[29] = a1[29];
          a1[29] = r;
          r = a0[30];
          a0[30] = a1[30];
          a1[30] = r;
          r = a0[31];
          a0[31] = a1[31];
          a1[31] = r;
        }

      }

    }

  }
  for (j = 0; j < N; j++)
  {
    if (j != (jp = IPIV[j]))
    {
      a0 = (A + (j * LDA)) + mu;
      a1 = (A + (jp * LDA)) + mu;
      for (i = 0; i < mr; i++)
      {
        r = a0[i];
        a0[i] = a1[i];
        a1[i] = r;
      }

    }

  }

}

