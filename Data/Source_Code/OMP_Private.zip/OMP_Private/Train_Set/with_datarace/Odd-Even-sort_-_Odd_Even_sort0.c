void Odd_Even_sort0(int *array, int N)
{
  int i;
  int start = 0;
  int flag = 1;
  int temp;
  while (start || flag)
  {
    flag = 0;
    #pragma omp parallel for
    for (i = start; i < (N - 1); i += 2)
    {
      if (array[i] > array[i + 1])
      {
        exch(&array[i], &array[i + 1]);
        flag = 1;
      }

    }

    start = (start) ? (0) : (1);
  }

}

