void findcov_(int *NVAR, int *NROW, int *NV, double *MType, double *COV)
{
  long IVar1;
  long IVar2;
  long IVar3;
  int nv_i = *NV;
  int nvar_i = *NVAR;
  int nrow_i = *NROW;
  int nrow_l = ((nrow_i + 15) >> 4) << 4;
  int nvar_l = nvar_i + nv_i;
  printf("%d %d\n", nvar_l, nrow_l);
  double *MT = (double *) _mm_malloc((((long) nvar_l) * nrow_l) * (sizeof(double)), 64);
  #pragma omp parallel
  {
    double t0 = dtime();
    #pragma omp for
    for (IVar1 = 0; IVar1 < nvar_l; IVar1++)
    {
      long I2 = IVar1 % nvar_i;
      long VR = IVar1 * nrow_l;
      for (IVar3 = 0; IVar3 < nrow_i; IVar3++)
      {
        double MTemp = MType[(IVar3 * nvar_i) + I2];
        MT[VR + IVar3] = ((MTemp != MTemp) || (fabs(MTemp - 65.0) <= 0.001)) ? (65.0) : (MTemp);
      }

    }

    double t1 = dtime();
    #pragma omp for
    for (IVar1 = 0; IVar1 < nvar_i; IVar1++)
    {
      for (IVar2 = 0; IVar2 < nv_i; IVar2++)
      {
        int NumMissing = 0;
        double MeanX1 = 0.0f;
        double MeanX2 = 0.0f;
        double C = 0.0f;
        long VR = IVar1 * nrow_l;
        long V1 = VR + ((IVar2 + 1) * nrow_l);
        #pragma vector aligned
        for (IVar3 = 0; IVar3 < nrow_i; IVar3++)
        {
          double M1 = MT[VR + IVar3];
          double M2 = MT[V1 + IVar3];
          if ((M1 != 65.0) && (M2 != 65.0))
          {
            NumMissing++;
            MeanX1 += M1;
            MeanX2 += M2;
            C += M1 * M2;
          }

        }

        double IRep = (NumMissing <= 0) ? (0.0f) : (1.0f / ((double) NumMissing));
        MeanX1 *= IRep;
        MeanX2 *= IRep;
        COV[(IVar2 * nvar_i) + IVar1] = (C * IRep) - (MeanX1 * MeanX2);
      }

    }

    double t2 = dtime();
  }
  _mm_free(MT);

  int x_min = *xmin;
  int x_max = *xmax;
  int y_min = *ymin;
  int y_max = *ymax;
  double min_x = *minx;
  double min_y = *miny;
  double d_x = *dx;
  double d_y = *dy;
  int j;
  int k;
  #pragma omp parallel
  {
    #pragma omp for private(j)
    #pragma ivdep
    for (j = x_min - 2; j <= (x_max + 3); j++)
    {
      vertexx[FTNREF1D(j, x_min - 2)] = min_x + (d_x * ((double) (j - x_min)));
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (j = x_min - 2; j <= (x_max + 3); j++)
    {
      vertexdx[FTNREF1D(j, x_min - 2)] = d_x;
    }

    #pragma omp for private(j,k)
    #pragma ivdep
    for (k = y_min - 2; k <= (y_max + 3); k++)
    {
      vertexy[FTNREF1D(k, y_min - 2)] = min_y + (d_y * ((double) (k - y_min)));
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (k = y_min - 2; k <= (y_max + 3); k++)
    {
      vertexdy[FTNREF1D(k, y_min - 2)] = d_y;
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (j = x_min - 2; j <= (x_max + 2); j++)
    {
      cellx[FTNREF1D(j, x_min - 2)] = 0.5 * (vertexx[FTNREF1D(j, x_min - 2)] + vertexx[FTNREF1D(j + 1, x_min - 2)]);
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (j = x_min - 2; j <= (x_max + 2); j++)
    {
      celldx[FTNREF1D(j, x_min - 2)] = d_x;
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (k = y_min - 2; k <= (y_max + 2); k++)
    {
      celly[FTNREF1D(k, y_min - 2)] = 0.5 * (vertexy[FTNREF1D(k, y_min - 2)] + vertexy[FTNREF1D(k + 1, x_min - 2)]);
    }

    #pragma omp for private(j)
    #pragma ivdep
    for (k = y_min - 2; k <= (y_max + 2); k++)
    {
      celldy[FTNREF1D(k, y_min - 2)] = d_y;
    }

    #pragma omp for private(j,k)
    for (k = y_min - 2; k <= (y_max + 2); k++)
    {
      #pragma ivdep
      for (j = x_min - 2; j <= (x_max + 2); j++)
      {
        volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = d_x * d_y;
      }

    }

    #pragma omp for private(j,k)
    for (k = y_min - 2; k <= (y_max + 2); k++)
    {
      #pragma ivdep
      for (j = x_min - 2; j <= (x_max + 2); j++)
      {
        xarea[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] = celldy[FTNREF1D(k, y_min - 2)];
      }

    }

    #pragma omp for private(j,k)
    for (k = y_min - 2; k <= (y_max + 2); k++)
    {
      #pragma ivdep
      for (j = x_min - 2; j <= (x_max + 2); j++)
      {
        yarea[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = celldx[FTNREF1D(j, x_min - 2)];
      }

    }

  }
}

