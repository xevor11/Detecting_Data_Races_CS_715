void SURE_prox_rw12_double(double *SURE, const double *La, const int *Idx, const double *Yb, const double *Sb2, const double *S2_Yb, const double *Mu, const int K, const int L, const int M)
{
  int k;
  int l;
  int m;
  int Lk;
  int Mk;
  double la;
  double la2;
  double ybla;
  double sqrd;
  double diff;
  #pragma omp parallel for
  for (k = 0; k < K; k++)
  {
    l = L * k;
    Lk = l + L;
    Mk = M * (k + 1);
    while ((l < Lk) && ((la = La[l]) >= 0.))
    {
      la2 = la * la;
      m = (Mk - M) + Idx[l];
      while (((++m) < Mk) && (Yb[m] == la))
      {
        SURE[l] += (la2 * Mu[m]) * Mu[m];
      }

      for (; m < Mk; m++)
      {
        ybla = Yb[m] + la;
        sqrd = sqrt((ybla * ybla) - (4. * la2));
        diff = (ybla - sqrd) * Mu[m];
        SURE[l] += (((diff * diff) / 4.) + ((1. + ((sqrd - la) / Yb[m])) * Sb2[m])) + (((1. + (((4. * la) - ybla) / sqrd)) * la) * S2_Yb[m]);
      }

      l++;
    }

  }

}

