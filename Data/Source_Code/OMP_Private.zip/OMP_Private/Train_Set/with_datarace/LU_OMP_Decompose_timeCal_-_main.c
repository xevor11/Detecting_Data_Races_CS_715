double **A;
double **L;
double **U;
void arrayInit(int n);
void verifyLU(int n);
void updateLU(int n);
void freemem(int n);
int rank;
int numprocs;
int main(int argc, char **argv)
{
  int i = 0;
  int j = 0;
  int k = 0;
  int n = 0;
  struct timeval bef;
  struct timeval aft;
  long duration = 0;
  n = atoi(argv[1]);
  numprocs = atoi(argv[2]);
  A = (double **) malloc((sizeof(double *)) * n);
  L = (double **) malloc((sizeof(double *)) * n);
  U = (double **) malloc((sizeof(double *)) * n);
  for (i = 0; i < n; i++)
  {
    A[i] = (double *) malloc(n * (sizeof(double)));
    L[i] = (double *) malloc(n * (sizeof(double)));
    U[i] = (double *) malloc(n * (sizeof(double)));
  }

  arrayInit(n);
  gettimeofday(&bef, 0);
  #pragma omp parallel num_threads(numprocs)
  {
    rank = omp_get_thread_num();
    for (k = 0; k < n; k++)
    {
      if ((k % numprocs) == rank)
      {
        for (j = k + 1; j < n; j++)
        {
          A[k][j] = A[k][j] / A[k][k];
        }

      }

      #pragma omp barrier
      #pragma omp for schedule(static,1)
      for (i = k + 1; i < n; i++)
      {
        for (j = k + 1; j < n; j++)
        {
          A[i][j] = A[i][j] - (A[i][k] * A[k][j]);
        }

      }

    }

  }
  gettimeofday(&aft, 0);
  duration = aft.tv_sec - bef.tv_sec;
  printf("%ld --- %d  \n", duration, n);
  freemem(n);
  return 0;
}

