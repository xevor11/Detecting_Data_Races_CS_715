int main()
{
  unsigned long long x;
  unsigned long long y;
  unsigned long long r;
  unsigned long long r2;
  unsigned long long P;
  int NumProcs;
  r2 = ((unsigned long) 100000L) * ((unsigned long) 100000L);
  P = 0L;
  NumProcs = 2 - 1;
  printf(" Approximation of the value of PI on %d cores.\n", NumProcs);
  #pragma omp parallel for num_threads(NumProcs) reduction(+:P)
  for (x = 0L; x <= 100000L; x++)
    for (y = 0L; y <= 100000L; y++)
    if (((x * x) + (y * y)) <= r2)
    P++;



  printf(" PI approximated: %.9lf\n", (4.0 * ((double) P)) / ((double) r2));
  printf(" PI exact:        3.141592653\n");
}

