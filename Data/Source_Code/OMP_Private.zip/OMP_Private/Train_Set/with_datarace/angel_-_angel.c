void angel()
{
  int roundCounter;
  int currentRow;
  int currentColumn;
  int neighborsAlive;
  int tempCounterRow;
  int tempCounterColumn;
  for (roundCounter = 0; roundCounter < roundTotal; roundCounter++)
  {
    #pragma omp parallel for
    for (currentRow = 1; currentRow < (sizeUniverseX - 1); currentRow++)
    {
      for (currentColumn = 1; currentColumn < (sizeUniverseY - 1); currentColumn++)
      {
        neighborsAlive = 0;
        for (tempCounterRow = currentRow - 1; tempCounterRow <= (currentRow + 1); tempCounterRow++)
        {
          for (tempCounterColumn = currentColumn - 1; tempCounterColumn <= (currentColumn + 1); tempCounterColumn++)
          {
            if ((tempCounterRow == currentRow) && (tempCounterColumn == currentColumn))
              continue;

            if (master[tempCounterRow][tempCounterColumn] == '#')
              neighborsAlive++;

          }

        }

        if (master[currentRow][currentColumn] == '.')
        {
          if (neighborsAlive == 3)
            slave[currentRow][currentColumn] = '#';
          else
            slave[currentRow][currentColumn] = '.';

        }
        else
        {
          if (neighborsAlive < 2)
          {
            slave[currentRow][currentColumn] = '.';
          }
          else
            if (neighborsAlive > 3)
          {
            slave[currentRow][currentColumn] = '.';
          }
          else
          {
            slave[currentRow][currentColumn] = '#';
          }


        }

      }

    }

    #pragma omp parallel for
    for (currentRow = 1; currentRow < (sizeUniverseX - 1); currentRow++)
    {
      for (currentColumn = 1; currentColumn < (sizeUniverseY - 1); currentColumn++)
      {
        master[currentRow][currentColumn] = slave[currentRow][currentColumn];
      }

    }

  }

}

