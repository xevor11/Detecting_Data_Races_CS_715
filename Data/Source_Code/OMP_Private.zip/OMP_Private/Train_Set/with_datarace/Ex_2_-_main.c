void main(int a, char **args)
{
  int i;
  int threads;
  double tempo;
  double N;
  double soma = 0;
  double x;
  double passo;
  double ln;
  le_entrada(args, &N, &threads);
  tempo = omp_get_wtime();
  passo = (2 - 1) / ((double) N);
  omp_set_num_threads(threads);
  #pragma omp parallel for shared(passo) reduction(+:soma)
  for (i = 0; i < N; i++)
  {
    x = 1 + (i * passo);
    soma += 0.5 * ((1 / x) + (1 / (x + passo)));
  }

  ln = soma * passo;
  tempo = omp_get_wtime() - tempo;
  printf("%.3lf ", tempo);

  int max = 0;
  omp_set_num_threads(4);
  int start_i;
  int end_i;
  int id;
  int i;
  int max0 = 0;
  int max1 = 0;
  int max2 = 0;
  int max3 = 0;
  #pragma omp parallel private(start_i, end_i, id, i)
  {
    id = omp_get_thread_num();
    if (id == 0)
      start_i = 0;
    else
      start_i = ((id * size) / 4) + 1;

    if (id == 3)
      end_i = size - 1;
    else
      end_i = ((id + 1) * size) / 4;

    for (i = start_i; i < (end_i + 1); i++)
    {
      switch (id)
      {
        case 0:
          if ((*(a + i)) > max0)
          max0 = *(a + i);

          break;

        case 1:
          if ((*(a + i)) > max1)
          max1 = *(a + i);

          break;

        case 2:
          if ((*(a + i)) > max2)
          max2 = *(a + i);

          break;

        case 3:
          if ((*(a + i)) > max3)
          max3 = *(a + i);

          break;

        default:
          break;

      }

    }

  }
  max = get_max(get_max(max0, max1), get_max(max2, max3));
  return max;
}

