void init(double *masas);
double *Newton(double *masas);
double freq_2(int k);
double Q(int k, double *masas);
double *derv(double *masas, double *masas_ant);
double E(int k, double *masas, double *masas_ant);
int main(int argc, char *argv[])
{
  FILE *posiciones;
  posiciones = fopen("posiciones.txt", "w");
  FILE *energias;
  energias = fopen("energias.txt", "w");
  int procs = argv[1][0] - '0';
  int i;
  int j;
  int iter = (((int) 5.0) * pow(64, 2.2)) / 0.005;
  double *osc;
  osc = malloc(64 * (sizeof(double)));
  double *osc_p;
  osc_p = malloc(64 * (sizeof(double)));
  double *vels;
  vels = malloc(64 * (sizeof(double)));
  double *vels_p;
  vels_p = malloc(64 * (sizeof(double)));
  double *acc;
  acc = malloc(64 * (sizeof(double)));
  init(osc_p);
  acc = Newton(osc_p);
  for (j = 0; j < 64; j++)
  {
    vels[j] = 0.0;
    vels_p[j] = 0.0;
  }

  for (j = 1; j < (64 - 1); j++)
  {
    vels[j] = (acc[j] * 0.005) / 2.0;
  }

  omp_set_num_threads(procs);
  for (i = 0; i < iter; i++)
  {
    #pragma omp parallel for, shared(osc, osc_p, vels)
    for (j = 1; j < (64 - 1); j++)
    {
      osc[j] = osc_p[j] + (vels[j] * 0.005);
    }

    acc = Newton(osc);
    for (j = 1; j < (64 - 1); j++)
    {
      vels_p[j] = vels[j];
    }

    #pragma omp parallel for, shared(vels, vels_p, acc)
    for (j = 1; j < (64 - 1); j++)
    {
      vels[j] = vels_p[j] + (acc[j] * 0.005);
    }

    if ((i % (iter / 1000)) == 0)
    {
      for (j = 0; j < 64; j++)
      {
        fprintf(posiciones, "%lf ", osc[j]);
      }

      fprintf(posiciones, "\n");
      fprintf(energias, "%lf %lf %lf %lf \n", E(1, osc, osc_p), E(2, osc, osc_p), E(3, osc, osc_p), i * 0.005);
    }

    for (j = 1; j < (64 - 1); j++)
    {
      osc_p[j] = osc[j];
    }

  }


  int found = 0;
  unsigned long current = 0;
  char hash[65];
  unsigned long keyspace = get_keyspace(low, high, alphabet);
  #pragma omp parallel for private(hash) shared(found)
  for (current = 0; current < keyspace; current++)
  {
    if (found)
      continue;

    char *candidate = malloc((sizeof(high)) * (high + 1));
    next_candidate(candidate, current, high, low, alphabet);
    sha256(candidate, hash);
    if (strncmp(secret, hash, 64) == 0)
    {
      found = 1;
      printf("\n The hash matches '%s'\n", candidate);
    }

    free(candidate);
    candidate = 0;
  }

  if (!found)
    printf("\n We could not crack the hash.\n");

}

