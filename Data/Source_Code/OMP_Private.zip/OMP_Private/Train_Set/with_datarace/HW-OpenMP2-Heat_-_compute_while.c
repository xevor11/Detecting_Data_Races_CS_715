void compute_while(int n, int *niters)
{
  double *phi_cur;
  double *phi_next;
  double *tmp;
  int conv;
  int i;
  int j;
  phi_cur = (double *) malloc((n * n) * (sizeof(double)));
  phi_next = (double *) malloc((n * n) * (sizeof(double)));
  init_phi(phi_cur, n);
  init_phi(phi_next, n);
  *niters = 0;
  #pragma omp parallel
  while (1)
  {
    #pragma omp master
    {
      (*niters)++;
      conv = 1;
    }
    {
      #pragma omp for
      for (j = 1; j < (n - 1); j++)
        for (i = 1; i < (n - 1); i++)
        phi_next[(j * n) + i] = (((phi_cur[((j - 1) * n) + i] + phi_cur[(j * n) + (i - 1)]) + phi_cur[(j * n) + (i + 1)]) + phi_cur[((j + 1) * n) + i]) / 4;


      #pragma omp for reduction(&&:conv)
      for (j = 1; j < (n - 1); j++)
        for (i = 1; i < (n - 1); i++)
        if (fabs(phi_next[(j * n) + i] - phi_cur[(j * n) + i]) > 5e-3)
        conv = 0;



    }
    if (conv)
    {
      break;
    }

    #pragma omp master
    {
      tmp = phi_cur;
      phi_cur = phi_next;
      phi_next = tmp;
    }
    #pragma omp barrier
  }

  free(phi_cur);
  free(phi_next);
}

