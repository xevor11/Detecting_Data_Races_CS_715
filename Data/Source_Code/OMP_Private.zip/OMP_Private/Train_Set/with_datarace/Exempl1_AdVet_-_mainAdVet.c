int mainAdVet()
{
  int i;
  int n;
  int chunk;
  float a[50];
  float b[50];
  float c[50];
  for (i = 0; i < 50; i++)
  {
    a[i] = (b[i] = i * 1.0);
  }

  n = 50;
  #pragma omp parallel shared (a, b, c, n)
  {
    #pragma omp sections nowait
    {
      #pragma omp section
      {
        for (i = 0; i < (n / 2); i++)
          c[i] = a[i] + b[i];

        printf("%d \n\n\n", omp_get_thread_num());
      }
      #pragma omp section
      {
        for (i = n / 2; i < n; i++)
          c[i] = a[i] + b[i];

        printf("%d \n\n\n", omp_get_thread_num());
      }
    }
  }
  for (i = 0; i < n; i = i + 5)
    printf("%f  %f  %f  %f  %f \n", c[i], c[i + 1], c[i + 2], c[i + 3], c[i + 4]);

  return 0;
}

