extern int N;
extern double x[1000000];
extern double move();
void updateNN()
{
  int i;
  int k;
  double totalForce[1000000];
  #pragma omp parallel for shared(x, totalForce)
  for (i = 0; i < N; i++)
  {
    totalForce[i] = 0.0;
    if (i > 0)
      totalForce[i] -= 1.0 / pow(x[i] - x[i - 1], 2);

    if (i < (N - 1))
      totalForce[i] += 1.0 / pow(x[i] - x[i + 1], 2);

  }

  #pragma omp parallel for shared(x, totalForce)
  for (i = 0; i < N; i++)
  {
    x[i] = move(x[i], totalForce[i]);
  }

}

