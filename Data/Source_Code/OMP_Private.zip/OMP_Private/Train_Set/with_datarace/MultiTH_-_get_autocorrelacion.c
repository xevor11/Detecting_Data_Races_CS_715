struct Pulso
{
  float pol_fase;
  float pol_cuadratura;
};
void cantidad_datos(void);
void almacenar_datos(struct Pulso *pulsos_vertical[], struct Pulso *pulsos_horizontal[], int);
void guardar_pulsos(struct Pulso *pulsos_vertical[], struct Pulso *pulsos_horizontal[]);
void guardar_gate_pulsos(int cant_datos, struct Pulso *gate_Vertical[][(((int) (0.5 * cant_datos)) / 250) + 1], struct Pulso *gate_Horizontal[][(((int) (0.5 * cant_datos)) / 250) + 1]);
void gate_Pulsos(int cant_datos, struct Pulso *pulsos_M[], struct Pulso *gate_Estruc[][(((int) (0.5 * cant_datos)) / 250) + 1], int);
float get_autocorrelacion(int cant_datos, struct Pulso *gate_Estruc[][(((int) (0.5 * cant_datos)) / 250) + 1], int);
FILE *source;
float dato;
int n = 0;
int j = 0;
short int cant_datos;
struct Pulso *pulso = 0;
float get_autocorrelacion(int cant_datos, struct Pulso *gate_Estruc[][(((int) (0.5 * cant_datos)) / 250) + 1], int iThreads)
{
  int gate = (0.5 * cant_datos) / 250;
  int i;
  float v_resultado = 0;
  omp_set_num_threads((cant_datos / gate) + 3);
  #pragma omp parallel for shared(v_resultado,gate_Estruc)
  for (i = 1; i < ((((int) cant_datos) / gate) - 1); i++)
  {
    v_resultado = v_resultado + (sqrt(pow(gate_Estruc[i][0]->pol_fase, 2) + pow(gate_Estruc[i - 1][0]->pol_cuadratura, 2)) * sqrt(pow(gate_Estruc[i][0]->pol_fase, 2) + pow(gate_Estruc[i - 1][0]->pol_cuadratura, 2)));
  }

  v_resultado = v_resultado / cant_datos;
  printf("Autocorrelacion:%f\n", v_resultado);
  return v_resultado;
}

