struct node
{
  int data;
  int fibdata;
  struct node *next;
};
int main(int argc, char *argv[])
{
  double start;
  double end;
  struct node *p = 0;
  struct node *temp = 0;
  struct node *head = 0;
  printf("Process linked list\n");
  printf("  Each linked list node will be processed by function 'processwork()'\n");
  printf("  Each ll node will compute %d fibonacci numbers beginning with %d\n", 5, 38);
  p = init_list(p);
  head = p;
  int i;
  int count = 0;
  p = head;
  while (p != 0)
  {
    count++;
    p = p->next;
  }

  struct node *parr[count];
  p = head;
  for (i = 0; i < count; i++)
  {
    parr[i] = p;
    p = p->next;
  }

  start = omp_get_wtime();
  #pragma omp parallel for num_threads(2) schedule(static,1)
  for (i = 0; i < count; i++)
  {
    processwork(parr[i]);
  }

  end = omp_get_wtime();
  p = head;
  while (p != 0)
  {
    printf("%d : %d\n", p->data, p->fibdata);
    temp = p->next;
    free(p);
    p = temp;
  }

  free(p);
  printf("Compute Time: %f seconds\n", end - start);
  return 0;
}

