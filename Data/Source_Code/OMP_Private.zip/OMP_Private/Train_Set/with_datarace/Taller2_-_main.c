int main(int argc, char *argv[])
{
  int tid;
  int nthreads;
  int i;
  int j;
  int k;
  int chunk;
  clock_t par_t_begin;
  clock_t par_t_end;
  double par_secs;
  double **a = (double **) malloc(800 * (sizeof(double *)));
  double **b = (double **) malloc(800 * (sizeof(double *)));
  double **c = (double **) malloc(800 * (sizeof(double *)));
  chunk = 10;
  #pragma omp parallel shared(a,b,c,nthreads,chunk)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Starting matrix multiple example with %d threads\n", nthreads);
      printf("Initializing matrices...\n");
    }

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 800; i++)
      a[i] = (double *) malloc(800 * (sizeof(double)));

    for (j = 0; j < 800; j++)
      a[i][j] = i + j;

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 800; i++)
      b[i] = (double *) malloc(800 * (sizeof(double)));

    for (j = 0; j < 800; j++)
      b[i][j] = i * j;

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 800; i++)
      c[i] = (double *) malloc(800 * (sizeof(double)));

    for (j = 0; j < 800; j++)
      c[i][j] = 0;

    printf("Thread %d starting matrix multiply...\n", tid);
    par_t_begin = clock();
    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 800; i++)
    {
      printf("Thread=%d did row=%d\n", tid, i);
      for (j = 0; j < 800; j++)
        for (k = 0; k < 800; k++)
        c[i][j] += a[i][k] * b[k][j];


    }

  }
  par_t_end = clock();
  par_secs = ((double) (par_t_end - par_t_begin)) / CLOCKS_PER_SEC;
  printf("******************************************************\n");
  printf("\nParalelo: La operacion se realizo en %.16g milisegundos\n", par_secs * 1000.0);
  printf("******************************************************\n");
  printf("Done.\n");
}

