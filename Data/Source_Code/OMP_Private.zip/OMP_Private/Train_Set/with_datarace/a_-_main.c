int main()
{
  int A[10][10];
  int B[10][10];
  int C[10][10];
  int i;
  int j;
  int k;
  int chunk = 10 / omp_get_num_threads();
  for (i = 0; i < 10; i++)
    for (j = 0; j < 10; j++)
  {
    A[i][j] = 1;
    B[i][j] = 1;
    C[i][j] = 0;
  }


  #pragma omp parallel shared(A,B,C)
  #pragma omp for schedule(static,chunk)
  for (i = 0; i < 10; i++)
    for (j = 0; j < 10; j++)
    for (k = 0; k < 10; k++)
    C[i][j] += A[i][k] * B[k][j];



  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      printf("%d ", C[i][j]);

    printf("\n");
  }

}

