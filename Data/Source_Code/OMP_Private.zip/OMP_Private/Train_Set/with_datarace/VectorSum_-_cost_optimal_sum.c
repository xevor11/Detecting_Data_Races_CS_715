long long serial_sum(const char *a, size_t n);
long long time_optimal_sum(const char *a, size_t n);
long long cost_optimal_sum(const char *a, size_t n);
long long cost_optimal_sum(const char *a, size_t n)
{
  static int firsttime = 1;
  int spin;
  int Mc_AN;
  int Gc_AN;
  int wan1;
  int TNO1;
  int h_AN;
  int Gh_AN;
  int wan2;
  int TNO2;
  int i;
  int j;
  int k;
  int NumMix;
  int NumSlide;
  int SCFi;
  int SCFj;
  int tno1;
  int tno0;
  int Cwan;
  int Hwan;
  int pSCF_iter;
  int size_OptRDM;
  int size_iOptRDM;
  int SpinP_num;
  int flag_nan;
  double *alden;
  double **A;
  double My_A;
  double **IA;
  double Av_dia;
  double IAv_dia;
  double tmp0;
  double OptNorm_RDM;
  double My_OptNorm_RDM;
  double dum1;
  double dum2;
  double bunsi;
  double bunbo;
  double sum;
  double coef_OptRDM;
  double *****OptRDM;
  double *****iOptRDM;
  int numprocs;
  int myid;
  char nanchar[300];
  MPI_Comm_size(mpi_comm_level1, &numprocs);
  MPI_Comm_rank(mpi_comm_level1, &myid);
  SpinP_num = SpinP_switch;
  alden = (double *) malloc((sizeof(double)) * List_YOUSO[16]);
  A = (double **) malloc((sizeof(double *)) * List_YOUSO[16]);
  for (i = 0; i < List_YOUSO[16]; i++)
  {
    A[i] = (double *) malloc((sizeof(double)) * List_YOUSO[16]);
  }

  IA = (double **) malloc((sizeof(double *)) * List_YOUSO[16]);
  for (i = 0; i < List_YOUSO[16]; i++)
  {
    IA[i] = (double *) malloc((sizeof(double)) * List_YOUSO[16]);
  }

  size_OptRDM = 0;
  OptRDM = (double *****) malloc((sizeof(double ****)) * (SpinP_num + 1));
  for (k = 0; k <= SpinP_num; k++)
  {
    OptRDM[k] = (double ****) malloc((sizeof(double ***)) * (atomnum + 1));
    FNAN[0] = 0;
    for (Mc_AN = 0; Mc_AN <= Matomnum; Mc_AN++)
    {
      if (Mc_AN == 0)
      {
        Gc_AN = 0;
        tno0 = 1;
      }
      else
      {
        Gc_AN = M2G[Mc_AN];
        Cwan = WhatSpecies[Gc_AN];
        tno0 = Spe_Total_NO[Cwan];
      }

      OptRDM[k][Mc_AN] = (double ***) malloc((sizeof(double **)) * (FNAN[Gc_AN] + 1));
      for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
      {
        if (Mc_AN == 0)
        {
          tno1 = 1;
        }
        else
        {
          Gh_AN = natn[Gc_AN][h_AN];
          Hwan = WhatSpecies[Gh_AN];
          tno1 = Spe_Total_NO[Hwan];
        }

        OptRDM[k][Mc_AN][h_AN] = (double **) malloc((sizeof(double *)) * tno0);
        for (i = 0; i < tno0; i++)
        {
          OptRDM[k][Mc_AN][h_AN][i] = (double *) malloc((sizeof(double)) * tno1);
        }

        size_OptRDM += tno0 * tno1;
      }

    }

  }

  if ((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1)))
  {
    size_iOptRDM = 0;
    iOptRDM = (double *****) malloc((sizeof(double ****)) * 2);
    for (k = 0; k < 2; k++)
    {
      iOptRDM[k] = (double ****) malloc((sizeof(double ***)) * (atomnum + 1));
      FNAN[0] = 0;
      for (Mc_AN = 0; Mc_AN <= Matomnum; Mc_AN++)
      {
        if (Mc_AN == 0)
        {
          Gc_AN = 0;
          tno0 = 1;
        }
        else
        {
          Gc_AN = M2G[Mc_AN];
          Cwan = WhatSpecies[Gc_AN];
          tno0 = Spe_Total_NO[Cwan];
        }

        iOptRDM[k][Mc_AN] = (double ***) malloc((sizeof(double **)) * (FNAN[Gc_AN] + 1));
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          if (Mc_AN == 0)
          {
            tno1 = 1;
          }
          else
          {
            Gh_AN = natn[Gc_AN][h_AN];
            Hwan = WhatSpecies[Gh_AN];
            tno1 = Spe_Total_NO[Hwan];
          }

          iOptRDM[k][Mc_AN][h_AN] = (double **) malloc((sizeof(double *)) * tno0);
          for (i = 0; i < tno0; i++)
          {
            iOptRDM[k][Mc_AN][h_AN][i] = (double *) malloc((sizeof(double)) * tno1);
          }

          size_iOptRDM += tno0 * tno1;
        }

      }

    }

  }

  if (SCF_iter == 1)
  {
    if (firsttime)
    {
      PrintMemory("DIIS_Mixing_DM: OptRDM", (sizeof(double)) * size_OptRDM, 0);
      if ((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1)))
      {
        PrintMemory("DIIS_Mixing_DM: iOptRDM", (sizeof(double)) * size_iOptRDM, 0);
      }

      firsttime = 0;
    }

    Simple_Mixing_DM(0, 1.00, DM[0], DM[1], DM[2], iDM[0], iDM[1], iDM[2], ResidualDM[2], iResidualDM[2]);
  }
  else
    if (SCF_iter == 2)
  {
    for (spin = 0; spin <= SpinP_num; spin++)
    {
      for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
      {
        Gc_AN = M2G[Mc_AN];
        wan1 = WhatSpecies[Gc_AN];
        TNO1 = Spe_Total_CNO[wan1];
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          Gh_AN = natn[Gc_AN][h_AN];
          wan2 = WhatSpecies[Gh_AN];
          TNO2 = Spe_Total_CNO[wan2];
          for (i = 0; i < TNO1; i++)
          {
            for (j = 0; j < TNO2; j++)
            {
              ResidualDM[2][spin][Mc_AN][h_AN][i][j] = DM[0][spin][Mc_AN][h_AN][i][j] - DM[1][spin][Mc_AN][h_AN][i][j];
            }

          }

          if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
          {
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                iResidualDM[2][spin][Mc_AN][h_AN][i][j] = iDM[0][spin][Mc_AN][h_AN][i][j] - iDM[1][spin][Mc_AN][h_AN][i][j];
              }

            }

          }

        }

      }

    }

    for (spin = 0; spin <= SpinP_num; spin++)
    {
      for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
      {
        Gc_AN = M2G[Mc_AN];
        wan1 = WhatSpecies[Gc_AN];
        TNO1 = Spe_Total_CNO[wan1];
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          Gh_AN = natn[Gc_AN][h_AN];
          wan2 = WhatSpecies[Gh_AN];
          TNO2 = Spe_Total_CNO[wan2];
          for (i = 0; i < TNO1; i++)
          {
            for (j = 0; j < TNO2; j++)
            {
              DM[2][spin][Mc_AN][h_AN][i][j] = DM[1][spin][Mc_AN][h_AN][i][j];
            }

          }

          if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
          {
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                iDM[2][spin][Mc_AN][h_AN][i][j] = iDM[1][spin][Mc_AN][h_AN][i][j];
              }

            }

          }

        }

      }

    }

    Simple_Mixing_DM(0, Mixing_weight, DM[0], DM[1], DM[2], iDM[0], iDM[1], iDM[2], ResidualDM[2], iResidualDM[2]);
  }
  else
  {
    for (spin = 0; spin <= SpinP_num; spin++)
    {
      for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
      {
        Gc_AN = M2G[Mc_AN];
        wan1 = WhatSpecies[Gc_AN];
        TNO1 = Spe_Total_CNO[wan1];
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          Gh_AN = natn[Gc_AN][h_AN];
          wan2 = WhatSpecies[Gh_AN];
          TNO2 = Spe_Total_CNO[wan2];
          for (i = 0; i < TNO1; i++)
          {
            for (j = 0; j < TNO2; j++)
            {
              ResidualDM[1][spin][Mc_AN][h_AN][i][j] = DM[0][spin][Mc_AN][h_AN][i][j] - DM[1][spin][Mc_AN][h_AN][i][j];
            }

          }

          if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
          {
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                iResidualDM[1][spin][Mc_AN][h_AN][i][j] = iDM[0][spin][Mc_AN][h_AN][i][j] - iDM[1][spin][Mc_AN][h_AN][i][j];
              }

            }

          }

        }

      }

    }

    if ((SCF_iter - 1) < Num_Mixing_pDM)
    {
      NumMix = SCF_iter - 1;
      NumSlide = NumMix + 1;
    }
    else
    {
      NumMix = Num_Mixing_pDM;
      NumSlide = NumMix;
    }

    for (SCFi = 1; SCFi <= NumMix; SCFi++)
    {
      for (SCFj = SCFi; SCFj <= NumMix; SCFj++)
      {
        My_A = 0.0;
        #pragma omp parallel for reduction(+:My_A) private(spin, Mc_AN, Gc_AN, wan1, TNO1, h_AN, Gh_AN, wan2, TNO2, i, j, dum1, dum2) if(SpinP_num > 1) schedule(static,1)
        for (spin = 0; spin <= SpinP_num; spin++)
        {
          for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
          {
            Gc_AN = M2G[Mc_AN];
            wan1 = WhatSpecies[Gc_AN];
            TNO1 = Spe_Total_CNO[wan1];
            for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
            {
              Gh_AN = natn[Gc_AN][h_AN];
              wan2 = WhatSpecies[Gh_AN];
              TNO2 = Spe_Total_CNO[wan2];
              for (i = 0; i < TNO1; i++)
              {
                for (j = 0; j < TNO2; j++)
                {
                  dum1 = ResidualDM[SCFi][spin][Mc_AN][h_AN][i][j];
                  dum2 = ResidualDM[SCFj][spin][Mc_AN][h_AN][i][j];
                  My_A += dum1 * dum2;
                }

              }

              if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
              {
                for (i = 0; i < TNO1; i++)
                {
                  for (j = 0; j < TNO2; j++)
                  {
                    dum1 = iResidualDM[SCFi][spin][Mc_AN][h_AN][i][j];
                    dum2 = iResidualDM[SCFj][spin][Mc_AN][h_AN][i][j];
                    My_A += dum1 * dum2;
                  }

                }

              }

            }

          }

        }

        MPI_Allreduce(&My_A, &A[SCFi - 1][SCFj - 1], 1, MPI_DOUBLE, MPI_SUM, mpi_comm_level1);
        A[SCFj - 1][SCFi - 1] = A[SCFi - 1][SCFj - 1];
      }

    }

    Av_dia = A[0][0];
    NormRD[0] = A[0][0];
    for (SCFi = 1; SCFi <= NumMix; SCFi++)
    {
      A[SCFi - 1][NumMix] = -1.0;
      A[NumMix][SCFi - 1] = -1.0;
    }

    A[NumMix][NumMix] = 0.0;
    #pragma forceinline
    Inverse(NumMix, A, IA);
    for (SCFi = 1; SCFi <= NumMix; SCFi++)
    {
      alden[SCFi] = -IA[SCFi - 1][NumMix];
    }

    flag_nan = 0;
    for (SCFi = 1; SCFi <= NumMix; SCFi++)
    {
      sprintf(nanchar, "%8.4f", alden[SCFi]);
      if ((((strstr(nanchar, "nan") != 0) || (strstr(nanchar, "NaN") != 0)) || (strstr(nanchar, "inf") != 0)) || (strstr(nanchar, "Inf") != 0))
      {
        flag_nan = 1;
      }

    }

    if (flag_nan == 1)
    {
      for (SCFi = 1; SCFi <= NumMix; SCFi++)
      {
        alden[SCFi] = 0.0;
      }

      alden[1] = 0.1;
      alden[2] = 0.9;
    }

    My_OptNorm_RDM = 0.0;
    for (spin = 0; spin <= SpinP_num; spin++)
    {
      for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
      {
        Gc_AN = M2G[Mc_AN];
        wan1 = WhatSpecies[Gc_AN];
        TNO1 = Spe_Total_CNO[wan1];
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          Gh_AN = natn[Gc_AN][h_AN];
          wan2 = WhatSpecies[Gh_AN];
          TNO2 = Spe_Total_CNO[wan2];
          for (i = 0; i < TNO1; i++)
          {
            for (j = 0; j < TNO2; j++)
            {
              sum = 0.0;
              for (pSCF_iter = 1; pSCF_iter <= NumMix; pSCF_iter++)
              {
                sum += alden[pSCF_iter] * ResidualDM[pSCF_iter][spin][Mc_AN][h_AN][i][j];
              }

              OptRDM[spin][Mc_AN][h_AN][i][j] = sum;
              My_OptNorm_RDM += sum * sum;
            }

          }

          if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
          {
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                sum = 0.0;
                for (pSCF_iter = 1; pSCF_iter <= NumMix; pSCF_iter++)
                {
                  sum += alden[pSCF_iter] * iResidualDM[pSCF_iter][spin][Mc_AN][h_AN][i][j];
                }

                iOptRDM[spin][Mc_AN][h_AN][i][j] = sum;
                My_OptNorm_RDM += sum * sum;
              }

            }

          }

        }

      }

    }

    MPI_Allreduce(&My_OptNorm_RDM, &OptNorm_RDM, 1, MPI_DOUBLE, MPI_SUM, mpi_comm_level1);
    if (1.0e-1 <= NormRD[0])
      coef_OptRDM = 0.5;
    else
      if ((1.0e-2 <= NormRD[0]) && (NormRD[0] < 1.0e-1))
      coef_OptRDM = 0.6;
    else
      if ((1.0e-3 <= NormRD[0]) && (NormRD[0] < 1.0e-2))
      coef_OptRDM = 0.7;
    else
      if ((1.0e-4 <= NormRD[0]) && (NormRD[0] < 1.0e-3))
      coef_OptRDM = 0.8;
    else
      coef_OptRDM = 1.0;




    for (spin = 0; spin <= SpinP_num; spin++)
    {
      for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
      {
        Gc_AN = M2G[Mc_AN];
        wan1 = WhatSpecies[Gc_AN];
        TNO1 = Spe_Total_CNO[wan1];
        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          Gh_AN = natn[Gc_AN][h_AN];
          wan2 = WhatSpecies[Gh_AN];
          TNO2 = Spe_Total_CNO[wan2];
          for (i = 0; i < TNO1; i++)
          {
            for (j = 0; j < TNO2; j++)
            {
              sum = 0.0;
              for (pSCF_iter = 1; pSCF_iter <= NumMix; pSCF_iter++)
              {
                sum += alden[pSCF_iter] * DM[pSCF_iter][spin][Mc_AN][h_AN][i][j];
              }

              DM[0][spin][Mc_AN][h_AN][i][j] = sum + (coef_OptRDM * OptRDM[spin][Mc_AN][h_AN][i][j]);
            }

          }

          if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
          {
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                sum = 0.0;
                for (pSCF_iter = 1; pSCF_iter <= NumMix; pSCF_iter++)
                {
                  sum += alden[pSCF_iter] * iDM[pSCF_iter][spin][Mc_AN][h_AN][i][j];
                }

                iDM[0][spin][Mc_AN][h_AN][i][j] = sum + (coef_OptRDM * iOptRDM[spin][Mc_AN][h_AN][i][j]);
              }

            }

          }

        }

      }

    }

    for (pSCF_iter = NumSlide; 0 < pSCF_iter; pSCF_iter--)
    {
      for (spin = 0; spin <= SpinP_num; spin++)
      {
        for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
        {
          Gc_AN = M2G[Mc_AN];
          wan1 = WhatSpecies[Gc_AN];
          TNO1 = Spe_Total_CNO[wan1];
          for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
          {
            Gh_AN = natn[Gc_AN][h_AN];
            wan2 = WhatSpecies[Gh_AN];
            TNO2 = Spe_Total_CNO[wan2];
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                DM[pSCF_iter][spin][Mc_AN][h_AN][i][j] = DM[pSCF_iter - 1][spin][Mc_AN][h_AN][i][j];
              }

            }

            if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
            {
              for (i = 0; i < TNO1; i++)
              {
                for (j = 0; j < TNO2; j++)
                {
                  iDM[pSCF_iter][spin][Mc_AN][h_AN][i][j] = iDM[pSCF_iter - 1][spin][Mc_AN][h_AN][i][j];
                }

              }

            }

          }

        }

      }

    }

    for (pSCF_iter = NumSlide; 1 < pSCF_iter; pSCF_iter--)
    {
      for (spin = 0; spin <= SpinP_num; spin++)
      {
        for (Mc_AN = 1; Mc_AN <= Matomnum; Mc_AN++)
        {
          Gc_AN = M2G[Mc_AN];
          wan1 = WhatSpecies[Gc_AN];
          TNO1 = Spe_Total_CNO[wan1];
          for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
          {
            Gh_AN = natn[Gc_AN][h_AN];
            wan2 = WhatSpecies[Gh_AN];
            TNO2 = Spe_Total_CNO[wan2];
            for (i = 0; i < TNO1; i++)
            {
              for (j = 0; j < TNO2; j++)
              {
                ResidualDM[pSCF_iter][spin][Mc_AN][h_AN][i][j] = ResidualDM[pSCF_iter - 1][spin][Mc_AN][h_AN][i][j];
              }

            }

            if (((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1))) && (spin < 2))
            {
              for (i = 0; i < TNO1; i++)
              {
                for (j = 0; j < TNO2; j++)
                {
                  iResidualDM[pSCF_iter][spin][Mc_AN][h_AN][i][j] = iResidualDM[pSCF_iter - 1][spin][Mc_AN][h_AN][i][j];
                }

              }

            }

          }

        }

      }

    }

  }


  free(alden);
  for (i = 0; i < List_YOUSO[16]; i++)
  {
    free(A[i]);
  }

  free(A);
  for (i = 0; i < List_YOUSO[16]; i++)
  {
    free(IA[i]);
  }

  free(IA);
  for (k = 0; k <= SpinP_num; k++)
  {
    FNAN[0] = 0;
    for (Mc_AN = 0; Mc_AN <= Matomnum; Mc_AN++)
    {
      if (Mc_AN == 0)
      {
        Gc_AN = 0;
        tno0 = 1;
      }
      else
      {
        Gc_AN = M2G[Mc_AN];
        Cwan = WhatSpecies[Gc_AN];
        tno0 = Spe_Total_NO[Cwan];
      }

      for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
      {
        if (Mc_AN == 0)
        {
          tno1 = 1;
        }
        else
        {
          Gh_AN = natn[Gc_AN][h_AN];
          Hwan = WhatSpecies[Gh_AN];
          tno1 = Spe_Total_NO[Hwan];
        }

        for (i = 0; i < tno0; i++)
        {
          free(OptRDM[k][Mc_AN][h_AN][i]);
        }

        free(OptRDM[k][Mc_AN][h_AN]);
      }

      free(OptRDM[k][Mc_AN]);
    }

    free(OptRDM[k]);
  }

  free(OptRDM);
  if ((SpinP_switch == 3) && (((((SO_switch == 1) || (Hub_U_switch == 1)) || (1 <= Constraint_NCS_switch)) || (Zeeman_NCS_switch == 1)) || (Zeeman_NCO_switch == 1)))
  {
    for (k = 0; k < 2; k++)
    {
      FNAN[0] = 0;
      for (Mc_AN = 0; Mc_AN <= Matomnum; Mc_AN++)
      {
        if (Mc_AN == 0)
        {
          Gc_AN = 0;
          tno0 = 1;
        }
        else
        {
          Gc_AN = M2G[Mc_AN];
          Cwan = WhatSpecies[Gc_AN];
          tno0 = Spe_Total_NO[Cwan];
        }

        for (h_AN = 0; h_AN <= FNAN[Gc_AN]; h_AN++)
        {
          if (Mc_AN == 0)
          {
            tno1 = 1;
          }
          else
          {
            Gh_AN = natn[Gc_AN][h_AN];
            Hwan = WhatSpecies[Gh_AN];
            tno1 = Spe_Total_NO[Hwan];
          }

          for (i = 0; i < tno0; i++)
          {
            free(iOptRDM[k][Mc_AN][h_AN][i]);
          }

          free(iOptRDM[k][Mc_AN][h_AN]);
        }

        free(iOptRDM[k][Mc_AN]);
      }

      free(iOptRDM[k]);
    }

    free(iOptRDM);
  }


  long long total = 0.;
  long long i;
  #pragma omp parallel reduction(+:total)
  {
    int thread_num = omp_get_num_threads();
    int thread_id = omp_get_thread_num();
    long chunk = (long) (n / thread_num);
    for (i = thread_id * chunk; i < ((thread_id + 1) * chunk); i += 1)
    {
      total += a[i];
    }

  }
  return total;
}

