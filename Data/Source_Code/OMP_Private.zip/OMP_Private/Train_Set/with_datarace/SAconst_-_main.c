struct point
{
  int i;
  int j;
  int k;
  int n = 10;
  init_array();
  for (i = 1; i < n; i++)
  {
    #pragma omp parallel for private(k)
    for (j = 0; j < i; j++)
    {
      for (k = 0; k < i; k++)
      {
        B[i][j] += (alpha * A[i][k]) * B[j][k];
      }

    }

    #pragma omp parallel for private(k)
    for (j = i; j < (i + 1); j++)
    {
      for (k = 0; k < i; k++)
      {
        B[i][j] += (alpha * A[i][k]) * B[j][k];
      }

    }

    #pragma omp parallel for private(k) check
    for (j = i + 1; j < n; j++)
    {
      for (k = 0; k < i; k++)
      {
        B[i][j] += (alpha * A[i][k]) * B[j][k];
      }

    }

  }

  double total = 0;
  for (int x = 0; x < n; ++x)
  {
    for (int y = 0; y < n; ++y)
    {
      total += B[x][y];
    }

  }

  printf("Total: %f\n", total);
  return 0;

  int x;
  int y;
};
int main(int argc, char *argv[])
{
  struct point p[10000];
  int n;
  int m;
  int initTour[10000];
  int tour[10000];
  int prec[10000];
  int i;
  int j;
  int times = 10;
  int count = 0;
  double initialT = 100.0;
  double finalT = 0.1;
  double coolingRate = 0.995;
  double min = 0;
  if (argc != 2)
  {
    fprintf(stderr, "Usage: %s <tsp_filename>\n", argv[0]);
    exit(1);
  }

  read_tsp_data(argv[1], p, &n, prec, &m);
  nn(p, n, initTour, m, prec);
  srand((unsigned) time(0));
  printf("This program use %d Threads\n", omp_get_max_threads());
  printf("init tour length : %.3lf\n\n", tour_length(p, n, initTour));
  #pragma omp parallel for
  for (i = 0; i < (times * omp_get_max_threads()); i++)
  {
    for (j = 0; j < n; j++)
      tour[j] = initTour[j];

    SimulatedAnnealing(p, n, tour, m, prec, initialT, finalT, coolingRate);
    count++;
    if ((!min) || (tour_length(p, n, tour) < min))
    {
      write_tour_data("res_sar.dat", n, tour);
      min = tour_length(p, n, tour);
      putchar('*');
      if (count < 10)
        putchar('0');

      printf("%d : %.3lf *\n", count, tour_length(p, n, tour));
    }
    else
    {
      if (count < 10)
        putchar('0');

      printf("%d : %.3lf\n", count, tour_length(p, n, tour));
    }

  }

  printf("Result tour length : %.3lf\n", min);
  exit(0);
}

