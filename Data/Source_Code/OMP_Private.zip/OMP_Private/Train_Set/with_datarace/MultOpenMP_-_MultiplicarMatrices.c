void MultiplicarMatrices(int fila1, int fila2, int columna2, float **matriz1, float **matriz2)
{
  FILE *resultado;
  int i;
  int j;
  int k;
  float **matrizr;
  float resultadop = 0;
  float a;
  resultado = fopen("resultado", "w");
  matrizr = malloc(fila1 * (sizeof(float *)));
  for (int i = 0; i < fila1; i++)
  {
    matrizr[i] = malloc(columna2 * (sizeof(float)));
  }

  fprintf(resultado, "%d \n", fila1);
  fprintf(resultado, "%d \n", columna2);
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (k = 0; k < fila1; k++)
    {
      for (i = 0; i < columna2; i++)
      {
        resultadop = 0;
        for (j = 0; j < fila2; j++)
        {
          resultadop = resultadop + (matriz1[k][j] * matriz2[j][i]);
        }

        matrizr[k][i] = resultadop;
      }

    }

  }
  for (i = 0; i < fila1; i++)
  {
    for (j = 0; j < columna2; j++)
    {
      if (j == (columna2 - 1))
      {
        fprintf(resultado, "%.1f", matrizr[i][j]);
      }
      else
      {
        fprintf(resultado, "%.1f,", matrizr[i][j]);
      }

    }

    fprintf(resultado, "\n");
  }

  fclose(resultado);
  free(matrizr);
}

