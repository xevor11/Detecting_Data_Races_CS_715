int useless;
{
  double cx;
  double cy;
  double zx;
  double zy;
  double new_zx;
  unsigned char n;
  int nx;
  int ny;
  int iter;
  int i;
  double time;
  timer_start();
  cy = yMin;
  iter = ((int) (yMax - yMin)) / dxy;
  #pragma omp parallel for ordered private(cx, zx, zy, n, new_zx) firstprivate(cy)
  for (i = 0; i < iter; i++)
  {
    for (cx = xMin; cx < xMax; cx += dxy)
    {
      zx = 0.0;
      zy = 0.0;
      n = 0;
      while ((((zx * zx) + (zy * zy)) < 4.0) && (n != 255))
      {
        new_zx = ((zx * zx) - (zy * zy)) + cx;
        zy = ((2.0 * zx) * zy) + cy;
        zx = new_zx;
        n++;
      }

      fprintf(stdout, "%d\n", n);
    }

    cy += dxy;
  }

  nx = 0;
  ny = 0;
  for (cx = xMin; cx < xMax; cx += dxy)
  {
    nx++;
  }

  for (cy = yMin; cy < yMax; cy += dxy)
  {
    ny++;
  }

  fflush(stdout);
  fprintf(stderr, "\n");
  time = timer_end();
  fprintf(stderr, "The program took %g seconds.\n", time);
  fprintf(stderr, "To process the image: convert -depth 8 -size %dx%d gray:output out.jpg\n", nx, ny);
  return 0;

  int length;
  int *array;
} int_array;
{
  int_array *arreglo;
  string cadena;
  int potencia;
  int tamano;
} witness;
string cadena;
witness *w;
{
  int x;
  int y;
} par;
{
  string *array;
  int length;
} string_array;
int brute_force_witness(int i)
{
  int tam_temp = (w->arreglo->length - i) + 1;
  int_array *b = init_int_array(tam_temp);
  omp_set_num_threads(tam_temp);
  #pragma omp parallel
  {
    int id = omp_get_thread_num() + 1;
    if (w->cadena[id] != w->cadena[(id + i) - 1])
      b->array[id] = 1;
    else
      b->array[id] = 0;

  }
  return get_min(b);
}

