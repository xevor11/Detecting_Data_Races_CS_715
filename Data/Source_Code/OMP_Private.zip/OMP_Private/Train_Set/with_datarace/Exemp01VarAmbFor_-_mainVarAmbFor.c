int mainVarAmbFor()
{
  int i;
  int n;
  int var;
  float a[10];
  float b[10];
  float c[10];
  float aux;
  float tmp;
  for (i = 0; i < 10; i++)
  {
    aux = i + 1.0f;
    a[i] = (2.0f * aux) * aux;
    b[i] = aux;
    printf("(%d,", a[i]);
    printf("%d) ", b[i]);
  }

  printf("\n");
  n = 10;
  var = 1;
  #pragma omp parallel for shared(a, b, c) schedule(static, var)
  for (i = 0; i < n; i++)
    c[i] = a[i] / b[i];

  for (i = 0; i < 10; i++)
  {
    printf("%d ", c[i]);
  }

  printf("\n");
  return 0;
}

