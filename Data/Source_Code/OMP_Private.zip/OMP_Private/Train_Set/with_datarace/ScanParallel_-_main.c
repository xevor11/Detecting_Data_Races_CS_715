int main(int argc, char **argv)
{
  int *t;
  int toread;
  long long int n;
  long long int i;
  long long int j;
  long long int size;
  n = atof(argv[1]);
  int ar[2][n];
  int a[n];
  randomArray(a, n);
  for (i = 0; i < n; i++)
    ar[0][i] = a[i];

  toread = 1;
  ar[1][0] = ar[0][0];
  size = 0;
  while (i)
  {
    size++;
    i >>= 1;
  }

  double start = omp_get_wtime();
  for (j = 0; j < size; j++)
  {
    toread = !toread;
    if (toread)
      t = ar[0];
    else
      t = ar[1];

    #pragma omp parallel for default(none) shared(n, j, t, ar, toread)
    for (i = 1; i < n; i++)
    {
      if ((i - (1 << j)) >= 0)
        t[i] = ar[toread][i] + ar[toread][i - (1 << j)];
      else
        t[i] = ar[toread][i];

    }

  }

  double stop = omp_get_wtime();
  printf("%lf\n", stop - start);
  toread = !toread;
  return 0;
}

