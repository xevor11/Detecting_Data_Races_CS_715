int **curr;
int **next;
int **prefix;
void prefix_sum(int row, int col)
{
  int x;
  int y;
  #pragma omp parallel for
  for (x = 2; x < row; x++)
  {
    for (y = 2; y < col; y++)
    {
      prefix[x][y] = ((curr[x][y] - prefix[x - 1][y - 1]) + prefix[x - 1][y]) + prefix[x][y - 1];
    }

  }

}

