extern void *polybench_alloc_data(unsigned long long int n, int elt_size);
static void init_array(int n, double X[500 + 0][500 + 0], double A[500 + 0][500 + 0], double B[500 + 0][500 + 0])
{
  {
    int c1;
    int c2;
    if (n >= 1)
    {
      #pragma omp parallel for
      for (c1 = 0; c1 <= (n + (-1)); c1++)
      {
        for (c2 = 0; c2 <= (n + (-1)); c2++)
        {
          X[c1][c2] = ((((double) c1) * (c2 + 1)) + 1) / n;
          A[c1][c2] = ((((double) c1) * (c2 + 2)) + 2) / n;
          B[c1][c2] = ((((double) c1) * (c2 + 3)) + 3) / n;
        }

      }

    }

  }
}

