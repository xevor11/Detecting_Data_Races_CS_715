int main(int argc, char *argv[])
{
  int nn;
  int tid;
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    printf("helilo world ! from openMp thread %d\n", tid);
  }
}

