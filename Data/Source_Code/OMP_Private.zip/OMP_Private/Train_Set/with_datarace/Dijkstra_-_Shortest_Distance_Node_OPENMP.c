struct timeval initial;
struct timeval final;
void Initialize_Array(int *Input_Array, int Value);
void Initialize_Dist_Array(float *Input_Array, float Value);
void Initialize_Graph(float *Graph, float Value);
void Set_Graph_Dist_Random(float *Graph, int *Edges_Per_Vertex);
int32_t Shortest_Distance_Node(float *Node_Shortest_Dist, uint32_t *Completed_Node);
void Shortest_Path_Computation_Serial(float *Graph, float *Node_Shortest_Dist, uint32_t *Parent_Node, uint32_t *Completed_Node, uint32_t Source);
double timetaken();
int32_t Shortest_Distance_Node_OPENMP(float *Node_Shortest_Dist, uint32_t *Completed_Node);
void Shortest_Path_Computation_Parallel(float *Graph, float *Node_Shortest_Dist, uint32_t *Parent_Node, uint32_t *Completed_Node, uint32_t Source);
int32_t Shortest_Distance_Node_OPENMP(float *Node_Shortest_Dist, uint32_t *Completed_Node)
{
  int32_t node_distance = 10000000;
  int32_t node = -1;
  int32_t smallest_dist_thread;
  int32_t closest_node_thread;
  uint32_t i;
  #pragma omp parallel shared(Node_Shortest_Dist, Completed_Node)
  {
    smallest_dist_thread = node_distance;
    closest_node_thread = node;
    #pragma omp barrier
    #pragma omp for nowait
    for (i = 0; i < 1000; i++)
    {
      if ((Node_Shortest_Dist[i] < smallest_dist_thread) && (Completed_Node[i] == 0))
      {
        smallest_dist_thread = Node_Shortest_Dist[i];
        closest_node_thread = i;
      }

    }

    #pragma omp critical
    {
      if (smallest_dist_thread < node_distance)
      {
        node_distance = smallest_dist_thread;
        node = closest_node_thread;
      }

    }
  }
  return node;
}

