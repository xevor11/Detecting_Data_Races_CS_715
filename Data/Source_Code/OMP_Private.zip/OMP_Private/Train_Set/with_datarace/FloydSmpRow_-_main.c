static int n;
static double **d;
int main(int argc, char **argv)
{
  int i;
  int r;
  int c;
  long long int t1;
  long long int t2;
  long long int t3;
  long long int t4;
  char *infile;
  char *outfile;
  FILE *in;
  FILE *out;
  t1 = currentTimeMillis();
  if (argc != 3)
    usage();

  infile = argv[1];
  outfile = argv[2];
  in = fopen(infile, "r");
  if (in == 0)
  {
    fprintf(stderr, "Error opening input file \"%s\"\n", infile);
    exit(1);
  }

  n = readInt(in);
  d = (double **) malloc(n * (sizeof(double *)));
  for (r = 0; r < n; ++r)
  {
    double *d_r = (double *) malloc(n * (sizeof(double)));
    d[r] = d_r;
    for (c = 0; c < n; ++c)
    {
      d_r[c] = readDouble(in);
    }

  }

  fclose(in);
  t2 = currentTimeMillis();
  #pragma omp parallel
  {
    for (i = 0; i < n; ++i)
    {
      double *d_i;
      if ((i < 0) || (i >= n))
        outOfBounds();

      d_i = d[i];
      #pragma omp for
      for (r = 0; r < n; ++r)
      {
        double *d_r;
        if ((r < 0) || (r >= n))
          outOfBounds();

        d_r = d[r];
        for (c = 0; c < n; ++c)
        {
          double d_r_c;
          double d_r_i;
          double d_i_c;
          if ((c < 0) || (c >= n))
            outOfBounds();

          d_r_c = d_r[c];
          if ((i < 0) || (i >= n))
            outOfBounds();

          d_r_i = d_r[i];
          if ((i < 0) || (i >= n))
            outOfBounds();

          d_i_c = d_i[c];
          if ((c < 0) || (c >= n))
            outOfBounds();

          d_r[c] = min(d_r_c, d_r_i + d_i_c);
        }

      }

    }

  }
  t3 = currentTimeMillis();
  out = fopen(outfile, "w");
  if (out == 0)
  {
    fprintf(stderr, "Error opening output file \"%s\"\n", outfile);
    exit(1);
  }

  fprintf(out, "%d\n", n);
  for (r = 0; r < n; ++r)
  {
    double *d_r = d[r];
    for (c = 0; c < n; ++c)
    {
      fprintf(out, "%e ", d_r[c]);
    }

    fprintf(out, "\n");
  }

  fclose(out);
  t4 = currentTimeMillis();
  printf("%lld msec pre\n", t2 - t1);
  printf("%lld msec calc\n", t3 - t2);
  printf("%lld msec post\n", t4 - t3);
  printf("%lld msec total\n", t4 - t1);
}

