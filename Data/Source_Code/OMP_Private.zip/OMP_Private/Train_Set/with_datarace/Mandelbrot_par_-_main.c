void printerOfMatrix(int *, int);
int main(int argc, char *argv[])
{
  int iX;
  int iY;
  int iXmax = 800;
  int iYmax = 800;
  double Cx;
  double Cy;
  const double CxMin = -2.5;
  const double CxMax = 1.5;
  const double CyMin = -2.0;
  const double CyMax = 2.0;
  double PixelWidth = (CxMax - CxMin) / iXmax;
  double PixelHeight = (CyMax - CyMin) / iYmax;
  const int MaxColorComponentValue = 255;
  char *filename = "new1.ppm";
  char *comment = "# ";
  static unsigned char color[3];
  double Zx;
  double Zy;
  double Zx2;
  double Zy2;
  int Iteration;
  const int IterationMax = 200;
  const double EscapeRadius = 2;
  double ER2 = EscapeRadius * EscapeRadius;
  if (argc == 2)
  {
    iXmax = atoi(argv[1]);
    iYmax = atoi(argv[1]);
  }

  CMP134_DECLARE_TIMER;
  CMP134_START_TIMER;
  #pragma omp parallel for schedule(dynamic)
  for (iY = 0; iY < iYmax; iY++)
  {
    Cy = CyMin + (iY * PixelHeight);
    if (fabs(Cy) < (PixelHeight / 2))
      Cy = 0.0;

    for (iX = 0; iX < iXmax; iX++)
    {
      Cx = CxMin + (iX * PixelWidth);
      Zx = 0.0;
      Zy = 0.0;
      Zx2 = Zx * Zx;
      Zy2 = Zy * Zy;
      for (Iteration = 0; (Iteration < IterationMax) && ((Zx2 + Zy2) < ER2); Iteration++)
      {
        Zy = ((2 * Zx) * Zy) + Cy;
        Zx = (Zx2 - Zy2) + Cx;
        Zx2 = Zx * Zx;
        Zy2 = Zy * Zy;
      }

      ;
      if (Iteration == IterationMax)
      {
        color[0] = 0;
        color[1] = 0;
        color[2] = 0;
      }
      else
      {
        color[0] = 255;
        color[1] = 255;
        color[2] = 255;
      }

      ;
    }

  }

  CMP134_END_TIMER;
  CMP134_REPORT_TIMER;
  return 0;

  int t;
  int i;
  for (t = 0; t < 1000; t++)
  {
    #pragma omp parallel for private(i) schedule(auto)
    for (i = 1; i < (750000 - 1); i = i + 2)
    {
      a[i] = 0.25 * ((a[i - 1] + (2 * a[i])) + a[i + 1]);
    }

    #pragma omp parallel for private(i) schedule(auto)
    for (i = 1; i < (750000 - 2); i = i + 2)
    {
      a[i + 1] = 0.25 * ((a[i] + (2 * a[i + 1])) + a[i + 2]);
    }

  }

}

