void myarray_add(struct myarray *A, struct myarray *B)
{
  int i;
  int j;
  assert(A->n_rows == B->n_rows);
  assert(A->n_cols == B->n_cols);
  #pragma omp parallel for schedule(static) collapse(2) shared(A, B) default(none)
  for (i = 0; i < A->n_rows; i++)
    for (j = 0; j < A->n_cols; j++)
  {
    *myarray_at(A, i, j) += *myarray_at(B, i, j);
  }


}

