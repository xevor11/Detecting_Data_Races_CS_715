int main()
{
  double passo;
  double soma;
  double x;
  int i;
  passo = (2.0 - 1) / 100000000;
  omp_set_num_threads(1);
  soma = 0;
  #pragma omp parallel shared(passo) private(x, i) reduction(+:soma)
  {
    #pragma omp for
    for (i = 0; i < 100000000; i++)
    {
      x = 1 + (i * passo);
      soma += 0.5 * ((1 / x) + (1 / (x + passo)));
    }

  }
  printf("ln %f = %20.15f\n", 2.0, passo * soma);
  return 0;

  int i;
  int j;
  i = 1;
  j = 2;
  #pragma omp parallel firstprivate(j)
  {
    i = 3;
    j = j + 2;
  }
  printf("%d %d\n", i, j);
  return 0;
}

