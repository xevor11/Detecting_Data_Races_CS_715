void PL_APSP_X(int *mat, int N, int num_thread)
{
  int per = N / num_thread;
  int tid;
  int i0;
  int i1;
  int i2;
  int sum;
  int i;
  int j;
  int k;
  #pragma omp parallel shared(per)
  {
    tid = omp_get_thread_num();
    for (k = 0; k < N; k++)
    {
      for (i = per * tid; i < (per * (tid + 1)); ++i)
      {
        for (j = 0; j < N; ++j)
        {
          i0 = (i * N) + j;
          i1 = (i * N) + k;
          i2 = (k * N) + j;
          sum = mat[i1] + mat[i2];
          if (sum < mat[i0])
            mat[i0] = sum;

        }

      }

      #pragma omp barrier
    }

  }
}

