int main(int argc, char *argv[])
{
  int numThreads;
  int tid;
  int a;
  int b;
  #pragma omp parallel
  {
    a = 1;
    b = 3;
    a = 6;
    b = 8;
  }
  tid = omp_get_thread_num();
  tid = omp_get_thread_num();
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread number %d\n", tid);
    if (tid == 0)
    {
      numThreads = omp_get_num_threads();
      printf("Number of threads is %d\n", numThreads);
    }

  }
  return 0;
}

