FILE *ofp;
int main(int argc, char **argv)
{
  int N;
  int t;
  int k;
  int v;
  double before;
  double after;
  before = omp_get_wtime();
  ofp = fopen("Output_1207543476", "a+");
  if (0 == ofp)
  {
    fprintf(stderr, "Opening output file failed.\n");
    printf("Opening output file failed.\n");
    exit(0);
  }

  scanf("%d %d %d %d", &N, &t, &k, &v);
  printf("=======================================\n");
  printf("Parallel ::: N=%d; t=%d, k=%d, v=%d\n", N, t, k, v);
  printf("=======================================\n");
  char *inputArray = (char *) calloc(N * k, sizeof(char));
  int pos = 0;
  char c = '0';
  while (EOF != c)
  {
    c = getchar();
    if (' ' != c)
    {
      if ('\n' != c)
      {
        inputArray[pos++] = c;
      }

    }

  }

  int combinationOfSymbols = (int) pow(v, t);
  char *elements = (char *) calloc(v, sizeof(char));
  char *Symbols = (char *) calloc(combinationOfSymbols * t, sizeof(char));
  int iLoopIndex = 0;
  int jLoopIndex = 0;
  int kLoopIndex = 0;
  int lLoopIndex = 0;
  if (2 == v)
  {
    int iCount = 0;
    elements[0] = '0';
    elements[1] = '1';
    if (2 == t)
    {
      for (iLoopIndex = 0; iLoopIndex < v; iLoopIndex++)
      {
        for (jLoopIndex = 0; jLoopIndex < v; jLoopIndex++)
        {
          for (kLoopIndex = 0; kLoopIndex < t; kLoopIndex++)
          {
            if (0 == (kLoopIndex % t))
            {
              Symbols[iCount] = elements[iLoopIndex];
            }
            else
            {
              Symbols[iCount] = elements[jLoopIndex];
            }

            iCount++;
          }

        }

      }

    }
    else
      if (3 == t)
    {
      elements[0] = '0';
      elements[1] = '1';
      elements[2] = '2';
      for (iLoopIndex = 0; iLoopIndex < v; iLoopIndex++)
      {
        for (jLoopIndex = 0; jLoopIndex < v; jLoopIndex++)
        {
          for (kLoopIndex = 0; kLoopIndex < v; kLoopIndex++)
          {
            for (lLoopIndex = 0; lLoopIndex < t; lLoopIndex++)
            {
              if (0 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[iLoopIndex];
              }
              else
                if (1 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[jLoopIndex];
              }
              else
                if (2 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[kLoopIndex];
              }



              iCount++;
            }

          }

        }

      }

    }


  }
  else
    if (3 == v)
  {
    int iCount = 0;
    elements[0] = '0';
    elements[1] = '1';
    elements[2] = '2';
    if (2 == t)
    {
      for (iLoopIndex = 0; iLoopIndex < v; iLoopIndex++)
      {
        for (jLoopIndex = 0; jLoopIndex < v; jLoopIndex++)
        {
          for (kLoopIndex = 0; kLoopIndex < t; kLoopIndex++)
          {
            if (0 == (kLoopIndex % t))
            {
              Symbols[iCount] = elements[iLoopIndex];
            }
            else
            {
              Symbols[iCount] = elements[jLoopIndex];
            }

            iCount++;
          }

        }

      }

    }
    else
      if (3 == t)
    {
      for (iLoopIndex = 0; iLoopIndex < v; iLoopIndex++)
      {
        for (jLoopIndex = 0; jLoopIndex < v; jLoopIndex++)
        {
          for (kLoopIndex = 0; kLoopIndex < v; kLoopIndex++)
          {
            for (lLoopIndex = 0; lLoopIndex < t; lLoopIndex++)
            {
              if (0 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[iLoopIndex];
              }
              else
                if (1 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[jLoopIndex];
              }
              else
                if (2 == (lLoopIndex % t))
              {
                Symbols[iCount] = elements[kLoopIndex];
              }



              iCount++;
            }

          }

        }

      }

    }


  }


  int iCount = 0;
  int i = 0;
  int noOfSubArrays = combination(k, t);
  int *SubArrays = (int *) calloc(noOfSubArrays * t, sizeof(int));
  if (2 == t)
  {
    int iCount = 0;
    for (iLoopIndex = 1; iLoopIndex <= k; iLoopIndex++)
    {
      for (jLoopIndex = iLoopIndex + 1; jLoopIndex <= k; jLoopIndex++)
      {
        for (kLoopIndex = 0; kLoopIndex < t; kLoopIndex++)
        {
          if (0 == (iCount % t))
          {
            SubArrays[iCount] = iLoopIndex;
          }
          else
          {
            SubArrays[iCount] = jLoopIndex;
          }

          iCount++;
        }

      }

    }

  }
  else
    if (3 == t)
  {
    int iCount = 0;
    for (iLoopIndex = 1; iLoopIndex <= k; iLoopIndex++)
    {
      for (jLoopIndex = iLoopIndex + 1; jLoopIndex <= k; jLoopIndex++)
      {
        for (kLoopIndex = jLoopIndex + 1; kLoopIndex <= k; kLoopIndex++)
        {
          for (lLoopIndex = 0; lLoopIndex < t; lLoopIndex++)
          {
            if (0 == (iCount % t))
            {
              SubArrays[iCount] = iLoopIndex;
            }
            else
              if (1 == (iCount % t))
            {
              SubArrays[iCount] = jLoopIndex;
            }
            else
              if (2 == (iCount % t))
            {
              SubArrays[iCount] = kLoopIndex;
            }



            iCount++;
          }

        }

      }

    }

  }


  iCount = 0;
  int *intermediateArray = (int *) calloc(noOfSubArrays * combinationOfSymbols, sizeof(int));
  #pragma omp parallel num_threads(16) shared(noOfSubArrays, SubArrays, t, N, inputArray, combinationOfSymbols, Symbols, intermediateArray)
  {
    #pragma omp for schedule(dynamic, 50)
    for (iLoopIndex = 0; iLoopIndex < noOfSubArrays; iLoopIndex++)
    {
      int firstColumnIndex = SubArrays[t * iLoopIndex];
      int secondColumnIndex = SubArrays[(t * iLoopIndex) + 1];
      int thirdColumnIndex = SubArrays[(t * iLoopIndex) + 2];
      char *tempInputArray = (char *) calloc(N * t, sizeof(char));
      for (jLoopIndex = 0; jLoopIndex < N; jLoopIndex++)
      {
        if (2 == t)
        {
          tempInputArray[t * jLoopIndex] = inputArray[((k * jLoopIndex) + firstColumnIndex) - 1];
          tempInputArray[(t * jLoopIndex) + 1] = inputArray[((k * jLoopIndex) + secondColumnIndex) - 1];
          for (kLoopIndex = 0; kLoopIndex < combinationOfSymbols; kLoopIndex++)
          {
            if ((tempInputArray[t * jLoopIndex] == Symbols[t * kLoopIndex]) && (tempInputArray[(t * jLoopIndex) + 1] == Symbols[(t * kLoopIndex) + 1]))
            {
              __sync_fetch_and_add(&intermediateArray[(combinationOfSymbols * iLoopIndex) + kLoopIndex], 1);
            }

          }

        }
        else
          if (3 == t)
        {
          tempInputArray[t * jLoopIndex] = inputArray[((k * jLoopIndex) + firstColumnIndex) - 1];
          tempInputArray[(t * jLoopIndex) + 1] = inputArray[((k * jLoopIndex) + secondColumnIndex) - 1];
          tempInputArray[(t * jLoopIndex) + 2] = inputArray[((k * jLoopIndex) + thirdColumnIndex) - 1];
          for (kLoopIndex = 0; kLoopIndex < combinationOfSymbols; kLoopIndex++)
          {
            if (((tempInputArray[t * jLoopIndex] == Symbols[t * kLoopIndex]) && (tempInputArray[(t * jLoopIndex) + 1] == Symbols[(t * kLoopIndex) + 1])) && (tempInputArray[(t * jLoopIndex) + 2] == Symbols[(t * kLoopIndex) + 2]))
            {
              __sync_fetch_and_add(&intermediateArray[(combinationOfSymbols * iLoopIndex) + kLoopIndex], 1);
            }

          }

        }


      }

      free(tempInputArray);
    }

  }
  char isCoveringArray = '1';
  for (iLoopIndex = 0; iLoopIndex < noOfSubArrays; iLoopIndex++)
  {
    for (jLoopIndex = 0; jLoopIndex < combinationOfSymbols; jLoopIndex++)
    {
      if (0 == intermediateArray[(combinationOfSymbols * iLoopIndex) + jLoopIndex])
      {
        isCoveringArray = '0';
      }

    }

  }

  if ('0' == isCoveringArray)
  {
    printf("Parallel::: No, It is Not a Covering Array\n");
  }
  else
  {
    printf("Parallel::: Yes, It is a Covering Array\n");
  }

  if ('1' == isCoveringArray)
  {
    int firstColumnIndex = 0;
    int secondColumnIndex = 0;
    int thirdColumnIndex = 0;
    char *finalArray = (char *) calloc(N * k, sizeof(char));
    memset(finalArray, '0', (N * k) * (sizeof(char)));
    for (iLoopIndex = 0; iLoopIndex < noOfSubArrays; iLoopIndex++)
    {
      for (jLoopIndex = 0; jLoopIndex < combinationOfSymbols; jLoopIndex++)
      {
        int positionOfOnes = 0;
        int p1_row = 0;
        int p1_column = 0;
        if (1 == intermediateArray[(combinationOfSymbols * iLoopIndex) + jLoopIndex])
        {
          if (2 == t)
          {
            positionOfOnes = (combinationOfSymbols * iLoopIndex) + jLoopIndex;
            p1_row = iLoopIndex;
            p1_column = jLoopIndex;
            firstColumnIndex = 0;
            secondColumnIndex = 0;
            char *tempInputArray = (char *) calloc(N * t, sizeof(char));
            int jLoopIndex_tempInputArray = 0;
            int tempIndex = 0;
            for (jLoopIndex_tempInputArray = 0; jLoopIndex_tempInputArray < N; jLoopIndex_tempInputArray++)
            {
              firstColumnIndex = SubArrays[t * iLoopIndex];
              secondColumnIndex = SubArrays[(t * iLoopIndex) + 1];
              tempInputArray[t * jLoopIndex_tempInputArray] = inputArray[((k * jLoopIndex_tempInputArray) + firstColumnIndex) - 1];
              tempInputArray[(t * jLoopIndex_tempInputArray) + 1] = inputArray[((k * jLoopIndex_tempInputArray) + secondColumnIndex) - 1];
            }

            for (tempIndex = 0; tempIndex < N; tempIndex++)
            {
              if ((tempInputArray[t * tempIndex] == Symbols[t * jLoopIndex]) && (tempInputArray[(t * tempIndex) + 1] == Symbols[(t * jLoopIndex) + 1]))
              {
                finalArray[((k * tempIndex) + firstColumnIndex) - 1]++;
                finalArray[((k * tempIndex) + secondColumnIndex) - 1]++;
              }
              else
              {
              }

            }

            free(tempInputArray);
          }
          else
            if (3 == t)
          {
            positionOfOnes = (combinationOfSymbols * iLoopIndex) + jLoopIndex;
            p1_row = iLoopIndex;
            p1_column = jLoopIndex;
            firstColumnIndex = 0;
            secondColumnIndex = 0;
            thirdColumnIndex = 0;
            char *tempInputArray = (char *) calloc(N * t, sizeof(char));
            int jLoopIndex_tempInputArray = 0;
            int tempIndex = 0;
            for (jLoopIndex_tempInputArray = 0; jLoopIndex_tempInputArray < N; jLoopIndex_tempInputArray++)
            {
              firstColumnIndex = SubArrays[t * iLoopIndex];
              secondColumnIndex = SubArrays[(t * iLoopIndex) + 1];
              thirdColumnIndex = SubArrays[(t * iLoopIndex) + 2];
              tempInputArray[t * jLoopIndex_tempInputArray] = inputArray[((k * jLoopIndex_tempInputArray) + firstColumnIndex) - 1];
              tempInputArray[(t * jLoopIndex_tempInputArray) + 1] = inputArray[((k * jLoopIndex_tempInputArray) + secondColumnIndex) - 1];
              tempInputArray[(t * jLoopIndex_tempInputArray) + 2] = inputArray[((k * jLoopIndex_tempInputArray) + thirdColumnIndex) - 1];
            }

            for (tempIndex = 0; tempIndex < N; tempIndex++)
            {
              if (((tempInputArray[t * tempIndex] == Symbols[t * jLoopIndex]) && (tempInputArray[(t * tempIndex) + 1] == Symbols[(t * jLoopIndex) + 1])) && (tempInputArray[(t * tempIndex) + 2] == Symbols[(t * jLoopIndex) + 2]))
              {
                finalArray[((k * tempIndex) + firstColumnIndex) - 1]++;
                finalArray[((k * tempIndex) + secondColumnIndex) - 1]++;
                finalArray[((k * tempIndex) + thirdColumnIndex) - 1]++;
              }
              else
              {
              }

            }

            free(tempInputArray);
          }


        }

      }

    }

    for (iLoopIndex = 0; iLoopIndex < N; iLoopIndex++)
    {
      for (jLoopIndex = 0; jLoopIndex < k; jLoopIndex++)
      {
        if ('0' == finalArray[(k * iLoopIndex) + jLoopIndex])
        {
          finalArray[(k * iLoopIndex) + jLoopIndex] = '*';
        }
        else
        {
          finalArray[(k * iLoopIndex) + jLoopIndex] = inputArray[(k * iLoopIndex) + jLoopIndex];
        }

      }

    }

    printf("Don't Care Matrix\n");
    printMatrix(finalArray, N, k);
    printf("Don't Care position\n");
    iCount = 0;
    for (iLoopIndex = 0; iLoopIndex < N; iLoopIndex++)
    {
      for (jLoopIndex = 0; jLoopIndex < k; jLoopIndex++)
      {
        if ('*' == finalArray[(k * iLoopIndex) + jLoopIndex])
        {
          iCount++;
          printf("(%d,%d)\t", iLoopIndex + 1, jLoopIndex + 1);
        }

      }

    }

    printf("\nTotal Number of Don't Cares :: %d\n", iCount);
    free(finalArray);
  }

  free(inputArray);
  free(elements);
  free(Symbols);
  free(SubArrays);
  free(intermediateArray);
  after = omp_get_wtime();
  printf("Parallel Time:::%8.6f secs\n", (float) (after - before));
  fprintf(ofp, "%8.6f\n", (float) (after - before));
  fclose(ofp);
  return 0;
}

