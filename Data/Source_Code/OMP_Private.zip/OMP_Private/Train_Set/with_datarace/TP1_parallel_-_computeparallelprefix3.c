void iniciar_vectores_est(double *tp_est1, double *tp_est2, double *tp_est3, int *im1, int *im2, int *im3);
void ver_estadisticas(double *tp_est1, double *tp_est2, double *tp_est3, int *im1, int *im2, int *im3, double speedup[][100], double porcentajes[][100]);
int convertir_cadena(char *pc);
void resultados_obtenidos(double par_t_paralelo, double par_t_procedural, int p_ntrh);
void datos_arreglo(int *pprefixsum);
void computeparallelprefix(int *iplist, int *_pprefixsum, unsigned long size);
void computeparallelprefix2(int *iplist, int *_pprefixsum, int *pz, int *pw);
void computeparallelprefix3(int *iplist, int *_pprefixsum, int *pz, int *pw);
void for_par(int *py, int *pw, int *iplist);
void for_impar(int *py, int *pw);
void computeparallelprefix3(int *iplist, int *_pprefixsum, int *pz, int *pw)
{
  int t;
  int ch;
  int i;
  int start_i;
  int stop_i;
  int cc_i;
  int min_moveout;
  int max_moveout;
  int network_offset;
  int station_offset;
  int cc_sum_offset;
  int *moveouts_t = 0;
  float *templates_t = 0;
  float *sum_square_templates_t = 0;
  float *weights_t = 0;
  for (t = 0; t < n_templates; t++)
  {
    network_offset = (t * n_stations) * n_components;
    station_offset = t * n_stations;
    cc_sum_offset = t * n_corr;
    min_moveout = 0;
    max_moveout = 0;
    for (ch = 0; ch < (n_stations * n_components); ch++)
    {
      if (moveouts[network_offset + ch] < min_moveout)
        min_moveout = moveouts[network_offset + ch];

      if (moveouts[network_offset + ch] > max_moveout)
        max_moveout = moveouts[network_offset + ch];

    }

    templates_t = templates + (network_offset * n_samples_template);
    moveouts_t = moveouts + network_offset;
    weights_t = weights + network_offset;
    sum_square_templates_t = sum_square_templates + network_offset;
    start_i = ((int) ceilf(abs(min_moveout) / ((float) step))) * step;
    stop_i = ((n_samples_data - n_samples_template) - max_moveout) - step;
    #pragma omp parallel for private(i, cc_i)
    for (i = start_i; i < stop_i; i += step)
    {
      cc_i = i / step;
      cc_sum[cc_sum_offset + cc_i] = network_corr(templates_t, sum_square_templates_t, moveouts_t, data + i, csum_square_data + i, weights_t, n_samples_template, n_samples_data, n_stations, n_components);
    }

  }


  int i;
  int *z = pz;
  int *y = _pprefixsum;
  int *w = pw;
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (i = 0; i < (2000000 / 2); i++)
    {
      z[i] = iplist[i * 2] + iplist[(i * 2) + 1];
    }

    #pragma omp single
    {
      y[0] = iplist[0];
      y[1] = z[0];
      y[2] = z[0] + iplist[2];
      w[0] = z[0] + z[1];
      for (i = 1; i < ((2000000 / 2) - 1); i++)
        w[i] = w[i - 1] + z[i + 1];

    }
    #pragma omp barrier
    #pragma omp sections
    {
      #pragma omp section
      {
        for_impar(y, w);
      }
      #pragma omp section
      {
        for_par(y, w, iplist);
      }
    }
  }
}

