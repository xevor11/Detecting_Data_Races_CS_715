struct pathNode
{
  int nodeNumber;
  struct pathNode *next;
};
struct path
{
  struct pathNode *head;
  int lastNode;
};
struct tour
{
  int cityCount;
  struct path *thePath;
  int totalCost;
};
struct AdjListNode
{
  int dest;
  int cost;
  struct AdjListNode *next;
};
struct AdjList
{
  struct AdjListNode *head;
};
struct Graph
{
  int V;
  struct AdjList *array;
};
{
  int capacity;
  int size;
  struct tour *elements;
} Stack;
int minCost = 32767;
int TreeSearch(struct Graph *graph, int src, int V, int *costMatrix)
{
  double x;
  x = omp_get_wtime();
  struct tour temp3;
  Stack *s = createStack(1000);
  struct tour bestTour;
  struct tour t = {0, 0, 0};
  struct pathNode *temp11 = 0;
  struct tour temp = {0, 0, 0};
  addCity(&t, src, V, costMatrix);
  push(s, t);
  t = pop(s);
  int i = 0;
  for (i = V - 1; i > 0; i--)
  {
    if (feasible(&t, i))
    {
      addCity(&t, i, V, costMatrix);
      temp3.thePath = 0;
      temp3.totalCost = t.totalCost;
      temp11 = t.thePath->head;
      while (temp11->next != 0)
      {
        addCity(&temp3, temp11->nodeNumber, V, costMatrix);
        temp11 = temp11->next;
      }

      addCity(&temp3, temp11->nodeNumber, V, costMatrix);
      temp3.cityCount = t.cityCount;
      push(s, temp3);
      removeLastCity(&t, costMatrix, V);
    }

  }

  struct pathNode *temp44 = t.thePath->head;
  struct pathNode *temp55 = temp44;
  while (temp44 != 0)
  {
    temp44 = temp44->next;
    free(temp55);
    temp55 = temp44;
  }

  free(t.thePath);
  #pragma omp parallel reduction(min:minCost)
  {
    int flag = 0;
    int count = 0;
    while (!isEmpty(s))
    {
      flag = 0;
      #pragma omp critical
      {
        if (!isEmpty(s))
        {
          flag = 1;
          t = pop(s);
        }

      }
      if (flag == 1)
      {
        if (t.cityCount == V)
        {
          int lastCost = *((costMatrix + (V * t.thePath->lastNode)) + t.thePath->head->nodeNumber);
          if ((t.totalCost + lastCost) < minCost)
          {
            minCost = t.totalCost + lastCost;
          }

          struct pathNode *temp44 = t.thePath->head;
          struct pathNode *temp55 = temp44;
          while (temp44 != 0)
          {
            temp44 = temp44->next;
            free(temp55);
            temp55 = temp44;
          }

          free(t.thePath);
        }
        else
        {
          int i = 0;
          for (i = V - 1; i > 0; i--)
          {
            if (feasible(&t, i))
            {
              addCity(&t, i, V, costMatrix);
              temp3.thePath = 0;
              temp3.totalCost = t.totalCost;
              temp11 = t.thePath->head;
              while (temp11->next != 0)
              {
                addCity(&temp3, temp11->nodeNumber, V, costMatrix);
                temp11 = temp11->next;
              }

              addCity(&temp3, temp11->nodeNumber, V, costMatrix);
              temp3.cityCount = t.cityCount;
              removeLastCity(&t, costMatrix, V);
              #pragma omp critical
              {
                push(s, temp3);
              }
            }

          }

          struct pathNode *temp44 = t.thePath->head;
          struct pathNode *temp55 = temp44;
          while (temp44 != 0)
          {
            temp44 = temp44->next;
            free(temp55);
            temp55 = temp44;
          }

          free(t.thePath);
        }

      }

    }

  }
  return minCost;

  register unsigned int i;
  register unsigned int j;
  register double r;
  #pragma omp parallel for private (i,j,r) schedule (static)
  for (i = 0; i < 512; i = i + 1)
  {
    r = 0.0;
    for (j = 0; j < 512; j = j + 1)
    {
      r += M[i][j] * b[j];
    }

    c[i] = r;
  }

  return;
}

