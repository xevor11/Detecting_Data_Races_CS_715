const float epsilon = 10;
int A_ad_num = 0;
int B_ad_num = 0;
int C_ad_num = 0;
int D_ad_num = 0;
int C_num = 0;
int C_tran;
float angle_rand_N[500][2];
int main(void)
{
  const float dt = 1e-5;
  const float evolu = sqrt(2 * dt);
  const float t = 2e2;
  const int Nstep = ceil(t / dt);
  float D_ad = 1;
  float dt_ad = dt / D_ad;
  float evolu_ad = sqrt(2 * dt_ad);
  int loop = 1;
  int sampling_freq = 1000;
  int i;
  int j;
  int k;
  int l;
  int g;
  int h;
  int o;
  int p;
  int q;
  int m;
  int c;
  int cl;
  int co;
  int target;
  int lcxyz;
  int lcyz;
  int lc[3];
  int mcl[3];
  lc[0] = 2 * 5.5;
  lc[1] = lc[0];
  lc[2] = lc[1];
  lcyz = lc[1] * lc[2];
  lcxyz = lc[0] * lcyz;
  float angle[2];
  int buff_l = 100;
  int ls_buff[buff_l];
  int mc[3];
  int rc[3];
  rc[0] = 1;
  rc[1] = 1;
  rc[2] = 1;
  C_tran = 0;
  int label[500];
  float P_C = 1;
  float r_ad = 2 + (1.1122 * 0.35);
  float r_escape = 2 + (2.5 * 0.35);
  int *ls = malloc(((sizeof(int)) * lcxyz) * buff_l);
  int *head = malloc((sizeof(int)) * lcxyz);
  float *ra = malloc(((sizeof(float)) * 500) * 3);
  float *rb = malloc(((sizeof(float)) * 500) * 3);
  float *r = malloc((sizeof(float)) * 500);
  float r_temp;
  float rd_temp[3];
  for (g = 0; g < loop; g++)
  {
    l = 0;
    char filename1[128];
    char filename2[128];
    char filename3[128];
    snprintf(filename1, (sizeof(char)) * 128, "traj_%fkT.txt", epsilon);
    FILE *traj;
    traj = fopen(filename1, "w");
    snprintf(filename2, (sizeof(char)) * 128, "particle_num_%fkT.txt", epsilon);
    FILE *particle_num;
    particle_num = fopen(filename2, "w");
    #pragma omp parallel for
    for (i = 0; i < 500; i++)
    {
      if ((i % 2) == 0)
        label[i] = 1;
      else
        label[i] = 2;

    }

    srand(time(0));
    int n_temp = 0;
    int mci[3];
    int lci = 5.5 + 1;
    float lsd = 0.9;
    float ld = 0.5;
    for (mci[0] = 0; mci[0] < ((2 * lci) + 1); mci[0]++)
    {
      for (mci[1] = 0; mci[1] < ((2 * lci) + 1); mci[1]++)
      {
        for (mci[2] = 0; mci[2] < ((2 * lci) + 1); mci[2]++)
        {
          if (n_temp > (500 - 1))
            goto bd;

          for (k = 0; k < 3; k++)
            ra[(n_temp * 3) + k] = (((-1) * lci) + mci[k]) * lsd;

          r[n_temp] = sqrt(dot_product(ra + (n_temp * 3), ra + (n_temp * 3)));
          if ((r[n_temp] < (5.5 - ld)) && (r[n_temp] > (2 + ld)))
          {
            n_temp++;
          }
          else
            continue;

        }

      }

    }

    bd:
    while (l < Nstep)
    {
      memset(head, 0, (sizeof(int)) * lcxyz);
      memset(ls, -1, ((sizeof(int)) * lcxyz) * buff_l);
      #pragma omp parallel for
      for (i = 0; i < 500; i++)
      {
        int mct[3];
        for (k = 0; k < 3; k++)
          mct[k] = floor(ra[(i * 3) + k] / rc[k]) + 5.5;

        c = ((mct[2] * lcyz) + (mct[1] * lc[0])) + mct[0];
        ls[(c * buff_l) + head[c]] = i;
        head[c]++;
      }

      #pragma omp parallel for
      for (j = 0; j < 500; j++)
      {
        for (k = 0; k < 3; k++)
          rb[(j * 3) + k] = (ra[(j * 3) + k] + ((LJ_shift(r[j], epsilon) * ra[(j * 3) + k]) * dt)) + (evolu * randn(0, 1));

        r[j] = sqrt(dot_product(rb + (j * 3), rb + (j * 3)));
        if (r[j] > 5.5)
        {
          for (k = 0; k < 3; k++)
            rb[(j * 3) + k] = ra[(j * 3) + k];

          switch (label[j])
          {
            case 5:
              label[j] = 1;
              break;

            case 6:
              label[j] = 2;
              break;

          }

        }

        switch (label[j])
        {
          case 1:
            if (r[j] < r_ad)
          {
            label[j] = 3;
            A_ad_num++;
          }

            break;

          case 2:
            if (r[j] < r_ad)
          {
            label[j] = 4;
            B_ad_num++;
          }

            break;

          case 3:
            if (r[j] > r_escape)
          {
            label[j] = 1;
            A_ad_num--;
          }

            break;

          case 4:
            if (r[j] > r_escape)
          {
            label[j] = 2;
            B_ad_num--;
          }

            break;

          case 5:
            if (r[j] < r_ad)
          {
            label[j] = 7;
            C_ad_num++;
          }

            break;

          case 6:
            if (r[j] < r_ad)
          {
            label[j] = 8;
            D_ad_num++;
          }

            break;

          case 7:
            if (r[j] > r_escape)
          {
            label[j] = 5;
            C_ad_num--;
          }

            break;

          case 8:
            if (r[j] > r_escape)
          {
            label[j] = 6;
            D_ad_num--;
          }

            break;

        }

      }

      for (i = 0; i < 500; i++)
      {
        if ((label[i] == 3) || (label[i] == 4))
        {
          int mct[3];
          for (k = 0; k < 3; k++)
            mct[k] = floor(rb[(i * 3) + k] / rc[k]) + 5.5;

          for (mcl[0] = mct[0] - 1; mcl[0] <= (mct[0] + 1); mcl[0]++)
            for (mcl[1] = mct[1] - 1; mcl[1] <= (mct[1] + 1); mcl[1]++)
            for (mcl[2] = mct[2] - 1; mcl[2] <= (mct[2] + 1); mcl[2]++)
          {
            cl = ((((mcl[2] + lc[2]) % lc[2]) * lcyz) + (((mcl[1] + lc[1]) % lc[1]) * lc[2])) + ((mcl[0] + lc[0]) % lc[0]);
            for (p = 0; p < head[cl]; p++)
            {
              j = ls[(cl * buff_l) + p];
              if (((label[i] == 3) && (label[j] == 4)) || ((label[i] == 4) && (label[j] == 3)))
              {
                for (k = 0; k < 3; k++)
                  rd_temp[k] = rb[(i * 3) + k] - rb[(j * 3) + k];

                r_temp = sqrt(dot_product(rd_temp, rd_temp));
                if ((r_temp < (1.1122 * 0.35)) && ((((float) rand()) / 32767) <= P_C))
                {
                  C_tran++;
                  switch (label[i])
                  {
                    case 3:
                      label[i] = 7;
                      label[j] = 8;
                      A_ad_num--;
                      B_ad_num--;
                      C_ad_num++;
                      D_ad_num++;
                      break;

                    case 4:
                      label[i] = 8;
                      label[j] = 7;
                      A_ad_num--;
                      B_ad_num--;
                      C_ad_num++;
                      D_ad_num++;
                      break;

                  }

                }

              }

            }

          }



        }

      }

      if ((l % sampling_freq) == 0)
      {
        for (j = 0; j < 500; j++)
          r[j] = sqrt(dot_product(rb + (j * 3), rb + (j * 3)));

        fprintf(traj, "%d\n\n", 500);
        for (j = 0; j < 500; j++)
          fprintf(traj, "type%d %f %f %f id=%d> \n", label[j], rb[j * 3], rb[(j * 3) + 1], rb[(j * 3) + 2], j);

      }

      if ((l % 10) == 0)
        fprintf(particle_num, "%d %d %d %d %d\n", A_ad_num, B_ad_num, C_tran, C_ad_num, D_ad_num);

      memcpy(ra, rb, (500 * (sizeof(float))) * 3);
      l++;
    }


    fclose(traj);
    fclose(particle_num);
  }

  free(ls);
  free(head);
  free(ra);
  free(rb);
  free(r);
  return 0;
}

