struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
double **dot(double **v, double *u, int n)
{
  long int a[((int) sqrt(10000000)) + 1];
  long int podzielniki[((int) sqrt(10000000)) + 1];
  long int pierwsze[10000000 / 10];
  long int i;
  long int k;
  long int liczba;
  long int reszt;
  long int reszta;
  long int suma;
  long int lpodz = 0;
  long int llpier = 0;
  double begin_t;
  double end_t;
  printf("--------------------------------------------------\n");
  for (i = 0; i <= ((int) sqrt(10000000)); i++)
    a[i] = 1;

  for (i = 2; i <= ((int) sqrt(10000000)); i++)
  {
    if (a[i] == 1)
    {
      pierwsze[llpier++] = (podzielniki[lpodz++] = i);
      for (k = i + i; k <= ((int) sqrt(10000000)); k += i)
      {
        a[k] = 0;
      }

    }

  }

  printf("Liczba liczb pierwszych %ld \n", llpier);
  printf("Liczba podzielnikow %ld \n", lpodz);
  printf("Najwieksza liczba pierwsza %ld \n", pierwsze[llpier - 1]);
  printf("--------------------------------------------------\n");
  begin_t = omp_get_wtime();
  #pragma omp parallel for private(k,liczba,reszta) shared (llpier, lpodz, pierwsze, podzielniki)
  for (liczba = ((int) sqrt(10000000)) + 1; liczba <= 10000000; liczba++)
  {
    for (k = 0; k < lpodz; k++)
    {
      reszta = liczba % podzielniki[k];
      if (reszta == 0)
        break;

    }

    if (reszta != 0)
    {
      #pragma omp critical
      pierwsze[llpier++] = liczba;
    }

  }

  end_t = omp_get_wtime();
  printf("Liczba liczb pierwszych: %ld \n", llpier);
  suma = 0;
  for (i = 0; i < llpier; i++)
  {
    suma = suma + pierwsze[i];
  }

  printf("Suma liczb pierwszych: %ld \n", suma);
  printf("\nNajwieksza liczba pierwsza: %ld \n", pierwsze[llpier - 1]);
  printf("Czas obliczeń liczb pierwszych %lf sek \n", end_t - begin_t);
  return 0;

  int i;
  double **res = malloc(n * (sizeof(double *)));
  for (i = 0; i < n; i++)
    res[i] = malloc(n * (sizeof(double)));

  #pragma omp parallel shared(v, u, res, n, chunk)
  {
    #pragma omp for schedule(guided, chunk) nowait
    for (i = 0; i < n; i++)
    {
      for (int j = 0; j < n; j++)
      {
        res[j][i] = v[i][0] * u[i];
      }

    }

  }
  return res;
}

