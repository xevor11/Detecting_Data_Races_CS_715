{
  int nx;
  int ny;
  int maxIters;
  int reynolds_dim;
  double density;
  double accel;
  double omega;
} t_param;
{
  double speeds[9];
} t_speed;
enum boolean {FALSE, TRUE};
int initialise(const char *paramfile, const char *obstaclefile, t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
int timestep(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int accelerate_flow(const t_param params, t_speed *cells, int *obstacles);
int propagate(const t_param params, t_speed *cells, t_speed *tmp_cells);
int rebound(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int collision(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int write_values(const t_param params, t_speed *cells, int *obstacles, double *av_vels);
int finalise(const t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
double total_density(const t_param params, t_speed *cells);
double av_velocity(const t_param params, t_speed *cells, int *obstacles);
double calc_reynolds(const t_param params, t_speed *cells, int *obstacles);
void die(const char *message, const int line, const char *file);
void usage(const char *exe);
double av_velocity(const t_param params, t_speed *cells, int *obstacles)
{
  int ii;
  int kk;
  int tot_cells = 0;
  double local_density;
  double u_x;
  double u_y;
  double tot_u;
  int row_start;
  int row_count;
  int row_end;
  tot_u = 0.0;
  #pragma omp parallel for shared(cells,obstacles) reduction(+:tot_cells,tot_u)
  for (ii = 0; ii < params.ny; ii++)
  {
    row_start = ii * params.nx;
    row_end = row_start + params.nx;
    for (row_count = row_start; row_count < row_end; row_count++)
    {
      if (!obstacles[row_count])
      {
        local_density = 0.0;
        for (kk = 0; kk < 9; kk++)
        {
          local_density += cells[row_count].speeds[kk];
        }

        u_x = (((cells[row_count].speeds[1] + cells[row_count].speeds[5]) + cells[row_count].speeds[8]) - ((cells[row_count].speeds[3] + cells[row_count].speeds[6]) + cells[row_count].speeds[7])) / local_density;
        u_y = (((cells[row_count].speeds[2] + cells[row_count].speeds[5]) + cells[row_count].speeds[6]) - ((cells[row_count].speeds[4] + cells[row_count].speeds[7]) + cells[row_count].speeds[8])) / local_density;
        tot_u = tot_u + sqrt((u_x * u_x) + (u_y * u_y));
        tot_cells = tot_cells + 1;
      }

    }

  }

  return tot_u / ((double) tot_cells);
}

