double exref[nx][ny + 1];
double eyref[nx + 1][ny];
double hzref[nx][ny];
double ex[nx][ny + 1];
double ey[nx + 1][ny];
double hz[nx][ny];
void compare();
int main()
{
  int i;
  int j;
  int k;
  double **A;
  double **B;
  double **C;
  double sum;
  double t1;
  double t2;
  int numthreads;
  int tid;
  #pragma omp parallel
  {
    numthreads = omp_get_num_threads();
    tid = omp_get_thread_num();
    if (tid == 0)
      printf("Running multiply with %d threads\n", numthreads);

  }
  A = create_matrix();
  B = create_matrix();
  C = (double **) malloc((sizeof(double *)) * 1000);
  for (i = 0; i < 1000; i++)
  {
    C[i] = (double *) malloc((sizeof(double)) * 1000);
  }

  t1 = get_clock();
  #pragma omp parallel shared(A,B,C) private(sum,i,j,k)
  {
    #pragma omp for collapse(1) schedule(static)
    for (i = 0; i < 1000; i++)
    {
      for (j = 0; j < 1000; j++)
      {
        sum = 0;
        for (k = 0; k < 1000; k++)
        {
          sum += A[i][k] * B[k][j];
        }

        C[i][j] = sum;
      }

    }

  }
  t2 = get_clock();
  printf("Time: %lf\n", t2 - t1);
  if (1)
  {
    char outfile[100];
    sprintf(outfile, "multiply_out_%d.txt", numthreads);
    printf("Outputting solution to %s\n", outfile);
    FILE *fp = fopen(outfile, "w");
    for (i = 0; i < 1000; i++)
    {
      for (j = 0; j < 1000; j++)
      {
        fprintf(fp, "%lf\n", C[i][j]);
      }

    }

    fclose(fp);
  }

  free_matrix(A);
  free_matrix(B);
  free_matrix(C);
  return 0;

  double rtclock();
  int tt;
  int i;
  int j;
  int nt;
  double clkbegin;
  double clkend;
  double t;
  double maxdiff;
  for (i = 0; i < nx; i++)
  {
    for (j = 0; j <= ny; j++)
    {
      exref[i][j] = (ex[i][j] = sin(i) * sin(j));
    }

  }

  for (i = 0; i <= nx; i++)
  {
    for (j = 0; j < ny; j++)
    {
      eyref[i][j] = (ey[i][j] = cos(i) * cos(j));
    }

  }

  for (i = 0; i < nx; i++)
  {
    for (j = 0; j < ny; j++)
    {
      hzref[i][j] = (hz[i][j] = sin(i) * cos(j));
    }

  }

  clkbegin = rtclock();
  for (tt = 0; tt < tmax; tt++)
  {
    for (j = 0; j < ny; j++)
      eyref[0][j] = tt;

    for (j = 0; j < ny; j++)
      for (i = 1; i < nx; i++)
      eyref[i][j] = eyref[i][j] - (0.5 * (hzref[i][j] - hzref[i - 1][j]));


    for (j = 1; j < ny; j++)
      for (i = 0; i < nx; i++)
      exref[i][j] = exref[i][j] - (0.5 * (hzref[i][j] - hzref[i][j - 1]));


    for (j = 0; j < ny; j++)
      for (i = 0; i < nx; i++)
      hzref[i][j] = hzref[i][j] - (0.7 * (((exref[i][j + 1] - exref[i][j]) + eyref[i + 1][j]) - eyref[i][j]));


  }

  clkend = rtclock();
  t = clkend - clkbegin;
  printf("%.1f Sequential MFLOPS;  \n", ((((10 * nx) * ny) * tmax) / t) / 1000000);
  printf("Maximum threads allowed by system is: %d\n", omp_get_max_threads());
  for (nt = 1; nt <= 8; nt++)
  {
    omp_set_num_threads(nt);
    for (i = 0; i < nx; i++)
    {
      for (j = 0; j <= ny; j++)
      {
        ex[i][j] = (ex[i][j] = sin(i) * sin(j));
      }

    }

    for (i = 0; i <= nx; i++)
    {
      for (j = 0; j < ny; j++)
      {
        ey[i][j] = (ey[i][j] = cos(i) * cos(j));
      }

    }

    for (i = 0; i < nx; i++)
    {
      for (j = 0; j < ny; j++)
      {
        hz[i][j] = (hz[i][j] = sin(i) * cos(j));
      }

    }

    clkbegin = rtclock();
    {
      for (tt = 0; tt < tmax; tt++)
      {
        #pragma omp parallel for schedule(dynamic, 16)
        for (j = 0; j < ny; j++)
          ey[0][j] = tt;

        #pragma omp parallel for schedule(dynamic, 16)
        for (j = 0; j < ny; j++)
          for (i = 1; i < nx; i++)
          ey[i][j] = ey[i][j] - (0.5 * (hz[i][j] - hz[i - 1][j]));


        #pragma omp parallel for schedule(dynamic, 16)
        for (j = 1; j < ny; j++)
          for (i = 0; i < nx; i++)
          ex[i][j] = ex[i][j] - (0.5 * (hz[i][j] - hz[i][j - 1]));


        #pragma omp parallel for schedule(dynamic, 16)
        for (j = 0; j < ny; j++)
          for (i = 0; i < nx; i++)
          hz[i][j] = hz[i][j] - (0.7 * (((ex[i][j + 1] - ex[i][j]) + ey[i + 1][j]) - ey[i][j]));


      }

    }
    clkend = rtclock();
    t = clkend - clkbegin;
    printf("%.1f MFLOPS with %d threads; Time = %.3f sec; ", ((((10 * nx) * ny) * tmax) / t) / 1000000, nt, t);
    compare();
  }

}

