int main(int argc, char **argv)
{
  int N = pow(2, 30);
  int i;
  double A[N];
  double B[N];
  double C[N];
  double wall_time = 0.00;
  clock_t start_time;
  clock_t end_time;
  start_time = clock();
  printf("\n");
  printf("  OpenMP C program to demonstrate array manipulation.\n\n");
  printf("  Size of the array : %d\n", N);
  for (i = 0; i < N; i++)
  {
    A[i] = i;
    B[i] = i + 1;
    C[i] = 0.00;
  }

  #pragma omp parallel for default(shared),
  for (i = 0; i < N; i++)
  {
    C[i] = A[i] + B[i];
  }

  end_time = clock();
  wall_time = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;
  printf("  Total time taken  : %f seconds\n\n", wall_time);
  return 0;
}

