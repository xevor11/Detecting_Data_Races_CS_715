void NLmean(double *x_NLM, double *weight_NLM, double *x_ref, double *x_moving, double *x_fusion, int *gridy, int *gridz, int *accids)
{
  double norm_fact = 1.0 / ((double) (((2 * 12) + 1) * ((2 * 12) + 1)));
  int ri = (5 * ((2 * 5) + 1)) + 5;
  int est_idy;
  #pragma omp parallel for
  for (est_idy = 0; est_idy < 96; est_idy++)
    for (int est_idz = 0; est_idz < 96; est_idz++)
    for (int ni = 0; ni < (((2 * 5) + 1) * ((2 * 5) + 1)); ni++)
  {
    int ref_idy;
    int ref_idz;
    int moving_idy;
    int moving_idz;
    double du;
    double d = 0.0;
    long int grid_rid;
    long int grid_nid;
    for (int si = 0; si < (((2 * 12) + 1) * ((2 * 12) + 1)); si++)
    {
      grid_rid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ri * ((2 * 12) + 1)) * ((2 * 12) + 1))) + si;
      grid_nid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ni * ((2 * 12) + 1)) * ((2 * 12) + 1))) + si;
      ref_idy = gridy[grid_rid];
      moving_idy = gridy[grid_nid];
      ref_idz = gridz[grid_rid];
      moving_idz = gridz[grid_nid];
      du = x_ref[(ref_idy * 96) + ref_idz] - x_moving[(moving_idy * 96) + moving_idz];
      d = d + ((norm_fact * du) * du);
    }

    double w = exp((-d) / ((2.0 * 0.1) * 0.1));
    for (int k = 0; k < (((2 * 12) + 1) * ((2 * 12) + 1)); k++)
    {
      int ai = accids[k];
      grid_rid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ri * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ai;
      grid_nid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ni * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ai;
      ref_idy = gridy[grid_rid];
      moving_idy = gridy[grid_nid];
      ref_idz = gridz[grid_rid];
      moving_idz = gridz[grid_nid];
      x_NLM[(ref_idy * 96) + ref_idz] = x_NLM[(ref_idy * 96) + ref_idz] + (w * x_fusion[(moving_idy * 96) + moving_idz]);
      weight_NLM[(ref_idy * 96) + ref_idz] = weight_NLM[(ref_idy * 96) + ref_idz] + w;
    }

  }




  long k;
  long i;
  long j;
  double temp;
  omp_set_num_threads(thread);
  for (i = 0; i < dim; i++)
    inv[i][i] = 1.0;

  for (k = 0; k < dim; k++)
  {
    #pragma omp parallel
    {
      #pragma omp for private(j,temp)
      for (i = 0; i < dim; i++)
      {
        if (k != i)
        {
          temp = mat[i][k] / mat[k][k];
          for (j = k + 1; j < dim; j++)
            mat[i][j] -= temp * mat[k][j];

          for (j = 0; j < dim; j++)
            inv[i][j] -= temp * inv[k][j];

        }

      }

      #pragma omp for
      for (j = 0; j < dim; j++)
      {
        inv[k][j] = inv[k][j] / mat[k][k];
        if (j != k)
          mat[k][j] = mat[k][j] / mat[k][k];

      }

      mat[k][k] = 1.0;
    }
  }

  return 0;
}

