void getTim(float *inbuffer, float *outbuffer, int nchans, int nsamps, int index)
{
  int i;
  int j;
  int g;
  int idx;
  int idg;
  const int *gidx;
  double ngp;
  void (*add_pow)(double *, double, const double, const double *, const int);
  double (*radical)(const double, const double);
  double invp = 1. / p;
  if (p == 1.)
  {
    add_pow = (W == 0) ? (add_pow_l11_real_double) : (add_pow_wl11_real_double);
    radical = radical_1_double;
  }
  else
    if (p == 2.)
  {
    add_pow = (W == 0) ? (add_pow_l12_real_double) : (add_pow_wl12_real_double);
    radical = radical_2_double;
  }
  else
    if (p == INFINITY)
  {
    add_pow = add_pow_l1inf_real_double;
    radical = radical_1_double;
  }
  else
  {
    add_pow = (W == 0) ? (add_pow_l1p_real_double) : (add_pow_wl1p_real_double);
    radical = radical_p_double;
  }



  #pragma omp parallel for private(i, j, g, idx, idg, gidx, ngp)
  for (g = 0; g < G[0][0]; g++)
  {
    gidx = G[g + 1];
    for (idg = I * g, i = 0; i < I; i++, idg++)
    {
      ngp = 0.;
      for (j = 1; j <= gidx[0]; j++)
      {
        idx = i + (I * gidx[j]);
        add_pow(&ngp, X[idx], p, W, idx);
      }

      Nb[idg] = radical(ngp, invp);
    }

  }


  int ii;
  int jj;
  int val;
  #pragma omp parallel for default(shared) shared(outbuffer,inbuffer)
  for (ii = 0; ii < nsamps; ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[index + ii] += inbuffer[(nchans * ii) + jj];
    }

  }

}

