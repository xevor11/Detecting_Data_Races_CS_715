{
  int N;
  int ORBS;
  int basis_size;
  unsigned int *to_bitstring;
  unsigned int *Y;
  double *one_p_int;
  double *two_p_int;
  double core_energy;
  double *diagonal;
} matvec_data;
void calculate_sigma_three(double *vec, double *two_p_int, unsigned int *to_bitstring, unsigned int *Y, int basis_size, const int N, const int L, double *result)
{
  int cnt;
  int cnt_exc;
  int k;
  int l;
  int L3;
  int L2;
  int *occ;
  int *exc_occ;
  int cnt_c;
  unsigned int bitstring;
  L2 = L * L;
  L3 = L2 * L;
  #pragma omp parallel default(none) shared(result, vec, two_p_int, to_bitstring, Y, basis_size, L2, L3)
  {
    occ = (int *) malloc(L * (sizeof(int)));
    exc_occ = (int *) malloc(L * (sizeof(int)));
    #pragma omp for schedule(static)
    for (cnt = 0; cnt < basis_size; cnt++)
    {
      bitstring = to_bitstring[cnt];
      fill_occupation(bitstring, occ, L);
      for (cnt_c = 0; cnt_c < L; cnt_c++)
        exc_occ[cnt_c] = occ[cnt_c];

      cnt_exc = cnt;
      k = -1;
      l = -1;
      while (next_bitstring(cnt, &cnt_exc, &k, &l, occ, exc_occ, Y, L, N))
        result[cnt] += two_p_int[((k + (l * L)) + (k * L2)) + (l * L3)] * vec[cnt_exc];

    }

    free(occ);
    free(exc_occ);
  }
}

