struct myarray *myarray_matmul(struct myarray *A, struct myarray *B)
{
  uint32_t bitmap[5];
} qryEntry_t;
{
  uint32_t column;
  uint32_t score;
} resEntry_t;
{
  uint32_t query;
  uint32_t position;
} candInfo_t;
{
  uint32_t size;
  uint32_t numEntries;
  uint32_t *h_reference;
  uint32_t *d_reference;
} ref_t;
{
  uint32_t numResults;
  resEntry_t *h_results;
  resEntry_t *d_results;
} res_t;
{
  uint32_t totalSizeQueries;
  uint32_t totalQueriesEntries;
  uint32_t sizeQueries;
  uint32_t numQueries;
  uint32_t numCandidates;
  float distance;
  qryEntry_t *h_queries;
  qryEntry_t *d_queries;
  candInfo_t *h_candidates;
  candInfo_t *d_candidates;
  uint32_t *d_Pv;
  uint32_t *d_Mv;
} qry_t;
int main(int argc, char *argv[])
{
  void *reference;
  void *queries;
  void *results;
  int32_t error;
  float distance = atof(argv[1]);
  unsigned char *refFile = argv[2];
  unsigned char *qryFile = argv[3];
  double ts;
  double ts1;
  double total;
  uint iter = 1;
  uint n;
  error = loadReference(refFile, &reference);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  error = loadQueries(qryFile, &queries, distance);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  error = initResults(&results, queries);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  ts = sampleTime();
  #pragma omp parallel private(n)
  {
    for (n = 0; n < iter; n++)
      computeAllQueriesCPU(reference, queries, results);

  }
  ts1 = sampleTime();
  total = (ts1 - ts) / iter;
  printf("TIME: \t %f \n", total);
  error = saveResults(qryFile, results);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  error = freeReference(reference);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  error = freeQueries(queries);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  error = freeResults(results);
  {
    {
      if (error)
      {
        fprintf(stderr, "%s\n", processError(error));
        exit(1);
      }

    }
  }
  ;
  return 0;

  int i;
  int j;
  int k;
  const int n = A->n_rows;
  const int mA = A->n_cols;
  const int mB = B->n_rows;
  const int p = B->n_cols;
  struct myarray *C;
  assert(mA == mB);
  C = myarray_construct(n, p);
  #pragma omp parallel for schedule(static) collapse(2) shared(A, B, C) default(none)
  for (i = 0; i < n; i++)
    for (j = 0; j < p; j++)
  {
    *myarray_at(C, i, j) = 0;
    for (k = 0; k < mA; k++)
    {
      *myarray_at(C, i, j) += (*myarray_at(A, i, k)) * (*myarray_at(B, k, j));
    }

  }


  return C;
}

