struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
double **ones2(int filas, int columnas)
{
  int i;
  int j;
  double **res = malloc(filas * (sizeof(double *)));
  for (int i = 0; i < filas; i++)
    res[i] = malloc(columnas * (sizeof(double)));

  #pragma omp parallel shared(filas, columnas, res, chunk)
  {
    #pragma omp for schedule(guided, chunk) nowait
    for (i = 0; i < filas; i++)
    {
      for (j = 0; j < columnas; j++)
      {
        res[i][j] = 1;
      }

    }

  }
  return res;

  int value;
  int hash_code;
  struct node_t *next;
};
int MAX_LOCKS = 64;
struct HashSet
{
  struct node_t **table;
  int capacity;
  int setSize;
  __int128 atomic_locks;
  int locks_length;
  __int128 owner;
};
int NULL_VALUE = 5139239;
void unlock_set(int *, int);
void resize(struct HashSet *);
void main(int argc, char *argv[])
{
  int num_threads = atoi(argv[1]);
  int inp_1 = atoi(argv[2]);
  int inp_2 = atoi(argv[3]);
  int inp_3 = atoi(argv[4]);
  struct HashSet *H = (struct HashSet *) malloc(sizeof(struct HashSet));
  initialize(H, 16);
  srand(time(0));
  int c;
  int k;
  int i;
  int j;
  int op_count = 1000000;
  int finds = inp_1;
  int deletes = inp_2;
  int inserts = inp_3;
  timer_tt * timer;
  int value_table[op_count];
  int op_table[op_count];
  for (i = 0; i < op_count; i++)
    value_table[i] = rand() % 100000;

  for (i = 0; i < finds; i++)
    op_table[i] = 1;

  for (i = 0; i < deletes; i++)
    op_table[finds + i] = 2;

  for (i = 0; i < inserts; i++)
    op_table[(finds + deletes) + i] = 3;

  shuffle(op_table, op_count);
  int segm = op_count / num_threads;
  int indx;
  int res;
  double total_time = 0;
  #pragma omp parallel for num_threads(num_threads) shared(H,value_table,op_table) private(c,j,timer,res,k,indx) reduction(+:total_time)
  for (i = 0; i < num_threads; i++)
  {
    c = 50;
    timer = timer_init(timer);
    timer_start(timer);
    for (j = 0; j < (1000000 / num_threads); j++)
    {
      for (k = 0; k < c; k++)
        ;

      indx = ((omp_get_thread_num() * segm) + j) % op_count;
      if (op_table[indx] == 1)
        res = contains(H, value_table[indx], value_table[indx]);
      else
        if (op_table[indx] == 2)
        res = delete(H, value_table[indx], value_table[indx]);
      else
        add(H, value_table[indx], value_table[indx], 0);


    }

    timer_stop(timer);
    total_time = timer_report_sec(timer);
    printf("%thread %d timer %lf\n", omp_get_thread_num(), timer_report_sec(timer));
  }

  double avg_total_time = total_time / ((double) num_threads);
  printf("avg total time %lf\n", avg_total_time);
  printf("%d \n", H->setSize);
  printf("%d \n", H->capacity);
  return;
}

