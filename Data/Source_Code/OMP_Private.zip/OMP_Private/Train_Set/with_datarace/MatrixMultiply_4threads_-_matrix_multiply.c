void matrix_multiply(float **a, float **b, float **c, int arows, int acols, int bcols)
{
  int phase;
  int i;
  int temp;
  #pragma omp parallel num_threads(threadNumber) default(none) shared(a,n) private(i,temp,phase)
  for (phase = 0; phase < n; ++phase)
  {
    if ((phase % 2) == 0)
    {
      #pragma omp for
      for (i = 1; i < n; i += 2)
        if (a[i - 1] > a[i])
      {
        temp = a[i];
        a[i] = a[i - 1];
        a[i - 1] = temp;
      }


    }
    else
    {
      #pragma omp for
      for (i = 1; i < (n - 1); i += 2)
        if (a[i] > a[i + 1])
      {
        temp = a[i];
        a[i] = a[i + 1];
        a[i + 1] = temp;
      }


    }

  }


  int i;
  int j;
  int k;
  float tmp;
  #pragma omp parallel for
  for (i = 0; i < arows; i++)
    for (j = 0; j < bcols; j++)
  {
    tmp = 0.0;
    for (k = 0; k < acols; k++)
      tmp += a[i][k] * b[k][j];

    c[i][j] = tmp;
  }


  return;
}

