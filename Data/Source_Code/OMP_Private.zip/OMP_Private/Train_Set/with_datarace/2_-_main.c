int main()
{
  int m = 1;
  int x = 0;
  for (m = 1; m < 9; m++)
  {
    int i;
    int j;
    int k = 0;
    FILE *fp;
    fp = fopen("result.txt", "w");
    if (fp == 0)
    {
      printf("faile open the file!\n");
      exit(-1);
    }

    double start = omp_get_wtime();
    omp_set_num_threads(m);
    #pragma omp parallel for reduction(+:k)
    for (i = 2; i < 100000; i++)
    {
      x = omp_get_num_threads();
      for (j = 2; j <= sqrt(i); j++)
      {
        if ((i % j) == 0)
        {
          break;
        }

      }

      if (j > sqrt(i))
      {
        fprintf(fp, "%d ", i);
        k++;
      }

    }

    printf("素数的个数为:%d ", k);
    printf("线程数为:%d ", x);
    double end = omp_get_wtime();
    printf("start = %.16g,end = %.16g,diff = %.16g seconds ", start, end, end - start);
    double s = 0.019 / (end - start);
    printf("加速比为:%f\n", s);
  }

  return 0;

  int i;
  int nthreads;
  int tid;
  int a[10];
  int b[10];
  int c[10];
  int d[10];
  for (i = 0; i < 10; i++)
  {
    a[i] = i * 5;
    b[i] = i * 2;
    c[i] = (d[i] = 0);
  }

  #pragma omp prallel shared(a,b,c,d,nthreads) private(i,tid)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("number of thread %d\n", nthreads);
    }

  }
  printf("thread %d starting\n", tid);
  #pragma omp sections nowait
  {
    #pragma omp section
    {
      printf("Thread % d doing section 1\n", tid);
      for (i = 0; i < 10; i++)
      {
        c[i] = a[i] + b[i];
        printf("Thread %d c[%d] = %d\n", tid, i, c[i]);
      }

    }
    #pragma omp section
    {
      printf("Thread % d doing section 2\n", tid);
      for (i = 0; i < 10; i++)
      {
        d[i] = a[i] - b[i];
        printf("Thread %d d[%d] = %d\n", tid, i, c[i]);
      }

    }
  }
}

