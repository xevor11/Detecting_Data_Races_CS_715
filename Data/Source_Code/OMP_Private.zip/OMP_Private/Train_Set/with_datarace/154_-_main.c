int main(int argc, char **argv)
{
  unsigned long k1;
  unsigned long k2;
  unsigned long k3;
  unsigned long long ans = 0;
  unsigned long *p2 = p_list(200000, 2);
  unsigned long *p5 = p_list(200000, 5);
  #pragma omp parallel for reduction(+ : ans)
  for (k1 = 0; k1 < (200000 / 3); k1++)
  {
    for (k2 = k1; k2 <= ((200000 - k1) - k2); k2++)
    {
      k3 = (200000 - k1) - k2;
      if ((((p2[k1] + p2[k2]) + p2[k3]) < 199983) && (((p5[k1] + p5[k2]) + p5[k3]) < 49987))
      {
        if ((k1 == k2) || (k2 == k3))
        {
          ans += 3;
        }
        else
        {
          ans += 6;
        }

      }

    }

  }

  free(p2);
  free(p5);
  printf("answer: %lld\n", ans);
  return 0;
}

