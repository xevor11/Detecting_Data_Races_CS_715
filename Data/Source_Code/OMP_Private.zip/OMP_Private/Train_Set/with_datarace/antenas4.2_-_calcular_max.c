{
  int y;
  int x;
} Antena;
{
  int valor;
  int x;
  int y;
} Registro;
int calcular_max(int *mapa, int rows, int cols, Registro *registros, int num_hilos)
{
  int maximo = 0;
  int ii = 0;
  int jj = 0;
  int i;
  int j;
  #pragma omp parallel for shared(mapa,registros) firstprivate(ii,jj,maximo)
  for (i = 0; i < rows; i++)
  {
    for (j = 0; j < cols; j++)
    {
      if (mapa[(i * cols) + j] > maximo)
      {
        maximo = mapa[(i * cols) + j];
        ii = i;
        jj = j;
      }

    }

    registros[omp_get_thread_num()].x = ii;
    registros[omp_get_thread_num()].y = jj;
    registros[omp_get_thread_num()].valor = maximo;
  }

  maximo = 0;
  for (i = 0; i < num_hilos; i++)
  {
    if (registros[i].valor > maximo)
    {
      maximo = registros[i].valor;
      registros[num_hilos].valor = maximo;
      registros[num_hilos].x = registros[i].x;
      registros[num_hilos].y = registros[i].y;
    }

  }

  return registros[num_hilos].valor;
}

