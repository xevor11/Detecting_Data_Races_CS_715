void pdv_kernel_c_(int *prdct, int *xmin, int *xmax, int *ymin, int *ymax, double *dtbyt, double *xarea, double *yarea, double *volume, double *density0, double *density1, double *energy0, double *energy1, double *pressure, double *viscosity, double *xvel0, double *xvel1, double *yvel0, double *yvel1, double *volume_change)
{0};
unsigned long long *rnd_ptrs[256] = {0};
unsigned long long debug_ret[256][4];
int num_threads = 1;
int omp_num_threads = 1;
int mem_size_per_thread_in_kb = 16;
int test_case = 0;
int cpubind = 0;
int stride = 256;
int hugepage_allocate = 0;
int hugepage_forced = 0;
double rand_ratio = 0.95;
int mega = 1;
unsigned long long n_bytes;
int default_loop = 1000;
double parallel_test()
{
  unsigned long long delta = 0;
  unsigned long long my_bytes = 0;
  unsigned long long n_segs = 0;
  unsigned long long *pos = 0;
  int idx;
  int omp_num_threads;
  int i;
  unsigned long long n_done = 0;
  unsigned long long n_conflict = 0;
  unsigned long long start_ns;
  struct timespec ts;
  printf("\n=== %s ===\n", __FUNCTION__);
  start_ns = time_ns(&ts);
  #pragma omp parallel private(idx)
  {
    omp_num_threads = omp_get_num_threads();
    my_bytes = n_bytes / omp_num_threads;
    idx = omp_get_thread_num();
    setup_rnd(ptrs[idx], my_bytes, stride, idx);
  }
  delta = time_ns(&ts) - start_ns;
  for (i = 0; i < omp_num_threads; i++)
  {
    n_done += debug_ret[i][0];
    n_conflict += debug_ret[i][1];
  }

  n_segs = n_bytes / stride;
  printf("%.3f ms with each %.03f ns; %lld + %lld (ratio %.3f), target is %lld, archieved %.2f%%.\n", ((double) delta) / 1000000.f, ((double) delta) / (n_conflict + n_done), n_done, n_conflict, ((double) ((n_done, n_conflict))) / ((double) n_done), n_segs, (((double) n_done) / ((double) n_segs)) * 100.f);
  pos = ptr;
  delta = measure_rnd_read((char **) (&pos), default_loop, 1000LLU * 10LLU);
  printf("%s single thread read: %.3f ms, %.3f ns each.\n", __FUNCTION__, ((double) delta) / 1000000.f, ((((double) delta) / ((double) (1000LLU * 10LLU))) / ((double) default_loop)) / 100LLU);
  start_ns = time_ns(&ts);
  #pragma omp parallel private(idx, pos)
  {
    idx = omp_get_thread_num();
    pos = ptrs[idx];
    measure_rnd_read((char **) (&pos), default_loop, 1000LLU * 10LLU);
  }
  delta = time_ns(&ts) - start_ns;
  printf("%s with %d threads read: %.3f ms, %.3f ns each.\n", __FUNCTION__, omp_num_threads, ((double) delta) / 1000000.f, ((((double) delta) / ((double) (1000LLU * 10LLU))) / ((double) default_loop)) / 100LLU);
  pos = ptr;
  delta = measure_rnd_fill(&pos, default_loop, 1000LLU * 10LLU);
  printf("%s single thread fill: %.3f ms, %.3f ns each.\n", __FUNCTION__, ((double) delta) / 1000000.f, ((((double) delta) / ((double) (1000LLU * 10LLU))) / ((double) default_loop)) / 100LLU);
  start_ns = time_ns(&ts);
  #pragma omp parallel private(idx, pos)
  {
    idx = omp_get_thread_num();
    pos = ptrs[idx];
    measure_rnd_fill(&pos, default_loop, 1000LLU * 10LLU);
  }
  delta = time_ns(&ts) - start_ns;
  printf("%s with %d threads fill: %.3f ms, %.3f ns each.\n", __FUNCTION__, omp_num_threads, ((double) delta) / 1000000.f, ((((double) delta) / ((double) (1000LLU * 10LLU))) / ((double) default_loop)) / 100LLU);

  int predict = *prdct;
  int x_min = *xmin;
  int x_max = *xmax;
  int y_min = *ymin;
  int y_max = *ymax;
  double dt = *dtbyt;
  int j;
  int k;
  double recip_volume;
  double energy_change;
  double min_cell_volume;
  double right_flux;
  double left_flux;
  double top_flux;
  double bottom_flux;
  double total_flux;
  #pragma omp parallel
  {
    if (predict == 0)
    {
      #pragma omp for
      for (k = y_min; k <= y_max; k++)
      {
        #pragma ivdep
        for (j = x_min; j <= x_max; j++)
        {
          left_flux = (((xarea[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] * (((xvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] + xvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + xvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)]) + xvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt) * 0.5;
          right_flux = (((xarea[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)] * (((xvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)] + xvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + xvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)]) + xvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt) * 0.5;
          bottom_flux = (((yarea[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] * (((yvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] + yvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)]) + yvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)]) + yvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt) * 0.5;
          top_flux = (((yarea[FTNREF2D(j, k + 1, x_max + 4, x_min - 2, y_min - 2)] * (((yvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)] + yvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + yvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + yvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt) * 0.5;
          total_flux = ((right_flux - left_flux) + top_flux) - bottom_flux;
          volume_change[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] = volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / (volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + total_flux);
          min_cell_volume = MIN((((volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + right_flux) - left_flux) + top_flux) - bottom_flux, MIN((volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + right_flux) - left_flux, (volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + top_flux) - bottom_flux));
          recip_volume = 1.0 / volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)];
          energy_change = (((pressure[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)]) + (viscosity[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)])) * total_flux) * recip_volume;
          energy1[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = energy0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] - energy_change;
          density1[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] * volume_change[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)];
        }

      }

    }
    else
    {
      #pragma omp for
      for (k = y_min; k <= y_max; k++)
      {
        #pragma ivdep
        for (j = x_min; j <= x_max; j++)
        {
          left_flux = ((xarea[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] * (((xvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] + xvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + xvel1[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)]) + xvel1[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt;
          right_flux = ((xarea[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)] * (((xvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)] + xvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + xvel1[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)]) + xvel1[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt;
          bottom_flux = ((yarea[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] * (((yvel0[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] + yvel0[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)]) + yvel1[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)]) + yvel1[FTNREF2D(j + 1, k, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt;
          top_flux = ((yarea[FTNREF2D(j, k + 1, x_max + 4, x_min - 2, y_min - 2)] * (((yvel0[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)] + yvel0[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + yvel1[FTNREF2D(j, k + 1, x_max + 5, x_min - 2, y_min - 2)]) + yvel1[FTNREF2D(j + 1, k + 1, x_max + 5, x_min - 2, y_min - 2)])) * 0.25) * dt;
          total_flux = ((right_flux - left_flux) + top_flux) - bottom_flux;
          volume_change[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)] = volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / (volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + total_flux);
          min_cell_volume = MIN((((volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + right_flux) - left_flux) + top_flux) - bottom_flux, MIN((volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + right_flux) - left_flux, (volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] + top_flux) - bottom_flux));
          recip_volume = 1.0 / volume[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)];
          energy_change = (((pressure[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)]) + (viscosity[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] / density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)])) * total_flux) * recip_volume;
          energy1[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = energy0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] - energy_change;
          density1[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] = density0[FTNREF2D(j, k, x_max + 4, x_min - 2, y_min - 2)] * volume_change[FTNREF2D(j, k, x_max + 5, x_min - 2, y_min - 2)];
        }

      }

    }

  }
}

