float R = 1.0;
float GAMA = 7. / 5.;
float CV = R / (GAMA - 1.0);
float CP = CV + R;
float *olddens;
float *newdens;
float *oldxv;
float *newxv;
float *oldtemp;
float *newtemp;
float *oldpress;
float *newpress;
float *cx;
float U[200][3];
float U_new[200][3];
float *F;
float *FL;
float *FR;
float FP[200][3];
float FM[200][3];
float dFP[200][3];
float dFM[200][3];
void Allocate_Memory();
void Init();
void Free();
void CalculateFlux();
void CalculateFPFM();
void CalculateResult();
void Save_Results();
void CalculateFlux()
{
  int i;
  int j;
  float tmp;
  if (a == b)
  {
    #pragma omp for schedule (static) private(i, j, tmp)
    for (i = 0; i < rows; i++)
    {
      tmp = 0;
      for (j = cols - 1; j >= 0; j--)
      {
        tmp += (A[i][j] * x[j]) + y[j];
      }

      z[i] = a * tmp;
    }

  }
  else
    if (b == (-1.0))
  {
    #pragma omp for schedule (static) private(i, j, tmp)
    for (i = 0; i < rows; i++)
    {
      tmp = 0;
      for (j = cols - 1; j >= 0; j--)
      {
        tmp += ((a * A[i][j]) * x[j]) - y[j];
      }

      z[i] = tmp;
    }

  }
  else
    if (b == 0.0)
  {
    #pragma omp for schedule (static) private(i, j, tmp)
    for (i = 0; i < rows; i++)
    {
      tmp = 0;
      for (j = cols - 1; j >= 0; j--)
      {
        tmp += A[i][j] * x[j];
      }

      z[i] = a * tmp;
    }

  }
  else
    if (a == (-1.0))
  {
    #pragma omp for schedule (static) private(i, j, tmp)
    for (i = 0; i < rows; i++)
    {
      tmp = 0;
      for (j = cols - 1; j >= 0; j--)
      {
        tmp += (b * y[j]) - (A[i][j] * x[j]);
      }

      z[i] = tmp;
    }

  }
  else
  {
    #pragma omp for schedule (static) private(i, j, tmp)
    for (i = 0; i < rows; i++)
    {
      tmp = 0;
      for (j = cols - 1; j >= 0; j--)
      {
        tmp += ((a * A[i][j]) * x[j]) + (b * y[j]);
      }

      z[i] = tmp;
    }

  }




  return;

  int i;
  int j;
  float a;
  float M;
  float M2;
  float F0;
  float F1;
  float F2;
  omp_set_num_threads(16);
  #pragma omp parallel for
  for (i = 0; i < 200; i++)
  {
    F0 = olddens[i] * oldxv[i];
    F1 = olddens[i] * ((oldxv[i] * oldxv[i]) + (R * oldtemp[i]));
    F2 = oldxv[i] * (U[i][2] + ((olddens[i] * R) * oldtemp[i]));
    a = sqrt((GAMA * R) * oldtemp[i]);
    M = oldxv[i] / a;
    if (M > 1.0)
    {
      M = 1.0;
    }
    else
      if (M < (-1.0))
    {
      M = -1.0;
    }


    M2 = M * M;
    FP[i][0] = 0.5 * ((F0 * (M + 1.0)) + ((U[i][0] * a) * (1 - M2)));
    FM[i][0] = (-0.5) * ((F0 * (M - 1.0)) + ((U[i][0] * a) * (1 - M2)));
    FP[i][1] = 0.5 * ((F1 * (M + 1.0)) + ((U[i][1] * a) * (1 - M2)));
    FM[i][1] = (-0.5) * ((F1 * (M - 1.0)) + ((U[i][1] * a) * (1 - M2)));
    FP[i][2] = 0.5 * ((F2 * (M + 1.0)) + ((U[i][2] * a) * (1 - M2)));
    FM[i][2] = (-0.5) * ((F2 * (M - 1.0)) + ((U[i][2] * a) * (1 - M2)));
  }

}

