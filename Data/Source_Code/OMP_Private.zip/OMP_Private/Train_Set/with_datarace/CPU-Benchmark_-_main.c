float fa[1024 * 1024];
float fb[1024 * 1024];
float fa1[1024 * 1024];
float fb1[1024 * 1024];
float fa2[1024 * 1024];
float fb2[1024 * 1024];
float fa3[1024 * 1024];
float fb3[1024 * 1024];
int main(int argc, char **argv)
{
  double istart;
  double iend;
  double itotal;
  double istart2;
  double iend2;
  double itotal2;
  double istart3;
  double iend3;
  double itotal3;
  double istart4;
  double iend4;
  double itotal4;
  double pstart;
  double pend;
  double ptotal;
  double pstart2;
  double pend2;
  double ptotal2;
  double pstart3;
  double pend3;
  double ptotal3;
  double pstart4;
  double pend4;
  double ptotal4;
  double gstart;
  double gend;
  double gtotal;
  double gstart2;
  double gend2;
  double gtotal2;
  double gstart3;
  double gend3;
  double gtotal3;
  double gstart4;
  double gend4;
  double gtotal4;
  int i;
  int j;
  int k;
  int thread_id;
  int nloops;
  int sum;
  int num = 1;
  int prime = 0;
  int limit = 500000;
  int numthreads;
  double gflops = 0.0;
  double gflops2 = 0.0;
  double gflops3 = 0.0;
  double gflops4 = 0.0;
  float a = 1.1;
  FILE *cpuinfo = fopen("/proc/cpuinfo", "rb");
  char *arg = 0;
  size_t size = 0;
  while (getdelim(&arg, &size, 0, cpuinfo) != (-1))
  {
    puts(arg);
  }

  free(arg);
  fclose(cpuinfo);
  char hostname[1024];
  struct utsname userinfo;
  if (uname(&userinfo) >= 0)
  {
    printf("\n***** System Details ******\n");
    printf("System Name    : %s\n", userinfo.sysname);
    printf("System Node    : %s\n", userinfo.nodename);
    printf("System Release : %s\n", userinfo.release);
    printf("System Version : %s\n", userinfo.version);
    printf("System Machine : %s\n", userinfo.machine);
  }
  else
    printf("\nSystem details fetch failed..\n");

  if (gethostname(&hostname, 1024) == 0)
  {
    printf("Hostname       : %s\n", hostname);
  }
  else
    printf("\nHostname details fetch failed..\n");

  int id = omp_get_max_threads();
  printf("No of Cores are %d\n", id);
  printf("\n\n");
  printf("============================================================================================================\n");
  printf("\t\t\t\t\t\tCPU BENCHMARKING\n");
  printf("============================================================================================================\n");
  printf("\t\t\tCORE 1\t\t\tCORE 2\t\t\tCORE 4\t\t\tCORE 8  \n");
  if (id == 1)
  {
    printf("\nITERATION\t\t");
    istart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend = omp_get_wtime();
    itotal = iend - istart;
    printf("%f\t\t", itotal);
    printf("\nPRIME\t\t\t");
    pstart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend = omp_get_wtime();
    ptotal = pend - pstart;
    printf("%f\t\t", ptotal);
    printf("\nGFLOPS\t\t");
    omp_set_num_threads(1);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa[i] = ((float) i) + 0.1;
      fb[i] = ((float) i) + 0.2;
    }

    gstart = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa[k + offset] = (a * fa[k + offset]) + fb[k + offset];
        }

      }

    }

    gend = omp_get_wtime();
    gflops = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal = gend - gstart;
    printf("   %lf\t\t %lf\t\t %lf\t\t", gflops, gflops2, gflops3);
    printf("\nTime\t\t   %lf\t\t %lf\t\t %lf\t\t", gtotal, gtotal2, gtotal3);
    printf("\nGflops/sec    \t   %lf\t\t %lf\t\t %lf\t\t", gflops / gtotal, gflops2 / gtotal2, gflops3 / gtotal3);
  }

  if (id == 2)
  {
    printf("\nITERATION\t\t");
    istart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend = omp_get_wtime();
    itotal = iend - istart;
    printf("%f\t\t", itotal);
    istart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend2 = omp_get_wtime();
    itotal2 = iend2 - istart2;
    printf("%f\t\t", itotal2);
    printf("\nPRIME\t\t\t");
    pstart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend = omp_get_wtime();
    ptotal = pend - pstart;
    printf("%f\t\t", ptotal);
    pstart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend2 = omp_get_wtime();
    ptotal2 = pend2 - pstart2;
    printf("%f\t\t", ptotal2);
    printf("\nGFLOPS\t\t");
    omp_set_num_threads(1);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa[i] = ((float) i) + 0.1;
      fb[i] = ((float) i) + 0.2;
    }

    gstart = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa[k + offset] = (a * fa[k + offset]) + fb[k + offset];
        }

      }

    }

    gend = omp_get_wtime();
    gflops = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal = gend - gstart;
    omp_set_num_threads(2);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa1[i] = ((float) i) + 0.1;
      fb1[i] = ((float) i) + 0.2;
    }

    gstart2 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa1[k + offset] = (a * fa1[k + offset]) + fb1[k + offset];
        }

      }

    }

    gend2 = omp_get_wtime();
    gflops2 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal2 = gend2 - gstart2;
    printf("   %lf\t\t %lf\t\t %lf\t\t", gflops, gflops2, gflops3);
    printf("\nTime\t\t   %lf\t\t %lf\t\t %lf\t\t", gtotal, gtotal2, gtotal3);
    printf("\nGflops/sec    \t   %lf\t\t %lf\t\t %lf\t\t", gflops / gtotal, gflops2 / gtotal2, gflops3 / gtotal3);
  }

  if (id == 4)
  {
    printf("\nITERATION\t\t");
    istart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend = omp_get_wtime();
    itotal = iend - istart;
    printf("%f\t\t", itotal);
    istart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend2 = omp_get_wtime();
    itotal2 = iend2 - istart2;
    printf("%f\t\t", itotal2);
    istart3 = omp_get_wtime();
    omp_set_num_threads(4);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend3 = omp_get_wtime();
    itotal3 = iend3 - istart3;
    printf("%f\t\t", itotal3);
    printf("\nPRIME\t\t\t");
    pstart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend = omp_get_wtime();
    ptotal = pend - pstart;
    printf("%f\t\t", ptotal);
    pstart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend2 = omp_get_wtime();
    ptotal2 = pend2 - pstart2;
    printf("%f\t\t", ptotal2);
    pstart3 = omp_get_wtime();
    omp_set_num_threads(4);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend3 = omp_get_wtime();
    ptotal3 = pend3 - pstart3;
    printf("%f\n", ptotal3);
    printf("\nGFLOPS\t\t");
    omp_set_num_threads(1);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa[i] = ((float) i) + 0.1;
      fb[i] = ((float) i) + 0.2;
    }

    gstart = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa[k + offset] = (a * fa[k + offset]) + fb[k + offset];
        }

      }

    }

    gend = omp_get_wtime();
    gflops = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal = gend - gstart;
    omp_set_num_threads(2);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa1[i] = ((float) i) + 0.1;
      fb1[i] = ((float) i) + 0.2;
    }

    gstart2 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa1[k + offset] = (a * fa1[k + offset]) + fb1[k + offset];
        }

      }

    }

    gend2 = omp_get_wtime();
    gflops2 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal2 = gend2 - gstart2;
    omp_set_num_threads(4);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa2[i] = ((float) i) + 0.1;
      fb2[i] = ((float) i) + 0.2;
    }

    gstart3 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa2[k + offset] = (a * fa2[k + offset]) + fb2[k + offset];
        }

      }

    }

    gend3 = omp_get_wtime();
    gflops3 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal3 = gend3 - gstart3;
    printf("   %lf\t\t %lf\t\t %lf\t\t", gflops, gflops2, gflops3);
    printf("\nTime\t\t   %lf\t\t %lf\t\t %lf\t\t", gtotal, gtotal2, gtotal3);
    printf("\nGflops/sec    \t   %lf\t\t %lf\t\t %lf\t\t", gflops / gtotal, gflops2 / gtotal2, gflops3 / gtotal3);
  }

  if (id == 8)
  {
    printf("\nITERATION\t\t");
    istart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend = omp_get_wtime();
    itotal = iend - istart;
    printf("%f\t\t", itotal);
    istart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend2 = omp_get_wtime();
    itotal2 = iend2 - istart2;
    printf("%f\t\t", itotal2);
    istart3 = omp_get_wtime();
    omp_set_num_threads(4);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend3 = omp_get_wtime();
    itotal3 = iend3 - istart3;
    printf("%f\t\t", itotal3);
    istart4 = omp_get_wtime();
    omp_set_num_threads(8);
    #pragma omp parallel for schedule(dynamic)
    for (i = 0; i < 400000; ++i)
    {
      for (j = 0; j <= 10000; j++)
      {
        sum = i + j;
      }

    }

    iend4 = omp_get_wtime();
    itotal4 = iend4 - istart4;
    printf("%f\t\t", itotal4);
    printf("\nPRIME\t\t\t");
    pstart = omp_get_wtime();
    omp_set_num_threads(1);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend = omp_get_wtime();
    ptotal = pend - pstart;
    printf("%f\t\t", ptotal);
    pstart2 = omp_get_wtime();
    omp_set_num_threads(2);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend2 = omp_get_wtime();
    ptotal2 = pend2 - pstart2;
    printf("%f\t\t", ptotal2);
    pstart3 = omp_get_wtime();
    omp_set_num_threads(4);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend3 = omp_get_wtime();
    ptotal3 = pend3 - pstart3;
    printf("%f\t\t", ptotal3);
    pstart4 = omp_get_wtime();
    omp_set_num_threads(8);
    #pragma omp parallel for schedule(dynamic) reduction(+:prime)
    for (num = 1; num < limit; num++)
    {
      int i = 2;
      while (i <= num)
      {
        if ((num % i) == 0)
          break;

        i++;
        if (i == num)
        {
          prime++;
        }

      }

    }

    pend4 = omp_get_wtime();
    ptotal4 = pend4 - pstart4;
    printf("%f\n", ptotal4);
    printf("GFLOPS\t\t\t");
    omp_set_num_threads(1);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa[i] = ((float) i) + 0.1;
      fb[i] = ((float) i) + 0.2;
    }

    gstart = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa[k + offset] = (a * fa[k + offset]) + fb[k + offset];
        }

      }

    }

    gend = omp_get_wtime();
    gflops = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal = gend - gstart;
    omp_set_num_threads(2);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa1[i] = ((float) i) + 0.1;
      fb1[i] = ((float) i) + 0.2;
    }

    gstart2 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa1[k + offset] = (a * fa1[k + offset]) + fb1[k + offset];
        }

      }

    }

    gend2 = omp_get_wtime();
    gflops2 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal2 = gend2 - gstart2;
    omp_set_num_threads(4);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa2[i] = ((float) i) + 0.1;
      fb2[i] = ((float) i) + 0.2;
    }

    gstart3 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa2[k + offset] = (a * fa2[k + offset]) + fb2[k + offset];
        }

      }

    }

    gend3 = omp_get_wtime();
    gflops3 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal3 = gend3 - gstart3;
    omp_set_num_threads(8);
    #pragma omp parallel for
    for (i = 0; i < (1024 * 1024); i++)
    {
      if (i == 0)
        numthreads = omp_get_num_threads();

      fa3[i] = ((float) i) + 0.1;
      fb3[i] = ((float) i) + 0.2;
    }

    gstart4 = omp_get_wtime();
    #pragma omp parallel for
    for (i = 0; i < numthreads; i++)
    {
      int offset = i * 128;
      for (j = 0; j < 100000000; j++)
      {
        for (k = 0; k < 128; k++)
        {
          fa3[k + offset] = (a * fa3[k + offset]) + fb3[k + offset];
        }

      }

    }

    gend4 = omp_get_wtime();
    gflops4 = (double) ((((1.0e-9 * numthreads) * 128) * 100000000) * 2);
    gtotal4 = gend4 - gstart4;
    printf("   %lf\t\t %lf\t\t %lf\t\t%lf\t\t", gflops, gflops2, gflops3, gflops4);
    printf("\nTime\t\t   %lf\t\t %lf\t\t %lf\t\t%lf\t\t", gtotal, gtotal2, gtotal3, gflops4);
    printf("\nGflops/sec    \t   %lf\t\t %lf\t\t %lf\t\t%lf\t\t", gflops / gtotal, gflops2 / gtotal2, gflops3 / gtotal3, gflops4 / gtotal4);
    printf("\n");
  }

  return 0;
}

