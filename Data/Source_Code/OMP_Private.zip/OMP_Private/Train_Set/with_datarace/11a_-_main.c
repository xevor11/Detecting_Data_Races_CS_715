int x;
int y;
int idx;
int main(int argc, const char *argv[])
{
  omp_set_num_threads(4);
  #pragma omp threadprivate(x)
  printf("Entering section 1\n");
  #pragma omp parallel
  {
    idx = omp_get_thread_num();
    x = idx;
    y = 10;
    printf("thread %d y = %d\n", x, y);
  }
  #pragma omp parallel
  {
    idx = omp_get_thread_num();
    x = idx;
    y = 100;
    printf("thread %d y = %d\n", x, y);
  }
  return 0;

  int *y = (int *) malloc((sizeof(int)) * n);
  int i;
  int j;
  #pragma omp parallel shared(A, x, n) private(i, j)
  {
    #pragma omp for
    for (i = 0; i < n; i++)
      y[i] = 0;

    #pragma omp for
    for (i = 0; i < n; i++)
      for (j = 0; j < n; j++)
      y[i] = y[i] + (A[(i * n) + j] * x[j]);


  }
  return y;
}

