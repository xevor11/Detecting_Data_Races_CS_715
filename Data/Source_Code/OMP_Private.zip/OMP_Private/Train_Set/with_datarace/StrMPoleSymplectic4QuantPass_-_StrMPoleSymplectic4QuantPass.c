struct elem
{
  double Length;
  double *PolynomA;
  double *PolynomB;
  int MaxOrder;
  int NumIntSteps;
  double Energy;
  int FringeQuadEntrance;
  int FringeQuadExit;
  double *fringeIntM0;
  double *fringeIntP0;
  double *R1;
  double *R2;
  double *T1;
  double *T2;
  double *RApertures;
  double *EApertures;
  double *KickAngle;
};
void StrMPoleSymplectic4QuantPass(double *r, double le, double *A, double *B, int max_order, int num_int_steps, int FringeQuadEntrance, int FringeQuadExit, double *fringeIntM0, double *fringeIntP0, double *T1, double *T2, double *R1, double *R2, double *RApertures, double *EApertures, double *KickAngle, double E0, int num_particles)
{
  double *r6;
  double SL;
  double L1;
  double L2;
  double K1;
  double K2;
  double dpp0;
  double ng;
  double ec;
  double de;
  double energy;
  double gamma;
  double cstec;
  double cstng;
  double s0;
  double ds;
  double rho;
  double dxp;
  double dyp;
  double xp0;
  double yp0;
  int c;
  int m;
  int i;
  int nph;
  double qe = 1.60217733e-19;
  double epsilon0 = 8.854187817e-12;
  double clight = 2.99792458e8;
  double emass = 510998.9461;
  double hbar = 1.054571726e-34;
  double pi = 3.14159265358979;
  double alpha0 = (qe * qe) / ((((4 * pi) * epsilon0) * hbar) * clight);
  bool useLinFrEleEntrance = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadEntrance == 2);
  bool useLinFrEleExit = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadExit == 2);
  SL = le / num_int_steps;
  L1 = SL * 0.6756035959798286638;
  L2 = SL * (-0.1756035959798286639);
  K1 = SL * 1.351207191959657328;
  K2 = SL * (-1.702414383919314656);
  if (KickAngle)
  {
    B[0] -= sin(KickAngle[0]) / le;
    A[0] += sin(KickAngle[1]) / le;
  }

  #pragma omp parallel for if (num_particles > OMP_PARTICLE_THRESHOLD) default(shared) shared(r,num_particles)
  for (c = 0; c < num_particles; c++)
  {
    r6 = r + (c * 6);
    if (!atIsNaN(r6[0]))
    {
      if (T1)
        ATaddvv(r6, T1);

      if (R1)
        ATmultmv(r6, R1);

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (FringeQuadEntrance && (B[1] != 0))
      {
        if (useLinFrEleEntrance)
          linearQuadFringeElegantEntrance(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassP(r6, B[1]);

      }

      for (m = 0; m < num_int_steps; m++)
      {
        r6 = r + (c * 6);
        dpp0 = r6[4];
        xp0 = r6[1] / (1 + r6[4]);
        yp0 = r6[3] / (1 + r6[4]);
        s0 = r6[5];
        ATdrift6(r6, L1);
        strthinkickrad(r6, A, B, K1, E0, max_order);
        ATdrift6(r6, L2);
        strthinkickrad(r6, A, B, K2, E0, max_order);
        ATdrift6(r6, L2);
        strthinkickrad(r6, A, B, K1, E0, max_order);
        ATdrift6(r6, L1);
        energy = (dpp0 * E0) + E0;
        gamma = energy / emass;
        cstec = ((((((3.0 * gamma) * gamma) * gamma) * clight) / 2.0) * hbar) / qe;
        cstng = (((5.0 * sqrt(3.0)) * alpha0) * gamma) / 6.0;
        dxp = (r6[1] / (1 + r6[4])) - xp0;
        dyp = (r6[3] / (1 + r6[4])) - yp0;
        ds = r6[5] - s0;
        rho = (SL + ds) / sqrt((dxp * dxp) + (dyp * dyp));
        ng = ((cstng * 1) / rho) * (SL + ds);
        ec = (cstec * 1) / rho;
        nph = poissonRandomNumber(ng);
        de = 0.0;
        if (nph > 0)
        {
          for (i = 0; i < nph; i++)
          {
            de = de + getEnergy(ec);
          }

          ;
        }

        ;
        r6[1] = (r6[1] / (1 + r6[4])) * ((1 + r6[4]) - (de / E0));
        r6[3] = (r6[3] / (1 + r6[4])) * ((1 + r6[4]) - (de / E0));
        r6[4] = r6[4] - (de / E0);
      }

      if (FringeQuadExit && (B[1] != 0))
      {
        if (useLinFrEleExit)
          linearQuadFringeElegantExit(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassN(r6, B[1]);

      }

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (R2)
        ATmultmv(r6, R2);

      if (T2)
        ATaddvv(r6, T2);

    }

  }

  if (KickAngle)
  {
    B[0] += sin(KickAngle[0]) / le;
    A[0] -= sin(KickAngle[1]) / le;
  }

}

