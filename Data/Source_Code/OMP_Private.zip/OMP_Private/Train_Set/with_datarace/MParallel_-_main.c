int main(int argc, char *argv[])
{
  int size;
  int debug = 0;
  int taskid;
  int numtasks;
  int nbthreads = 1;
  unsigned long start_time_lt;
  unsigned long initTime;
  unsigned long compTime;
  unsigned long sendTime;
  double start;
  double finish;
  char *resultFileName = 0;
  register int i;
  register int j;
  register int k;
  register double *A;
  register double *B;
  register double *C;
  for (k = 1; k < argc; ++k)
  {
    if (isdigit(argv[k][0]))
      size = atoi(argv[k]);
    else
      if (isdigit(argv[k][0]) && (size > 0))
    {
      nbthreads = atoi(argv[k]);
      omp_set_num_threads(nbthreads);
    }
    else
      if (strncmp(argv[k], "dump", 4) == 0)
      resultFileName = strchr(argv[k], '=');
    else
      if (debug = strncmp(argv[k], "debug", 5) == 0)
      fprintf(stderr, "debug is now on.\n");




  }

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &taskid);
  MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
  int stripe_height = size / numtasks;
  int extra_stripe_height = size % numtasks;
  int from = taskid * stripe_height;
  int to = (taskid + 1) * stripe_height;
  if (taskid == (numtasks - 1))
    to += extra_stripe_height;

  if ((taskid == 0) && debug)
    fprintf(stderr, "\nStart parallel MPI/OpenMP algorithm (size=%d)...\n", size);

  if (taskid == 0)
    start_time_lt = my_ftime();

  int stripe_size = stripe_height * size;
  int last_stripe_size = (extra_stripe_height * size) + stripe_size;
  if (taskid == 0)
  {
    A = allocate_real_matrix(size, -1);
    B = allocate_real_matrix(size, -1);
    C = allocate_real_matrix(size, -2);
  }
  else
  {
    A = allocate_real_matrix(size, -2);
    B = allocate_real_matrix(size, -2);
    C = allocate_real_matrix(size, -2);
  }

  MPI_Bcast(B, size * size, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  int *displs = (int *) malloc(numtasks * (sizeof(int)));
  int *scounts = (int *) malloc(numtasks * (sizeof(int)));
  for (i = 0; i < (numtasks - 1); ++i)
  {
    displs[i] = i * stripe_size;
    scounts[i] = stripe_size;
  }

  displs[i] = i * stripe_size;
  scounts[i] = last_stripe_size;
  if (taskid == 0)
    initTime = my_ftime() - start_time_lt;

  if (taskid == 0)
    MPI_Scatterv(A, scounts, displs, MPI_DOUBLE, MPI_IN_PLACE, stripe_size, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  else
    MPI_Scatterv(A, scounts, displs, MPI_DOUBLE, A + (from * size), (taskid == (numtasks - 1)) ? (last_stripe_size) : (stripe_size), MPI_DOUBLE, 0, MPI_COMM_WORLD);

  if (taskid == 0)
    sendTime = my_ftime() - start_time_lt;

  if ((taskid == 0) && debug)
  {
    fprintf(stderr, "Created and sent Matrices A, B and C of size %dx%d\n", size, size);
  }

  #pragma omp parallel shared(A,B,C)
  {
    #pragma omp for schedule(static)
    for (i = from; i < to; i++)
      for (j = 0; j < size; j++)
    {
      C[(i * size) + j] = 0;
      for (k = 0; k < size; k++)
        C[(i * size) + j] += A[(i * size) + k] * B[(k * size) + j];

    }


  }
  if (taskid == 0)
    MPI_Gatherv(MPI_IN_PLACE, stripe_size, MPI_DOUBLE, C, scounts, displs, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  else
    MPI_Gatherv(C + (from * size), (taskid == (numtasks - 1)) ? (last_stripe_size) : (stripe_size), MPI_DOUBLE, C, scounts, displs, MPI_DOUBLE, 0, MPI_COMM_WORLD);

  if (taskid == 0)
    compTime = (my_ftime() - start_time_lt) - initTime;

  if ((taskid == 0) && debug)
  {
    fprintf(stderr, "A[%dx%d]:\n", size, size);
    display(A, size, (size < 100) ? (size) : (100));
  }

  if ((taskid == 0) && debug)
  {
    fprintf(stderr, "B[%dx%d]:\n", size, size);
    display(B, size, (size < 100) ? (size) : (100));
  }

  if ((taskid == 0) && debug)
  {
    fprintf(stderr, "C[%dx%d]=A*B:\n", size, size);
    display(C, size, (size < 100) ? (size) : (100));
  }

  if (taskid == 0)
  {
    printf("Times (init, send and computing) = %.4g, %.4g, %.4g sec\n\n", initTime / 1000.0, sendTime / 1000.0, compTime / 1000.0);
    printf("size=%d\tinitTime=%g\tsendTime=%g\tcomputeTime=%g (%lu min, %lu sec)\n", size, initTime / 1000.0, sendTime / 1000.0, compTime / 1000.0, (compTime / 1000) / 60, (compTime / 1000) % 60);
  }

  if ((resultFileName != 0) && (taskid == 0))
  {
    ++resultFileName;
    if (debug)
      fprintf(stderr, "dumping result to %s\n", resultFileName);

    FILE *f = fopen(resultFileName, "w");
    if (f == 0)
      fprintf(stderr, "\nERROR OPENING result file - no results are saved !!\n");
    else
    {
      dump(C, size, f);
      fclose(f);
    }

  }

  if ((taskid == 0) && debug)
    fprintf(stderr, "Done!\n");

  free_real_matrix(A, size);
  free_real_matrix(B, size);
  free_real_matrix(C, size);
  free(scounts);
  free(displs);
  MPI_Finalize();
  return 0;

  double *datsin = malloc(N * (sizeof(double)));
  double *datcos = malloc(N * (sizeof(double)));
  double omega0 = f0 * 6.28318530717958647692528676655900576839433879875e-6;
  for (size_t k = 0; k < N; ++k)
  {
    datsin[k] = sin(omega0 * time[k]);
    datcos[k] = cos(omega0 * time[k]);
  }

  double alphasin = 0;
  double betasin = 0;
  double alphacos = 0;
  double betacos = 0;
  double ny = 0;
  size_t i;
  if (useweight == 0)
  {
    #pragma omp parallel default(shared) private(alphasin, betasin, alphacos, betacos, ny)
    {
      #pragma omp for schedule(static)
      for (i = 0; i < M; ++i)
      {
        ny = freq[i] * 6.28318530717958647692528676655900576839433879875e-6;
        windowalpbet(time, datsin, datcos, N, ny, &alphasin, &betasin, &alphacos, &betacos);
        window[i] = 0.5 * (((alphasin * alphasin) + (betasin * betasin)) + ((alphacos * alphacos) + (betacos * betacos)));
      }

    }
  }
  else
  {
    double sumweights = arr_sum(weight, N);
    #pragma omp parallel default(shared) private(alphasin, betasin, alphacos, betacos, ny)
    {
      #pragma omp for schedule(static)
      for (i = 0; i < M; ++i)
      {
        ny = freq[i] * 6.28318530717958647692528676655900576839433879875e-6;
        windowalpbetW(time, weight, datsin, datcos, N, ny, sumweights, &alphasin, &betasin, &alphacos, &betacos);
        window[i] = 0.5 * (((alphasin * alphasin) + (betasin * betasin)) + ((alphacos * alphacos) + (betacos * betacos)));
      }

    }
  }

  free(datsin);
  free(datcos);
}

