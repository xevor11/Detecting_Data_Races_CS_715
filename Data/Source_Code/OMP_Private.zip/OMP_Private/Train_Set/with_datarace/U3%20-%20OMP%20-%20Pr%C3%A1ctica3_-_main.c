ll mat[8][15];
int main()
{
  srand(time(0));
  omp_set_num_threads(4);
  ll i;
  ll j;
  ll v;
  for (i = 0; i < 8; i++)
  {
    for (j = 0; j < 8; j++)
    {
      v = (rand() % 20) + 1;
      mat[i][j] = (ll) v;
    }

  }

  for (i = 0; i < 8; i++)
  {
    for (j = 8; j < 15; j++)
    {
      mat[i][j] = mat[i][j - 8];
    }

  }

  ll r;
  ll c = 0;
  ll tot = 0;
  ll res;
  ll chunk = 2;
  ll tid;
  ll sum_diag = 0;
  ll sum_antdiag = 0;
  #pragma omp parallel shared(mat,chunk) reduction(+:sum_diag) reduction(+:sum_antdiag)
  {
    tid = omp_get_thread_num();
    tot = 0;
    sum_diag = (sum_antdiag = 0);
    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 8; i++)
    {
      res = 1;
      for (r = 0; r < 8; r++)
      {
        res = res * mat[r][r + i];
      }

      sum_diag += res;
    }

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 8; i++)
    {
      res = 1;
      for (r = 0; r < 8; r++)
      {
        res = res * mat[(8 - r) - 1][r + i];
      }

      sum_antdiag += res;
    }

  }
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    #pragma omp master
    {
      printf("Thread: %lld\n", tid);
      printf("Res: %lld - %lld = %lld\n", sum_diag, sum_antdiag, sum_diag - sum_antdiag);
    }
  }
  return 0;
}

