double rtclock();
void compare();
double A[128][128][128];
double B[128][128][128];
double C[128][128];
double RefOut[128][128];
int main()
{
  double clkbegin;
  double clkend;
  double t;
  int nt;
  int maxthr;
  int i;
  int j;
  int k;
  int l;
  printf("Matrix Size = %d\n", 128);
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
  {
    C[i][j] = (1.0 * (i + (0.25 * j))) / (128 + 1);
    for (k = 0; k < 128; k++)
    {
      A[i][j][k] = (1.0 * ((i + (0.25 * j)) - (0.125 * k))) / (128 + 1);
      B[i][j][k] = (1.0 * ((i - (0.5 * j)) + (0.125 * k))) / (128 + 1);
    }

  }


  clkbegin = rtclock();
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
    for (k = 0; k < 128; k++)
    for (l = k + 1; l < 128; l++)
    C[k][l] += 0.5 * ((A[l][i][j] * B[k][i][j]) + (A[k][i][j] * B[l][i][j]));




  clkend = rtclock();
  t = clkend - clkbegin;
  if ((C[128 / 2][128 / 2] * C[128 / 2][128 / 2]) < (-1000.0))
    printf("To foil dead-code elimination by compiler: should never get here\n");

  printf("Base Sequential: %.1f GFLOPS; Time = %.3f sec; \n", ((((((5.0 * 128) * 128) * 128) * (128 - 1)) / 2.0) / t) / 1.0e9, t);
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
    RefOut[i][j] = C[i][j];


  maxthr = omp_get_max_threads();
  printf("Maximum threads allowed by system is: %d\n", maxthr);
  for (nt = 1; nt <= maxthr; nt++)
  {
    omp_set_num_threads(nt);
    for (i = 0; i < 128; i++)
      for (j = 0; j < 128; j++)
    {
      C[i][j] = (1.0 * (i + (0.25 * j))) / (128 + 1);
      for (k = 0; k < 128; k++)
      {
        A[i][j][k] = (1.0 * ((i + (0.25 * j)) - (0.125 * k))) / (128 + 1);
        B[i][j][k] = (1.0 * ((i - (0.5 * j)) + (0.125 * k))) / (128 + 1);
      }

    }


    printf("Requesting thrds=%d\n", nt);
    clkbegin = rtclock();
    #pragma omp parallel
    {
      if ((omp_get_thread_num() == 0) && (omp_get_num_threads() != nt))
        printf("Warning: Actual #threads %d differs from requested number %d\n", omp_get_num_threads(), nt);

      #pragma omp for
      for (k = 0; k < 128; k++)
        for (l = k + 1; l < 128; l++)
        for (i = 0; i < 128; i++)
        for (j = 0; j < 128; j += 4)
      {
        C[k][l] += 0.5 * ((A[l][i][j] * B[k][i][j]) + (A[k][i][j] * B[l][i][j]));
        C[k][l] += 0.5 * ((A[l][i][j + 1] * B[k][i][j + 1]) + (A[k][i][j + 1] * B[l][i][j + 1]));
        C[k][l] += 0.5 * ((A[l][i][j + 2] * B[k][i][j + 2]) + (A[k][i][j + 2] * B[l][i][j + 2]));
        C[k][l] += 0.5 * ((A[l][i][j + 3] * B[k][i][j + 3]) + (A[k][i][j + 3] * B[l][i][j + 3]));
      }




    }
    clkend = rtclock();
    t = clkend - clkbegin;
    if ((C[128 / 2][128 / 2] * C[128 / 2][128 / 2]) < (-1000.0))
      printf("To foil dead-code elimination by compiler: should never get here\n");

    printf("%.1f GFLOPS with %d threads; Time = %.3f sec; \n", ((((((5.0 * 128) * 128) * 128) * (128 - 1)) / 2.0) / t) / 1.0e9, nt, t);
    compare();
  }


  double omega;
  int i;
  int j;
  int k;
  double resid;
  double ax;
  double ay;
  double b;
  static double error;
  omega = relax;
  ax = 1.0 / (dx * dx);
  ay = 1.0 / (dy * dy);
  b = (((-2.0) / (dx * dx)) - (2.0 / (dy * dy))) - alpha;
  error = 10.0 * tol;
  k = 1;
  while ((k <= mits) && (error > tol))
  {
    error = 0.0;
    #pragma omp parallel
    {
      #pragma omp for private(j,i)
      for (i = 0; i < n; i++)
      {
        for (j = 0; j < m; j++)
        {
          uold[i][j] = u[i][j];
        }

      }

      #pragma omp for private(resid,j,i) nowait
      for (i = 1; i < (n - 1); i++)
      {
        for (j = 1; j < (m - 1); j++)
        {
          resid = ((((ax * (uold[i - 1][j] + uold[i + 1][j])) + (ay * (uold[i][j - 1] + uold[i][j + 1]))) + (b * uold[i][j])) - f[i][j]) / b;
          u[i][j] = uold[i][j] - (omega * resid);
          #pragma omp critical
          {
            error = error + (resid * resid);
          }
        }

      }

    }
    k = k + 1;
    if ((k % 500) == 0)
      printf("** Finished %d iteration.\n", k);

    printf("Finished %d iteration.\n", k);
    error = sqrt(error) / (n * m);
  }

  printf("Total Number of Iterations:%d\n", k);
  printf("Residual:%E\n", error);
}

