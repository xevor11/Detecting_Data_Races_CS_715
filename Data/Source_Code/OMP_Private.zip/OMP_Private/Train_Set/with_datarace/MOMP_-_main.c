int main(int argc, char *argv[])
{
  int size;
  int debug = 0;
  unsigned long start_time_lt;
  unsigned long initTime;
  unsigned long compTime;
  char *resultFileName = 0;
  register int i;
  register int j;
  register int k;
  for (k = 1; k < argc; ++k)
  {
    if (isdigit(argv[k][0]))
      size = atoi(argv[k]);
    else
      if (strncmp(argv[k], "dump", 4) == 0)
      resultFileName = strchr(argv[k], '=');
    else
      if (debug = strncmp(argv[k], "debug", 5) == 0)
      fprintf(stderr, "debug is now on.\n");



  }

  if (debug)
    fprintf(stderr, "\nStart sequential standard algorithm (size=%d)...\n", size);

  start_time_lt = my_ftime();
  register double *A = allocate_real_matrix(size, -1);
  register double *B = allocate_real_matrix(size, -1);
  register double *C = allocate_real_matrix(size, -2);
  if (debug)
    fprintf(stderr, "Created Matrices A, B and C of size %dx%d\n", size, size);

  initTime = my_ftime() - start_time_lt;
  #pragma omp parallel shared(A,B,C)
  {
    #pragma omp for schedule(static)
    for (i = 0; i < size; i++)
    {
      for (j = 0; j < size; j++)
      {
        C[(i * size) + j] = 0;
        for (k = 0; k < size; k++)
        {
          C[(i * size) + j] += A[(i * size) + k] * B[(k * size) + j];
        }

      }

    }

  }
  compTime = (my_ftime() - start_time_lt) - initTime;
  if (debug)
  {
    fprintf(stderr, "A[%dx%d]:\n", size, size);
    display(A, size, (size < 100) ? (size) : (100));
  }

  if (debug)
  {
    fprintf(stderr, "B[%dx%d]:\n", size, size);
    display(B, size, (size < 100) ? (size) : (100));
  }

  printf("Times (init and computing) = %.4g, %.4g sec\n\n", initTime / 1000.0, compTime / 1000.0);
  printf("size=%d\tinitTime=%g\tcomputeTime=%g (%lu min, %lu sec)\n", size, initTime / 1000.0, compTime / 1000.0, (compTime / 1000) / 60, (compTime / 1000) % 60);
  if (debug)
  {
    fprintf(stderr, "C[%dx%d]=A*B:\n", size, size);
    display(C, size, (size < 100) ? (size) : (100));
  }

  if (resultFileName != 0)
  {
    ++resultFileName;
    if (debug)
      fprintf(stderr, "dumping result to %s\n", resultFileName);

    FILE *f = fopen(resultFileName, "w");
    if (f == 0)
      fprintf(stderr, "\nERROR OPENING result file - no results are saved !!\n");
    else
    {
      dump(C, size, f);
      fclose(f);
    }

  }

  if (debug)
    fprintf(stderr, "Done!\n");

  return 0;
}

