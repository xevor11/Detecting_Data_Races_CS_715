struct resampled *PI0;
static double ct[128];
static int Ltmp = 64;
void arbitrary_mom_eval(double **xavg, struct resampled **bootavg, struct mom_info **mominfo, struct input_params *INPARAMS, const int NSLICES, const int LT, const bool renormalise)
{
  printf("\n--> Arbitrary mom evaluation <--\n");
  printf("\n--> Renormalising <--\n");
  size_t i;
  for (i = 0; i < NSLICES; i++)
  {
    size_t j;
    for (j = 0; j < INPARAMS->NDATA[i]; j++)
    {
      mult_constant(&bootavg[i][j], INPARAMS->quarks[0].ZV);
    }

  }

  make_xmgrace_graph("corrs.agr", "( aq )\\S2\\N", "\\xP\\f{}");
  for (i = 0; i < (NSLICES / 4); i++)
  {
    plot_data(bootavg[i], xavg[i], INPARAMS->NDATA[i]);
  }

  close_xmgrace_graph();
  PI0 = malloc((NSLICES / 4) * (sizeof(struct resampled)));
  for (i = 0; i < (NSLICES / 4); i++)
  {
    PI0[i] = compute_PI0(bootavg[i], INPARAMS->dimensions[i][3]);
    printf("%e %e \n", pow(INPARAMS->dimensions[i][3] * INPARAMS->quarks[0].ainverse, 2), PI0[i].avg);
  }

  for (i = 0; i < (NSLICES / 4); i++)
  {
    int L;
    for (L = 16; L <= INPARAMS->dimensions[i][3]; L++)
    {
      struct resampled *PIS = compute_PIS(bootavg[i], 12, L, HPQCD_MOMENTS, INPARAMS->mom_type);
      printf("%e %e %e\n", (double) L, PIS[0].avg, PIS[0].err);
    }

    printf("\n");
  }

  printf("\n--> Integrating amu <--\n");
  struct resampled **data = malloc(NSLICES * (sizeof(struct resampled *)));
  double **x = malloc(NSLICES * (sizeof(double *)));
  make_xmgrace_graph("data.agr", "( aq )\\S2\\N", "\\xP\\f{}");
  for (i = 0; i < (NSLICES / 4); i++)
  {
    const double max = (INPARAMS->dimensions[i][3] / 2) - 1;
    const int range = 300;
    const double granularity = max / range;
    x[i] = malloc(range * (sizeof(double)));
    data[i] = malloc(range * (sizeof(struct resampled)));
    int j;
    #pragma omp parallel for
    for (j = 0; j < range; j++)
    {
      double q = j * granularity;
      double lmom;
      data[i][j] = arbq(&lmom, bootavg[i], q, INPARAMS->dimensions[i][3]);
      add(&data[i][j], PI0[i]);
      x[i][j] = lmom * lmom;
    }

    plot_data(data[i], x[i], range);
    plot_data(bootavg[((2 * NSLICES) / 4) + i], xavg[((2 * NSLICES) / 4) + i], INPARAMS->NDATA[((2 * NSLICES) / 4) + i]);
  }

  close_xmgrace_graph();
  return;
}

