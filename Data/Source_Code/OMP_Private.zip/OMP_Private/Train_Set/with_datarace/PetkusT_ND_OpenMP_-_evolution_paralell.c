const int MAX_ROW = 200;
const int MAX_COL = 200;
const int counter_hit = 100;
void evolution(int (*pop)[MAX_COL], int generation);
void evolution_paralell(int (*pop)[MAX_COL]);
void evolution_paralell_chaos(int (*pop)[MAX_COL]);
void print(int (*pop)[MAX_COL], int generation);
int generation_pass(int (*pop)[MAX_COL], int i, int j);
int check_neighbour(int pop);
void evolution_paralell(int (*pop)[MAX_COL])
{
  int gijosNr = omp_get_thread_num();
  int i = 0;
  omp_set_num_threads(MAX_ROW * MAX_COL);
  #pragma omp parallel
  {
    gijosNr = omp_get_thread_num();
    int row = gijosNr / MAX_ROW;
    int col = gijosNr - (MAX_ROW * row);
    pop[row][col] = generation_pass(pop, row, col);
  }
}

