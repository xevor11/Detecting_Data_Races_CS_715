int main(int argc, char *argv[])
{
  int i;
  int j;
  #pragma omp for collapse(2) private(i, j)
  for (i = 0; i < 600; ++i)
  {
    for (j = 0; j < 1000; ++j)
    {
      arr[i][j] = 0;
    }

  }

  #pragma omp single
  {
    char c = '5';
    switch (c - '0')
    {
      case 1:
        arr[31][32] = 1;
        arr[32][31] = 1;
        arr[32][32] = 1;
        arr[34][31] = 1;
        arr[35][31] = 1;
        arr[36][31] = 1;
        arr[32][34] = 1;
        arr[34][34] = 1;
        arr[33][35] = 1;
        arr[33][36] = 1;
        break;

      case 2:
        arr[1][25] = 1;
        arr[2][23] = 1;
        arr[2][25] = 1;
        arr[3][13] = 1;
        arr[3][14] = 1;
        arr[3][21] = 1;
        arr[3][22] = 1;
        arr[3][35] = 1;
        arr[3][36] = 1;
        arr[4][12] = 1;
        arr[4][16] = 1;
        arr[4][21] = 1;
        arr[4][22] = 1;
        arr[4][35] = 1;
        arr[4][36] = 1;
        arr[5][1] = 1;
        arr[5][2] = 1;
        arr[5][11] = 1;
        arr[5][17] = 1;
        arr[5][21] = 1;
        arr[5][22] = 1;
        arr[6][1] = 1;
        arr[6][2] = 1;
        arr[6][11] = 1;
        arr[6][15] = 1;
        arr[6][17] = 1;
        arr[6][18] = 1;
        arr[6][23] = 1;
        arr[6][25] = 1;
        arr[7][11] = 1;
        arr[7][17] = 1;
        arr[7][25] = 1;
        arr[8][12] = 1;
        arr[8][16] = 1;
        arr[9][13] = 1;
        arr[9][14] = 1;
        arr[10][24] = 1;
        arr[11][25] = 1;
        arr[11][26] = 1;
        arr[12][24] = 1;
        arr[12][25] = 1;
        arr[18][31] = 1;
        arr[18][33] = 1;
        arr[19][32] = 1;
        arr[19][33] = 1;
        arr[20][32] = 1;
        break;

      case 3:
        arr[15][11] = 1;
        arr[15][12] = 1;
        arr[16][12] = 1;
        arr[14][17] = 1;
        arr[16][16] = 1;
        arr[16][17] = 1;
        arr[16][18] = 1;
        break;

      case 4:
        arr[50][21] = 1;
        arr[50][22] = 1;
        arr[51][22] = 1;
        arr[27][23] = 1;
        arr[28][24] = 1;
        arr[28][25] = 1;
        arr[29][24] = 1;
        arr[34][28] = 1;
        arr[34][29] = 1;
        arr[35][29] = 1;
        arr[21][35] = 1;
        arr[21][36] = 1;
        arr[21][37] = 1;
        arr[29][40] = 1;
        arr[30][40] = 1;
        arr[31][40] = 1;
        arr[32][41] = 1;
        arr[33][41] = 1;
        arr[33][40] = 1;
        break;

      default:
        arr[0][0] = 1;
        arr[1][1] = 1;
        arr[1][2] = 1;
        arr[2][0] = 1;
        arr[2][1] = 1;
        break;

    }

  }

  int M = 500;
  int N = 500;
  double diff;
  double err_tol = 0.001;
  int i;
  int itr;
  int itr_print;
  int j;
  double mean;
  double obtd_diff;
  double u[M][N];
  double w[M][N];
  double wtime;
  printf("\n");
  printf("HEATED_PLATE_OPENMP\n");
  printf("  Parallel version\n");
  printf("A program to solve the steady state temperature distribution in a 2D rectangular plate\n");
  printf("\n");
  printf("  Spatial grid of %d by %d points.\n", M, N);
  printf("  The iteration will be repeated until the change is <= %e\n", err_tol);
  omp_set_num_threads(4);
  #pragma omp parallel
  #pragma omp master
  {
    printf("  Number of threads available =%d\n", omp_get_num_threads());
  }
  mean = 0.0;
  #pragma omp parallel shared ( w )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j] = 0.0;
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = (mean + w[i][0]) + w[i][N - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = (mean + w[M - 1][j]) + w[0][j];
    }

  }
  mean = mean / ((double) (((2 * M) + (2 * N)) - 4));
  printf("\n");
  printf("  Mean Temperature = %f\n", mean);
  #pragma omp parallel shared ( mean, w )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      for (j = 1; j < (N - 1); j++)
      {
        w[i][j] = mean;
      }

    }

  }
  itr = 0;
  itr_print = 1;
  printf("\n");
  printf(" Iteration  Change in temperature\n");
  printf("\n");
  wtime = omp_get_wtime();
  diff = err_tol;
  while (err_tol <= diff)
  {
    #pragma omp parallel shared ( u, w )
    {
      #pragma omp for
      for (i = 0; i < M; i++)
      {
        for (j = 0; j < N; j++)
        {
          u[i][j] = w[i][j];
        }

      }

      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          w[i][j] = (((u[i - 1][j] + u[i + 1][j]) + u[i][j - 1]) + u[i][j + 1]) / 4.0;
        }

      }

    }
    diff = 0.0;
    #pragma omp parallel shared ( diff, u, w )
    {
      obtd_diff = 0.0;
      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          if (obtd_diff < fabs(w[i][j] - u[i][j]))
          {
            obtd_diff = fabs(w[i][j] - u[i][j]);
          }

        }

      }

      #pragma omp critical
      {
        if (diff < obtd_diff)
        {
          diff = obtd_diff;
        }

      }
    }
    itr++;
    if (itr == itr_print)
    {
      printf("  %8d  %f\n", itr, diff);
      itr_print = 2 * itr_print;
    }

  }

  wtime = omp_get_wtime() - wtime;
  printf("\n");
  printf("  %8d  %f\n", itr, diff);
  printf("\n");
  printf("  Error tolerance achieved.\n");
  printf("  Wallclock time = %f\n", wtime);
  printf("\n");
  printf("HEATED_PLATE_OPENMP:\n");
  printf("  Normal end of execution.\n");
  return 0;
}

