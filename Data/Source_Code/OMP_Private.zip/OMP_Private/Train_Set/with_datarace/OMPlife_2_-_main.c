int i;
int j;
int n;
int im;
int ip;
int jm;
int jp;
int nsum;
int isum;
int offset;
int **old;
int **new;
float x;
int id;
int iBound;
clock_t timer;
clock_t start_timer;
clock_t end_timer;
int main(int argc, char *argv[])
{
  old = malloc(1000 * (sizeof(int *)));
  new = malloc(1000 * (sizeof(int *)));
  time_t start_time;
  time_t end_time;
  double total_run_time;
  stopWatch();
  omp_set_num_threads(8);
  #pragma omp parallel for schedule(static)
  for (i = 0; i < 1000; i++)
  {
    old[i] = malloc(1000 * (sizeof(int)));
    new[i] = malloc(1000 * (sizeof(int)));
  }

  #pragma omp parallel
  {
    id = omp_get_thread_num();
    srand(id);
    for (i = 0; i < 1000; i++)
    {
      #pragma omp for schedule(static)
      for (j = 0; j < 1000; j++)
      {
        x = rand() / (((float) 32767) + 1);
        if (x < 0.5)
        {
          old[i][j] = 0;
        }
        else
        {
          old[i][j] = 1;
        }

      }

    }

  }
  for (n = 0; n < 500; n++)
  {
    doTimeStep(n);
  }

  printf("Total running time: %.20f.\n", stopWatch() / CLOCKS_PER_SEC);
  getchar();
  return 0;
}

