void rho_k(const double x_vec[][3], int N_x, const double k_vec[][3], int N_k, double (* restrict rho_k)[2])
{
  int x_i;
  int k_i;
  double rho_ki_0;
  double rho_ki_1;
  double factor = 1.0 / sqrt((double) N_x);
  register double alpha;
  #pragma omp parallel for shared(rho_k, x_vec, k_vec, factor)
  for (k_i = 0; k_i < N_k; k_i++)
  {
    rho_ki_0 = 0.0;
    rho_ki_1 = 0.0;
    for (x_i = 0; x_i < N_x; x_i++)
    {
      alpha = ((x_vec[x_i][0] * k_vec[k_i][0]) + (x_vec[x_i][1] * k_vec[k_i][1])) + (x_vec[x_i][2] * k_vec[k_i][2]);
      rho_ki_0 += cos(alpha);
      rho_ki_1 += sin(alpha);
    }

    rho_k[k_i][0] = factor * rho_ki_0;
    rho_k[k_i][1] = factor * rho_ki_1;
  }

}

