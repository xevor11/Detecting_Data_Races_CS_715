void dumpA(char *, int [], int);
int randint(int);
void count_sort(int [], int);
void parallel_count_sort(int [], int);
void qsort_wrapper(int [], int);
int cmp_int(const void *, const void *);
double timed_sort(void (*)(int [], int), int [], int);
struct timespec diff(struct timespec, struct timespec);
int no_threads = 4;
enum sort_type {SERIAL, PARALLEL, QSORT};
void parallel_count_sort(int a[], int n)
{
  int i;
  int j;
  int count;
  int *temp = malloc(n * (sizeof(int)));
  #pragma omp parallel num_threads(no_threads) default(none) shared(a, n, temp)
  #pragma omp for
  for (i = 0; i < n; i++)
  {
    count = 0;
    for (j = 0; j < n; j++)
    {
      if (a[j] < a[i])
        count++;
      else
        if ((a[j] == a[i]) && (j < i))
        count++;


    }

    temp[count] = a[i];
  }

  #pragma omp for
  for (i = 0; i < n; i++)
  {
    memcpy(a + i, temp + i, sizeof(int));
  }

  free(temp);
}

