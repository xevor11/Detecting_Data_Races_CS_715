int main(int argc, char *argv[])
{
  float A[10][10];
  float b[10];
  float c[10];
  float total;
  int i;
  int j;
  total = 0.0;
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      A[i][j] = (j + 1) * 1.0;

    b[i] = 1.0 * (i + 1);
    c[i] = 0.0;
  }

  printf("\nStarting values of matrix A and vector b:\n");
  for (i = 0; i < 10; i++)
  {
    printf("  A[%d]= ", i);
    for (j = 0; j < 10; j++)
      printf("%.1f ", A[i][j]);

    printf("  b[%d]= %.1f\n", i, b[i]);
  }

  printf("\nIntermediate results:\n");
  #pragma omp parallel for private(j)
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
      c[i] += A[i][j] * b[j];

    printf("Hello, I am %d and I just calculated %.2f.\n", omp_get_thread_num(), c[i]);
    #pragma omp atomic update
    total += c[i];
  }

  printf("\nMatrix-vector total - sum of all c[] = %.2f\n\n", total);
  return 0;

  int nthreads;
  int tid;
  printf("Hello there!, I'm the master of the universe!\n");
  #pragma omp parallel num_threads(24)
  {
    char hostname[1024];
    tid = omp_get_thread_num();
    gethostname(hostname, 1024);
    printf("Hello World from thread = %d at machine [%s]\n", tid, hostname);
    if (omp_get_thread_num() == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d at machine [%s]\n", nthreads, hostname);
    }

  }
  printf("Good bye from the the master of the universe!\n");
}

