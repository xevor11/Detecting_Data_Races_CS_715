double v1[100000000];
double v2[100000000];
double v3[100000000];
int tama;
int main(int argc, char **argv)
{
  int i;
  int c;
  struct timespec cgt1;
  struct timespec cgt2;
  double t1;
  double t2;
  double tfin;
  if (argc < 2)
  {
    printf("Faltan no componentes del vector\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  tama = N;
  c = (N / 4) + 1;
  #pragma omp parallel sections
  {
    #pragma omp section
    (void) inicializaVector1();
    #pragma omp section
    (void) inicializaVector2();
  }
  t1 = omp_get_wtime();
  #pragma omp parallel sections
  {
    #pragma omp section
    for (i = 0; i < c; i++)
      v3[i] = v1[i] + v2[i];

    #pragma omp section
    for (i = c; i < (2 * c); i++)
      v3[i] = v1[i] + v2[i];

    #pragma omp section
    for (i = 2 * c; i < (3 * c); i++)
      v3[i] = v1[i] + v2[i];

    #pragma omp section
    for (i = 3 * c; i < N; i++)
      v3[i] = v1[i] + v2[i];

  }
  t2 = omp_get_wtime();
  tfin = t2 - t1;
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n", tfin, N);
  return 0;
}

