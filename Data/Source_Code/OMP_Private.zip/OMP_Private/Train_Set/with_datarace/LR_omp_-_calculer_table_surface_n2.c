{
  int x;
  int y;
} Point;
long long calculer_table_surface_n2(Point *table_points, int n)
{
  int i;
  int left;
  int right;
  long long max_surface = 0;
  long long surface = 0;
  long long max_surface1 = 0;
  long long surface1 = 0;
  int min_y = table_points[0].y;
  #pragma omp parallel shared(max_surface,table_points)
  {
    #pragma omp for schedule(dynamic,10) reduction(max:max_surface)
    for (i = 1; i < (n - 1); i++)
    {
      left = i - 1;
      while (table_points[left].x == table_points[i].x)
      {
        left--;
      }

      while ((table_points[i].y <= table_points[left].y) && (left > 0))
      {
        left--;
      }

      min_y = table_points[i].y;
      right = i + 1;
      while (table_points[right].x == table_points[i].x)
      {
        right++;
      }

      while ((table_points[i].y <= table_points[right].y) && (right < (n - 1)))
      {
        right++;
      }

      surface = ((long long) min_y) * ((long long) (table_points[right].x - table_points[left].x));
      surface1 = ((long long) (table_points[i + 1].x - table_points[i].x)) * ((long long) table_points[0].y);
      max_surface1 = max(surface, surface1);
      max_surface = max(max_surface, max_surface1);
    }

  }
  return max_surface;

  int ii;
  int jj;
  #pragma omp parallel for default(shared) private(jj,ii)
  for (ii = 0; ii < nsamps; ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[(ii * nchans) + jj] = (inbuffer[(ii * nchans) + jj] / factbuffer[jj]) - plusbuffer[jj];
      if (inbuffer[(ii * nchans) + jj] > flagMax[jj])
        flagbuffer[(ii * nchans) + jj] = 2;
      else
        if (inbuffer[(ii * nchans) + jj] < flagMin[jj])
        flagbuffer[(ii * nchans) + jj] = 0;
      else
        flagbuffer[(ii * nchans) + jj] = 1;


    }

  }

}

