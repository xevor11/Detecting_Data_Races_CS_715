double RB_GS_OmpLoopV1(double **black, double **red, int m, int n, double eps, int maxit, int iterations_print, int *iterations)
{
  int i;
  int j;
  double v;
  double my_diff;
  double my_diffR;
  double my_diffB;
  double diff = eps;
  while ((eps <= diff) && ((*iterations) < maxit))
  {
    diff = 0.0;
    #pragma omp parallel
    {
      my_diffB = 0.0;
      #pragma omp for schedule(OMP_SCHED)
      for (i = 1; i < (m - 1); i++)
        for (j = i % 2; j < ((n / 2) - ((i + 1) % 2)); j++)
      {
        v = 0.25 * (((red[i - 1][j] + red[i + 1][j]) + red[i][j - (i % 2)]) + red[i][j + ((i + 1) % 2)]);
        if (my_diffB < fabs(v - black[i][j]))
          my_diffB = fabs(v - black[i][j]);

        black[i][j] = v;
      }


      my_diffR = 0.0;
      #pragma omp for schedule(OMP_SCHED) nowait
      for (i = 1; i < (m - 1); i++)
        for (j = (i + 1) % 2; j < ((n / 2) - (i % 2)); j++)
      {
        v = 0.25 * (((black[i - 1][j] + black[i + 1][j]) + black[i][j - ((i + 1) % 2)]) + black[i][j + (i % 2)]);
        if (my_diffR < fabs(v - red[i][j]))
          my_diffR = fabs(v - red[i][j]);

        red[i][j] = v;
      }


      my_diff = (my_diffB < my_diffR) ? (my_diffR) : (my_diffB);
      #pragma omp barrier
      if (diff < my_diff)
        #pragma omp atomic write

      diff = my_diff;
    }
    (*iterations)++;
  }

  return diff;
}

