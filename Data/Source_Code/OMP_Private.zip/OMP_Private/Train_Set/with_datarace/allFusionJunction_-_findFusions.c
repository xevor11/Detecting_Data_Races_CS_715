static struct optionSpec options[] = {{"minSpan", OPTION_INT}, {"minOverlap", OPTION_INT}, {0, 0}};
static int MINSPAN;
static int MINJ;
void findFusions(char *regions, char *geneList, char *dir, char *fileName, char *bin)
{
  FILE *fp = 0;
  char buf[500];
  char dirName[500];
  int i;
  int total;
  fp = mustOpen(regions, "r");
  total = 0;
  while (fgets(buf, 500, fp))
    ++total;

  fclose(fp);
  #pragma omp parallel for
  for (i = 1; i <= total; i++)
  {
    sprintf(dirName, "%s/R%d", dir, i);
    do_cmd("%s/singleFusionJunction -minOverlap=%d -minSpan=%d %s %s %s/output/out.junctions", bin, MINJ, MINSPAN, geneList, dirName, dirName);
    do_cmd("%s/ifJunctionAnnotated.pl %s/output/final.sam %s/output/out.junctions > %s/output/out.fusions", bin, dirName, dirName, dirName);
    if (strcmp(regions, "RG"))
      do_cmd("%s/fusionInterpret.pl %s/output/out.fusions Z_known.exon.intron %s/output", bin, dirName, dirName);

  }

  for (i = 1; i <= total; i++)
  {
    sprintf(dirName, "%s/R%d", dir, i);
    if (i == 1)
      do_cmd("cat %s/output/out.fusions > %s", dirName, fileName);
    else
      do_cmd("cat %s/output/out.fusions >> %s", dirName, fileName);

  }

}

