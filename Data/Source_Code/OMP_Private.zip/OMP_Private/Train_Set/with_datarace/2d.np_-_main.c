int main(int argc, char *argv[])
{
  struct timeval start;
  struct timeval end;
  long int t;
  long int i;
  long int j;
  int NX = atoi(argv[1]);
  int NY = atoi(argv[2]);
  int T = atoi(argv[3]);
  int Bx = atoi(argv[4]);
  int By = atoi(argv[5]);
  int tb = atoi(argv[6]);
  if (((((Bx < ((2 * 1) + 1)) || (By < ((2 * 1) + 1))) || (Bx > NX)) || (By > NY)) || (tb > (((((Bx - 1) / 2) / 1) < (((By - 1) / 2) / 1)) ? (((Bx - 1) / 2) / 1) : (((By - 1) / 2) / 1))))
  {
    return 0;
  }

  double (*A)[NX + (2 * 1)][NY + (2 * 1)] = (double (*)[NX + (2 * 1)][NY + (2 * 1)]) malloc((((sizeof(double)) * (NX + (2 * 1))) * (NY + (2 * 1))) * 2);
  if (0 == A)
    return 0;

  srand(100);
  for (i = 0; i < (NX + (2 * 1)); i++)
  {
    for (j = 0; j < (NY + (2 * 1)); j++)
    {
      A[0][i][j] = (double) (1.0 * (rand() % 1024));
      A[1][i][j] = 0;
    }

  }

  int bx = Bx - (2 * (tb * 1));
  int by = By - (2 * (tb * 1));
  int ix = Bx + bx;
  int iy = By + by;
  int xnb0 = ceil(((double) NX) / ((double) ix));
  int ynb0 = ceil(((double) NY) / ((double) iy));
  int xnb11 = ceil(((double) ((NX - (ix / 2)) + 1)) / ((double) ix)) + 1;
  int ynb12 = ceil(((double) ((NY - (iy / 2)) + 1)) / ((double) iy)) + 1;
  int xnb12 = xnb0;
  int ynb11 = ynb0;
  int xnb2 = (xnb11 > xnb0) ? (xnb11) : (xnb0);
  int ynb2 = (ynb12 > ynb0) ? (ynb12) : (ynb0);
  int nb1[2] = {xnb12 * ynb12, xnb11 * ynb11};
  int nb02[2] = {xnb2 * ynb2, xnb0 * ynb0};
  int xnb1[2] = {xnb12, xnb11};
  int xnb02[2] = {xnb2, xnb0};
  int xleft02[2] = {1 - bx, 1 + ((Bx - bx) / 2)};
  int ybottom02[2] = {1 - by, 1 + ((By - by) / 2)};
  int xleft11[2] = {1 + ((Bx - bx) / 2), 1 - bx};
  int ybottom11[2] = {1 - ((By + by) / 2), 1};
  int xleft12[2] = {1 - ((Bx + bx) / 2), 1};
  int ybottom12[2] = {1 + ((By - by) / 2), 1 - by};
  int level = 1;
  int tt;
  int n;
  int x;
  int y;
  register int ymin;
  register int ymax;
  int xmin;
  int xmax;
  gettimeofday(&start, 0);
  for (tt = -tb; tt < T; tt += tb)
  {
    #pragma omp parallel for schedule(dynamic)
    for (n = 0; n < nb02[level]; n++)
    {
      for (t = (tt > 0) ? (tt) : (0); t < (((tt + (2 * tb)) < T) ? (tt + (2 * tb)) : (T)); t++)
      {
        xmin = (1 > (((xleft02[level] + ((n % xnb02[level]) * ix)) - (tb * 1)) + ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1))) ? (1) : (((xleft02[level] + ((n % xnb02[level]) * ix)) - (tb * 1)) + ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1));
        xmax = ((NX + 1) < ((((xleft02[level] + ((n % xnb02[level]) * ix)) + bx) + (tb * 1)) - ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1))) ? (NX + 1) : ((((xleft02[level] + ((n % xnb02[level]) * ix)) + bx) + (tb * 1)) - ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1));
        ymin = (1 > (((ybottom02[level] + ((n / xnb02[level]) * iy)) - (tb * 1)) + ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1))) ? (1) : (((ybottom02[level] + ((n / xnb02[level]) * iy)) - (tb * 1)) + ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1));
        ymax = ((NY + 1) < ((((ybottom02[level] + ((n / xnb02[level]) * iy)) + by) + (tb * 1)) - ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1))) ? (NY + 1) : ((((ybottom02[level] + ((n / xnb02[level]) * iy)) + by) + (tb * 1)) - ((((t + 1) > (tt + tb)) ? ((t + 1) - (tt + tb)) : ((tt + tb) - (t + 1))) * 1));
        for (x = xmin; x < xmax; x++)
        {
          #pragma simd
          for (y = ymin; y < ymax; y++)
          {
            A[(t + 1) % 2][x][y] = ((0.125 * ((A[t % 2][x + 1][y] - (2.0 * A[t % 2][x][y])) + A[t % 2][x - 1][y])) + (0.125 * ((A[t % 2][x][y + 1] - (2.0 * A[t % 2][x][y])) + A[t % 2][x][y - 1]))) + A[t % 2][x][y];
            ;
          }

        }

      }

    }

    #pragma omp parallel for schedule(dynamic)
    for (n = 0; n < (nb1[0] + nb1[1]); n++)
    {
      for (t = tt + tb; t < (((tt + (2 * tb)) < T) ? (tt + (2 * tb)) : (T)); t++)
      {
        if (n < nb1[level])
        {
          xmin = (1 > ((xleft11[level] + ((n % xnb1[level]) * ix)) - ((((t + 1) - tt) - tb) * 1))) ? (1) : ((xleft11[level] + ((n % xnb1[level]) * ix)) - ((((t + 1) - tt) - tb) * 1));
          xmax = ((NX + 1) < (((xleft11[level] + ((n % xnb1[level]) * ix)) + bx) + ((((t + 1) - tt) - tb) * 1))) ? (NX + 1) : (((xleft11[level] + ((n % xnb1[level]) * ix)) + bx) + ((((t + 1) - tt) - tb) * 1));
          ymin = (1 > ((ybottom11[level] + ((n / xnb1[level]) * iy)) + ((((t + 1) - tt) - tb) * 1))) ? (1) : ((ybottom11[level] + ((n / xnb1[level]) * iy)) + ((((t + 1) - tt) - tb) * 1));
          ymax = ((NY + 1) < (((ybottom11[level] + ((n / xnb1[level]) * iy)) + By) - ((((t + 1) - tt) - tb) * 1))) ? (NY + 1) : (((ybottom11[level] + ((n / xnb1[level]) * iy)) + By) - ((((t + 1) - tt) - tb) * 1));
        }
        else
        {
          xmin = (1 > ((xleft12[level] + (((n - nb1[level]) % xnb1[1 - level]) * ix)) + ((((t + 1) - tt) - tb) * 1))) ? (1) : ((xleft12[level] + (((n - nb1[level]) % xnb1[1 - level]) * ix)) + ((((t + 1) - tt) - tb) * 1));
          xmax = ((NX + 1) < (((xleft12[level] + (((n - nb1[level]) % xnb1[1 - level]) * ix)) + Bx) - ((((t + 1) - tt) - tb) * 1))) ? (NX + 1) : (((xleft12[level] + (((n - nb1[level]) % xnb1[1 - level]) * ix)) + Bx) - ((((t + 1) - tt) - tb) * 1));
          ymin = (1 > ((ybottom12[level] + (((n - nb1[level]) / xnb1[1 - level]) * iy)) - ((((t + 1) - tt) - tb) * 1))) ? (1) : ((ybottom12[level] + (((n - nb1[level]) / xnb1[1 - level]) * iy)) - ((((t + 1) - tt) - tb) * 1));
          ymax = ((NY + 1) < (((ybottom12[level] + (((n - nb1[level]) / xnb1[1 - level]) * iy)) + by) + ((((t + 1) - tt) - tb) * 1))) ? (NY + 1) : (((ybottom12[level] + (((n - nb1[level]) / xnb1[1 - level]) * iy)) + by) + ((((t + 1) - tt) - tb) * 1));
        }

        for (x = xmin; x < xmax; x++)
        {
          #pragma simd
          for (y = ymin; y < ymax; y++)
          {
            A[(t + 1) % 2][x][y] = ((0.125 * ((A[t % 2][x + 1][y] - (2.0 * A[t % 2][x][y])) + A[t % 2][x - 1][y])) + (0.125 * ((A[t % 2][x][y + 1] - (2.0 * A[t % 2][x][y])) + A[t % 2][x][y - 1]))) + A[t % 2][x][y];
            ;
          }

        }

      }

    }

    level = 1 - level;
  }

  gettimeofday(&end, 0);
  printf("MStencil/s = %f\n", (((((double) NX) * NY) * T) / ((double) ((end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec) * 1.0e-6)))) / 1000000L);
}

