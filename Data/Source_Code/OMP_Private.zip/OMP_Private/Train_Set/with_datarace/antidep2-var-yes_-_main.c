int main(int argc, char *argv[])
{
  int i;
  int j;
  int len = 20;
  if (argc > 1)
    len = atoi(argv[1]);

  double a[len][len];
  for (i = 0; i < len; i++)
    for (j = 0; j < len; j++)
    a[i][j] = 0.5;


  #pragma omp parallel for
  for (i = 0; i < (len - 1); i += 1)
  {
    for (j = 0; j < len; j += 1)
    {
      a[i][j] += a[i + 1][j];
    }

  }

  return 0;

  int i;
  int j;
  int k;
  int ni = 10;
  int nj = 10;
  int nk = 10;
  int nl = 10;
  init_array();
  struct timeval start;
  struct timeval end;
  long mtime;
  long seconds;
  long useconds;
  gettimeofday(&start, 0);
  #pragma omp parallel for private (j, k) check hybrid
  for (i = 0; i < ni; i++)
    for (j = 0; j < nj; j++)
  {
    C[i][j] = 0;
    for (k = 0; k < nk; ++k)
      C[i][j] += A[i][k] * B[k][j];

  }


  gettimeofday(&end, 0);
  seconds = end.tv_sec - start.tv_sec;
  useconds = end.tv_usec - start.tv_usec;
  mtime = ((seconds * 1000) + (useconds / 1000.0)) + 0.5;
  printf("Elapsed time: %ld milliseconds\n", mtime);
  double total = 0;
  for (int x = 0; x < ni; ++x)
  {
    for (int y = 0; y < ni; ++y)
    {
      total += E[x][y];
    }

  }

  printf("Total: %f\n", total);
  return 0;
}

