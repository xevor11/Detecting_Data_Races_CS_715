int distance_matrix[1200][1200] = {0};
int main(int argc, char *argv[])
{
  int nthreads;
  int src;
  int dst;
  int middle;
  for (src = 0; src < 1200; src++)
  {
    for (dst = 0; dst < 1200; dst++)
    {
      if (src != dst)
      {
        distance_matrix[src][dst] = rand() % 20;
      }

    }

  }

  double start_time = omp_get_wtime();
  for (middle = 0; middle < 1200; middle++)
  {
    int *dm = distance_matrix[middle];
    for (src = 0; src < 1200; src++)
    {
      int *ds = distance_matrix[src];
      for (dst = 0; dst < 1200; dst++)
      {
        ds[dst] = (ds[dst] < (ds[middle] + dm[dst])) ? (ds[dst]) : (ds[middle] + dm[dst]);
      }

    }

  }

  double time = omp_get_wtime() - start_time;
  printf("Total time for sequential (in sec):%.2f\n", time);
  for (nthreads = 1; nthreads <= 10; nthreads++)
  {
    omp_set_num_threads(nthreads);
    double start_time = omp_get_wtime();
    #pragma omp parallel shared(distance_matrix)
    for (middle = 0; middle < 1200; middle++)
    {
      int *dm = distance_matrix[middle];
      #pragma omp parallel for schedule(dynamic)
      for (src = 0; src < 1200; src++)
      {
        int *ds = distance_matrix[src];
        for (dst = 0; dst < 1200; dst++)
        {
          ds[dst] = (ds[dst] < (ds[middle] + dm[dst])) ? (ds[dst]) : (ds[middle] + dm[dst]);
        }

      }

    }

    double time = omp_get_wtime() - start_time;
    printf("Total time for thread %d (in sec):%.2f\n", nthreads, time);
  }

  return 0;
}

