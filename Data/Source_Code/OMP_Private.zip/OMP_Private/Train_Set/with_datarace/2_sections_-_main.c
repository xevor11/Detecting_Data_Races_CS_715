int main()
{
  int i;
  int j;
  int x;
  int y;
  int z;
  #pragma omp parallel for default(none), private(i, j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
  for (i = 0; i < PARAMQ; i++)
    for (j = 0; j < (((xlength[0] + 2) * (xlength[1] + 2)) * (xlength[2] + 2)); j++)
    collideField[j + (((i * (xlength[0] + 2)) * (xlength[1] + 2)) * (xlength[2] + 2))] = (streamField[j + (((i * (xlength[0] + 2)) * (xlength[1] + 2)) * (xlength[2] + 2))] = LATTICEWEIGHTS[i]);


  #pragma omp parallel for default(none), private(i, j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
  for (i = 0; i < (((xlength[0] + 2) * (xlength[1] + 2)) * (xlength[2] + 2)); i++)
    flagField[i] = FLUID;

  if (!strcmp(problem, "drivenCavity"))
  {
    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(y * (xlength[0] + 2)) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + xlength[0]) + 1] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((((xlength[2] + 1) * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + ((xlength[1] + 1) * (xlength[0] + 2))) + x] = MOVING_WALL;


  }

  if (!strcmp(problem, "tiltedPlate"))
  {
    int **pgmImage;
    pgmImage = read_pgm(pgmInput);
    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem, pgmImage) schedule(static)
    for (z = 1; z <= xlength[2]; z++)
      for (y = 1; y <= xlength[1]; y++)
      for (x = 1; x <= xlength[0]; x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = !(!pgmImage[x][y]);



    free_imatrix(pgmImage, 0, xlength[0] + 2, 0, xlength[1] + 2);
    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      if (flagField[(((xlength[2] * (xlength[0] + 2)) * (xlength[1] + 2)) + ((xlength[0] + 2) * y)) + x] == NO_SLIP)
      flagField[((((xlength[2] + 1) * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = NO_SLIP;
    else
      flagField[((((xlength[2] + 1) * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = FREE_SLIP;



    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      if (flagField[(y * (xlength[0] + 2)) + x] == NO_SLIP)
      flagField[(y * (xlength[0] + 2)) + x] = NO_SLIP;
    else
      flagField[(y * (xlength[0] + 2)) + x] = FREE_SLIP;



    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))] = INFLOW;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + xlength[0]) + 1] = OUTFLOW;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + ((xlength[1] + 1) * (xlength[0] + 2))) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + x] = NO_SLIP;


  }

  if (!strcmp(problem, "flowStep"))
  {
    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((((xlength[2] + 1) * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(y * (xlength[0] + 2)) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))] = INFLOW;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + xlength[0]) + 1] = OUTFLOW;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + ((xlength[1] + 1) * (xlength[0] + 2))) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 1; y <= (xlength[1] / 2); y++)
      for (x = 1; x <= (xlength[1] / 2); x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = NO_SLIP;



  }

  if (!strcmp(problem, "planeShearFlow"))
  {
    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((((xlength[2] + 1) * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + x] = FREE_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (y = 0; y <= (xlength[1] + 1); y++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(y * (xlength[0] + 2)) + x] = FREE_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))] = PRESSURE_IN;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (y = 0; y <= (xlength[1] + 1); y++)
      flagField[((((z * (xlength[0] + 2)) * (xlength[1] + 2)) + (y * (xlength[0] + 2))) + xlength[0]) + 1] = OUTFLOW;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[(((z * (xlength[0] + 2)) * (xlength[1] + 2)) + ((xlength[1] + 1) * (xlength[0] + 2))) + x] = NO_SLIP;


    #pragma omp parallel for default(none), private(i,j, x, y, z, pgmInput), shared(collideField, streamField, flagField, xlength, problem) schedule(static)
    for (z = 0; z <= (xlength[2] + 1); z++)
      for (x = 0; x <= (xlength[0] + 1); x++)
      flagField[((z * (xlength[0] + 2)) * (xlength[1] + 2)) + x] = NO_SLIP;


  }


  int i;
  int tid;
  float a[1000];
  float b[1000];
  float c[1000];
  float d[1000];
  for (i = 0; i < 1000; i++)
  {
    a[i] = i * 1.5;
    b[i] = i + 22.35;
  }

  #pragma omp parallel shared(a,b,c,d)
  {
    tid = omp_get_thread_num();
    #pragma omp sections nowait
    {
      #pragma omp section
      {
        printf("Section 1, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          c[i] = a[i] + b[i];

      }
      #pragma omp section
      {
        printf("Section 2, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          d[i] = a[i] * b[i];

      }
      #pragma omp section
      {
        printf("Section 3, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          d[i] = a[i] * b[i];

      }
      #pragma omp section
      {
        printf("Section 4, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          d[i] = a[i] * b[i];

      }
      #pragma omp section
      {
        printf("Section 5, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          d[i] = a[i] * b[i];

      }
      #pragma omp section
      {
        printf("Section 6, thread %d\n", tid);
        for (i = 0; i < 1000; i++)
          d[i] = a[i] * b[i];

      }
    }
  }
}

