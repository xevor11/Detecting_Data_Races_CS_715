int main(int argc, char **argv)
{
  int i;
  int j;
  double t1;
  double t2;
  double total;
  if (argc < 2)
  {
    printf("Falta tamaño de matriz y vector\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  double *v1;
  double *v2;
  double **M;
  v1 = (double *) malloc(N * (sizeof(double)));
  v2 = (double *) malloc(N * (sizeof(double)));
  M = (double **) malloc(N * (sizeof(double *)));
  if (((v1 == 0) || (v2 == 0)) || (M == 0))
  {
    printf("Error en la reserva de espacio para los vectores\n");
    exit(-2);
  }

  for (i = 0; i < N; i++)
  {
    M[i] = (double *) malloc(N * (sizeof(double)));
    if (M[i] == 0)
    {
      printf("Error en la reserva de espacio para los vectores\n");
      exit(-2);
    }

  }

  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < N; i++)
      v1[i] = 1;

    #pragma omp for
    for (i = 0; i < N; i++)
    {
      for (j = 0; j < N; j++)
      {
        M[i][j] = 1;
      }

    }

    #pragma omp single
    {
      t1 = omp_get_wtime();
    }
    for (i = 0; i < N; i++)
    {
      v2[i] = 0;
      double res = 0;
      #pragma omp for
      for (j = 0; j < N; j++)
      {
        res += M[i][j] * v1[j];
      }

      #pragma omp atomic
      v2[i] += res;
    }

    #pragma omp single
    {
      t2 = omp_get_wtime();
    }
  }
  total = t2 - t1;
  printf("Tiempo(seg.): %11.9f\t / Tamaño:%u\t/ V2[0]=%8.6f V2[%d]=%8.6f\n", total, N, v2[0], N - 1, v2[N - 1]);
  i = 0, j = 0;
  if (N < 30)
  {
    for (i = 0; i < N; i++)
      printf("%f ", v2[i]);

    printf("\n");
  }

  free(v1);
  free(v2);
  for (i = 0; i < N; i++)
    free(M[i]);

  free(M);
  return 0;
}

