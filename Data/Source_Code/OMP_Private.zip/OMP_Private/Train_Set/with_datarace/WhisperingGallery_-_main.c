int main()
{
  int t;
  int i;
  int j;
  int k;
  int x_max = 1000;
  int y_max = 1000;
  float *_e_0_0;
  float *e_0_0;
  float *_e_1_0;
  float *e_1_0;
  float *_e_0_1;
  float *e_0_1;
  float *_e_1_1;
  float *e_1_1;
  float *_h_2_0;
  float *h_2_0;
  float *_h_2_1;
  float *h_2_1;
  float *_ca;
  float *ca;
  float *_cb;
  float *cb;
  float *_da;
  float *da;
  float *_db;
  float *db;
  float *_u_em;
  float *u_em;
  allocate(&_e_0_0, &e_0_0, x_max, y_max);
  allocate(&_e_1_0, &e_1_0, x_max, y_max);
  allocate(&_e_0_1, &e_0_1, x_max, y_max);
  allocate(&_e_1_1, &e_1_1, x_max, y_max);
  allocate(&_h_2_0, &h_2_0, x_max, y_max);
  allocate(&_h_2_1, &h_2_1, x_max, y_max);
  allocate(&_ca, &ca, x_max, y_max);
  allocate(&_cb, &cb, x_max, y_max);
  allocate(&_da, &da, x_max, y_max);
  allocate(&_db, &db, x_max, y_max);
  allocate(&_u_em, &u_em, x_max, y_max);
  float ca_vacuum = calculateCa(0.0f, 1.0f);
  float cb_vacuum = calculateCb(0.0f, 1.0f);
  float da_vacuum = calculateDa(0.0f, 1.0f);
  float db_vacuum = calculateDb(0.0f, 1.0f);
  float ca_material = calculateCa(0.0f, 1.0f);
  float cb_material = calculateCb(0.0f, 1.0f);
  float da_material = 0.0f;
  float db_material = 0.0f;
  initialize_fdtdE2D(e_0_0, e_1_0, e_0_1, e_1_1, h_2_0, ca, cb, ca_vacuum, ca_material, cb_vacuum, cb_material, x_max, y_max);
  initialize_fdtdH2D(e_0_0, e_1_0, h_2_0, h_2_1, da, db, da_vacuum, da_material, db_vacuum, db_material, x_max, y_max);
  initialize_integrate(e_0_0, e_1_0, h_2_0, u_em, u_em, 1.25663706e-6f, 8.854187817e-12f, x_max, y_max);
  float *dummy = 0;
  double fTimeStart = gettime();
  #pragma omp parallel
  {
    for (t = 0; t < 5000; t++)
    {
      fdtdE2D(&dummy, &dummy, e_0_0, e_1_0, e_0_1, e_1_1, h_2_0, ca, cb, ca_vacuum, ca_material, cb_vacuum, cb_material, x_max, y_max);
      #pragma omp barrier
      #pragma omp single
      {
        float *temp0 = e_0_0;
        e_0_0 = e_0_1;
        e_0_1 = temp0;
        float *temp1 = e_1_0;
        e_1_0 = e_1_1;
        e_1_1 = temp1;
      }
      fdtdH2D(&dummy, e_0_0, e_1_0, h_2_0, h_2_1, da, db, da_vacuum, da_material, db_vacuum, db_material, x_max, y_max);
      #pragma omp barrier
      #pragma omp single
      {
        float *temp2 = h_2_0;
        h_2_0 = h_2_1;
        h_2_1 = temp2;
        h_2_0[((int) (1000 * 0.5)) + (x_max * ((int) (1000 * 0.3)))] += gaussianSource(t * 5.896635842e-17f);
      }
      if (t > 4000)
      {
        integrate(&dummy, e_0_0, e_1_0, h_2_0, u_em, u_em, 1.25663706e-6f, 8.854187817e-12f, x_max, y_max);
        #pragma omp barrier
      }

    }

  }
  double fTimeEnd = gettime();
  printf("Time used: %f s\n", fTimeEnd - fTimeStart);
  write(u_em, x_max, y_max);
  free(_e_0_0);
  free(_e_1_0);
  free(_e_0_1);
  free(_e_1_1);
  free(_h_2_0);
  free(_h_2_1);
  free(_u_em);
  free(_ca);
  free(_cb);
  free(_da);
  free(_db);
  return 0;
}

