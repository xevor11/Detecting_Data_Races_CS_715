{
  int y;
  int x;
} Antena;
{
  int valor;
  int x;
  int y;
} Registro;
Antena calcular_max(int *mapa, int rows, int cols, Registro *registros, int num_hilos)
{
  int maximo = 0;
  int i;
  int j;
  #pragma omp parallel for shared(mapa,registros) firstprivate(maximo)
  for (i = 0; i < rows; i++)
    for (j = 0; j < cols; j++)
  {
    if (mapa[(i * cols) + j] > maximo)
    {
      maximo = mapa[(i * cols) + j];
      registros[omp_get_thread_num()].x = i;
      registros[omp_get_thread_num()].y = j;
      registros[omp_get_thread_num()].valor = mapa[(i * cols) + j];
    }

  }


  maximo = 0;
  for (i = 0; i < num_hilos; i++)
    if (registros[i].valor > registros[maximo].valor)
    maximo = i;


  Antena antena = {registros[maximo].x, registros[maximo].y};
  return antena;
  ;

  double delta_t = 5E-3;
  int N = 64;
  double T = 5.0 * pow(N, 2.2);
  int N_T = T / delta_t;
  double E_k_1 = 0.0;
  double E_k_2 = 0.0;
  double E_k_3 = 0.0;
  double *x = malloc(N * (sizeof(double)));
  double *v = malloc(N * (sizeof(double)));
  int t;
  int n;
  int n_proc;
  double F_x;
  n_proc = atoi(argv[1]);
  initialize(x, v, N);
  omp_set_num_threads(n_proc);
  for (t = 0; t < N_T; t++)
  {
    #pragma omp parallel for shared(v,x) private(F_x)
    for (n = 1; n < (N - 1); n++)
    {
      F_x = F(x[n], x[n - 1], x[n + 1]);
      v[n] += (F_x * delta_t) * 0.5;
    }

    #pragma omp parallel for shared(v,x)
    for (n = 1; n < (N - 1); n++)
    {
      x[n] += v[n] * delta_t;
    }

    #pragma omp parallel for shared(v,x) private(F_x)
    for (n = 1; n < (N - 1); n++)
    {
      F_x = F(x[n], x[n - 1], x[n + 1]);
      v[n] += (F_x * delta_t) * 0.5;
    }

    if (!(t % (N_T / 1000)))
    {
      E_k_1 = energy(x, v, N, 1);
      E_k_2 = energy(x, v, N, 2);
      E_k_3 = energy(x, v, N, 3);
      printf("%d %e %e %e\n", t, E_k_1, E_k_2, E_k_3);
    }

  }

  return 0;
}

