void LocalMatrixProduct()
{
  int i;
  int j;
  int k;
  omp_set_num_threads(NbThreads);
  switch (KernelId)
  {
    case 0:
      #pragma omp parallel for
      for (i = 0; i < SIZE; i++)
    {
      for (j = 0; j < SIZE; j++)
      {
        double accu[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        for (k = 0; k < ((SIZE / 8) * 8); k += 8)
        {
          accu[0] += A[i][k] * Bt[j][k];
          accu[1] += A[i][k + 1] * Bt[j][k + 1];
          accu[2] += A[i][k + 2] * Bt[j][k + 2];
          accu[3] += A[i][k + 3] * Bt[j][k + 3];
          accu[4] += A[i][k + 4] * Bt[j][k + 4];
          accu[5] += A[i][k + 5] * Bt[j][k + 5];
          accu[6] += A[i][k + 6] * Bt[j][k + 6];
          accu[7] += A[i][k + 7] * Bt[j][k + 7];
        }

        for (; k < SIZE; ++k)
          accu[7] += A[i][k] * Bt[j][k];

        C[i][j] = ((((((accu[0] + accu[1]) + accu[2]) + accu[3]) + accu[4]) + accu[5]) + accu[6]) + accu[7];
      }

    }

      break;

    case 1:
      #pragma omp parallel
    {
      const int R = SIZE % omp_get_num_threads();
      const int Q = SIZE / omp_get_num_threads();
      if (omp_get_thread_num() < R)
      {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, Q + 1, SIZE, SIZE, 1.0, A[(Q + 1) * omp_get_thread_num()], SIZE, *B, SIZE, 0.0, C[(Q + 1) * omp_get_thread_num()], SIZE);
      }
      else
      {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, Q, SIZE, SIZE, 1.0, A[(Q * omp_get_thread_num()) + R], SIZE, *B, SIZE, 0.0, C[(Q * omp_get_thread_num()) + R], SIZE);
      }

    }
      break;

    default:
      fprintf(stderr, "Error: kernel %d not implemented!\n", KernelId);
      exit(1);
      break;

  }

}

