int main(int argc, char *argv[])
{
  int i;
  int j;
  int k;
  int idx = 0;
  int num_thrs = 0;
  double time_start;
  double time_stop;
  int N = atoi(argv[1]);
  int *A = malloc((N * N) * (sizeof(int)));
  int *B = malloc((N * N) * (sizeof(int)));
  int *C = malloc((N * N) * (sizeof(int)));
  time_start = seconds();
  #pragma omp parallel
  {
    idx = omp_get_thread_num();
    num_thrs = omp_get_num_threads();
    #pragma omp for
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
    {
      A[(i * N) + j] = i + j;
      B[(i * N) + j] = i - j;
    }


    #pragma omp for
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
      for (k = 0; k < N; k++)
    {
      C[(i * N) + j] += A[(i * N) + k] * B[(k * N) + j];
    }



  }
  time_stop = seconds() - time_start;
  printf("%f\n", time_stop);
  free(A);
  free(B);
  free(C);
  return 0;
}

