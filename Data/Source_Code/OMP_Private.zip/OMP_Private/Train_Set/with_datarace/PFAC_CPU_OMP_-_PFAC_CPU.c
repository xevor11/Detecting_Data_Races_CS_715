char *input_string;
int input_size;
int PFAC_table[131000][256];
int output_table[131000];
int *match_result;
int pattern_len[11000];
int initial_state;
void PFAC_CPU(char *d_input_string, int *d_match_result, int input_size)
{
  int start;
  int pos;
  int state;
  int inputChar;
  int match_pattern = 0;
  struct timeval t_start;
  struct timeval t_end;
  float elapsedTime;
  for (pos = 0; pos < input_size; pos++)
  {
    d_match_result[pos] = 0;
  }

  gettimeofday(&t_start, 0);
  #pragma omp parallel shared (d_match_result, input_size, d_input_string, PFAC_table, initial_state) num_threads(8)
  {
    #pragma omp for schedule(dynamic,32768)
    for (start = 0; start < input_size; start++)
    {
      state = initial_state;
      pos = start;
      while ((state != (-1)) && (pos < input_size))
      {
        if (state < initial_state)
        {
          d_match_result[start] = state + 1;
        }

        inputChar = (unsigned char) d_input_string[pos];
        state = PFAC_table[state][inputChar];
        pos = pos + 1;
      }

    }

  }
  gettimeofday(&t_end, 0);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_usec - t_start.tv_usec) / 1000.0;
  printf("The elapsed time is %f ms\n", elapsedTime);
  printf("The input size is %d bytes\n", input_size);
  printf("The throughput is %f Gbps\n", (((float) input_size) / (elapsedTime * 1000000)) * 8);

  int nthreads;
  int tid;
  #pragma omp parallel num_threads(20) private(tid)
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }

  }
  return 0;
}

