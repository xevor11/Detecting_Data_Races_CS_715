int **curr;
int **next;
int dx[] = {
  int field[79][100];
  char fieldc[79][100];
  float v_r;
  float v_i;
  float v_r_step;
  float v_i_step;
  char schedenv[] = "OMP_SCHEDULE";
  char *sched;
  int i;
  int j;
  double *time_per_thread;
  int num_threads;
  double start;
  double end;
  sched = getenv(schedenv);
  v_r_step = (1.0 - (-1.0)) / 79;
  v_i_step = (1.0 - (-1.0)) / 100;
  char *num_threads_env = getenv("OMP_NUM_THREADS");
  if (!num_threads_env)
  {
    num_threads = 1;
  }
  else
  {
    num_threads = atoi(num_threads_env);
  }

  time_per_thread = calloc(num_threads, sizeof(double));
  for (i = 1; i <= 79; i++)
  {
    v_r = (-1.0) + ((i - 1) * v_r_step);
    #pragma omp parallel for private(start, end)
    for (j = 1; j <= 100; j++)
    {
      v_i = (-1.0) + ((j - 1) * v_i_step);
      start = omp_get_wtime();
      field[i - 1][j - 1] = icalman(v_r, v_i);
      end = omp_get_wtime();
      time_per_thread[omp_get_thread_num()] += end - start;
    }

  }

  for (i = 1; i <= 79; i++)
  {
    for (j = 1; j <= 100; j++)
    {
      if (field[i - 1][j - 1] == (-1))
        fieldc[i - 1][j - 1] = '*';
      else
        fieldc[i - 1][j - 1] = ' ';

    }

  }

  for (j = 1; j <= 100; j++)
  {
    for (i = 1; i <= 79; i++)
    {
      printf("%c", fieldc[i - 1][j - 1]);
    }

    printf("\n");
  }

  printf("%s=%s\n", schedenv, sched);
  #pragma omp parallel
  printf("Execution time of thread %d: %f\n", omp_get_thread_num() + 1, time_per_thread[omp_get_thread_num()]);
  return 0;
-1, 0, 1, -1, 1, -1, 0, 1};
int dy[] = {-1, -1, -1, 0, 0, 1, 1, 1};
void change(int r, int c)
{
  int i;
  int j;
  int k;
  #pragma omp parallel for
  for (i = 1; i < (r - 1); i++)
  {
    int alive;
    int state;
    int c1 = 0;
    int c2 = 0;
    int c3 = 0;
    j = 1;
    c1 = (curr[i][j - 1] + curr[i - 1][j - 1]) + curr[i + 1][j - 1];
    c2 = curr[i - 1][j] + curr[i + 1][j];
    c3 = (curr[i][j + 1] + curr[i - 1][j + 1]) + curr[i + 1][j + 1];
    for (j = 1; j < (c - 1); j++)
    {
      alive = (c1 + c2) + c3;
      c2 = c2 + curr[i][j];
      c3 = c3 - curr[i][j + 1];
      c1 = c2;
      c2 = c3;
      c3 = (curr[i - 1][j + 2] + curr[i][j + 2]) + curr[i + 1][j + 2];
      state = curr[i][j];
      next[i][j] = state;
      if ((state == 1) && ((alive < 2) || (alive > 3)))
      {
        next[i][j] = 0;
      }

      if ((state == 0) && (alive == 3))
      {
        next[i][j] = 1;
      }

    }

  }

  for (i = 0; i < r; i++)
  {
    int alive;
    int state;
    alive = neighbours(i, 0, r, c);
    state = curr[i][0];
    next[i][0] = state;
    if ((state == 1) && ((alive < 2) || (alive > 3)))
    {
      next[i][0] = 0;
    }

    if ((state == 0) && (alive == 3))
    {
      next[i][0] = 1;
    }

    alive = neighbours(i, c - 1, r, c);
    state = curr[i][c - 1];
    next[i][c - 1] = state;
    if ((state == 1) && ((alive < 2) || (alive > 3)))
    {
      next[i][c - 1] = 0;
    }

    if ((state == 0) && (alive == 3))
    {
      next[i][c - 1] = 1;
    }

  }

  for (j = 0; j < c; j++)
  {
    int alive;
    int state;
    alive = neighbours(0, j, r, c);
    state = curr[0][j];
    next[0][j] = state;
    if ((state == 1) && ((alive < 2) || (alive > 3)))
    {
      next[0][j] = 0;
    }

    if ((state == 0) && (alive == 3))
    {
      next[0][j] = 1;
    }

    alive = neighbours(c - 1, j, r, c);
    state = curr[c - 1][j];
    next[c - 1][j] = state;
    if ((state == 1) && ((alive < 2) || (alive > 3)))
    {
      next[c - 1][j] = 0;
    }

    if ((state == 0) && (alive == 3))
    {
      next[c - 1][j] = 1;
    }

  }

  int **temp = curr;
  curr = next;
  next = temp;
}

