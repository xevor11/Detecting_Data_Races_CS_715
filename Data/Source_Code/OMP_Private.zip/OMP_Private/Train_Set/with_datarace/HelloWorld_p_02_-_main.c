int main(int argc, char **argv)
{
  int i;
  #pragma omp target
  #pragma omp teams
  #pragma omp distribute parallel for shared(a) firstprivate(n) private(i) firstprivate(j)
  for (i = j + 1; i < n; i += 3)
    a[i] = i;


  int num_procs;
  int max_threads;
  int thread_id;
  double wall_time = 0.00;
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  printf("\n");
  printf("  Total number of processors available : %d\n", num_procs);
  printf("  Maximum number of usable threads     : %d\n\n", max_threads);
  #pragma omp parallel shared(max_threads)
  {
    thread_id = omp_get_thread_num();
    printf("  Hello, World! from thread %d out of %d\n", thread_id, max_threads);
  }
  wall_time = omp_get_wtime() - wall_time;
  printf("\n");
  printf("  Total time taken : %f seconds\n\n", wall_time);
  return 0;
}

