int processors;
int num_of_threads;
int num_blocks_cache;
int length_of_trace;
int bus_command = 0;
int bus_address = 0;
int bus_valid = 0;
int *all_requests;
int *all_priorities;
int current_head;
int arbitrate_bus(int request, int priority);
int simulate(int **operation, int **address);
int thread_print = 0;
int simulate(int **operation, int **address)
{
  int i;
  int j;
  int cache_size = pow(2, num_blocks_cache);
  int all_done = 0;
  int hits[processors];
  int misses[processors];
  int completed_cycles[processors];
  memset(hits, 0, (sizeof(hits[0])) * processors);
  memset(misses, 0, (sizeof(misses[0])) * processors);
  memset(completed_cycles, 0, (sizeof(completed_cycles[0])) * processors);
  #pragma omp parallel num_threads(num_of_threads)
  {
    int line;
    int j;
    int cycle;
    int cache_address;
    int current_op;
    int current_addr;
    int done = 0;
    int made_request = 0;
    int had_bus = 0;
    int thread_num = omp_get_thread_num();
    int cache[cache_size][2];
    memset(cache, 0, ((sizeof(cache[0][0])) * cache_size) * 2);
    for (cycle = 1, line = 0;; cycle++)
    {
      if (line >= length_of_trace)
      {
        printf("Thread:%d Completed\n", thread_num);
        line = -1;
        done = 1;
        completed_cycles[thread_num] = cycle;
        #pragma omp atomic
        all_done++;
      }

      #pragma omp barrier
      if (all_done == (num_of_threads - 1))
      {
        #pragma omp barrier
        break;
      }

      if (done)
      {
        arbitrate_bus(0, 0);
      }
      else
        if (thread_num == (num_of_threads - 1))
      {
        cache_address = (address[line][thread_num] / 4) % cache_size;
        current_op = operation[line][thread_num];
        current_addr = address[line][thread_num];
        arbitrate_bus(0, 0);
      }
      else
      {
        cache_address = (address[line][thread_num] / 4) % cache_size;
        current_op = operation[line][thread_num];
        current_addr = address[line][thread_num];
        if (cache[cache_address][1] && (cache[cache_address][0] == current_addr))
        {
          if ((cache[cache_address][1] == 1) && (current_op == 1))
          {
            if (arbitrate_bus(1, 0))
            {
              printf("Cycle:%d P:action\tTHD:%d CMD:invalidate\tADDR:%d PRI:normal\n", cycle, thread_num, current_addr);
              bus_command = 4;
              bus_address = current_addr;
              bus_valid = 1;
              hits[thread_num]++;
              had_bus = 1;
              cache[cache_address][1] = 2;
              line++;
            }

          }
          else
          {
            arbitrate_bus(0, 0);
            hits[thread_num]++;
            line++;
          }

        }
        else
          if (cache[cache_address][1] == 2)
        {
          if (arbitrate_bus(1, 0))
          {
            printf("Cycle:%d P:action\tTHD:%d CMD:writeback\tADDR:%d PRI:normal\n", cycle, thread_num, cache[cache_address][0]);
            bus_command = 3;
            bus_address = cache[cache_address][0];
            bus_valid = 1;
            had_bus = 1;
            cache[cache_address][1] = 0;
            cache[cache_address][0] = 0;
          }

        }
        else
        {
          if (arbitrate_bus(1, 0))
          {
            misses[thread_num]++;
            printf("Cycle:%d P:action\tTHD:%d CMD:%s\tADDR:%d PRI:normal\n", cycle, thread_num, (current_op) ? ("write") : ("read"), current_addr);
            bus_command = current_op;
            bus_address = current_addr;
            bus_valid = 1;
            made_request = 1;
            had_bus = 1;
            line++;
          }

        }


      }


      #pragma omp barrier
      if (thread_num == (num_of_threads - 1))
      {
        if ((bus_command == 0) || (bus_command == 1))
        {
          if (arbitrate_bus(1, 0))
          {
            printf("Cycle:%d P:reaction\tTHD:%d CMD:reply\tADDR:%d PRI:normal\n", cycle, thread_num, bus_address);
            bus_command = 2;
            bus_valid = 1;
          }

        }
        else
          arbitrate_bus(0, 0);

      }
      else
      {
        cache_address = (bus_address / 4) % cache_size;
        if ((bus_command == 0) || (bus_command == 1))
        {
          if ((cache[cache_address][1] == 2) && (cache[cache_address][0] == bus_address))
          {
            cache[cache_address][1] = (bus_command) ? (0) : (1);
            cache[cache_address][0] = (bus_command) ? (0) : (cache[cache_address][0]);
            if (arbitrate_bus(1, 1))
            {
              printf("Cycle:%d P:reaction\tTHD:%d CMD:writeback/reply\tADDR:%d PRI:high\n", cycle, thread_num, bus_address);
              bus_command = 3;
              bus_valid = 1;
            }

          }
          else
            if (((cache[cache_address][1] == 1) && (cache[cache_address][0] == bus_address)) && (bus_command == 1))
          {
            cache[cache_address][1] = 0;
            cache[cache_address][0] = 0;
            arbitrate_bus(0, 0);
          }
          else
          {
            arbitrate_bus(0, 0);
          }


        }
        else
          if (bus_command == 4)
        {
          if ((cache[cache_address][1] && (cache[cache_address][0] == bus_address)) && (!had_bus))
          {
            cache[cache_address][1] = 0;
            cache[cache_address][0] = 0;
          }

          arbitrate_bus(0, 0);
        }
        else
        {
          arbitrate_bus(0, 0);
        }


      }

      #pragma omp barrier
      if (((bus_command == 2) || (bus_command == 3)) && made_request)
      {
        made_request = 0;
        cache_address = (bus_address / 4) % cache_size;
        cache[cache_address][0] = bus_address;
        if (current_op)
          cache[cache_address][1] = 2;
        else
          cache[cache_address][1] = 1;

      }

      had_bus = 0;
      if ((processors <= 4) && (num_blocks_cache <= 3))
      {
        while (thread_print != thread_num)
          ;

        if (thread_num != (num_of_threads - 1))
        {
          printf("Thread Num: %d\t", thread_num);
          for (j = 0; j < cache_size; j++)
          {
            printf("%d %s\t", cache[j][0], (cache[j][1] == 1) ? ("S") : ((cache[j][1] == 2) ? ("M") : ("I")));
          }

          printf("\n");
          thread_print++;
        }
        else
        {
          thread_print = 0;
        }

      }

      #pragma omp barrier
    }

  }
  char strcycles[256] = "Completed Cycles: ";
  char strhits[256] = "Cache Hits: ";
  char strmisses[256] = "Cache Misses: ";
  char strmissrate[256] = "Cache Miss Rate: ";
  char temp[256];
  for (i = 0; i < (processors - 1); i++)
  {
    sprintf(temp, "%d, ", completed_cycles[i]);
    strcat(strcycles, temp);
    memset(temp, 0, 128);
    sprintf(temp, "%d, ", hits[i]);
    strcat(strhits, temp);
    memset(temp, 0, 128);
    sprintf(temp, "%d, ", misses[i]);
    strcat(strmisses, temp);
    memset(temp, 0, 128);
    sprintf(temp, "%f, ", ((float) misses[i]) / ((float) (misses[i] + hits[i])));
    strcat(strmissrate, temp);
    memset(temp, 0, 128);
  }

  sprintf(temp, "%d\n", completed_cycles[i]);
  strcat(strcycles, temp);
  memset(temp, 0, 128);
  sprintf(temp, "%d\n", hits[i]);
  strcat(strhits, temp);
  memset(temp, 0, 128);
  sprintf(temp, "%d\n", misses[i]);
  strcat(strmisses, temp);
  memset(temp, 0, 128);
  sprintf(temp, "%f\n", ((float) misses[i]) / ((float) (misses[i] + hits[i])));
  strcat(strmissrate, temp);
  memset(temp, 0, 128);
  printf(strcycles);
  printf(strhits);
  printf(strmisses);
  printf(strmissrate);
  printf("All threads completed\n");
}

