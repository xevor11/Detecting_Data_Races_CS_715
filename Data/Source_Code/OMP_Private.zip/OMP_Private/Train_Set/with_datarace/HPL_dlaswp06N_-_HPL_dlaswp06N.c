void HPL_dlaswp06N(M, N, A, LDA, U, LDU, LINDXA)
const int M;
const int N;
double *A;
const int LDA;
double *U;
const int LDU;
const int *LINDXA;
{
  double r;
  double *U0 = U;
  double *a0;
  double *u0;
  const int incA = (int) (((unsigned int) LDA) << 5);
  const int incU = (int) (((unsigned int) LDU) << 5);
  int nr;
  int nu;
  register int i;
  register int j;
  register int k;
  if ((M <= 0) || (N <= 0))
    return;

  nr = N - (nu = (int) ((((unsigned int) N) >> 5) << 5));
  int nthreads;
  double *tmpA;
  double *tmpU0;
  #pragma omp parallel
  {
    k = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    tmpA = A + (k * incA);
    tmpU0 = U0 + (k * incU);
    for (j = k * 32; j < nu; j += nthreads * 32, tmpA += nthreads * incA, tmpU0 += nthreads * incU)
    {
      for (i = 0; i < M; i++)
      {
        a0 = tmpA + ((size_t) LINDXA[i]);
        u0 = tmpU0 + ((size_t) i);
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
        r = *a0;
        *a0 = *u0;
        *u0 = r;
        a0 += LDA;
        u0 += LDU;
      }

    }

  }
  tmpA = A + (((size_t) nu) * ((size_t) LDA));
  tmpU0 = U0 + (((size_t) nu) * ((size_t) LDU));
  if (nr)
  {
    for (i = 0; i < M; i++)
    {
      a0 = tmpA + ((size_t) LINDXA[i]);
      u0 = tmpU0 + ((size_t) i);
      for (j = 0; j < nr; j++, a0 += LDA, u0 += LDU)
      {
        r = *a0;
        *a0 = *u0;
        *u0 = r;
      }

    }

  }

}

