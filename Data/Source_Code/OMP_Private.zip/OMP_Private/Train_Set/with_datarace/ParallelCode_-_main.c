double T[200][200][40];
double T_old[200][200][40];
void Initialization();
void SetBoundary();
double MaxFunc(double a, double b);
int main()
{
  int i;
  int j;
  int k;
  int iter;
  double deltaT;
  double begin;
  double end;
  double duration_time;
  iter = 1;
  deltaT = 1000;
  printf("Simulation begins, parallel  code version \n\n");
  begin = omp_get_wtime();
  omp_set_num_threads(1);
  Initialization();
  SetBoundary();
  #pragma omp parallel for
  for (i = 0; i < 200; ++i)
  {
    for (j = 0; j < 200; ++j)
    {
      for (k = 0; k < 40; ++k)
      {
        T_old[i][j][k] = T[i][j][k];
      }

    }

  }

  while ((iter < 1000) && (deltaT > 0.001))
  {
    #pragma omp parallel for
    for (i = 1; i < (200 - 1); ++i)
    {
      for (j = 1; j < (200 - 1); ++j)
      {
        for (k = 1; k < (40 - 1); ++k)
        {
          T[i][j][k] = (1.0 / 6) * (((((T_old[i - 1][j][k] + T_old[i + 1][j][k]) + T_old[i][j - 1][k]) + T_old[i][j + 1][k]) + T_old[i][j][k - 1]) + T_old[i][j][k + 1]);
        }

      }

    }

    deltaT = 0.0;
    #pragma omp parallel for reduction(max:deltaT)
    for (i = 1; i < (200 - 1); ++i)
    {
      for (j = 1; j < (200 - 1); ++j)
      {
        for (k = 1; k < (40 - 1); ++k)
        {
          deltaT = MaxFunc(deltaT, fabs(T[i][j][k] - T_old[i][j][k]));
          T_old[i][j][k] = T[i][j][k];
        }

      }

    }

    iter++;
  }

  printf("------------Iteration: %d-----------\n", iter);
  printf("Temperature of vertical center line:\n");
  for (k = 0; k < 40; ++k)
  {
    printf("T[%d,%d,%d] = %.5f\n", 200 / 2, 200 / 2, k, T[200 / 2][200 / 2][k]);
  }

  end = omp_get_wtime();
  duration_time = end - begin;
  printf("Simulation ends.\nTotal running time is %f seconds\n", duration_time);
  return 0;
}

