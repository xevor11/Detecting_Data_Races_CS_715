void compute_conv(int n, int *niters)
{
  double *phi_cur;
  double *phi_next;
  double *tmp;
  int conv;
  int i;
  int j;
  phi_cur = (double *) malloc((n * n) * (sizeof(double)));
  phi_next = (double *) malloc((n * n) * (sizeof(double)));
  init_phi(phi_cur, n);
  init_phi(phi_next, n);
  *niters = 0;
  while (1)
  {
    (*niters)++;
    #pragma omp parallel for
    for (j = 1; j < (n - 1); j++)
      for (i = 1; i < (n - 1); i++)
      phi_next[(j * n) + i] = (((phi_cur[((j - 1) * n) + i] + phi_cur[(j * n) + (i - 1)]) + phi_cur[(j * n) + (i + 1)]) + phi_cur[((j + 1) * n) + i]) / 4;


    conv = 1;
    #pragma omp parallel for reduction(&&:conv)
    for (j = 1; j < (n - 1); j++)
      for (i = 1; i < (n - 1); i++)
      if (fabs(phi_next[(j * n) + i] - phi_cur[(j * n) + i]) > 5e-3)
      conv = 0;



    if (conv)
      break;

    tmp = phi_cur;
    phi_cur = phi_next;
    phi_next = tmp;
  }

  free(phi_cur);
  free(phi_next);
}

