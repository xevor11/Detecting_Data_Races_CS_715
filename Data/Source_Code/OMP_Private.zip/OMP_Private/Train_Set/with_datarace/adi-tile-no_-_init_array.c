extern void *polybench_alloc_data(unsigned long long int n, int elt_size);
static void init_array(int n, double X[500 + 0][500 + 0], double A[500 + 0][500 + 0], double B[500 + 0][500 + 0])
{
  {
    int c1;
    int c3;
    int c2;
    int c4;
    if (n >= 1)
    {
      #pragma omp parallel for
      for (c1 = 0; c1 <= ((((n + (-1)) * 16) < 0) ? ((16 < 0) ? (-((((-(n + (-1))) + 16) + 1) / 16)) : (-((((-(n + (-1))) + 16) - 1) / 16))) : ((n + (-1)) / 16)); c1++)
      {
        for (c2 = 0; c2 <= ((((n + (-1)) * 16) < 0) ? ((16 < 0) ? (-((((-(n + (-1))) + 16) + 1) / 16)) : (-((((-(n + (-1))) + 16) - 1) / 16))) : ((n + (-1)) / 16)); c2++)
        {
          for (c3 = 16 * c1; c3 <= ((((16 * c1) + 15) < (n + (-1))) ? ((16 * c1) + 15) : (n + (-1))); c3++)
          {
            #pragma omp simd
            for (c4 = 16 * c2; c4 <= ((((16 * c2) + 15) < (n + (-1))) ? ((16 * c2) + 15) : (n + (-1))); c4++)
            {
              X[c3][c4] = ((((double) c3) * (c4 + 1)) + 1) / n;
              A[c3][c4] = ((((double) c3) * (c4 + 2)) + 2) / n;
              B[c3][c4] = ((((double) c3) * (c4 + 3)) + 3) / n;
            }

          }

        }

      }

    }

  }

  register int i;
  register int j;
  register int k;
  unsigned int ***Sij;
  float step = max_distance / ((bins - 1) * mesh.psize[0]);
  particle_bins = 1;
  switch (mesh.data_size)
  {
    case 1:
      for (i = 0; i < mesh.n_elements; i++)
    {
      int tag = ((unsigned char *) mesh.data)[i];
      if (tag > particle_bins)
        particle_bins = tag;

    }

      break;

    case 2:
      for (i = 0; i < mesh.n_elements; i++)
    {
      int tag = ((unsigned short *) mesh.data)[i];
      if (tag > particle_bins)
        particle_bins = tag;

    }

      break;

  }

  Sij = (unsigned int ***) malloc((particle_bins + 1) * (sizeof(unsigned int **)));
  for (i = 0; i <= particle_bins; i++)
  {
    Sij[i] = (unsigned int **) malloc((particle_bins + 1) * (sizeof(unsigned int *)));
    for (j = 0; j <= particle_bins; j++)
    {
      Sij[i][j] = (unsigned int *) malloc(bins * (sizeof(unsigned int)));
      memset((void *) Sij[i][j], 0, bins * (sizeof(unsigned int)));
    }

  }

  #pragma omp parallel for default(shared) private(i,j)
  for (i = 0; i < bins; i++)
  {
    unsigned short st[3];
    double distance = i * step;
    for (j = 0; j < points_per_bin; j++)
    {
      int bin_x;
      int bin_xdx;
      double x[3];
      double v[3];
      x[0] = random_uniform_r(st, 0, mesh.size[0]);
      x[1] = random_uniform_r(st, 0, mesh.size[1]);
      x[2] = random_uniform_r(st, 0, mesh.size[2]);
      bin_x = (*mesh.voxel_content)((int) x[0], (int) x[1], (int) x[2]);
      random_unit_vector_r(st, v);
      x[0] += distance * v[0];
      x[1] += distance * v[1];
      x[2] += distance * v[2];
      if ((((((x[0] < 0) || (x[0] >= mesh.size[0])) || (x[1] < 0)) || (x[1] >= mesh.size[1])) || (x[2] < 0)) || (x[2] >= mesh.size[2]))
      {
        j = j - 1;
        continue;
      }

      bin_xdx = (*mesh.voxel_content)((int) x[0], (int) x[1], (int) x[2]);
      #pragma omp atomic
      Sij[bin_x][bin_xdx][i]++;
    }

  }

  for (k = 0; k < bins; k++)
  {
    fprintf(output, "%8.3f ", (max_distance * k) / (bins - 1));
    for (i = 0; i <= particle_bins; i++)
      for (j = 0; j <= particle_bins; j++)
      fprintf(output, "%.6f ", ((double) Sij[i][j][k]) / points_per_bin);


    fprintf(output, "\n");
  }

  for (i = 0; i < particle_bins; i++)
  {
    for (j = 0; j < particle_bins; j++)
      free(Sij[i][j]);

    free(Sij[i]);
  }

}

