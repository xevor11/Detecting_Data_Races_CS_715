float R = 1.0;
float GAMA = 7. / 5.;
float CV = R / (GAMA - 1.0);
float CP = CV + R;
float *olddens;
float *newdens;
float *oldxv;
float *newxv;
float *oldtemp;
float *newtemp;
float *oldpress;
float *newpress;
float *cx;
float U[200][3];
float U_new[200][3];
float *F;
float *FL;
float *FR;
float FP[200][3];
float FM[200][3];
float dFP[200][3];
float dFM[200][3];
void Allocate_Memory();
void Init();
void Free();
void CalculateFlux();
void CalculateFPFM();
void CalculateResult();
void Save_Results();
void CalculateFPFM()
{
  int i;
  int k;
  float dFP_left;
  float dFP_right;
  float dFM_left;
  float dFM_right;
  omp_set_num_threads(16);
  #pragma omp parallel for
  for (i = 0; i < 200; i++)
  {
    dFP[i][0] = 0.0;
    dFP[i][1] = 0.0;
    dFP[i][2] = 0.0;
    dFM[i][0] = 0.0;
    dFM[i][1] = 0.0;
    dFM[i][2] = 0.0;
    if ((i > 0) && (i < (200 - 1)))
    {
      for (k = 0; k < 3; k++)
      {
        dFP_left = FP[i + 1][k] - FP[i][k];
        dFP_right = FP[i][k] - FP[i - 1][k];
        if ((dFP_left * dFP_right) > 0)
        {
          if (abs(dFP_right) < abs(dFP_left))
          {
            dFP[i][k] = dFP_right / (1.0 / 200);
          }
          else
            dFP[i][k] = dFP_left / (1.0 / 200);

        }

        dFM_left = FM[i + 1][k] - FM[i][k];
        dFM_right = FM[i][k] - FM[i - 1][k];
        if ((dFM_left * dFM_right) > 0)
        {
          if (abs(dFM_right) < abs(dFM_left))
          {
            dFM[i][k] = dFM_right / (1.0 / 200);
          }
          else
            dFM[i][k] = dFM_left / (1.0 / 200);

        }

      }

    }

  }

}

