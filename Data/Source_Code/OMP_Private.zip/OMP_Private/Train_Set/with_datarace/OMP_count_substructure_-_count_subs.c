void count_subs(int num_threads, long int *Nhalos, long long int *NEWdeepID_array, long long int *hostHalo_array, long long int *substructure_array);
void count_subs(int num_threads, long int *Nhalos, long long int *NEWdeepID_array, long long int *hostHalo_array, long long int *substructure_array)
{
  printf("Starting count_subs. There are %lli halos.\n", *Nhalos);
  long int halo;
  int chunk = 100;
  int nthreads;
  int tid;
  omp_set_num_threads(num_threads);
  #pragma omp parallel shared(hostHalo_array, NEWdeepID_array, substructure_array)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }

    #pragma omp for schedule(dynamic, chunk)
    for (halo = 0; halo < (*Nhalos); halo++)
    {
      long long int numsubs = 0;
      long int current_halo = NEWdeepID_array[halo];
      int host;
      for (host = 0; host < (*Nhalos); host++)
      {
        if (hostHalo_array[host] == current_halo)
        {
          numsubs++;
        }
        else
        {
          continue;
        }

      }

      substructure_array[halo] = numsubs;
    }

  }
}

