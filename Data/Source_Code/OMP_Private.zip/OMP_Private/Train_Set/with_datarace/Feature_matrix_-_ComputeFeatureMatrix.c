void dgemm_(char *TRANSA, char *TRANSB, int *M, int *N, int *K, double *ALPHA, double *A, int *LDA, double *B, int *LDB, double *BETA, double *C, int *LDC);
void ComputeFeatureMatrix(int n, int d, int r, double *X, double *w, double *b, double *Z, double sigma)
{
  int i;
  int j;
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < r; j++)
    {
      Z[i + (j * n)] = b[j];
    }

  }

  double ONE = 1.0;
  char TRANS_N = 'N';
  dgemm_(&TRANS_N, &TRANS_N, &n, &r, &d, &ONE, X, &n, w, &d, &ONE, Z, &n);
  double two = 2;
  double fac = sqrt(two / r);
  #pragma omp parallel for
  for (i = 0; i < (n * r); i++)
  {
    Z[i] = cos(Z[i]) * fac;
  }


  int i;
  int nthreads;
  int tid;
  float a[50];
  float b[50];
  float c[50];
  float d[50];
  for (i = 0; i < 50; i++)
  {
    a[i] = i * 1.5;
    b[i] = i + 22.35;
    c[i] = (d[i] = 0.0);
  }

  #pragma omp parallel shared (a,b,c,d,nthreads) private(i,tid)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }

    printf("Thread %d starting...\n", tid);
    #pragma omp sections nowait
    {
      #pragma omp section
      {
        printf("Thread %d doing section 1\n", tid);
        for (i = 0; i < 50; i++)
        {
          c[i] = a[i] + b[i];
          printf("Thread %d: c[%d]= %f\n", tid, i, c[i]);
        }

      }
      #pragma omp section
      {
        printf("Thread %d doing section 2\n", tid);
        for (i = 0; i < 50; i++)
        {
          d[i] = a[i] * b[i];
          printf("Thread %d: d[%d]= %f\n", tid, i, d[i]);
        }

      }
    }
    printf("Thread %d done.\n", tid);
  }
}

