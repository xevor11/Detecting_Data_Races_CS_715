struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
void escalarMatrixMultiplication(double **m, int f, int c, double val)
{
  #pragma omp parallel for private(i, j, k)
  for (i = 0; i <= (225 - 1); i++)
    for (j = 0; j <= (225 - 1); j++)
    for (k = 0; k <= (225 - 1); k++)
  {
    if ((((((i == 0) || (i == (225 - 1))) || (j == 0)) || (j == (225 - 1))) || (k == 0)) || (k == (225 - 1)))
      A[i][j][k] = 0.;
    else
      A[i][j][k] = ((4. + i) + j) + k;

  }




  int i;
  int j;
  double aux;
  #pragma omp parallel for default(shared) schedule(guided,chunk) reduction(*:aux)
  for (i = 0; i < f; i++)
  {
    for (j = 0; j < c; j++)
    {
      aux = m[i][j] * val;
      m[i][j] = aux;
    }

  }

}

