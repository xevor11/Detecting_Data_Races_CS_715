extern int decode;
extern int latlon;
extern int flush_mode;
extern enum output_order_type output_order;
extern int use_scale;
extern int dec_scale;
extern int bin_scale;
extern int wanted_bits;
extern int max_bits;
extern enum output_grib_type grib_type;
extern double *lat;
extern double *lon;
extern int npts;
extern int nx;
extern int ny;
extern int scan;
static unsigned int idx(int ix, int iy, int nx, int ny, int cyclic_grid);
int small_grib(unsigned char **sec, int mode, float *data, double *lon, double *lat, unsigned int ndata, int ix0, int ix1, int iy0, int iy1, FILE *out)
{
  int k;
  int big[32] = {1, 2, 4, 5, 8, 10, 13, 14, 16, 18, 19, 22, 25, 27, 29, 30, 3, 6, 7, 9, 11, 12, 15, 17, 20, 21, 23, 24, 26, 28, 31, 32};
  int *A = big;
  int *B = &big[16];
  int C[32];
  register int i;
  for (i = 0; i < 32; i++)
    C[i] = -1;

  int ln = 5;
  int x = 32 / 5;
  printf("Source array 1:  ");
  printarr(A, 16);
  printf("Source array 2:  ");
  printarr(B, 16);
  int ind;
  int inds[x];
  int onepass = 0;
  if (onepass)
  {
    #pragma omp parallel for private(ind)
    for (k = 0; k < 32; k += x)
    {
      ind = (k > 15) ? ((bs(A, big[k], 16, 0) + k) - 16) : (bs(B, big[k], 16, 0) + k);
      C[ind] = big[k];
      inds[k / x] = ind;
    }

    printf("Result (seg'd):  ");
    printarr(C, 32);
  }
  else
  {
    #pragma omp parallel for private(ind)
    for (k = 0; k < 16; k += x)
    {
      ind = bs(B, big[k], 16, 0) + k;
      C[ind] = big[k];
      inds[k / x] = ind;
    }

    printf("Result (pass 1): ");
    printarr(C, 32);
    #pragma omp parallel for private(ind)
    for (k = (16 - (16 % x)) + x; k < 32; k += x)
    {
      ind = (bs(A, big[k], 16, 0) + k) - 16;
      C[ind] = big[k];
      inds[k / x] = ind;
    }

    printf("Result (pass 2): ");
    printarr(C, 32);
  }

  int a;
  int b;
  #pragma omp parallel for private(a,b)
  for (k = 0; k < x; k++)
  {
    int ind = inds[k];
    a = bs(A, C[ind], 16, 0);
    b = bs(B, C[ind], 16, 0);
    if (A[a] == C[ind])
      a++;

    if (B[b] == C[ind])
      b++;

    ind++;
    while (C[ind] < 0)
    {
      if ((a > 15) && (b < 16))
        C[ind++] = B[b++];
      else
        if ((b > 15) && (a < 16))
        C[ind++] = A[a++];
      else
        C[ind++] = (A[a] < B[b]) ? (A[a++]) : (B[b++]);


    }

  }

  printf("Final result:    ");
  printarr(C, 32);

  int can_subset;
  int grid_template;
  int nx;
  int ny;
  int res;
  int scan;
  int new_nx;
  int new_ny;
  int i;
  int j;
  unsigned int sec3_len;
  unsigned int new_ndata;
  unsigned int k;
  unsigned int npnts;
  unsigned char *sec3;
  unsigned char *new_sec[8];
  double units;
  int basic_ang;
  int sub_ang;
  int cyclic_grid;
  float *new_data;
  get_nxny(sec, &nx, &ny, &npnts, &res, &scan);
  grid_template = code_table_3_1(sec);
  sec3_len = GB2_Sec3_size(sec);
  sec3 = (unsigned char *) malloc(sec3_len);
  for (k = 0; k < sec3_len; k++)
    sec3[k] = sec[3][k];

  new_sec[0] = sec[0];
  new_sec[1] = sec[1];
  new_sec[2] = sec[2];
  new_sec[3] = sec3;
  new_sec[4] = sec[4];
  new_sec[5] = sec[5];
  new_sec[6] = sec[6];
  new_sec[7] = sec[7];
  can_subset = 1;
  if ((lat == 0) || (lon == 0))
    can_subset = 0;

  new_nx = (ix1 - ix0) + 1;
  new_ny = (iy1 - iy0) + 1;
  if (new_nx <= 0)
    fatal_error("small_grib, new_nx is <= 0", "");

  if (new_ny <= 0)
    fatal_error("small_grib, new_ny is <= 0", "");

  new_ndata = new_nx * new_ny;
  cyclic_grid = 0;
  if (can_subset)
  {
    cyclic_grid = cyclic(sec);
    if (((grid_template == 0) && (sec3_len == 72)) || ((grid_template == 1) && (sec3_len == 04)))
    {
      uint_char(new_nx, sec3 + 30);
      uint_char(new_ny, sec3 + 34);
      basic_ang = GDS_LatLon_basic_ang(sec3);
      sub_ang = GDS_LatLon_sub_ang(sec3);
      if (basic_ang != 0)
      {
        units = ((double) basic_ang) / ((double) sub_ang);
      }
      else
      {
        units = 0.000001;
      }

      i = lat[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 46);
      i = lon[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 50);
      i = lat[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 55);
      i = lon[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 59);
    }
    else
      if ((grid_template == 40) && (sec3_len == 72))
    {
      uint_char(new_nx, sec3 + 30);
      uint_char(new_ny, sec3 + 34);
      basic_ang = GDS_Gaussian_basic_ang(sec3);
      sub_ang = GDS_Gaussian_sub_ang(sec3);
      if (basic_ang != 0)
      {
        units = ((double) basic_ang) / ((double) sub_ang);
      }
      else
      {
        units = 0.000001;
      }

      i = lat[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 46);
      i = lon[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 50);
      i = lat[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 55);
      i = lon[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 59);
    }
    else
      if (((grid_template == 20) && (sec3_len == 65)) || ((grid_template == 30) && (sec3_len == 81)))
    {
      uint_char(new_nx, sec3 + 30);
      uint_char(new_ny, sec3 + 34);
      i = (int) (lat[idx(ix0, iy0, nx, ny, cyclic_grid)] * 1000000.0);
      int_char(i, sec3 + 38);
      i = (int) (lon[idx(ix0, iy0, nx, ny, cyclic_grid)] * 1000000.0);
      int_char(i, sec3 + 42);
    }
    else
      if ((grid_template == 10) && (sec3_len == 72))
    {
      uint_char(new_nx, sec3 + 30);
      uint_char(new_ny, sec3 + 34);
      units = 0.000001;
      i = lat[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 38);
      i = lon[idx(ix0, iy0, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 42);
      i = lat[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 51);
      i = lon[idx(ix1, iy1, nx, ny, cyclic_grid)] / units;
      int_char(i, sec3 + 55);
    }
    else
    {
      can_subset = 0;
    }




  }

  if (can_subset)
  {
    uint_char(new_ndata, sec3 + 6);
    new_data = (float *) malloc(new_ndata * (sizeof(float)));
    #pragma omp parallel for
    for (j = iy0; j <= iy1; j++)
    {
      k = (j - iy0) * ((ix1 - ix0) + 1);
      for (i = ix0; i <= ix1; i++)
      {
        new_data[(i - ix0) + k] = data[idx(i, j, nx, ny, cyclic_grid)];
      }

    }

  }
  else
  {
    new_ndata = ndata;
    new_data = (float *) malloc(new_ndata * (sizeof(float)));
    for (k = 0; k < ndata; k++)
      new_data[k] = data[k];

    new_nx = nx;
    new_ny = ny;
  }

  set_order(new_sec, output_order);
  grib_wrt(new_sec, new_data, new_ndata, new_nx, new_ny, use_scale, dec_scale, bin_scale, wanted_bits, max_bits, grib_type, out);
  if (flush_mode)
    fflush(out);

  free(new_data);
  free(sec3);
  return 0;
}

