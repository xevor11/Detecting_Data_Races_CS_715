int main();
void test01();
void test02();
void test03();
void test04();
float r4_exp(uint32_t *jsr, uint32_t ke[256], float fe[256], float we[256]);
void r4_exp_setup(uint32_t ke[256], float fe[256], float we[256]);
float r4_nor(uint32_t *jsr, uint32_t kn[128], float fn[128], float wn[128]);
void r4_nor_setup(uint32_t kn[128], float fn[128], float wn[128]);
float r4_uni(uint32_t *jsr);
uint32_t shr3_seeded(uint32_t *jsr);
void timestamp();
int partition(float bucket[], int low, int high);
int mergesort(float bucket[], int low, int mid, int high);
int bucket(float *arr, int size, int max_number);
int rank;
int Node_size;
int main(int argc, char *argv[])
{
  int i;
  double sum = 0.0;
  #pragma omp parallel for reduction(+:sum) private(i)
  #pragma novector
  for (i = 0; i < N; ++i)
  {
    double c = 0.0;
    double prod = a[i] * b[i];
    double y = prod - c;
    double t = sum + y;
    c = (t - sum) - y;
    sum = t;
  }

  *r = sum;

  int i;
  int range;
  int j;
  int bukrow;
  int low;
  int high;
  int size;
  int max_number;
  int Node_size;
  int rank;
  clock_t begin;
  clock_t end;
  if (strcmp("-t", argv[1]) != 0)
  {
    printf("Error\n");
    return 0;
  }

  size = atoi(argv[2]);
  max_number = atoi(argv[2]);
  static float arr[1000000];
  static float bucket[20][1000000];
  for (i = 0; i < 20; i++)
  {
    for (j = 0; j < size; j++)
      bucket[i][j] = 0;

  }

  random_number_generator_simple(arr, size, max_number);
  begin = clock();
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &Node_size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  range = 1 + floor(size / Node_size);
  #pragma omp parallel shared(bucket)
  {
    #pragma omp for
    for (i = 0, j = 0; (j < size) && (i < size); i++)
    {
      if (floor(arr[i] / range) == rank)
      {
        bucket[rank][j] = arr[i];
        j++;
      }

    }

  }
  low = 0;
  high = j - 1;
  if (high <= 0)
  {
  }
  else
    partition(bucket[rank], low, high);

  end = clock();
  printf("\n");
  printf("\n");
  if (rank == 0)
    printf("The time is: %f\n", ((double) (end - begin)) / CLOCKS_PER_SEC);

  MPI_Finalize();
  return 0;
}

