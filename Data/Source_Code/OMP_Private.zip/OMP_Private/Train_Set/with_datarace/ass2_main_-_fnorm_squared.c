double fnorm_squared(double **u, double **uo, int N)
{
  int i;
  int j;
  double sum = 0;
  #pragma omp for reduction(+:sum)
  for (i = 1; i < (N - 1); i++)
  {
    for (j = 1; j < (N - 1); j++)
    {
      sum += (u[i][j] - uo[i][j]) * (u[i][j] - uo[i][j]);
    }

  }

  return sum / (N * N);
}

