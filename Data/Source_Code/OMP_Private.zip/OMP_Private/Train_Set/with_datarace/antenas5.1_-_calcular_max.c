{
  uint32_t ui32Idx;
  uint32_t ui32IdxCount;
  ;
  uint32_t ui32TotalSize;
  char *pcSizeString;
  uint32_t ui32SizePrint;
  volatile double *pdBuffer;
  ui32TotalSize = ui32Size >> 1;
  pdBuffer = (double *) pfBuffer;
  if (ui32TotalSize < (1024 * 1024))
  {
    ui32SizePrint = ui32Size / 1024;
    pcSizeString = "K";
  }
  else
    if (ui32TotalSize < ((1024 * 1024) * 1024))
  {
    ui32SizePrint = ui32Size / (1024 * 1024);
    pcSizeString = "M";
  }
  else
  {
    ui32SizePrint = ui32Size / ((1024 * 1024) * 1024);
    pcSizeString = "G";
  }


  if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
  {
    ui32IdxCount = ui32TotalSize;
  }
  else
  {
    ui32IdxCount = DESTBUFFERSIZE >> 1;
  }

  for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
  {
    pdBuffer[ui32Idx] = ui32Idx + 0.001;
  }

  g_ui64StartTime = (uint64_t) TSCL;
  g_ui64StartTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  while (ui32TotalSize)
  {
    if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
    {
      ui32IdxCount = ui32TotalSize;
    }
    else
    {
      ui32IdxCount = DESTBUFFERSIZE >> 1;
    }

    #pragma omp parallel private(ui32Idx) shared(ui32IdxCount,pfBuffer)
    {
      #pragma omp for
      for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
      {
        pdBuffer[ui32Idx] = atan2dp(pdBuffer[ui32Idx], (double) 2.344356789);
      }

    }
    ui32TotalSize = ui32TotalSize - ui32IdxCount;
  }

  g_ui64StopTime = (uint64_t) TSCL;
  g_ui64StopTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  g_ui64ElapsedTime = g_ui64StopTime - g_ui64StartTime;
  ui32TotalSize = ui32Size >> 1;
  if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
  {
    ui32IdxCount = ui32TotalSize;
  }
  else
  {
    ui32IdxCount = DESTBUFFERSIZE >> 1;
  }

  for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
  {
    pdBuffer[ui32Idx] = ui32Idx + 0.002;
  }

  g_ui64StartTime = (uint64_t) TSCL;
  g_ui64StartTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  while (ui32TotalSize)
  {
    if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
    {
      ui32IdxCount = ui32TotalSize;
    }
    else
    {
      ui32IdxCount = DESTBUFFERSIZE >> 1;
    }

    #pragma omp parallel private(ui32Idx) shared(ui32IdxCount,pfBuffer)
    {
      #pragma omp for
      for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
      {
        pdBuffer[ui32Idx] = atan2dp(pdBuffer[ui32Idx], (double) 2.543245786542);
      }

    }
    ui32TotalSize = ui32TotalSize - ui32IdxCount;
  }

  g_ui64StopTime = (uint64_t) TSCL;
  g_ui64StopTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  g_ui64ElapsedTime = (g_ui64ElapsedTime + g_ui64StopTime) - g_ui64StartTime;
  printf("MATHLIB_TEST %sdp %d%s(%d) words Elapsed_Cycles: %llu Elapsed_Time: %llu (ns) Cycles/Word: %llu \n\n", psFuncName, ui32SizePrint, pcSizeString, ui32Size, (uint64_t) g_ui64ElapsedTime, (uint64_t) g_ui64ElapsedTime, (uint64_t) (g_ui64ElapsedTime / ui32Size));
  ui32TotalSize = ui32Size >> 1;
  if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
  {
    ui32IdxCount = ui32TotalSize;
  }
  else
  {
    ui32IdxCount = DESTBUFFERSIZE >> 1;
  }

  for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
  {
    pdBuffer[ui32Idx] = ui32Idx + 0.001;
  }

  g_ui64StartTime = (uint64_t) TSCL;
  g_ui64StartTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  while (ui32TotalSize)
  {
    if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
    {
      ui32IdxCount = ui32TotalSize;
    }
    else
    {
      ui32IdxCount = DESTBUFFERSIZE >> 1;
    }

    #pragma omp parallel private(ui32Idx) shared(ui32IdxCount,pfBuffer)
    {
      #pragma omp for
      for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
      {
        pdBuffer[ui32Idx] = atan2dp_i(pdBuffer[ui32Idx], (double) 2.35644356789);
      }

    }
    ui32TotalSize = ui32TotalSize - ui32IdxCount;
  }

  g_ui64StopTime = (uint64_t) TSCL;
  g_ui64StopTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  g_ui64ElapsedTime = g_ui64StopTime - g_ui64StartTime;
  ui32TotalSize = ui32Size >> 1;
  if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
  {
    ui32IdxCount = ui32TotalSize;
  }
  else
  {
    ui32IdxCount = DESTBUFFERSIZE >> 1;
  }

  for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
  {
    pdBuffer[ui32Idx] = ui32Idx + 0.002;
  }

  g_ui64StartTime = (uint64_t) TSCL;
  g_ui64StartTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  while (ui32TotalSize)
  {
    if (ui32TotalSize < (DESTBUFFERSIZE >> 1))
    {
      ui32IdxCount = ui32TotalSize;
    }
    else
    {
      ui32IdxCount = DESTBUFFERSIZE >> 1;
    }

    #pragma omp parallel private(ui32Idx) shared(ui32IdxCount,pfBuffer)
    {
      #pragma omp for
      for (ui32Idx = 0; ui32Idx < ui32IdxCount; ui32Idx++)
      {
        pdBuffer[ui32Idx] = atan2dp_i(pdBuffer[ui32Idx], (double) 2.344356789);
      }

    }
    ui32TotalSize = ui32TotalSize - ui32IdxCount;
  }

  g_ui64StopTime = (uint64_t) TSCL;
  g_ui64StopTime |= (uint64_t) (((uint64_t) TSCH) << 32);
  g_ui64ElapsedTime = (g_ui64ElapsedTime + g_ui64StopTime) - g_ui64StartTime;
  printf("MATHLIB_TEST %sdp_i %d%s(%d) words Elapsed_Cycles: %llu Elapsed_Time: %llu (ns) Cycles/Word: %llu \n\n", psFuncName, ui32SizePrint, pcSizeString, ui32Size, (uint64_t) g_ui64ElapsedTime, (uint64_t) g_ui64ElapsedTime, (uint64_t) (g_ui64ElapsedTime / ui32Size));

  int y;
  int x;
} Antena;
{
  int valor;
  int x;
  int y;
} Registro;
int num_hilos;
Antena calcular_max(int **mapa, int rows, int cols, Registro *registros)
{
  int maximo = 0;
  int numHilo;
  #pragma omp parallel for shared(mapa,registros) firstprivate(maximo)
  for (int i = 0; i < rows; i++)
  {
    numHilo = omp_get_thread_num();
    for (int j = 0; j < cols; j++)
    {
      if (mapa[i][j] > maximo)
      {
        maximo = mapa[i][j];
        registros[numHilo].x = i;
        registros[numHilo].y = j;
        registros[numHilo].valor = mapa[i][j];
      }

    }

  }

  maximo = 0;
  for (int i = 0; i < num_hilos; i++)
    if (registros[i].valor > registros[maximo].valor)
    maximo = i;


  Antena antena = {registros[maximo].x, registros[maximo].y};
  return antena;
}

