double xref[n];
double yref[n];
double zref[n];
double x[n];
double y[n];
double z[n];
double a[n][n];
void compare();
int main()
{
  double rtclock();
  int tt;
  int i;
  int j;
  int nt;
  double clkbegin;
  double clkend;
  double t;
  double maxdiff;
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
    {
      a[i][j] = sin(i) * sin(j);
    }

    xref[i] = sin(i);
    yref[i] = cos(i);
    zref[i] = sin(i) * cos(i);
  }

  clkbegin = rtclock();
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
  {
    yref[i] = yref[i] + (a[i][j] * xref[j]);
    zref[i] = zref[i] + (a[j][i] * xref[j]);
  }


  clkend = rtclock();
  t = clkend - clkbegin;
  printf("%.1f Sequential MFLOPS;  \n", (((4 * n) * n) / t) / 1000000);
  printf("Maximum threads allowed by system is: %d\n", omp_get_max_threads());
  for (nt = 1; nt <= 8; nt++)
  {
    omp_set_num_threads(nt);
    for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
      {
        a[i][j] = sin(i) * sin(j);
      }

      x[i] = sin(i);
      y[i] = cos(i);
      z[i] = sin(i) * cos(i);
    }

    clkbegin = rtclock();
    {
      #pragma omp parallel
      {
        #pragma omp for schedule(dynamic, 16)
        for (i = 0; i < n; i++)
          for (j = 0; j < n; j++)
        {
          y[i] = y[i] + (a[i][j] * x[j]);
          z[i] = z[i] + (a[j][i] * x[j]);
        }


      }
    }
    clkend = rtclock();
    t = clkend - clkbegin;
    printf("%.1f MFLOPS with %d threads; Time = %.3f sec; ", (((4 * n) * n) / t) / 1000000, nt, t);
    compare();
  }

}

