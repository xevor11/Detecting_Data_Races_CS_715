int main(int argc, const char *argv[])
{
  int nthreads;
  int tid;
  int T = 2;
  char c;
  char name[50];
  if (argc <= 1)
  {
    print_usage(argv[0]);
  }
  else
  {
    while ((c = getopt(argc, argv, "ht:")) != EOF)
    {
      switch (c)
      {
        case 'h':
          print_usage(argv[0]);

        case 't':
          T = atoi(optarg);
          break;

        default:
          print_usage(argv[0]);

      }

    }

  }

  #pragma omp parallel private(nthreads, tid) num_threads(T)
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      gethostname(name, 50);
      printf("Number of threads on node %s = %d\n", name, nthreads);
    }

  }
  exit(0);

  int t1;
  int t2;
  int t3;
  int lb;
  int ub;
  int lbp;
  int ubp;
  int lb2;
  int ub2;
  register int lbv;
  register int ubv;
  lbv = 0;
  ubv = 10;
  #pragma ivdep
  #pragma vector always
  for (t2 = lbv; t2 <= ubv; t2++)
  {
    a[(3 * 0) + 1][t2 + (2 * 0)] = (2 * 0) + (5 * t2);
    ;
  }

  c[0][0] = a[0 + 3][0 + 1];
  ;
  lbv = 2;
  ubv = 11;
  #pragma ivdep
  #pragma vector always
  for (t2 = lbv; t2 <= ubv; t2++)
  {
    c[0][t2 - 1] = a[0 + 3][(t2 - 1) + 1];
    ;
  }

  lbp = 3;
  ubp = 12;
  #pragma omp parallel for
  for (t1 = lbp; t1 <= ubp; t1++)
  {
    lbv = 1;
    ubv = floor(((double) ((2 * t1) - 1)) / ((double) 3));
    #pragma ivdep
    #pragma vector always
    for (t2 = lbv; t2 <= ubv; t2++)
    {
      c[t1 - 2][t2 - 1] = a[(t1 - 2) + 3][(t2 - 1) + 1];
      ;
    }

    lbv = ceil(((double) (2 * t1)) / ((double) 3));
    ubv = 11;
    #pragma ivdep
    #pragma vector always
    for (t2 = lbv; t2 <= ubv; t2++)
    {
      if ((t1 % 3) == 0)
      {
        a[(3 * (t1 / 3)) + 1][((((-2) * t1) + (3 * t2)) / 3) + (2 * (t1 / 3))] = (2 * (t1 / 3)) + (5 * ((((-2) * t1) + (3 * t2)) / 3));
        ;
      }

      c[t1 - 2][t2 - 1] = a[(t1 - 2) + 3][(t2 - 1) + 1];
      ;
    }

    lbv = 12;
    ubv = floor(((double) ((2 * t1) + 30)) / ((double) 3));
    #pragma ivdep
    #pragma vector always
    for (t2 = lbv; t2 <= ubv; t2++)
    {
      if ((t1 % 3) == 0)
      {
        a[(3 * (t1 / 3)) + 1][((((-2) * t1) + (3 * t2)) / 3) + (2 * (t1 / 3))] = (2 * (t1 / 3)) + (5 * ((((-2) * t1) + (3 * t2)) / 3));
        ;
      }

    }

  }

  lbp = 13;
  ubp = 30;
  #pragma omp parallel for
  for (t1 = lbp; t1 <= ubp; t1++)
  {
    lbv = ceil(((double) (2 * t1)) / ((double) 3));
    ubv = floor(((double) ((2 * t1) + 30)) / ((double) 3));
    #pragma ivdep
    #pragma vector always
    for (t2 = lbv; t2 <= ubv; t2++)
    {
      if ((t1 % 3) == 0)
      {
        a[(3 * (t1 / 3)) + 1][((((-2) * t1) + (3 * t2)) / 3) + (2 * (t1 / 3))] = (2 * (t1 / 3)) + (5 * ((((-2) * t1) + (3 * t2)) / 3));
        ;
      }

    }

  }

  return 0;
}

