void multiplica2(int m, int n, int **matA, int **matB, int **matC, int nucleos)
{
  int i;
  int j;
  int k;
  int som;
  #pragma omp parallel for num_threads(nucleos)
  for (j = 0; j < m; j++)
  {
    for (i = 0; i < n; i++)
    {
      for (k = 0; k < m; k += 4)
      {
        matC[i][j] += matA[i][k] * matB[k][j];
        matC[i][j] += matA[i][k + 1] * matB[k + 1][j];
        matC[i][j] += matA[i][k + 2] * matB[k + 2][j];
        matC[i][j] += matA[i][k + 3] * matB[k + 3][j];
      }

    }

  }


  FILE *ppmfile;
  char filename[32];
  int i;
  int j;
  int k;
  int frame;
  int idx;
  byte lut[256][3];
  byte *rgb;
  if (bw)
  {
    #pragma omp parallel for schedule(static)
    for (i = 0; i < 256; i++)
    {
      lut[i][0] = (lut[i][1] = (lut[i][2] = (byte) i));
    }

  }
  else
  {
    #pragma omp parallel for schedule(static)
    for (i = 0; i < 256; i++)
    {
      lut[i][0] = (byte) i;
      lut[i][1] = (byte) (127 + (2 * ((i < 64) ? (i) : ((i < 192) ? (128 - i) : (i - 255)))));
      lut[i][2] = (byte) (255 - i);
    }

  }

  rgb = malloc(((3 * N) * N) * (sizeof(byte)));
  #pragma omp parallel for private(i,j,k) schedule(static)
  for (frame = 0; frame < NFRAMES; frame++)
  {
    k = 0;
    for (i = 0; i < N; i++)
    {
      for (j = 0; j < N; j++)
      {
        idx = (int) u[frame][i][j];
        rgb[k++] = (byte) lut[idx][0];
        rgb[k++] = (byte) lut[idx][1];
        rgb[k++] = (byte) lut[idx][2];
      }

    }

    if (N >= 255)
    {
      int i0 = (N / 2) - 128;
      #pragma omp parallel for private(j) schedule(static)
      for (i = 0; i < 256; i++)
      {
        k = 3 * (((i + i0) * N) + 10);
        for (j = 0; j < 16; j++)
        {
          rgb[k++] = lut[i][0];
          rgb[k++] = lut[i][1];
          rgb[k++] = lut[i][2];
        }

      }

    }

    sprintf(filename, "frame%04d.ppm", frame);
    ppmfile = fopen(filename, "wb");
    fprintf(ppmfile, "P6\n");
    fprintf(ppmfile, "%d %d\n", N, N);
    fprintf(ppmfile, "255\n");
    fwrite(rgb, sizeof(byte), (3 * N) * N, ppmfile);
    fclose(ppmfile);
  }

  free(rgb);
}

