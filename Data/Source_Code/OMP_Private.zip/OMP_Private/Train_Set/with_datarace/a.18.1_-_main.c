extern void abort(void);
int synch[4];
int work[4];
int result[4];
int main()
{
  int n;
  int max_iter = 1;
  int number_solutions = 0;
  int i;
  n = 9;
  for (i = 0; i < n; i++)
  {
    max_iter *= n;
  }

  int iter;
  int code;
  int queen_rows[16];
  #pragma omp parallel for reduction(+:number_solutions) private(code, queen_rows) check
  for (iter = 0; iter < max_iter; iter++)
  {
    int i;
    code = iter;
    for (i = 0; i < n; i++)
    {
      queen_rows[i] = code % n;
      code /= n;
    }

    if (check_acceptable(queen_rows, n))
    {
      number_solutions += 1;
    }

    for (i = 0; i < n; i++)
    {
      queen_rows[i] = 0;
    }

  }

  printf("Number of found solutions is %d\n", number_solutions);
  return 0;

  int i;
  int iam;
  int neighbor;
  omp_set_num_threads(4);
  #pragma omp parallel shared(work,synch)
  {
    iam = omp_get_thread_num();
    synch[iam] = 0;
    #pragma omp barrier
    work[iam] = fn1(iam);
    #pragma omp flush(work,synch)
    synch[iam] = 1;
    #pragma omp flush(synch)
    neighbor = ((iam > 0) ? (iam) : (omp_get_num_threads())) - 1;
    while (synch[neighbor] == 0)
    {
      #pragma omp flush(synch)
    }

    #pragma omp flush(work,synch)
    result[iam] = fn2(work[neighbor], work[iam]);
  }
  for (i = 0; i < 4; i++)
  {
    neighbor = ((i > 0) ? (i) : (4)) - 1;
    if (result[i] != ((i * 2) + (neighbor * 2)))
      abort();

  }

  return 0;
}

