int main(int argc, const char *argv[])
{
  int A[100];
  int B[100];
  int S[100];
  int i;
  srand(time(0));
  #pragma omp parallel
  {
    printf("Hilo %d de %d \n", omp_get_thread_num(), omp_get_num_threads());
    for (i = 0; i < 100; i++)
    {
      A[i] = rand() % 100;
      B[i] = rand() % 100;
      S[i] = 0;
    }

  }
  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < 100; i++)
    {
      S[i] = A[i] + B[i];
    }

  }
  for (i = 0; i < 100; i++)
  {
    printf("[%7d] %3d + %3d = %4d \n", i, A[i], B[i], S[i]);
  }

  return 0;
}

