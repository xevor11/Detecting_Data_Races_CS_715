void axpy_base(int N, float Y[], float X[], float a);
void axpy_base_sub(int i_start, int Nt, int N, float Y[], float X[], float a);
void axpy_dist(int N, float Y[], float X[], float a, int num_tasks);
void axpy_pthread(int N, float Y[], float X[], float a, int num_tasks);
void axpy_openmp(int N, float Y[], float X[], float a, int num_tasks);
void axpy_openmp(int N, float Y[], float X[], float a, int num_tasks)
{
  int i;
  #pragma omp parallel for shared(N, X, Y) num_threads(num_tasks)
  for (i = 0; i < N; ++i)
    Y[i] += a * X[i];

}

