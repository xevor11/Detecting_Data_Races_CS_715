int **get_array();
int **distance(int **count_mat);
int min(int l, int p);
int *trace_back(int **trace_mat);
int **distance(int **count_mat)
{
  int i;
  int j = 0;
  int **my_dist = malloc(10 * (sizeof(int *)));
  for (i = 0; i < 10; i++)
  {
    my_dist[i] = malloc(10 * (sizeof(int)));
  }

  #pragma omp paralel for schedule(static)
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 10; j++)
    {
      my_dist[i][j] = 99;
    }

  }

  for (i = 0; i < (10 - 1); i++)
  {
    for (j = 0; j < 10; j++)
    {
      my_dist[0][0] = 0;
      if (count_mat[i][j] == 0)
      {
        my_dist[i][j] = 99;
      }
      else
        if ((count_mat[i + 1][j] == 1) || (count_mat[i][j + 1] == 1))
      {
        if (count_mat[i + 1][j] == 1)
        {
          my_dist[i + 1][j] = min(my_dist[i][j] + 1, my_dist[i + 1][j]);
        }

        if (count_mat[i][j + 1] == 1)
        {
          my_dist[i][j + 1] = min(my_dist[i][j] + 1, my_dist[i][j + 1]);
        }

      }
      else
      {
        my_dist[i][j] = my_dist[i][j];
      }


    }

  }

  return my_dist;
}

