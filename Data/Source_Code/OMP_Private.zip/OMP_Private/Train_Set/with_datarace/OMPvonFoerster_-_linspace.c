struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
void linspace(double a, double b, int c, double *d)
{
  double aa = ((double) b) - a;
  double bb = ((double) c) - 1;
  double delta = aa / bb;
  int i;
  #pragma omp parallel shared(a, d, c, delta, chunk)
  {
    #pragma omp for schedule(static, chunk) nowait
    for (i = 0; i < c; i++)
    {
      d[i] = a + (i * delta);
    }

  }

  double diff;
  double epsilon = 0.001;
  int i;
  int iterations;
  int iterations_print;
  int j;
  double mean;
  double my_diff;
  double u[500][500];
  double w[500][500];
  double wtime;
  int procs = omp_get_num_procs();
  int th = omp_get_max_threads();
  printf("\n");
  printf("HEATED_PLATE_OPENMP\n");
  printf("  A program to solve for the steady state temperature distribution\n");
  printf("  over a rectangular plate.\n");
  printf("\n");
  printf("  Spatial grid of %d by %d points.\n", 500, 500);
  printf("  The iteration will be repeated until the change is <= %e\n", epsilon);
  printf("  Number of processors available = %d\n", procs);
  printf("  Number of threads =              %d\n", th);
  mean = 0.0;
  #pragma omp parallel shared (w) private (i, j)
  {
    #pragma omp for
    for (i = 1; i < (500 - 1); i++)
    {
      w[i][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (500 - 1); i++)
    {
      w[i][500 - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < 500; j++)
    {
      w[500 - 1][j] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < 500; j++)
    {
      w[0][j] = 0.0;
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (500 - 1); i++)
    {
      mean = (mean + w[i][0]) + w[i][500 - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < 500; j++)
    {
      mean = (mean + w[500 - 1][j]) + w[0][j];
    }

  }
  mean = mean / ((double) (((2 * 500) + (2 * 500)) - 4));
  printf("\n");
  printf("  MEAN = %f\n", mean);
  #pragma omp parallel shared ( mean, w ) private ( i, j )
  {
    #pragma omp for
    for (i = 1; i < (500 - 1); i++)
    {
      for (j = 1; j < (500 - 1); j++)
      {
        w[i][j] = mean;
      }

    }

  }
  iterations = 0;
  iterations_print = 1;
  printf("\n");
  printf(" Iteration  Change\n");
  printf("\n");
  wtime = omp_get_wtime();
  diff = epsilon;
  while (epsilon <= diff)
  {
    #pragma omp parallel shared ( u, w ) private ( i, j )
    {
      #pragma omp for
      for (i = 0; i < 500; i++)
      {
        for (j = 0; j < 500; j++)
        {
          u[i][j] = w[i][j];
        }

      }

      #pragma omp for
      for (i = 1; i < (500 - 1); i++)
      {
        for (j = 1; j < (500 - 1); j++)
        {
          w[i][j] = (((u[i - 1][j] + u[i + 1][j]) + u[i][j - 1]) + u[i][j + 1]) / 4.0;
        }

      }

    }
    diff = 0.0;
    #pragma omp parallel shared ( diff, u, w ) private ( i, j, my_diff )
    {
      my_diff = 0.0;
      #pragma omp for reduction(max:my_diff)
      for (i = 1; i < (500 - 1); i++)
      {
        for (j = 1; j < (500 - 1); j++)
        {
          my_diff = fabs(w[i][j] - u[i][j]);
        }

      }

      diff = my_diff;
    }
    iterations++;
    if (iterations == iterations_print)
    {
      printf("  %8d  %f\n", iterations, diff);
      iterations_print = 2 * iterations_print;
    }

  }

  wtime = omp_get_wtime() - wtime;
  printf("\n");
  printf("Iterations: %8d diff: %f\n", iterations, diff);
  printf("\n");
  printf("  Wallclock time = %f\n", wtime);
  printf("\n");
  printf("HEATED_PLATE_OPENMP:\n");
  return 0;
}

