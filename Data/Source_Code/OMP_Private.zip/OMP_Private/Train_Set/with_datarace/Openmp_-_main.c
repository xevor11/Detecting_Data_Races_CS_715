void insertionMatrix(int orderforMatrix, double **MatrixProblem, double *Outputofmatrix);
void printMatrix(int orderforMatrix, double **MatrixProblem, double *Outputofmatrix);
void backSubstitution(int orderforMatrix, double **MatrixProblem, double *Outputofmatrix, double *coefficientVector, int numThreads);
void OutputMatrix(double *coefficientVector, int orderforMatrix);
void main()
{
  int orderforMatrix;
  int q;
  int numThreads;
  struct timeval startTime;
  struct timeval DestroyTime;
  struct timeval SubstitutionTIme;
  double eliminationTime;
  double substitutionTime;
  double totalTime;
  printf("Enter the order of the matrix here");
  scanf("%d", &orderforMatrix);
  printf("Enter the number of thread here");
  scanf("%d", &numThreads);
  double **MatrixProblem = (double **) malloc((sizeof(double *)) * orderforMatrix);
  for (q = 0; q < orderforMatrix; q++)
    MatrixProblem[q] = (double *) calloc(orderforMatrix, sizeof(double *));

  double *Outputofmatrix = (double *) malloc((sizeof(double)) * orderforMatrix);
  double *coefficientVector = (double *) malloc((sizeof(double)) * orderforMatrix);
  insertionMatrix(orderforMatrix, MatrixProblem, Outputofmatrix);
  printf("\nPerforming gaussian elimination with the following matrix (MatrixProblem) and vector (Outputofmatrix):\n\n");
  gettimeofday(&startTime, 0);
  int i;
  int k;
  int j;
  double m;
  for (j = 0; j < (orderforMatrix - 1); j++)
  {
    #pragma omp parallel default(none) num_threads(numThreads) shared(orderforMatrix,MatrixProblem,Outputofmatrix,j)
    {
      #pragma omp for schedule(static)
      for (k = j + 1; k < orderforMatrix; k++)
      {
        m = MatrixProblem[k][j] / MatrixProblem[j][j];
        for (i = j; i < orderforMatrix; i++)
        {
          MatrixProblem[k][i] = MatrixProblem[k][i] - (m * MatrixProblem[j][i]);
        }

        Outputofmatrix[k] = Outputofmatrix[k] - (m * Outputofmatrix[j]);
      }

    }
  }

  gettimeofday(&DestroyTime, 0);
  printf("\n-------Gaussian Elimination -------\n");
  backSubstitution(orderforMatrix, MatrixProblem, Outputofmatrix, coefficientVector, numThreads);
  printf("\n--------Back Substitution ---------\n");
  gettimeofday(&SubstitutionTIme, 0);
  eliminationTime = ((((DestroyTime.tv_sec - startTime.tv_sec) * 1000000u) + DestroyTime.tv_usec) - startTime.tv_usec) / 1.e6;
  substitutionTime = ((((SubstitutionTIme.tv_sec - DestroyTime.tv_sec) * 1000000u) + SubstitutionTIme.tv_usec) - DestroyTime.tv_usec) / 1.e6;
  totalTime = ((((SubstitutionTIme.tv_sec - startTime.tv_sec) * 1000000u) + SubstitutionTIme.tv_usec) - startTime.tv_usec) / 1.e6;
  OutputMatrix(coefficientVector, orderforMatrix);
  printf("Substitution execution time: %.3f seconds.\n", eliminationTime);
  printf("Substitution execution time: %.3f seconds.\n", substitutionTime);
  printf("Total execution: \n%.3f seconds elapsed with %d threads used.\n\n", totalTime, numThreads);
}

