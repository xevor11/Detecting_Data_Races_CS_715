int main()
{
  int row;
  int col;
  double sum = 0.0;
  int NUM_2 = 512 >> 1;
  #pragma omp parallel for shared(pres_black, pres_red, sum) reduction(+:sum) private(col, row)
  #pragma acc kernels present(pres_red[0:SIZEP], pres_black[0:SIZEP])
  #pragma acc loop independent
  for (col = 1; col < (512 + 1); ++col)
  {
    #pragma acc loop independent
    for (row = 1; row < ((512 / 2) + 1); ++row)
    {
      double pres_r = pres_red[(col * (NUM_2 + 2)) + row];
      double pres_b = pres_black[(col * (NUM_2 + 2)) + row];
      sum += (pres_r * pres_r) + (pres_b * pres_b);
    }

  }

  return sum;

  const int NTH = 1;
  ;
  double tsc[NTH];
  double tsc1;
  double t1;
  double t2;
  double tt1;
  double tt;
  double tio1;
  double tio = 0;
  double tc1;
  double tc = 0;
  double tw1;
  double tw = 0;
  double temp;
  double mrun();
  double **ablock[2];
  double **bblock[2];
  double **cblock[2];
  int acols = 0;
  int arows = 0;
  int bcols = 0;
  int brows = 0;
  int ccols = 0;
  int crows = 0;
  int blk_cols = 0;
  int blk_rows = 0;
  int mopt_a = 0;
  int mopt_b = 1;
  int mopt_c = 1;
  int colleft;
  int i = 0;
  int j = 0;
  int k = 0;
  int I;
  int J;
  int K;
  int iplus;
  int jplus;
  int kplus;
  int tog = 0;
  int ctog = 0;
  int TID;
  int ar;
  int ac;
  int rc;
  int nI;
  int nThreads;
  char c = ' ';
  tt1 = mrun();
  matrix_info_read(&blk_rows, &blk_cols, &arows, &acols, &brows, &bcols, &crows, &ccols);
  colleft = blk_cols % 30;
  nI = blk_rows * (blk_cols / 30);
  rc = blk_cols - colleft;
  ablock[0] = block_allocate(blk_rows, blk_cols, mopt_a);
  bblock[0] = block_allocate(blk_rows, blk_cols, mopt_b);
  cblock[0] = block_allocate(blk_rows, blk_cols, mopt_c);
  ablock[1] = block_allocate(blk_rows, blk_cols, mopt_a);
  bblock[1] = block_allocate(blk_rows, blk_cols, mopt_b);
  cblock[1] = block_allocate(blk_rows, blk_cols, mopt_c);
  ClearMatrix(cblock[0], blk_rows, blk_cols);
  ClearMatrix(cblock[1], blk_rows, blk_cols);
  #pragma omp parallel default(none) shared(blk_cols, blk_rows, ablock, bblock, cblock, mopt_a, mopt_b, mopt_c, acols, crows, ccols, colleft, nI, nThreads, rc, t1, t2, tsc, tsc1) firstprivate( tog, ctog, i, j, k, tio, tc, tw )
  {
    #pragma omp single
    {
      nThreads = 1;
      ;
      t1 = mrun();
    }
    tc1 = t1;
    TID = 0;
    ;
    #pragma omp single
    {
      tio1 = mrun();
      tc += tio1 - tc1;
      block_readdisk(blk_rows, blk_cols, "A", 0, 0, ablock[0], mopt_a, 0);
      block_readdisk(blk_rows, blk_cols, "B", 0, 0, bblock[0], mopt_a, 0);
      tc1 = mrun();
      tio += tc1 - tio1;
    }
    while (i < crows)
    {
      kplus = (k + 1) % acols;
      jplus = (kplus == 0) ? ((j + 1) % ccols) : (j);
      iplus = ((jplus == 0) && (kplus == 0)) ? (i + 1) : (i);
      #pragma omp single nowait
      {
        if (iplus < crows)
        {
          tio1 = mrun();
          tc += tio1 - tc1;
          block_readdisk(blk_rows, blk_cols, "A", iplus, kplus, ablock[1 - tog], mopt_a, 0);
          block_readdisk(blk_rows, blk_cols, "B", kplus, jplus, bblock[1 - tog], mopt_b, 0);
          tc1 = mrun();
          tio += tc1 - tio1;
        }

      }
      #pragma omp single nowait
      if (((i == 0) && (j == 0)) && (k == 0))
        tsc1 = mrun();

      #pragma omp for nowait schedule(dynamic)
      for (I = 0; I < nI; I++)
      {
        ar = I % blk_rows, ac = (I / blk_rows) * 30;
        for (K = 0; K < blk_cols; K++)
        {
          temp = 0;
          for (J = 0; J < 30; J++)
            temp += ablock[tog][ar][ac + J] * bblock[tog][ac + J][K];

          #pragma omp atomic update
          cblock[ctog][ar][K] += temp;
        }

      }

      if (colleft)
      {
        #pragma omp for nowait schedule(dynamic)
        for (ar = 0; ar < blk_rows; ar++)
        {
          ac = rc;
          for (K = 0; K < blk_cols; K++)
          {
            temp = 0;
            for (J = 0; J < colleft; J++)
              temp += ablock[tog][ar][ac + J] * bblock[tog][ac + J][K];

            #pragma omp atomic update
            cblock[ctog][ar][K] += temp;
          }

        }

      }

      tw1 = mrun();
      tc += tw1 - tc1;
      if (((i == 0) && (j == 0)) && (k == 0))
        tsc[TID] = mrun();

      #pragma omp barrier
      tc1 = mrun();
      tw += tc1 - tw1;
      if (kplus == 0)
      {
        #pragma omp single nowait
        {
          tio1 = mrun();
          tc += tio1 - tc1;
          block_write2disk(blk_rows, blk_cols, "C", i, j, cblock[ctog][0]);
          ClearMatrix(cblock[ctog], blk_rows, blk_cols);
          tc1 = mrun();
          tio += tc1 - tio1;
        }
        ctog = 1 - ctog;
      }

      tog = 1 - tog;
      i = iplus;
      j = jplus;
      k = kplus;
    }

    #pragma omp master
    {
      t2 = mrun() - t1;
    }
  }
  for (i = 1; i < nThreads; i++)
    tsc[0] = (tsc[0] < tsc[i]) ? (tsc[i]) : (tsc[0]);

  tt = mrun() - tt1;
  printf("\n|step3 code|\tblk:%5dx%5d, matrix:%2dx%2d, %2dThreads\n", blk_rows, blk_cols, arows, acols, nThreads);
  printf("Total time: %les\n", tt);
  printf("--------------------------------------------------------\n");
  return 0;
}

