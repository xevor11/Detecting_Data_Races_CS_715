struct elem
{
  double Length;
  double *PolynomA;
  double *PolynomB;
  int MaxOrder;
  int NumIntSteps;
  double Energy;
  int FringeQuadEntrance;
  int FringeQuadExit;
  double *fringeIntM0;
  double *fringeIntP0;
  double *R1;
  double *R2;
  double *T1;
  double *T2;
  double *RApertures;
  double *EApertures;
  double *KickAngle;
};
void StrMPoleSymplectic4RadPass(double *r, double le, double *A, double *B, int max_order, int num_int_steps, int FringeQuadEntrance, int FringeQuadExit, double *fringeIntM0, double *fringeIntP0, double *T1, double *T2, double *R1, double *R2, double *RApertures, double *EApertures, double *KickAngle, double E0, int num_particles)
{
  int c;
  int m;
  double *r6;
  double SL;
  double L1;
  double L2;
  double K1;
  double K2;
  bool useLinFrEleEntrance = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadEntrance == 2);
  bool useLinFrEleExit = ((fringeIntM0 != 0) && (fringeIntP0 != 0)) && (FringeQuadExit == 2);
  SL = le / num_int_steps;
  L1 = SL * 0.6756035959798286638;
  L2 = SL * (-0.1756035959798286639);
  K1 = SL * 1.351207191959657328;
  K2 = SL * (-1.702414383919314656);
  if (KickAngle)
  {
    B[0] -= sin(KickAngle[0]) / le;
    A[0] += sin(KickAngle[1]) / le;
  }

  #pragma omp parallel for if (num_particles > OMP_PARTICLE_THRESHOLD) default(shared) shared(r,num_particles)
  for (c = 0; c < num_particles; c++)
  {
    r6 = r + (c * 6);
    if (!atIsNaN(r6[0]))
    {
      if (T1)
        ATaddvv(r6, T1);

      if (R1)
        ATmultmv(r6, R1);

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (FringeQuadEntrance && (B[1] != 0))
      {
        if (useLinFrEleEntrance)
          linearQuadFringeElegantEntrance(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassP(r6, B[1]);

      }

      for (m = 0; m < num_int_steps; m++)
      {
        r6 = r + (c * 6);
        ATdrift6(r6, L1);
        strthinkickrad(r6, A, B, K1, E0, max_order);
        ATdrift6(r6, L2);
        strthinkickrad(r6, A, B, K2, E0, max_order);
        ATdrift6(r6, L2);
        strthinkickrad(r6, A, B, K1, E0, max_order);
        ATdrift6(r6, L1);
      }

      if (FringeQuadExit && (B[1] != 0))
      {
        if (useLinFrEleExit)
          linearQuadFringeElegantExit(r6, B[1], fringeIntM0, fringeIntP0);
        else
          QuadFringePassN(r6, B[1]);

      }

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (R2)
        ATmultmv(r6, R2);

      if (T2)
        ATaddvv(r6, T2);

    }

  }

  if (KickAngle)
  {
    B[0] += sin(KickAngle[0]) / le;
    A[0] -= sin(KickAngle[1]) / le;
  }

}

