int main()
{
  int i;
  int j;
  int counter;
  int correct;
  double start;
  double stop;
  unsigned int cur;
  if (parseArgs(argc, argv))
  {
    return 0;
  }

  start = omp_get_wtime();
  InitializeData();
  correct = 0;
  omp_set_num_threads(pN);
  for (i = 0; i < rep; i++)
  {
    #pragma omp parallel for private(j, counter, cur)
    for (j = 0; j < arraySize; j++)
    {
      counter = 0;
      cur = input[j];
      while (cur != 1)
      {
        counter++;
        if ((cur % 2) == 0)
        {
          cur = cur / 2;
        }
        else
        {
          cur = (cur * 3) + 1;
        }

        if (counter > 100000)
        {
          counter = -1;
          break;
        }

      }

      output[j] = counter;
    }

  }

  stop = omp_get_wtime();
  correct = 0;
  for (int i = 0; i < arraySize; i++)
  {
    if (output[i] >= 0)
    {
      correct++;
    }

  }

  printf("\n");
  printf("Computed '%d/%d' values to 1!\n", correct, arraySize);
  printf("TIME- %f\n", (double) (stop - start));
  return 0;

  int i;
  int x = 0;
  omp_set_num_threads(8);
  #pragma omp parallel
  {
    int id = omp_get_thread_num();
    for (i = id; i < (1 << 10); i += 8)
    {
      x++;
    }

  }
  if (x == (1 << 10))
    printf("Congratulations!, program executed correctly (x = %d)\n", x);
  else
    printf("Sorry, something went wrong, value of x = %d\n", x);

  return 0;
}

