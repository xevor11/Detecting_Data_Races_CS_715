int main(int argc, char *argv[])
{
  int i;
  int a[6];
  int b[6];
  int c[6];
  int d[6];
  #pragma omp parallel default(none) shared(a,b,c,d)
  {
    #pragma omp sections nowait
    {
      #pragma omp section
      {
        double tmp;
        tmp = 0.0;
        for (i = 0; i < 6; i++)
        {
          a[i] = i;
          b[i] = a[i];
          printf("Thread# %d, a: %d, b: %d\n", omp_get_thread_num(), a[i], b[i]);
        }

      }
      #pragma omp section
      {
        double aaa;
        aaa = 0.1;
        for (i = 0; i < 6; i++)
        {
          c[i] = i;
          d[i] = c[i];
          printf("Thread# %d, c: %d, d: %d\n", omp_get_thread_num(), c[i], b[i]);
        }

      }
    }
  }
  return 0;
}

