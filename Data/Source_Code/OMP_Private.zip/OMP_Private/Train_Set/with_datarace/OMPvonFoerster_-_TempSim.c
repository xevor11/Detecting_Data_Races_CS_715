struct timeval start;
struct timeval end;
int chunk = 1;
void linspace(double a, double b, int c, double *d);
void meshgrid(double *x, double *y, double **X, double **Y, int nt);
void ones(double X[][1], int filas);
void matriz_por_escalar(double k, double m[][1], int filas);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds);
double sum(double *m, int size);
double *trapz(double **v, double filas, double columnas);
float brierei(double tmps, double *p);
double **dot(double **v, double *u, int n);
double *cumtrapz(double *hs, int sz);
double **transposef(double **m, int r, int c);
double **ones2(int filas, int columnas);
double **diff(double **a, double **b, int f, int c);
void absMatrix(double **m, int f, int c);
void sumEscalarToMatrix(double **m, int f, int c, double val);
void escalarMatrixMultiplication(double **m, int f, int c, double val);
double **multiplyMatrices(double **firstMatrix, double **secondMatrix, int rowFirst, int columnFirst, int rowSecond, int columnSecond);
void TempSim(double *t, int T0, int T1, int T365, int nt, double *tmps, double *tmeds)
{
  T1 /= 2;
  T365 /= 2;
  int i;
  #pragma omp parallel shared(tmeds, t, T0, T1, chunk, nt)
  {
    #pragma omp for schedule(guided, chunk) nowait
    for (i = 0; i < nt; i++)
    {
      tmeds[i] = T0 + (T1 * cos(((2 * 3.14159265359) / 365) * t[i]));
    }

  }
  #pragma omp parallel shared(tmeds, t, tmps, T365, chunk, nt)
  {
    #pragma omp for schedule(guided, chunk) nowait
    for (int i = 0; i < nt; i++)
    {
      tmps[i] = tmeds[i] - (T365 * cos((2 * 3.14159265359) * (t[i] - ((int) t[i]))));
    }

  }

  double *L = (double *) calloc(n * n, sizeof(double));
  int j;
  int k;
  int i;
  double s;
  if (L == 0)
    exit(1);

  for (j = 0; j < n; j++)
  {
    s = 0.0;
    #pragma omp parallel for num_threads(n_threads) default(none) shared(L, n, j) private(k) reduction(+: s)
    for (k = 0; k < j; k++)
    {
      s += L[(j * n) + k] * L[(j * n) + k];
    }

    L[(j * n) + j] = sqrt(A[(j * n) + j] - s);
    #pragma omp parallel for num_threads(n_threads) private(i, k, s) shared(j, n, L, A)
    for (i = j + 1; i < n; i++)
    {
      s = 0.0;
      for (k = 0; k < j; k++)
      {
        s += L[(i * n) + k] * L[(j * n) + k];
      }

      L[(i * n) + j] = (1.0 / L[(j * n) + j]) * (A[(i * n) + j] - s);
    }

  }

  return L;
}

