{
  int num_pcls;
  double *x;
  double *y;
  double *z;
  double *u;
  double *v;
  double *w;
  double * restrict _xavg;
  double * restrict _yavg;
  double * restrict _zavg;
  double field_component_0[6];
  double field_component_1[6];
  double field_component_2[6];
  double field_component_3[6];
  double field_component_4[6];
  double field_component_5[6];
  double field_component_6[6];
  double field_component_7[6];
} Mesh_cell;
inline double time_sec();
void flush_cache();
void move_bucket_old();
void move_bucket_new();
void move_bucket_new_blocked();
Mesh_cell *mesh_cells;
volatile char *cache;
double xstart = 0;
double ystart = 0;
double zstart = 0;
double inv_dx = .25;
double inv_dy = .25;
double inv_dz = .25;
double dto2 = .4;
double cx = 1;
double cy = 2;
double cz = 3;
double qdto2mc = .123;
int num_pcls = 1024;
double *x;
double *y;
double *z;
double *u;
double *v;
double *w;
double * restrict _xavg;
double * restrict _yavg;
double * restrict _zavg;
double *field_components[8];
int nprocs;
int my_pid;
void move_bucket_old()
{
  int c;
  int cidx;
  int pidx;
  double time[2];
  #pragma omp parallel
  {
  }
  time[0] = time_sec();
  #pragma omp parallel
  {
    #pragma omp for nowait
    for (cidx = 0; cidx < (30 * 30); cidx++)
    {
      int num_pcls = mesh_cells[cidx].num_pcls;
      double * restrict x = mesh_cells[cidx].x;
      double * restrict y = mesh_cells[cidx].y;
      double * restrict z = mesh_cells[cidx].z;
      double * restrict u = mesh_cells[cidx].u;
      double * restrict v = mesh_cells[cidx].v;
      double * restrict w = mesh_cells[cidx].w;
      double * restrict _xavg = mesh_cells[cidx]._xavg;
      double * restrict _yavg = mesh_cells[cidx]._yavg;
      double * restrict _zavg = mesh_cells[cidx]._zavg;
      __assume_aligned(x, 64);
      __assume_aligned(y, 64);
      __assume_aligned(z, 64);
      __assume_aligned(u, 64);
      __assume_aligned(v, 64);
      __assume_aligned(w, 64);
      __assume_aligned(_xavg, 64);
      __assume_aligned(_yavg, 64);
      __assume_aligned(_zavg, 64);
      double field_components[8][6];
      for (pidx = 0; pidx < num_pcls; pidx++)
      {
        const double xorig = x[pidx];
        const double yorig = y[pidx];
        const double zorig = z[pidx];
        const double uorig = u[pidx];
        const double vorig = v[pidx];
        const double worig = w[pidx];
        double weights[8];
        const double abs_xpos = _xavg[pidx];
        const double abs_ypos = _yavg[pidx];
        const double abs_zpos = _zavg[pidx];
        const double rel_xpos = abs_xpos - xstart;
        const double rel_ypos = abs_ypos - ystart;
        const double rel_zpos = abs_zpos - zstart;
        const double cxm1_pos = rel_xpos * inv_dx;
        const double cym1_pos = rel_ypos * inv_dy;
        const double czm1_pos = rel_zpos * inv_dz;
        const int ix = cx + 1;
        const int iy = cy + 1;
        const int iz = cz + 1;
        const double w1x = cx - cxm1_pos;
        const double w1y = cy - cym1_pos;
        const double w1z = cz - czm1_pos;
        const double w0x = 1 - w1x;
        const double w0y = 1 - w1y;
        const double w0z = 1 - w1z;
        const double weight00 = w0x * w0y;
        const double weight01 = w0x * w1y;
        const double weight10 = w1x * w0y;
        const double weight11 = w1x * w1y;
        weights[0] = weight00 * w0z;
        weights[1] = weight00 * w1z;
        weights[2] = weight01 * w0z;
        weights[3] = weight01 * w1z;
        weights[4] = weight10 * w0z;
        weights[5] = weight10 * w1z;
        weights[6] = weight11 * w0z;
        weights[7] = weight11 * w1z;
        double Exl = 0.0;
        double Eyl = 0.0;
        double Ezl = 0.0;
        double Bxl = 0.0;
        double Byl = 0.0;
        double Bzl = 0.0;
        for (c = 0; c < 8; c++)
        {
          Bxl += weights[c] * field_components[c][0];
          Byl += weights[c] * field_components[c][1];
          Bzl += weights[c] * field_components[c][2];
          Exl += weights[c] * field_components[c][3];
          Eyl += weights[c] * field_components[c][4];
          Ezl += weights[c] * field_components[c][5];
        }

        const double Omx = qdto2mc * Bxl;
        const double Omy = qdto2mc * Byl;
        const double Omz = qdto2mc * Bzl;
        const double omsq = ((Omx * Omx) + (Omy * Omy)) + (Omz * Omz);
        const double denom = 1.0 / (1.0 + omsq);
        const double ut = uorig + (qdto2mc * Exl);
        const double vt = vorig + (qdto2mc * Eyl);
        const double wt = worig + (qdto2mc * Ezl);
        const double udotOm = ((ut * Omx) + (vt * Omy)) + (wt * Omz);
        const double uavg = (ut + (((vt * Omz) - (wt * Omy)) + (udotOm * Omx))) * denom;
        const double vavg = (vt + (((wt * Omx) - (ut * Omz)) + (udotOm * Omy))) * denom;
        const double wavg = (wt + (((ut * Omy) - (vt * Omx)) + (udotOm * Omz))) * denom;
        _xavg[pidx] = xorig + (uavg * dto2);
        _yavg[pidx] = yorig + (vavg * dto2);
        _zavg[pidx] = zorig + (wavg * dto2);
      }

    }

  }
  time[1] = time_sec();
  printf("move_bucket_old:         total: %f\n", time[1] - time[0]);

  int i;
  double diff = 0.0;
  #pragma omp parallel private(i)
  #pragma omp parallel for schedule(static) reduction(+:diff)
  for (i = 0; i < n; i++)
    diff += fabs(a[i] - b[i]);

  return diff;
}

