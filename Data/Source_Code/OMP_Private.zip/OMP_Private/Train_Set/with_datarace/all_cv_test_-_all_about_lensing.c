void all_about_lensing(float *xi1, float *xi2, int nx1, int nx2, float *spar, int nspars, float *spars, int nssubs, float *lpar, int nlpars, float *lpars, int nlsubs, float *s_image, float *g_lensimage, float *critical, float *caustic)
{
  float *al1 = (float *) malloc(((sizeof(float)) * nx1) * nx2);
  float *al2 = (float *) malloc(((sizeof(float)) * nx1) * nx2);
  float yi1;
  float yi2;
  int i;
  int k;
  int l;
  #pragma omp parallel num_threads(4) shared(xi1,xi2,nx1,nx2,lpar,nlpars,lpars,nlsubs,spar,nspars,spars,nssubs,s_image,g_lensimage)
  {
    #pragma omp for schedule(dynamic,16)
    for (i = 0; i < (nx1 * nx2); i++)
    {
      tot_alphas(xi1[i], xi2[i], lpar, nlpars, lpars, nlsubs, &al1[i], &al2[i]);
      yi1 = xi1[i] - al1[i];
      yi2 = xi2[i] - al2[i];
    }

  }
  float dsx = xi1[nx2 + 1] - xi1[0];
  float *a11 = (float *) malloc((nx1 * nx2) * (sizeof(float)));
  float *a12 = (float *) malloc((nx1 * nx2) * (sizeof(float)));
  float *a21 = (float *) malloc((nx1 * nx2) * (sizeof(float)));
  float *a22 = (float *) malloc((nx1 * nx2) * (sizeof(float)));
  lanczos_diff_2_tag(al1, al2, a21, a22, a11, a12, dsx, nx1, -1);
  free(al1);
  free(al2);
  float *imu = (float *) malloc((nx1 * nx2) * (sizeof(float)));
  int index;
  for (k = 0; k < nx1; k++)
    for (l = 0; l < nx2; l++)
  {
    index = (k * nx2) + l;
    imu[index] = ((1.0 - (a11[index] + a22[index])) + (a11[index] * a22[index])) - (a12[index] * a21[index]);
  }


  free(a11);
  free(a12);
  free(a21);
  free(a22);
  find_critical_curve(imu, nx1, nx2, critical);
  free(imu);
  find_caustics(xi1, xi2, nx1, nx2, dsx, critical, lpar, nlpars, lpars, nlsubs, caustic);
}

