extern int use_gctpc;
extern int latlon;
extern double *lon;
extern double *lat;
extern enum output_order_type output_order;
static int warning_LamAZ = 0;
int gctpc_get_latlon(unsigned char **sec, double **lon, double **lat)
{
  int gdt;
  unsigned char *gds;
  double r_maj;
  double r_min;
  double lat1;
  double lat2;
  double c_lon;
  double c_lat;
  double false_east;
  double false_north;
  double dx;
  double dy;
  double x0;
  double y0;
  long int (*inv_fn)();
  double *llat;
  double *llon;
  double rlon;
  double rlat;
  int nnx;
  int nny;
  int nres;
  int nscan;
  unsigned int i;
  unsigned int nnpnts;
  long g_error;
  gdt = code_table_3_1(sec);
  gds = sec[3];
  if (((((gdt != 10) && (gdt != 20)) && (gdt != 30)) && (gdt != 31)) && (gdt != 140))
    return 1;

  get_nxny(sec, &nnx, &nny, &nnpnts, &nres, &nscan);
  llat = *lat;
  llon = *lon;
  if (llat != 0)
  {
    free(llat);
    free(llon);
    *lat = (*lon = (llat = (llon = 0)));
  }

  inv_fn = 0;
  dx = (dy = 0.0);
  if (gdt == 10)
  {
    axes_earth(sec, &r_maj, &r_min);
    dy = GDS_Mercator_dy(gds);
    dx = GDS_Mercator_dx(gds);
    c_lon = GDS_Mercator_ori_angle(gds) * (3.14159265358979323846 / 180.0);
    c_lat = GDS_Mercator_latD(gds) * (3.14159265358979323846 / 180.0);
    false_east = (false_north = 0.0);
    g_error = merforint(r_maj, r_min, c_lon, c_lat, false_east, false_north);
    if (g_error)
      fatal_error_i("merforint %d", g_error);

    rlon = GDS_Mercator_lon1(gds) * (3.14159265358979323846 / 180.0);
    rlat = GDS_Mercator_lat1(gds) * (3.14159265358979323846 / 180.0);
    g_error = merfor(rlon, rlat, &x0, &y0);
    if (g_error)
      fatal_error_i("merfor %d", g_error);

    x0 = -x0;
    y0 = -y0;
    g_error = merinvint(r_maj, r_min, c_lon, c_lat, x0, y0);
    if (g_error)
      fatal_error_i("merinvint %d", g_error);

    inv_fn = &merinv;
  }
  else
    if (gdt == 20)
  {
    axes_earth(sec, &r_maj, &r_min);
    dy = GDS_Polar_dy(gds);
    dx = GDS_Polar_dx(gds);
    c_lon = GDS_Polar_lov(gds) * (3.14159265358979323846 / 180.0);
    c_lat = GDS_Polar_lad(gds) * (3.14159265358979323846 / 180.0);
    false_east = (false_north = 0.0);
    g_error = psforint(r_maj, r_min, c_lon, c_lat, false_east, false_north);
    if (g_error)
      fatal_error_i("psforint %d", g_error);

    rlon = GDS_Polar_lon1(gds) * (3.14159265358979323846 / 180.0);
    rlat = GDS_Polar_lat1(gds) * (3.14159265358979323846 / 180.0);
    g_error = psfor(rlon, rlat, &x0, &y0);
    if (g_error)
      fatal_error_i("psfor %d", g_error);

    x0 = -x0;
    y0 = -y0;
    g_error = psinvint(r_maj, r_min, c_lon, c_lat, x0, y0);
    if (g_error)
      fatal_error_i("psinvint %d", g_error);

    inv_fn = &psinv;
  }
  else
    if (gdt == 30)
  {
    axes_earth(sec, &r_maj, &r_min);
    dy = GDS_Lambert_dy(gds);
    dx = GDS_Lambert_dx(gds);
    lat1 = GDS_Lambert_Latin1(gds) * (3.14159265358979323846 / 180.0);
    lat2 = GDS_Lambert_Latin2(gds) * (3.14159265358979323846 / 180.0);
    c_lon = GDS_Lambert_Lov(gds) * (3.14159265358979323846 / 180.0);
    c_lat = GDS_Lambert_LatD(gds) * (3.14159265358979323846 / 180.0);
    false_east = (false_north = 0.0);
    g_error = lamccforint(r_maj, r_min, lat1, lat2, c_lon, c_lat, false_east, false_north);
    if (g_error)
      fatal_error_i("lamccforint %d", g_error);

    rlon = GDS_Lambert_Lo1(gds) * (3.14159265358979323846 / 180.0);
    rlat = GDS_Lambert_La1(gds) * (3.14159265358979323846 / 180.0);
    g_error = lamccfor(rlon, rlat, &x0, &y0);
    if (g_error)
      fatal_error_i("lamccfor %d", g_error);

    x0 = -x0;
    y0 = -y0;
    g_error = lamccinvint(r_maj, r_min, lat1, lat2, c_lon, c_lat, x0, y0);
    if (g_error)
      fatal_error_i("lamccinvint %d", g_error);

    inv_fn = &lamccinv;
  }
  else
    if (gdt == 31)
  {
    axes_earth(sec, &r_maj, &r_min);
    dy = GDS_Albers_dy(gds);
    dx = GDS_Albers_dx(gds);
    lat1 = GDS_Albers_Latin1(gds) * (3.14159265358979323846 / 180.0);
    lat2 = GDS_Albers_Latin2(gds) * (3.14159265358979323846 / 180.0);
    c_lon = GDS_Albers_Lov(gds) * (3.14159265358979323846 / 180.0);
    c_lat = GDS_Albers_LatD(gds) * (3.14159265358979323846 / 180.0);
    false_east = (false_north = 0.0);
    g_error = alberforint(r_maj, r_min, lat1, lat2, c_lon, c_lat, false_east, false_north);
    if (g_error)
      fatal_error_i("alberforint %d", g_error);

    rlon = GDS_Albers_Lo1(gds) * (3.14159265358979323846 / 180.0);
    rlat = GDS_Albers_La1(gds) * (3.14159265358979323846 / 180.0);
    g_error = alberfor(rlon, rlat, &x0, &y0);
    if (g_error)
      fatal_error_i("alberfor %d", g_error);

    x0 = -x0;
    y0 = -y0;
    g_error = alberinvint(r_maj, r_min, lat1, lat2, c_lon, c_lat, x0, y0);
    if (g_error)
      fatal_error_i("alberinvint %d", g_error);

    inv_fn = &alberinv;
  }
  else
    if (gdt == 140)
  {
    axes_earth(sec, &r_maj, &r_min);
    if ((r_maj != r_min) && (warning_LamAZ < 3))
    {
      warning_LamAZ++;
      fprintf(stderr, "**WARNING gctpc only does spherical Lambert Azimuthal Equal Area.\n**WARNING wgrib2 with Proj4 does aspherical earth:  -proj4 1\n");
    }

    r_maj = (r_maj + r_min) / 2.0;
    dy = GDS_Lambert_Az_dy(gds);
    dx = GDS_Lambert_Az_dx(gds);
    c_lon = GDS_Lambert_Az_Cen_Lon(gds) * (3.14159265358979323846 / 180.0);
    c_lat = GDS_Lambert_Az_Std_Par(gds) * (3.14159265358979323846 / 180.0);
    false_east = (false_north = 0.0);
    g_error = lamazforint(r_maj, c_lon, c_lat, false_east, false_north);
    if (g_error)
      fatal_error_i("lamazforint %d", g_error);

    rlon = GDS_Lambert_Az_Lo1(gds) * (3.14159265358979323846 / 180.0);
    rlat = GDS_Lambert_Az_La1(gds) * (3.14159265358979323846 / 180.0);
    g_error = lamazfor(rlon, rlat, &x0, &y0);
    if (g_error)
      fatal_error_i("lamazfor %d", g_error);

    x0 = -x0;
    y0 = -y0;
    g_error = lamazinvint(r_maj, c_lon, c_lat, x0, y0);
    if (g_error)
      fatal_error_i("lamazinvint %d", g_error);

    inv_fn = &lamazinv;
  }





  if (inv_fn == 0)
    return 1;

  if ((*lat = (llat = (double *) malloc(((size_t) nnpnts) * (sizeof(double))))) == 0)
  {
    fatal_error("gctpc_get_latlon memory allocation failed", "");
  }

  if ((*lon = (llon = (double *) malloc(((size_t) nnpnts) * (sizeof(double))))) == 0)
  {
    fatal_error("gctpc_get_latlon memory allocation failed", "");
  }

  if (stagger(sec, nnpnts, llon, llat))
    fatal_error("gctpc: stagger problem", "");

  #pragma omp parallel for
  for (i = 0; i < nnpnts; i++)
  {
    inv_fn(llon[i] * dx, llat[i] * dy, llon + i, llat + i);
    llat[i] *= 180.0 / 3.14159265358979323846;
    llon[i] *= 180.0 / 3.14159265358979323846;
    if (llon[i] < 0.0)
      llon[i] += 360.0;

  }

  return 0;
}

