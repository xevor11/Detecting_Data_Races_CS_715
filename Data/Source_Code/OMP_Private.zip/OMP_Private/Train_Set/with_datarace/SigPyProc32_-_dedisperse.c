void dedisperse(float *inbuffer, float *outbuffer, int *delays, int maxdelay, int nchans, int nsamps, int index)
{
  int ii;
  int jj;
  #pragma omp parallel for default(shared) shared(outbuffer,inbuffer)
  for (ii = 0; ii < (nsamps - maxdelay); ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[index + ii] += inbuffer[((ii * nchans) + (delays[jj] * nchans)) + jj];
    }

  }

}

