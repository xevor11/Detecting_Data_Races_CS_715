double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
double valid1(void);
double valid2(void);
void loop1(void)
{
  int i;
  int j;
  #pragma omp parallel for num_threads(N_Threads) schedule(dynamic,16) default(none) shared(a,b)
  for (i = 0; i < 729; i++)
  {
    for (j = 729 - 1; j > i; j--)
    {
      a[i][j] += cos(b[i][j]);
    }

  }

}

