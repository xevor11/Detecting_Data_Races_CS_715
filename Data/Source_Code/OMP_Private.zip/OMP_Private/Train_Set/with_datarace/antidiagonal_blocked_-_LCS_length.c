double time;
void LCS_length(const char *X, const char *Y, short int ***c_out, char ***b_out)
{
  int m;
  int n;
  short int **c;
  char **b;
  int diag;
  int left;
  int up;
  int i;
  int j;
  m = strlen(X);
  n = strlen(Y);
  c = malloc((m + 1) * (sizeof(short int *)));
  b = malloc((m + 1) * (sizeof(char *)));
  for (i = 0; i <= m; i++)
  {
    c[i] = malloc((n + 1) * (sizeof(short int)));
    b[i] = calloc(n + 1, sizeof(char));
  }

  c[0][0] = 0;
  b[0][0] = ' ';
  for (i = 1; i <= m; i++)
  {
    c[i][0] = i * (-3);
    b[i][0] = '|';
  }

  for (j = 1; j <= n; j++)
  {
    c[0][j] = j * (-3);
    b[0][j] = '_';
  }

  time = omp_get_wtime();
  int M = m / 20;
  int N = n / 20;
  int I;
  int J;
  int K;
  #pragma omp parallel for schedule(static,1)
  for (K = 1; K <= (M + N); K++)
  {
    if (K < M)
    {
      for (I = K, J = 1; (I > 0) && (J <= N); I--, J++)
      {
        for (i = (I * 20) - (20 - 1); i <= (I * 20); i++)
        {
          for (j = (J * 20) - (20 - 1); j <= (J * 20); j++)
          {
            while ((b[i][j - 1] == 0) || (b[i - 1][j] == 0))
              ;

            diag = c[i - 1][j - 1] + ((X[i - 1] == Y[j - 1]) ? (+1) : (-1));
            up = c[i - 1][j] + (-3);
            left = c[i][j - 1] + (-3);
            if ((diag >= up) && (diag >= left))
            {
              c[i][j] = diag;
              b[i][j] = '\\';
            }
            else
              if (up >= left)
            {
              c[i][j] = up;
              b[i][j] = '|';
            }
            else
            {
              c[i][j] = left;
              b[i][j] = '_';
            }


          }

        }

      }

    }
    else
      if (K > M)
    {
      for (I = M, J = K - M; (I > 0) && (J <= N); I--, J++)
      {
        for (i = (I * 20) - (20 - 1); i <= (I * 20); i++)
        {
          for (j = (J * 20) - (20 - 1); j <= (J * 20); j++)
          {
            while ((b[i][j - 1] == 0) || (b[i - 1][j] == 0))
              ;

            diag = c[i - 1][j - 1] + ((X[i - 1] == Y[j - 1]) ? (+1) : (-1));
            up = c[i - 1][j] + (-3);
            left = c[i][j - 1] + (-3);
            if ((diag >= up) && (diag >= left))
            {
              c[i][j] = diag;
              b[i][j] = '\\';
            }
            else
              if (up >= left)
            {
              c[i][j] = up;
              b[i][j] = '|';
            }
            else
            {
              c[i][j] = left;
              b[i][j] = '_';
            }


          }

        }

      }

    }


  }

  time = omp_get_wtime() - time;
  *c_out = c;
  *b_out = b;
}

