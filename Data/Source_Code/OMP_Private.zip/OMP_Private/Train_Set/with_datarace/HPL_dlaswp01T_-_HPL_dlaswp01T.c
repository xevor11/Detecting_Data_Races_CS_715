void HPL_dlaswp01T(M, N, A, LDA, U, LDU, LINDXA, LINDXAU)
const int M;
const int N;
double *A;
const int LDA;
double *U;
const int LDU;
const int *LINDXA;
const int *LINDXAU;
{
  double *a0;
  double *a1;
  const int incA = (int) (((unsigned int) LDA) << 5);
  const int incU = 1 << 5;
  int nu;
  int nr;
  register int i;
  register int j;
  register int k;
  if ((M <= 0) || (N <= 0))
    return;

  nr = N - (nu = (int) ((((unsigned int) N) >> 5) << 5));
  int nthreads;
  double *tmpA;
  double *tmpU;
  #pragma omp parallel
  {
    k = omp_get_thread_num();
    nthreads = omp_get_num_threads();
    tmpA = A + (k * incA);
    tmpU = U + (k * incU);
    for (j = k * 32; j < nu; j += nthreads * 32, tmpA += nthreads * incA, tmpU += nthreads * incU)
    {
      for (i = 0; i < M; i++)
      {
        a0 = tmpA + ((size_t) LINDXA[i]);
        if (LINDXAU[i] >= 0)
        {
          a1 = tmpU + (((size_t) LINDXAU[i]) * ((size_t) LDU));
          a1[0] = *a0;
          a0 += LDA;
          a1[1] = *a0;
          a0 += LDA;
          a1[2] = *a0;
          a0 += LDA;
          a1[3] = *a0;
          a0 += LDA;
          a1[4] = *a0;
          a0 += LDA;
          a1[5] = *a0;
          a0 += LDA;
          a1[6] = *a0;
          a0 += LDA;
          a1[7] = *a0;
          a0 += LDA;
          a1[8] = *a0;
          a0 += LDA;
          a1[9] = *a0;
          a0 += LDA;
          a1[10] = *a0;
          a0 += LDA;
          a1[11] = *a0;
          a0 += LDA;
          a1[12] = *a0;
          a0 += LDA;
          a1[13] = *a0;
          a0 += LDA;
          a1[14] = *a0;
          a0 += LDA;
          a1[15] = *a0;
          a0 += LDA;
          a1[16] = *a0;
          a0 += LDA;
          a1[17] = *a0;
          a0 += LDA;
          a1[18] = *a0;
          a0 += LDA;
          a1[19] = *a0;
          a0 += LDA;
          a1[20] = *a0;
          a0 += LDA;
          a1[21] = *a0;
          a0 += LDA;
          a1[22] = *a0;
          a0 += LDA;
          a1[23] = *a0;
          a0 += LDA;
          a1[24] = *a0;
          a0 += LDA;
          a1[25] = *a0;
          a0 += LDA;
          a1[26] = *a0;
          a0 += LDA;
          a1[27] = *a0;
          a0 += LDA;
          a1[28] = *a0;
          a0 += LDA;
          a1[29] = *a0;
          a0 += LDA;
          a1[30] = *a0;
          a0 += LDA;
          a1[31] = *a0;
          a0 += LDA;
        }
        else
        {
          a1 = tmpA - ((size_t) LINDXAU[i]);
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
          *a1 = *a0;
          a1 += LDA;
          a0 += LDA;
        }

      }

    }

  }
  tmpA = A + (((size_t) nu) * ((size_t) LDA));
  tmpU = U + nu;
  if (nr > 0)
  {
    for (i = 0; i < M; i++)
    {
      a0 = tmpA + ((size_t) LINDXA[i]);
      if (LINDXAU[i] >= 0)
      {
        a1 = tmpU + (((size_t) LINDXAU[i]) * ((size_t) LDU));
        for (j = 0; j < nr; j++, a0 += LDA)
        {
          a1[j] = *a0;
        }

      }
      else
      {
        a1 = tmpA - ((size_t) LINDXAU[i]);
        for (j = 0; j < nr; j++, a1 += LDA, a0 += LDA)
        {
          *a1 = *a0;
        }

      }

    }

  }

}

