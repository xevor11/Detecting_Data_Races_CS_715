double mean(int n, double v[n]);
double sd(int n, double v[n]);
double ttest(int n1, int n2, double v1[n1], double v2[n2]);
int main(int argc, char *argv[])
{
  long long int i;
  long long int sum = 0;
  long long int local_sum;
  long long int work;
  int thread_id;
  int n_threads;
  int start;
  int end;
  #pragma omp parallel private(i, thread_id, local_sum, start, end)
  {
    local_sum = 0;
    thread_id = omp_get_thread_num();
    #pragma omp single
    {
      n_threads = omp_get_num_threads();
      work = N / n_threads;
    }
    start = work * thread_id;
    end = (thread_id < (n_threads - 1)) ? (start + work) : (N);
    printf("in thread %d of %d from %d to %d\n", thread_id, n_threads, start, end);
    for (i = start; i < end; i++)
    {
      local_sum += v[i];
    }

    #pragma omp atomic
    sum += local_sum;
  }
  return sum;

  FILE *fid;
  int nr = 0;
  char buf[255];
  fid = fopen("A2_1_data.csv", "r");
  while (!feof(fid))
  {
    fgets(buf, 255, fid);
    nr++;
  }

  nr--;
  fseek(fid, 0, 0);
  double c1[nr];
  double c2[nr];
  int i;
  for (i = 0; i < nr; i++)
  {
    fscanf(fid, "%lf,%lf\n", &c1[i], &c2[i]);
  }

  fclose(fid);
  for (i = 0; i < nr; i++)
  {
    printf("c1[%d]=%f, c2[%d]=%f\n", i, c1[i], i, c2[i]);
  }

  double tobs = ttest(nr, nr, c1, c2);
  printf("tobs = %f\n", tobs);
  srand((unsigned) time(0));
  int j;
  int nboot = 1e6;
  int tcount = 0;
  double tboot;
  double c1boot[nr];
  double c2boot[nr];
  double allc[nr + nr];
  for (i = 0; i < nr; i++)
    allc[i] = c1[i];

  for (i = 0; i < nr; i++)
    allc[i + nr] = c2[i];

  #pragma omp parallel for reduction(+: tcount)
  for (i = 0; i < nboot; i++)
  {
    for (j = 0; j < nr; j++)
      c1boot[j] = allc[rand() % (nr + nr)];

    for (j = 0; j < nr; j++)
      c2boot[j] = allc[rand() % (nr + nr)];

    tboot = ttest(nr, nr, c1boot, c2boot);
    if (tboot >= tobs)
      tcount++;

  }

  printf("%d/%d, p=%.5f\n", tcount, nboot, ((double) tcount) / nboot);
  return 0;
}

