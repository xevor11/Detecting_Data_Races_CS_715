int main()
{
  int rank;
  int size;
  MPI_Init(0, 0);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  int N_samples_all;
  int N_samples;
  int N_features;
  int N_clusters;
  int N_repeat;
  int i;
  int j;
  int k;
  int k_best;
  int initial_idx;
  float **X;
  float **X_all;
  int **GUESS;
  float dist;
  float dist_min;
  float dist_sum_old;
  float dist_sum_new;
  float inert_best = FLT_MAX;
  double iStart1 = MPI_Wtime();
  if (rank == 0)
  {
    readX("Data_Analysis/data/SSWdata.nc", &X_all, &GUESS, &N_samples_all, &N_features, &N_clusters, &N_repeat);
  }
  else
  {
    float *dummy_for_X_all = 0;
    X_all = &dummy_for_X_all;
  }

  MPI_Bcast(&N_samples_all, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast(&N_features, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast(&N_clusters, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast(&N_repeat, 1, MPI_INT, 0, MPI_COMM_WORLD);
  if (rank == 0)
  {
    printf("Last element in global array: %f \n", X_all[N_samples_all - 1][N_features - 1]);
  }

  int *sendcounts;
  int *displs;
  if (rank == 0)
  {
    int N_samples_slave = N_samples_all / size;
    N_samples = N_samples_all - (N_samples_slave * (size - 1));
    sendcounts = (int *) malloc(size * (sizeof(int)));
    displs = (int *) malloc(size * (sizeof(int)));
    sendcounts[0] = N_samples * N_features;
    displs[0] = 0;
    for (i = 1; i < size; i++)
    {
      displs[i] = (N_samples + ((i - 1) * N_samples_slave)) * N_features;
      sendcounts[i] = N_samples_slave * N_features;
    }

  }
  else
  {
    N_samples = N_samples_all / size;
    sendcounts = 0;
    displs = 0;
  }

  X = Make2DFloatArray(N_samples, N_features);
  MPI_Scatterv(*X_all, sendcounts, displs, MPI_FLOAT, *X, N_samples * N_features, MPI_FLOAT, 0, MPI_COMM_WORLD);
  if (rank == (size - 1))
  {
    printf("Last element after scattering %d: %f \n", rank, X[N_samples - 1][N_features - 1]);
  }

  double iElaps1 = MPI_Wtime() - iStart1;
  int *labels = (int *) malloc(N_samples * (sizeof(int)));
  int *labels_best = (int *) malloc(N_samples * (sizeof(int)));
  float **old_cluster_centers = Make2DFloatArray(N_clusters, N_features);
  float **new_cluster_centers = Make2DFloatArray(N_clusters, N_features);
  int *cluster_sizes = (int *) malloc(N_clusters * (sizeof(int)));
  MPI_Barrier(MPI_COMM_WORLD);
  if (rank == 0)
    printf("=====Applying K-mean======\n");

  double iStart2;
  double iElaps2;
  double iStart3a;
  double iStart3b;
  double iStart3c;
  double iElaps3a = 0;
  double iElaps3b = 0;
  double iElaps3c = 0;
  iStart2 = MPI_Wtime();
  for (int i_repeat = 0; i_repeat < N_repeat; i_repeat++)
  {
    if (rank == 0)
    {
      for (k = 0; k < N_clusters; k++)
      {
        cluster_sizes[k] = 0;
        initial_idx = GUESS[i_repeat][k];
        for (j = 0; j < N_features; j++)
        {
          old_cluster_centers[k][j] = X_all[initial_idx][j];
          new_cluster_centers[k][j] = 0.0;
        }

      }

    }
    else
    {
      for (k = 0; k < N_clusters; k++)
      {
        cluster_sizes[k] = 0;
        for (j = 0; j < N_features; j++)
        {
          new_cluster_centers[k][j] = 0.0;
        }

      }

    }

    MPI_Bcast(*old_cluster_centers, N_clusters * N_features, MPI_FLOAT, 0, MPI_COMM_WORLD);
    int i_iter = 0;
    dist_sum_new = 0.0;
    do
    {
      i_iter++;
      dist_sum_old = dist_sum_new;
      dist_sum_new = 0.0;
      iStart3a = MPI_Wtime();
      #pragma omp parallel for default(shared) schedule(static) reduction(+:dist_sum_new)
      for (i = 0; i < N_samples; i++)
      {
        k_best = 0;
        dist_min = correlation(N_features, X[i], old_cluster_centers[k_best]);
        for (k = 1; k < N_clusters; k++)
        {
          dist = correlation(N_features, X[i], old_cluster_centers[k]);
          if (dist < dist_min)
          {
            dist_min = dist;
            k_best = k;
          }

        }

        labels[i] = k_best;
        dist_sum_new += dist_min;
      }

      iElaps3a += MPI_Wtime() - iStart3a;
      iStart3b = MPI_Wtime();
      for (i = 0; i < N_samples; i++)
      {
        k_best = labels[i];
        cluster_sizes[k_best]++;
        for (j = 0; j < N_features; j++)
          new_cluster_centers[k_best][j] += X[i][j];

      }

      MPI_Allreduce(MPI_IN_PLACE, *new_cluster_centers, N_clusters * N_features, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
      MPI_Allreduce(MPI_IN_PLACE, cluster_sizes, N_clusters, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
      iElaps3b += MPI_Wtime() - iStart3b;
      iStart3c = MPI_Wtime();
      for (k = 0; k < N_clusters; k++)
      {
        for (j = 0; j < N_features; j++)
        {
          if (cluster_sizes[k] > 0)
            old_cluster_centers[k][j] = new_cluster_centers[k][j] / cluster_sizes[k];

          new_cluster_centers[k][j] = 0.0;
        }

        cluster_sizes[k] = 0;
      }

      iElaps3c += MPI_Wtime() - iStart3c;
      MPI_Allreduce(MPI_IN_PLACE, &dist_sum_new, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
    }
    while ((i_iter == 1) || (((dist_sum_old - dist_sum_new) > 0.0001) && (i_iter < 100)));
    if (dist_sum_new < inert_best)
    {
      inert_best = dist_sum_new;
      for (i = 0; i < N_samples; i++)
        labels_best[i] = labels[i];

    }

  }

  iElaps2 = MPI_Wtime() - iStart2;
  double iElaps1_max;
  MPI_Reduce(&iElaps1, &iElaps1_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (rank == 0)
  {
    printf("Best inertia: %f \n", inert_best);
    printf("I/O time use (ms): %f \n", iElaps1_max * 1000.0);
    printf("Kmean total time use (ms): %f \n", iElaps2 * 1000.0);
    printf("\n(sub-component timing not accurate) \n");
    printf("E-step time use (ms): %f \n", iElaps3a * 1000.0);
    printf("M-step-1st-half time use (ms): %f \n", iElaps3b * 1000.0);
    printf("M-step-2nd-half time use (ms): %f \n", iElaps3c * 1000.0);
  }

  MPI_Finalize();
  return 0;

  char num_dice;
  char triple;
  char face[6];
} dice_t;
int main(int argc, char **argv)
{
  if (argc != 5)
  {
    printf("Error: Impropper usage.  %s <num games> <mincutoff> <maxcutoff> <num threads>\n", argv[0]);
    exit(0);
  }

  games = atoi(argv[1]);
  int mincutoff = atoi(argv[2]);
  int maxcutoff = atoi(argv[3]);
  int num_threads = atoi(argv[4]);
  printf("Playing %d games for each cutoff ranging from %d-%d using %d threads\n", games, mincutoff, maxcutoff, num_threads);
  unsigned long start = GetCC();
  long long total_inplay_throws[7];
  long long total_inplay_points[7];
  long long total_inplay_duds[7];
  long long max_turns = 0;
  long long min_turns = games * 10000;
  int max_cutoff;
  int min_cutoff;
  for (int i = 1; i < 7; i++)
  {
    total_inplay_throws[i] = 0;
    total_inplay_points[i] = 0;
    total_inplay_duds[i] = 0;
  }

  int thread_id;
  int c;
  int seed;
  omp_set_num_threads(num_threads);
  #pragma omp parallel
  #pragma omp private(thread_id, c)
  {
    thread_id = omp_get_thread_num();
    seed = thread_id;
    #pragma omp for schedule(dynamic, 1)
    for (c = mincutoff; c < maxcutoff; c += 50)
    {
      long long cutoffturns = 0;
      for (int i = 0; i < games; ++i)
      {
        long long inplay_duds[7];
        long long inplay_throws[7];
        long long inplay_points[7];
        for (int i = 1; i < 7; i++)
        {
          inplay_duds[i] = 0;
          inplay_throws[i] = 0;
          inplay_points[i] = 0;
        }

        int turns = play_game(c, inplay_throws, inplay_points, inplay_duds, &seed);
        #pragma omp critical (TOTAL_INPLAY)
        {
          for (int i = 1; i < 7; i++)
          {
            total_inplay_throws[i] += inplay_throws[i];
            total_inplay_points[i] += inplay_points[i];
            total_inplay_duds[i] += inplay_duds[i];
          }

        }
        cutoffturns += turns;
      }

      #pragma omp critical (RECORD)
      {
        if (cutoffturns > max_turns)
        {
          max_turns = cutoffturns;
          max_cutoff = c;
        }
        else
          if (cutoffturns < min_turns)
        {
          min_turns = cutoffturns;
          min_cutoff = c;
        }


      }
    }

  }
  unsigned long finish = GetCC();
  printf("Execution time in cycles: %lld\n", (long long) (finish - start));
  printf("\nPlayed %d games per cutoff leading to the folling statistics:\n", games);
  printf("\tBest Cutoff(%d) resulted in %.2f turns on average\n", min_cutoff, ((double) min_turns) / ((double) games));
  printf("\tWorst Cutoff(%d) resulted in %.2f turns on average\n", max_cutoff, ((double) max_turns) / ((double) games));
  for (int i = 1; i < 7; i++)
  {
    printf("\tAverage points accumualted with %d dice in play: %.2f\n", i, ((double) total_inplay_points[i]) / ((double) total_inplay_throws[i]));
  }

  for (int i = 1; i < 7; i++)
  {
    printf("\tProbability of throwing a dud with %d dice in play: %.2f\n", i, ((double) total_inplay_duds[i]) / ((double) total_inplay_throws[i]));
  }

  return 1;
}

