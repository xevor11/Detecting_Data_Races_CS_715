int main(int argc, char **argv)
{
  int N = 500;
  int p;
  int **mat1 = (int **) malloc((sizeof(int *)) * N);
  int **mat2 = (int **) malloc((sizeof(int *)) * N);
  int **mat3 = (int **) malloc((sizeof(int *)) * N);
  for (p = 0; p < N; p++)
  {
    mat1[p] = (int *) malloc((sizeof(int)) * N);
    mat2[p] = (int *) malloc((sizeof(int)) * N);
    mat3[p] = (int *) malloc((sizeof(int)) * N);
  }

  int c;
  int m;
  int j;
  int k;
  double tall;
  for (m = 1; m <= 16; m *= 2)
  {
    omp_set_num_threads(m);
    for (int j = 0; j < N; j++)
    {
      for (int k = 0; k < N; k++)
      {
        mat1[j][k] = k + j;
        mat2[j][k] = k + j;
        mat3[j][k] = k + j;
      }

    }

    for (c = 0; c < 5; c++)
    {
      double tstart = omp_get_wtime();
      #pragma omp parallel for schedule (dynamic,102) shared(mat1,mat2,mat3)
      for (int i = 0; i < N; i++)
      {
        for (int j = 0; j < N; j++)
        {
          for (int k = 0; k < N; k++)
          {
            mat3[i][j] += mat1[i][k] * mat2[k][j];
          }

        }

      }

      double tend = omp_get_wtime();
      tall += tend - tstart;
    }

    printf("dynamic,102 - m: %d n: %d time: %f\n", m, 500, tall / c);
    tall = 0;
  }

  free(mat1);
  free(mat2);
  free(mat3);
  return 0;
}

