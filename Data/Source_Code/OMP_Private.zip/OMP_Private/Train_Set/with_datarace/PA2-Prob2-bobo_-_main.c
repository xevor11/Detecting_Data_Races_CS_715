double rtclock();
void compare();
double A[128][128][128];
double B[128][128][128];
double C[128][128];
double RefOut[128][128];
int main()
{
  double clkbegin;
  double clkend;
  double t;
  int nt;
  int maxthr;
  int i;
  int j;
  int k;
  int l;
  printf("Matrix Size = %d\n", 128);
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
  {
    C[i][j] = (1.0 * (i + (0.25 * j))) / (128 + 1);
    for (k = 0; k < 128; k++)
    {
      A[i][j][k] = (1.0 * ((i + (0.25 * j)) - (0.125 * k))) / (128 + 1);
      B[i][j][k] = (1.0 * ((i - (0.5 * j)) + (0.125 * k))) / (128 + 1);
    }

  }


  clkbegin = rtclock();
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
    for (k = 0; k < 128; k++)
    for (l = k + 1; l < 128; l++)
    C[k][l] += 0.5 * ((A[l][i][j] * B[k][i][j]) + (A[k][i][j] * B[l][i][j]));




  clkend = rtclock();
  t = clkend - clkbegin;
  if ((C[128 / 2][128 / 2] * C[128 / 2][128 / 2]) < (-1000.0))
    printf("To foil dead-code elimination by compiler: should never get here\n");

  printf("Base Sequential: %.1f GFLOPS; Time = %.3f sec; \n", ((((((5.0 * 128) * 128) * 128) * (128 - 1)) / 2.0) / t) / 1.0e9, t);
  for (i = 0; i < 128; i++)
    for (j = 0; j < 128; j++)
    RefOut[i][j] = C[i][j];


  maxthr = omp_get_max_threads();
  printf("Maximum threads allowed by system is: %d\n", maxthr);
  for (nt = 1; nt <= maxthr; nt++)
  {
    omp_set_num_threads(nt);
    for (i = 0; i < 128; i++)
      for (j = 0; j < 128; j++)
    {
      C[i][j] = (1.0 * (i + (0.25 * j))) / (128 + 1);
      for (k = 0; k < 128; k++)
      {
        A[i][j][k] = (1.0 * ((i + (0.25 * j)) - (0.125 * k))) / (128 + 1);
        B[i][j][k] = (1.0 * ((i - (0.5 * j)) + (0.125 * k))) / (128 + 1);
      }

    }


    printf("Requesting thrds=%d\n", nt);
    clkbegin = rtclock();
    #pragma omp parallel
    {
      if ((omp_get_thread_num() == 0) && (omp_get_num_threads() != nt))
        printf("Warning: Actual #threads %d differs from requested number %d\n", omp_get_num_threads(), nt);

      #pragma omp for
      for (k = 0; k < 128; k++)
        for (l = k + 1; l < 128; l++)
        for (i = 0; i < 128; i++)
        for (j = 0; j < 128; j++)
        C[k][l] += 0.5 * ((A[l][i][j] * B[k][i][j]) + (A[k][i][j] * B[l][i][j]));




    }
    clkend = rtclock();
    t = clkend - clkbegin;
    if ((C[128 / 2][128 / 2] * C[128 / 2][128 / 2]) < (-1000.0))
      printf("To foil dead-code elimination by compiler: should never get here\n");

    printf("%.1f GFLOPS with %d threads; Time = %.3f sec; \n", ((((((5.0 * 128) * 128) * 128) * (128 - 1)) / 2.0) / t) / 1.0e9, nt, t);
    compare();
  }

}

