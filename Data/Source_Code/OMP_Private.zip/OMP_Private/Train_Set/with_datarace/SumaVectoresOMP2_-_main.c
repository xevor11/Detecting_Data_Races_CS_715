int main(int argc, char **argv)
{
  int i;
  double cgt1;
  double cgt2;
  double ncgt;
  if (argc < 2)
  {
    printf("Faltan nº componentes del vector\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  double v1[N];
  double v2[N];
  double v3[N];
  #pragma omp parallel
  {
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < (N / 2); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
      }

      #pragma omp section
      for (i = N / 2; i < N; i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
      }

      #pragma omp section
      for (i = 0; i < (N / 2); i++)
      {
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = N / 2; i < N; i++)
      {
        v2[i] = (N * 0.1) - (i * 0.1);
      }

    }
    cgt1 = omp_get_wtime();
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < (N / 2); i++)
      {
        v3[i] = v1[i] + v2[i];
      }

      #pragma omp section
      for (i = N / 2; i < N; i++)
      {
        v3[i] = v1[i] + v2[i];
      }

    }
    cgt2 = omp_get_wtime();
    ncgt = (double) (cgt2 - cgt1);
    #pragma omp master
    printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\t/ V1[0]+V2[0]=V3[0](%8.6f+%8.6f=%8.6f) / / V1[%d]+V2[%d]=V3[%d](%8.6f+%8.6f=%8.6f)/\n", ncgt, N, v1[0], v2[0], v3[0], N - 1, N - 1, N - 1, v1[N - 1], v2[N - 1], v3[N - 1]);
  }
  return 0;

  int i;
  int j;
  #pragma omp parallel for private(j) schedule(dynamic)
  for (i = 0; i < 5000; i++)
  {
    for (j = 0; j < 5000; j++)
    {
      M[i][j] = X[i] * Y[j];
    }

  }

}

