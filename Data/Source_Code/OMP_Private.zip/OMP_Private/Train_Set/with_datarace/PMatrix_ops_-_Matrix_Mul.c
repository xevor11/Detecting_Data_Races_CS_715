float **Matrix_Mul(float **X, float **Y, int m, int n, int q)
{
  float **Q;
  Q = Matrix_Alloc(m, m);
  int i;
  int j;
  int k;
  double start = a();
  #pragma omp parallel shared(Q,X,Y)
  {
    #pragma omp for schedule (static)
    for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)
      {
        for (k = 0; k < q; k++)
          Q[i][j] = Q[i][j] + (X[i][k] * Y[k][j]);

      }

    }

  }
  double end = a();
  printf("time 9: %f", end - start);
  return Q;
}

