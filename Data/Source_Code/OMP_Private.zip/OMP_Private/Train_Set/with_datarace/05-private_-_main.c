int main(int argc, char *argv[])
{
  int i;
  int j;
  int a[4][3];
  int b[3];
  #pragma omp parallel num_threads(4)
  {
    #pragma omp for
    for (i = 0; i < 4; i++)
    {
      for (j = 0; j < 3; j++)
      {
        b[j] = i;
        a[i][j] = b[j] + 1;
        printf("Thread# %d, a[%d][%d] = %d, b[%d] = %d\n", omp_get_thread_num(), i, j, a[i][j], i, b[j]);
      }

    }

  }
  return 0;
}

