int main()
{
  int i;
  int j;
  int k;
  int chunk;
  int ans;
  int nthreads;
  int tid;
  double begin;
  double end;
  int *A = (int *) malloc((2000 * 2000) * (sizeof(int)));
  int *B = (int *) malloc((2000 * 2000) * (sizeof(int)));
  int *C = (int *) malloc((2000 * 2000) * (sizeof(int)));
  int *C_p = (int *) malloc((2000 * 2000) * (sizeof(int)));
  printf("Matrix size: %dx%d\n", 2000, 2000);
  for (i = 0; i < (2000 * 2000); i++)
  {
    A[i] = rand() % 10;
    B[i] = rand() % 10;
    C[i] = 0;
    C_p[i] = 0;
  }

  begin = omp_get_wtime();
  for (i = 0; i < 2000; i++)
  {
    for (j = 0; j < 2000; j++)
    {
      ans = 0;
      for (k = 0; k < 2000; k++)
      {
        ans += A[(i * 2000) + k] * B[(k * 2000) + j];
      }

      C[(i * 2000) + j] = ans;
    }

  }

  end = omp_get_wtime();
  printf("\nTime in serial version: %.5f\n", end - begin);
  begin = omp_get_wtime();
  chunk = 10;
  #pragma omp parallel shared(A, B, C_p, chunk, nthreads)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("\nNumber of threads = %d\nChunk size: %d\n", nthreads, chunk);
    }

    #pragma omp for schedule(static, chunk)
    for (i = 0; i < 2000; i++)
    {
      for (j = 0; j < 2000; j++)
      {
        ans = 0;
        for (k = 0; k < 2000; k++)
        {
          ans += A[(i * 2000) + k] * B[(k * 2000) + j];
        }

        C_p[(i * 2000) + j] = ans;
      }

    }

  }
  end = omp_get_wtime();
  printf("\nTime in Parallel version: %.5f\n", end - begin);
  free(A);
  free(B);
  free(C);
  free(C_p);
  return 0;
}

