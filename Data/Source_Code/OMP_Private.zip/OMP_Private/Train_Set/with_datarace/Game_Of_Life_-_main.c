int main(int argc, char *argv[])
{
  int N;
  int T;
  int **current;
  int **previous;
  int **swap;
  int t;
  int i;
  int j;
  int nbrs;
  double time;
  struct timeval ts;
  struct timeval tf;
  if (argc != 3)
  {
    fprintf(stderr, "Usage: ./exec ArraySize TimeSteps\n");
    exit(-1);
  }
  else
  {
    N = atoi(argv[1]);
    T = atoi(argv[2]);
  }

  current = allocate_array(N);
  previous = allocate_array(N);
  init_random(previous, current, N);
  int num_proc = sysconf(_SC_NPROCESSORS_ONLN);
  int chunk = N / num_proc;
  fprintf(stdout, "N %d, num_threads %d, chunk %d\r\n", N, num_proc, chunk);
  gettimeofday(&ts, 0);
  for (t = 0; t < T; t++)
  {
    #pragma omp parallel for
    for (i = 1; i < (N - 1); i++)
      for (j = 1; j < (N - 1); j++)
    {
      nbrs = ((((((previous[i + 1][j + 1] + previous[i + 1][j]) + previous[i + 1][j - 1]) + previous[i][j - 1]) + previous[i][j + 1]) + previous[i - 1][j - 1]) + previous[i - 1][j]) + previous[i - 1][j + 1];
      if ((nbrs == 3) || ((previous[i][j] + nbrs) == 3))
      {
        current[i][j] = 1;
      }
      else
      {
        current[i][j] = 0;
      }

    }


    {
      swap = current;
      current = previous;
      previous = swap;
    }
  }

  gettimeofday(&tf, 0);
  time = (tf.tv_sec - ts.tv_sec) + ((tf.tv_usec - ts.tv_usec) * 0.000001);
  free_array(current, N);
  free_array(previous, N);
  printf("GameOfLife: Size %d Steps %d Time %lf\n", N, T, time);
  return 0;
}

