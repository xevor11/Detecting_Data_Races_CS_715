int main(int argc, char *argv[])
{
  int i;
  int j;
  int k;
  double a[62][15];
  double b[15][7];
  double c[62][7];
  for (i = 0; i < 62; i++)
    for (j = 0; j < 15; j++)
    a[i][j] = i + j;


  for (i = 0; i < 15; i++)
    for (j = 0; j < 7; j++)
    b[i][j] = i * j;


  for (i = 0; i < 62; i++)
    for (j = 0; j < 7; j++)
    c[i][j] = 0;


  #pragma omp parallel for shared(c, a, b) num_threads(8)
  for (i = 0; i < 62; i++)
  {
    for (j = 0; j < 7; j++)
    {
      for (k = 0; k < 15; k++)
      {
        c[i][j] += a[i][k] * b[k][j];
      }

    }

  }

  printf("******************************************************\n");
  printf("Result Matrix:\n");
  for (i = 0; i < 62; i++)
  {
    for (j = 0; j < 7; j++)
    {
      printf("%6.2f   ", c[i][j]);
    }

    printf("\n");
  }

  printf("******************************************************\n");
  printf("Done.\n");
  return 0;

  int i;
  int j;
  double **transpose = malloc(c * (sizeof(double *)));
  for (i = 0; i < c; i++)
    transpose[i] = malloc(r * (sizeof(double)));

  #pragma omp parallel shared(m, r, c, transpose, chunk) private(j, i)
  {
    #pragma omp for schedule(guided, chunk) nowait
    for (i = 0; i < r; i++)
      for (j = 0; j < c; j++)
      transpose[j][i] = m[i][j];


  }
  return transpose;
}

