int main(int argc, char *argv[])
{
  int nthreads = 1;
  if (argc == 2)
  {
    nthreads = argv[1][0] - '0';
  }

  int n = 100000000;
  long double dx = 1 / (((long double) n) + 1);
  long double x = 0;
  #pragma omp parallel for
  for (int i = 0; i < n; i++)
  {
    x = i * dx;
    long double y = ((exp(x) * cos(x)) * sin(x)) * sqrt((5 * x) + 6.0);
    if (((i % 1000000) == 0) && (i != 0))
    {
      #pragma omp critical
      {
      }
    }

  }

  return 0;

  int i;
  #pragma omp parallel private(i)
  {
    #pragma omp single copyprivate(i, counter)
    {
      i = 50;
      counter = 100;
      printf("thread %d execute single\n", omp_get_thread_num());
    }
    printf("thread %d: i is %d and counter is %d\n", omp_get_thread_num(), i, counter);
  }
}

