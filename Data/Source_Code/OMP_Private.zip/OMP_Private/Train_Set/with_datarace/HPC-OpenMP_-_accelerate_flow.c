{
  int nx;
  int ny;
  int maxIters;
  int reynolds_dim;
  double density;
  double accel;
  double omega;
} t_param;
{
  double speeds[9];
} t_speed;
enum boolean {FALSE, TRUE};
int initialise(const char *paramfile, const char *obstaclefile, t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
int timestep(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int accelerate_flow(const t_param params, t_speed *cells, int *obstacles);
int propagate(const t_param params, t_speed *cells, t_speed *tmp_cells);
int rebound(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int collision(const t_param params, t_speed *cells, t_speed *tmp_cells, int *obstacles);
int write_values(const t_param params, t_speed *cells, int *obstacles, double *av_vels);
int finalise(const t_param *params, t_speed **cells_ptr, t_speed **tmp_cells_ptr, int **obstacles_ptr, double **av_vels_ptr);
double total_density(const t_param params, t_speed *cells);
double av_velocity(const t_param params, t_speed *cells, int *obstacles);
double calc_reynolds(const t_param params, t_speed *cells, int *obstacles);
void die(const char *message, const int line, const char *file);
void usage(const char *exe);
int accelerate_flow(const t_param params, t_speed *cells, int *obstacles)
{
  int ii;
  double w1;
  double w2;
  int row_count;
  int row_start;
  int row_end;
  w1 = (params.density * params.accel) / 9.0;
  w2 = (params.density * params.accel) / 36.0;
  ii = params.ny - 2;
  row_start = ii * params.nx;
  row_end = row_start + params.nx;
  #pragma omp parallel for shared(cells,obstacles,ii) firstprivate(row_start,row_end)
  for (row_count = row_start; row_count < row_end; row_count++)
  {
    if ((((!obstacles[row_count]) && ((cells[row_count].speeds[3] - w1) > 0.0)) && ((cells[row_count].speeds[6] - w2) > 0.0)) && ((cells[row_count].speeds[7] - w2) > 0.0))
    {
      cells[row_count].speeds[1] += w1;
      cells[row_count].speeds[5] += w2;
      cells[row_count].speeds[8] += w2;
      cells[row_count].speeds[3] -= w1;
      cells[row_count].speeds[6] -= w2;
      cells[row_count].speeds[7] -= w2;
    }

  }

  return 0;
}

