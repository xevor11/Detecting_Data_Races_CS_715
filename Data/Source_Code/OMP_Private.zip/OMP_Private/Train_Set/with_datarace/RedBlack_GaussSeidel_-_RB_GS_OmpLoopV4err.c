double RB_GS_OmpLoopV4err(double **black, double **red, int m, int n, double eps, int maxit, int iterations_print, int *iterations)
{
  int i;
  int j;
  double v;
  double error = 10.0 * eps;
  while ((error >= eps) && ((*iterations) < maxit))
  {
    #pragma omp parallel
    {
      #pragma omp for schedule(OMP_SCHED) reduction(+:error)
      for (i = 1; i < (m - 1); i++)
        for (j = i % 2; j < ((n / 2) - ((i + 1) % 2)); j++)
      {
        v = 0.25 * (((red[i - 1][j] + red[i + 1][j]) + red[i][j - (i % 2)]) + red[i][j + ((i + 1) % 2)]);
        black[i][j] = v;
      }


      #pragma omp for schedule(OMP_SCHED) reduction(+:error)
      for (i = 1; i < (m - 1); i++)
        for (j = (i + 1) % 2; j < ((n / 2) - (i % 2)); j++)
      {
        v = 0.25 * (((black[i - 1][j] + black[i + 1][j]) + black[i][j - ((i + 1) % 2)]) + black[i][j + (i % 2)]);
        red[i][j] = v;
      }


      #pragma omp for schedule(OMP_SCHED) reduction(+:error)
      for (i = 1; i < (m - 1); i++)
        for (j = i % 2; j < ((n / 2) - ((i + 1) % 2)); j++)
      {
        v = 0.25 * (((red[i - 1][j] + red[i + 1][j]) + red[i][j - (i % 2)]) + red[i][j + ((i + 1) % 2)]);
        error += (v - black[i][j]) * (v - black[i][j]);
        black[i][j] = v;
      }


      #pragma omp for schedule(OMP_SCHED) reduction(+:error) nowait
      for (i = 1; i < (m - 1); i++)
        for (j = (i + 1) % 2; j < ((n / 2) - (i % 2)); j++)
      {
        v = 0.25 * (((black[i - 1][j] + black[i + 1][j]) + black[i][j - ((i + 1) % 2)]) + black[i][j + (i % 2)]);
        error += (v - red[i][j]) * (v - red[i][j]);
        red[i][j] = v;
      }


    }
    error = sqrt(error) / (m * n);
    *iterations += 2;
  }

  return error;
}

