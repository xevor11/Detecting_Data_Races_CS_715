int main()
{
  int num_steps = 1000000000;
  int my_id;
  int numprocs;
  int numthreads;
  int threadlevel;
  double x;
  double pi;
  double step;
  double sum = 0.0;
  step = 1.0 / ((double) num_steps);
  MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &threadlevel);
  MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  if (my_id == 0)
  {
    #pragma omp parallel
    #pragma omp master
    {
      numthreads = omp_get_num_threads();
    }
  }

  MPI_Bcast(&numthreads, 1, MPI_INT, 0, MPI_COMM_WORLD);
  omp_set_num_threads(numthreads);
  printf("numthreads = %d\n", numthreads);
  #pragma omp parallel for private(x) reduction(+:sum) schedule(static)
  for (int i = my_id; i < num_steps; i += numprocs)
  {
    x = (i + 0.5) * step;
    sum += 4.0 * (1 + (x * x));
  }

  MPI_Reduce(&sum, &pi, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
  if (my_id == 0)
    printf("pi %lf\n", pi);

  MPI_Finalize();
  return 0;

  int i;
  int a[20];
  omp_set_num_threads(4);
  #pragma omp parallel
  {
    if (omp_get_thread_num() != 2)
      sleep(2);

    #pragma omp for
    for (i = 0; i < 20; i++)
    {
      a[i] = i;
      printf("a[%d]=%d tid=%d\n", i, a[i], omp_get_thread_num());
    }

    printf("end %d thread\n", omp_get_thread_num());
  }
}

