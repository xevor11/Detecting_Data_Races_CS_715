struct elem
{
  double Length;
  double *R1;
  double *R2;
  double *T1;
  double *T2;
  double *EApertures;
  double *RApertures;
};
void DriftPass(double *r_in, double le, const double *T1, const double *T2, const double *R1, const double *R2, double *RApertures, double *EApertures, int num_particles)
{
  double *r6;
  int c;
  #pragma omp parallel for if (num_particles > OMP_PARTICLE_THRESHOLD*10) default(shared) shared(r_in,num_particles)
  for (c = 0; c < num_particles; c++)
  {
    r6 = r_in + (c * 6);
    if (!atIsNaN(r6[0]))
    {
      if (T1)
        ATaddvv(r6, T1);

      if (R1)
        ATmultmv(r6, R1);

      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      ATdrift6(r6, le);
      if (RApertures)
        checkiflostRectangularAp(r6, RApertures);

      if (EApertures)
        checkiflostEllipticalAp(r6, EApertures);

      if (R2)
        ATmultmv(r6, R2);

      if (T2)
        ATaddvv(r6, T2);

    }

  }

}

