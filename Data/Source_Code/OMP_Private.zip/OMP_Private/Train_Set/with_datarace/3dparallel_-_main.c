int main(int argc, char *argv[])
{
  int M = atoi(argv[1]);
  int N = atoi(argv[1]);
  int K = atoi(argv[1]);
  double ctime;
  double ctime1;
  double ctime2;
  double diff;
  double th_diff;
  double epsilon = atof(argv[2]);
  int num_threads = atoi(argv[3]);
  int i;
  int iterations;
  int j;
  int k;
  double mean;
  omp_set_num_threads(num_threads);
  double *u[M][N];
  for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    u[i][j] = (double *) malloc(K * (sizeof(double)));


  double *w[M][N];
  for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    w[i][j] = (double *) malloc(K * (sizeof(double)));


  diff = epsilon;
  mean = 0.0;
  ctime1 = omp_get_wtime();
  #pragma omp parallel shared ( w )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1][0] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j][0] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j][0] = 0.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0][K - 1] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1][K - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j][K - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j][K - 1] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[0][0][k] = 0.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[0][N - 1][k] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[M - 1][0][k] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[M - 1][N - 1][k] = 100.0;
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][0][0];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][N - 1][0];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[M - 1][j][0];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[0][j][0];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][0][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][N - 1][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[M - 1][j][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[0][j][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[0][0][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[0][N - 1][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[M - 1][0][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[M - 1][N - 1][k];
    }

  }
  mean = mean / ((double) ((((4 * M) + (4 * N)) + (4 * K)) - 12));
  #pragma omp parallel shared ( mean, w )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      for (j = 1; j < (N - 1); j++)
      {
        for (k = 1; k < (K - 1); k++)
        {
          w[i][j][k] = mean;
        }

      }

    }

  }
  iterations = 0;
  while (epsilon <= diff)
  {
    #pragma omp parallel shared ( diff, u, w )
    {
      #pragma omp for
      for (i = 0; i < M; i++)
      {
        for (j = 0; j < N; j++)
        {
          for (k = 0; k < K; k++)
          {
            u[i][j][k] = w[i][j][k];
          }

        }

      }

      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          for (k = 1; k < (K - 1); k++)
          {
            w[i][j][k] = (((((u[i - 1][j][k] + u[i + 1][j][k]) + u[i][j - 1][k]) + u[i][j + 1][k]) + u[i][j][k + 1]) + u[i][j][k - 1]) / 6.0;
          }

        }

      }

    }
    diff = 0.0;
    #pragma omp parallel shared ( diff, u, w )
    {
      th_diff = 0.0;
      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          for (k = 1; k < (K - 1); k++)
          {
            if (th_diff < fabs(w[i][j][k] - u[i][j][k]))
            {
              th_diff = fabs(w[i][j][k] - u[i][j][k]);
            }

          }

        }

      }

      #pragma omp critical
      {
        if (diff < th_diff)
        {
          diff = th_diff;
        }

      }
    }
    iterations++;
  }

  ctime2 = omp_get_wtime();
  ctime = ctime2 - ctime1;
  printf("%d %f\n", iterations, ctime);
  return 0;

  int a[10][6];
  int b[10][6];
  int c[10][6];
  int i;
  int j;
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 6; j++)
    {
      a[i][j] = i + j;
      b[i][j] = (2 * i) + (2 * j);
    }

  }

  printf("Mang a:\n");
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 6; j++)
    {
      printf("%d ", a[i][j]);
    }

    printf("\n");
  }

  printf("\nMang b:\n");
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 6; j++)
    {
      printf("%d ", b[i][j]);
    }

    printf("\n");
  }

  int Nid;
  int id;
  int sid;
  int eid;
  int T = 5;
  omp_set_num_threads(T);
  Nid = 10 / T;
  #pragma omp parallel private(id, sid, eid,i)
  {
    id = omp_get_thread_num();
    sid = id * Nid;
    eid = sid + Nid;
    for (i = sid; i < eid; i++)
    {
      for (j = 0; j < 6; j++)
      {
        c[i][j] = a[i][j] + b[i][j];
      }

    }

  }
  printf("\nKq cua mang c[][]: \n");
  for (i = 0; i < 10; i++)
  {
    for (j = 0; j < 6; j++)
    {
      printf("%d ", c[i][j]);
    }

    printf("\n");
  }

  return 0;
}

