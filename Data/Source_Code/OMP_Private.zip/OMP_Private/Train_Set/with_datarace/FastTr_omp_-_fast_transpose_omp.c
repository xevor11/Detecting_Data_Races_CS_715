void fast_transpose_omp(double *A, double *AT, size_t dim, size_t block_size)
{
  size_t i;
  size_t j;
  size_t bi;
  size_t bj;
  double elaps_t_i;
  double elaps_t_f;
  double elaps_time;
  elaps_t_i = seconds();
  #pragma omp parallel
  {
    #pragma omp for collapse(2)
    for (i = 0; i < dim; i += block_size)
      for (j = 0; j < dim; j += block_size)
      for (bi = i; bi < (i + block_size); ++bi)
      for (bj = j; bj < (j + block_size); ++bj)
    {
      AT[bi + (bj * dim)] = A[(bi * dim) + bj];
    }




  }
  elaps_t_f = seconds();
  elaps_time = elaps_t_f - elaps_t_i;
  printf("%e\n", elaps_time);
}

