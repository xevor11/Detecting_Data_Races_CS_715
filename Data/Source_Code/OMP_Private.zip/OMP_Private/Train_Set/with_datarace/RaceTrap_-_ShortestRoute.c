{
  int x;
  int y;
} Coord;
{
  double length;
  unsigned char nPlaced;
  unsigned char path[0];
} RouteDefinition;
int nBags = 0;
Coord *bagCoords;
double **distanceTable;
double maxRouteLen = 10E100;
double globalBest = 10E100;
int done = 0;
RouteDefinition *ShortestRoute(RouteDefinition *route)
{
  int i;
  RouteDefinition *bestRoute;
  if (route->nPlaced == nBags)
  {
    route->length += distanceTable[route->path[route->nPlaced - 1]][route->path[0]];
    return route;
  }

  bestRoute = Alloc_RouteDefinition();
  bestRoute->length = maxRouteLen;
  #pragma omp parallel for
  for (i = route->nPlaced; i < nBags; i++)
  {
    done++;
    double newLength = route->length + distanceTable[route->path[route->nPlaced - 1]][route->path[i]];
    RouteDefinition *newRoute;
    if (newLength >= globalBest)
      continue;

    newRoute = Alloc_RouteDefinition();
    memcpy(newRoute->path, route->path, nBags);
    newRoute->path[route->nPlaced] = route->path[i];
    newRoute->path[i] = route->path[route->nPlaced];
    newRoute->nPlaced = route->nPlaced + 1;
    newRoute->length = newLength;
    if (done > 1)
      newRoute = ShortestRoute2(newRoute);
    else
      newRoute = ShortestRoute(newRoute);

    if (newRoute->length < bestRoute->length)
    {
      free(bestRoute);
      bestRoute = newRoute;
      #pragma omp critical
      {
        if (bestRoute->length < globalBest)
        {
          globalBest = bestRoute->length;
        }

      }
    }
    else
    {
      free(newRoute);
    }

  }

  free(route);
  return bestRoute;

  int i;
  #pragma omp parallel for private(i), shared(vector,deriv)
  for (i = 0; i < N; i++)
  {
    vector[i] += (mult * deriv[i]) * dt;
  }

}

