int main(int argc, char *argv[])
{
  double pi = 0.0;
  int n = 100000000;
  double h;
  double x;
  double f;
  double sum;
  double tstart;
  double tend;
  double time;
  int i;
  tstart = esecs();
  h = 1.0 / n;
  sum = 0.0;
  #pragma omp parallel for reduction(+:sum)
  for (i = 1; i <= n; i++)
  {
    x = (i - 0.5) * h;
    f = 4.0 / (1.0 + (x * x));
    sum = sum + f;
  }

  pi = h * sum;
  tend = esecs();
  time = tend - tstart;
  printf("Value of pi is: %20.16lf\n\n", pi);
  printf("Time for n=%d : %lf secs\n", n, time);
  return 0;
}

