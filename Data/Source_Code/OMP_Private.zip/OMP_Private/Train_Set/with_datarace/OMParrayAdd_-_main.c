int main(int argc, char **argv)
{
  int size = 10;
  int tid = 0;
  int TRANSPOSE = 0;
  double *A;
  double *B;
  double *R;
  if (argc > 1)
  {
    size = atoi(argv[1]);
  }

  A = hpcelo_create_matrixC(size);
  B = hpcelo_create_matrixC(size);
  R = calloc(size * size, sizeof(double));
  HPCELO_DECLARE_TIMER;
  HPCELO_START_TIMER;
  int i;
  int j;
  int k;
  double tmp = 0.0;
  #pragma omp parallel for private(i,j,k) schedule(static)
  for (i = 0; i < size; i++)
    for (j = 0; j < size; j++)
  {
    tmp = 0;
    for (k = 0; k < size; k++)
      tmp = tmp + (A[(i * size) + k] * B[(k * size) + j]);

    R[(i * size) + j] = tmp;
  }


  HPCELO_END_TIMER;
  if (0 != 1)
  {
    HPCELO_REPORT_TIMER;
  }
  else
  {
    printerOfMatrix(R, size);
  }

  hpcelo_free_matrixC(A);
  hpcelo_free_matrixC(B);
  hpcelo_free_matrixC(R);
  return 0;

  int *A;
  int *B;
  int *C;
  int N;
  int i;
  int id;
  int P;
  double start;
  double stop;
  #pragma omp parallel
  {
    id = omp_get_thread_num();
    if (id == 0)
    {
      printf("\nInsert N, size of A and B arrays: ");
      scanf("%d", &N);
    }

  }
  A = malloc(N * (sizeof(int)));
  B = malloc(N * (sizeof(int)));
  C = malloc(N * (sizeof(int)));
  for (i = 0; i < N; i++)
  {
    A[i] = rand() % 10;
    B[i] = rand() % 10;
  }

  start = omp_get_wtime();
  #pragma omp parallel for
  for (i = 0; i < N; i++)
  {
    id = omp_get_thread_num();
    printf("\ntask: %d, i: %d", id, i);
    C[i] = A[i] + B[i];
  }

  stop = omp_get_wtime();
  printf("\n\nA:\n");
  for (i = 0; i < N; i++)
  {
    printf("%4d", A[i]);
  }

  printf("\n");
  printf("\nB:\n");
  for (i = 0; i < N; i++)
  {
    printf("%4d", B[i]);
  }

  printf("\n");
  printf("\nC:\n");
  for (i = 0; i < N; i++)
  {
    printf("%4d", C[i]);
  }

  printf("\n\nRun time: %.6fs", stop - start);
  printf("\n\n");
  return 0;
}

