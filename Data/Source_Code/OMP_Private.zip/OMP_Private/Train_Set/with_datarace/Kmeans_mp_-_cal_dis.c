int NUM_THREADS = 4;
int NUM_CLUSTERS = 6;
int MAX_ITERATIONS = 100;
void cal_dis(int num_points, int num_col, int num_dim, float **mtrx, float **cen_mtrx)
{
  int nthreads;
  int tid;
  #pragma omp parallel private(nthreads, tid)
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }

  }

  int ii;
  int jj;
  omp_set_num_threads(NUM_THREADS);
  #pragma omp parallel for collapse(2) default(shared)
  for (ii = 0; ii < num_points; ii++)
  {
    for (jj = 0; jj < NUM_CLUSTERS; jj++)
    {
      float xdiff = mtrx[ii][1] - cen_mtrx[jj][0];
      float ydiff = mtrx[ii][2] - cen_mtrx[jj][1];
      mtrx[ii][(jj + num_dim) + 1] = sqrt((xdiff * xdiff) + (ydiff * ydiff));
    }

  }

}

