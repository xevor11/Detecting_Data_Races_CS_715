int main()
{
  ll facto = 15;
  ll r1;
  ll r2;
  ll tid;
  ll res = 1;
  ll i;
  ll mod = 0;
  omp_set_num_threads(3);
  ll chunk = facto / 3;
  #pragma omp parallel reduction(*:res) shared(facto,mod,chunk)
  {
    tid = omp_get_thread_num();
    mod = facto % 3;
    switch (tid)
    {
      case 0:
        switch (mod)
      {
        case 0:
          r1 = 1;
          r2 = chunk;
          break;

        case 1:
          r1 = 1;
          r2 = chunk + 1;
          break;

        case 2:
          r1 = 1;
          r2 = chunk + 1;
          break;

      }

        break;

      case 1:
        switch (mod)
      {
        case 0:
          r1 = chunk + 1;
          r2 = chunk * 2;
          break;

        case 1:
          r1 = chunk + 2;
          r2 = (chunk * 2) + 1;
          break;

        case 2:
          r1 = chunk + 2;
          r2 = (chunk * 2) + 2;
          break;

      }

        break;

      case 2:
        switch (mod)
      {
        case 0:
          r1 = (chunk * 2) + 1;
          r2 = facto;
          break;

        case 1:
          r1 = (chunk * 2) + 2;
          r2 = facto;
          break;

        case 2:
          r1 = (chunk * 2) + 3;
          r2 = facto;
          break;

      }

        break;

    }

    printf("Thread: %lld hace el rango [%lld,%lld]\n", tid, r1, r2);
    res = multi(r1, r2);
  }
  printf("Factorial = %lld\n", res);
  return 0;

  int sum;
};
struct element_t partial[256];
int sum(int *v, int n)
{
  int i;
  int sum;
  int nthreads;
  int myid;
  int init;
  int end;
  int slice;
  printf("parallel\n");
  sum = 0;
  for (i = 0; i < 256; i++)
    partial[i].sum = 0;

  #pragma omp parallel shared(sum, nthreads) private(i,myid,init,end,slice)
  {
    #pragma omp single
    {
      nthreads = omp_get_num_threads();
    }
    myid = omp_get_thread_num();
    slice = n / nthreads;
    init = myid * slice;
    if (myid == (nthreads - 1))
      end = n;
    else
      end = init + slice;

    for (i = init; i < end; i++)
    {
      partial[myid].sum += v[i];
    }

  }
  for (i = 0; i < 256; i++)
    sum += partial[i].sum;

  return sum;
}

