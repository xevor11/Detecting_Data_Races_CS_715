int main(void)
{
  int a[1000][1000];
  int b[1000][1000];
  int result[1000][1000];
  printf("Initializing matricies %d X %d...\n", 1000, 1000);
  for (int i = 0; i < 1000; i++)
  {
    for (int j = 0; j < 1000; j++)
    {
      a[i][j] = i + j;
      b[i][j] = i + j;
    }

  }

  printf("Multiplying matricies %d X %d...\n", 1000, 1000);
  int i;
  int j;
  int k;
  #pragma omp for
  for (i = 0; i < 1000; i++)
  {
    for (j = 0; j < 1000; j++)
    {
      int sum = 0;
      for (k = 0; k < 1000; k++)
      {
        sum += a[i][k] * b[k][j];
      }

      result[i][j] = sum;
    }

  }

  puts("---------------COMPLETE---------------");

  int i;
  double sum = 0.0;
  double pi;
  double x_i;
  double step = 1.0 / 1000000;
  #pragma omp parallel num_threads(NUM_THREADS) private(i, x_i) reduction(+:sum)
  {
    int id = omp_get_thread_num();
    int nths = omp_get_num_threads();
    for (i = id; i < 1000000; i += nths)
    {
      x_i = (i + 0.5) * step;
      sum = sum + (4.0 / (1.0 + (x_i * x_i)));
    }

  }
  pi = sum * step;
  printf("Pi: %.15e\n", pi);
  return 0;
}

