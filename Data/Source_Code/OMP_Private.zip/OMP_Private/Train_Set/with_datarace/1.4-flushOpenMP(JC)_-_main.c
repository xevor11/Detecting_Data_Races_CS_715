int main(int argc, char **argv)
{
  int nthreads;
  int tid;
  int hilos;
  int numElementos;
  int i;
  int j;
  int indiceActual;
  int *vector;
  int suma;
  int aux;
  if (argc < 2)
  {
    printf("\nSintaxis: %s numHilos\n\n", argv[0]);
    return 1;
  }

  numElementos = (hilos = atoi(argv[1]));
  if (hilos < 0)
  {
    printf("\nEl número de hilos debe ser positivo\n");
    printf("\nSintaxis: %s numHilos\n\n", argv[0]);
    return 1;
  }

  printf("getWTime de hebra PADRE: %f \n", omp_get_wtime());
  omp_set_num_threads(hilos);
  vector = malloc(numElementos * (sizeof(int)));
  if (vector == 0)
  {
    printf("\n ERROR: al reservar memoria \n");
    return 1;
  }

  for (i = 0; i < numElementos; i++)
  {
    vector[i] = 1;
  }

  suma = 0;
  #pragma omp parallel shared(vector)
  {
    tid = omp_get_thread_num();
    for (i = 0; i < 100000; i++)
    {
      vector[tid]++;
      if ((tid == 0) && ((vector[tid] % 100) == 0))
      {
        vector[tid]++;
        #pragma omp flush(vector)
      }

      if ((vector[0] % 100) == 0)
      {
        if (tid != 0)
        {
          printf("el hilo %d no ve el valor correcto de vector[0]:%d\n", tid, vector[0]++);
          #pragma omp flush(vector)
          printf("SINCRONIZADO: hilo %d, valor correcto del vector[0]:%d\n", tid, vector[0]);
        }

      }

    }

  }
  printf("\n");
  printf("\ngetWTime de hebra PADRE: %f \n", omp_get_wtime());
}

