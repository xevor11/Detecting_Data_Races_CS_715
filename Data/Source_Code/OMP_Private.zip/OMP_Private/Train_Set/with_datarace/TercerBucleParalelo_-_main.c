int main(int argc, char *argv[])
{
  int thread_count = strtol(argv[1], 0, 10);
  int af;
  int ac;
  int bf;
  int bc;
  int i;
  int j;
  int k;
  int sum;
  printf("Filas de Matriz A-->");
  scanf("%d", &af);
  printf("Columnas de Matriz  A-->");
  scanf("%d", &ac);
  printf("Filas de matriz B-->");
  scanf("%d", &bf);
  printf("Columnas de matriz  B-->");
  scanf("%d", &bc);
  if (ac != bf)
  {
    printf("no es posible hacer la multiplicación, las columnas de la matriz A deben ser las mismas que las filas de la matriz B \n");
    system("pause");
    return 0;
  }

  struct tms t1;
  struct tms t2;
  clock_t start;
  clock_t end;
  clock_t astart;
  clock_t aend;
  double start_get;
  double end_get;
  int **matriz_A;
  int **matriz_B;
  int **matriz_C;
  matriz_A = (int **) malloc(af * (sizeof(int *)));
  matriz_B = (int **) malloc(bf * (sizeof(int *)));
  matriz_C = (int **) malloc(af * (sizeof(int *)));
  for (i = 0; i < af; i++)
  {
    matriz_A[i] = (int *) malloc(ac * (sizeof(int)));
  }

  for (i = 0; i < bf; i++)
  {
    matriz_B[i] = (int *) malloc(bc * (sizeof(int)));
  }

  for (i = 0; i < af; i++)
  {
    matriz_C[i] = (int *) malloc(bc * (sizeof(int)));
  }

  astart = times(&t1);
  start = clock();
  start_get = get_time();
  for (i = 0; i < af; i++)
  {
    for (j = 0; j < bc; j++)
    {
      sum = 0;
      #pragma omp parallel for num_threads(thread_count) reduction(+:sum)
      for (k = 0; k < ac; k++)
      {
        sum = matriz_A[i][k] * matriz_B[k][j];
      }

      matriz_C[i][j] = sum;
    }

  }

  aend = times(&t2);
  end = clock();
  end_get = get_time();
  printf("salida(times())=%ld\n", (long) (aend - astart));
  printf("La funcion clock() da:%lf\n", ((double) (end - start)) / CLOCKS_PER_SEC);
  printf("La función get_time:%lf segundos\n", end_get - start_get);
}

