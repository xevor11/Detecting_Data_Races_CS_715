void Print_Matrix(double *v, int M, int N);
void InitMatrix(double *A, int N);
void ProcessDiagonalBlock(double *A, int L1, int N);
void ProcessBlockOnRow(double *A, double *D, int L1, int L3, int N);
void ProcessBlockOnColumn(double *A, double *D, int L1, int L2, int N);
void ProcessInnerBlock(double *A, double *R, double *C, int L1, int L2, int L3, int N);
void stepLU(double *A, int Block, int offset, int N);
void InitMatrix2(double *A, int N);
void InitMatrix3(double *A, int N);
void stage1(double *A, int offset, int *sizedim, int *start, int N, int M);
void stage2(double *A, int offset, int *sizedim, int *start, int N, int M);
void stage3(double *A, int offset, int *sizedim, int *start, int N, int M);
void lu2(double *A, int N);
int N = 100;
int Block = 1;
int M = 1;
void InitMatrix3(double *A, int N)
{
  long long i;
  long long j;
  long long k;
  double *L;
  double *U;
  L = (double *) malloc((N * N) * (sizeof(double)));
  U = (double *) malloc((N * N) * (sizeof(double)));
  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
    {
      A[(i * N) + j] = 0;
      if (i >= j)
        L[(i * N) + j] = (i - j) + 1;
      else
        L[(i * N) + j] = 0;

      if (i <= j)
        U[(i * N) + j] = (j - i) + 1;
      else
        U[(i * N) + j] = 0;

    }


    #pragma omp for
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
      for (k = 0; k < N; k++)
      A[(i * N) + j] += L[(i * N) + k] * U[(k * N) + j];



  }
}

