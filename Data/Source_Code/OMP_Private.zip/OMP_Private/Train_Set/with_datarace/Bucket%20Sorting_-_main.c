int main(int argc, char **argv[])
{
  int i;
  int k;
  int n;
  int tid;
  int nthreads;
  int array[50];
  int ans[49];
  printf("\n Enter the number of elements to be sorted :");
  scanf("%d", &n);
  printf("\n Enter the elements to be sorted :\n");
  for (i = 0; i < n; i++)
  {
    scanf("\n%d", &array[i]);
  }

  printf("Bucket Sorting Let's Begin..\n");
  #pragma omp parallel shared(array,nthreads,ans,n,k)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
    {
      nthreads = omp_get_num_threads();
    }

    #pragma omp
    {
      Bucket_Sort(array, ans, n);
    }
  }
  for (k = 0; k < n; k++)
  {
    printf("%d\n", ans[k]);
  }

  printf("  Result of Bucket Sort with %d threads\n", nthreads);
}

