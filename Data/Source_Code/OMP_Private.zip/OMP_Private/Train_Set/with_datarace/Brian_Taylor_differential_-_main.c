int main(int argc, char *argv[])
{
  int i;
  int j;
  int k;
  int iter;
  float **x;
  float **xn;
  float **temp;
  int conv;
  int n;
  int p;
  float error;
  double time_start;
  double time_end;
  struct timeval tv;
  struct timezone tz;
  if (argc != 3)
  {
    printf("wrong number of arguments");
    exit(2);
  }

  n = atoi(argv[1]);
  p = atoi(argv[2]);
  printf("Array size = %d \n ", n);
  x = malloc((sizeof(float *)) * (n + 2));
  for (i = 0; i < (n + 2); i++)
  {
    x[i] = malloc((sizeof(float)) * (n + 2));
  }

  xn = malloc((sizeof(float *)) * (n + 2));
  for (i = 0; i < (n + 2); i++)
  {
    xn[i] = malloc((sizeof(float)) * (n + 2));
  }

  iter = 0;
  #pragma omp parallel num_threads(p) shared(x, xn, iter, conv)
  {
    #pragma omp for schedule (static)
    for (i = 1; i <= n; i++)
    {
      for (j = 1; j <= n; j++)
      {
        x[i][j] = 0;
        xn[i][j] = 0;
      }

      x[0][i] = 0;
      x[i][0] = 0;
      x[n + 1][i] = i;
      x[i][n + 1] = i;
      xn[0][i] = 0;
      xn[i][0] = 0;
      xn[n + 1][i] = i;
      xn[i][n + 1] = i;
    }

    #pragma omp single
    {
      gettimeofday(&tv, &tz);
      time_start = ((double) tv.tv_sec) + (((double) tv.tv_usec) / 1000000.0);
    }
    for (k = 1; k < 150000; k++)
    {
      #pragma omp barrier
      #pragma omp single
      conv = 1;
      #pragma omp for schedule (static)
      for (i = 1; i <= n; i++)
      {
        for (j = 1; j <= n; j++)
        {
          xn[i][j] = 0.25 * (((x[i - 1][j] + x[i + 1][j]) + x[i][j - 1]) + x[i][j + 1]);
          if (conv)
          {
            if (xn[i][j] <= x[i][j])
              error = x[i][j] - xn[i][j];
            else
              error = xn[i][j] - x[i][j];

            if (error > 0.001)
            {
              conv = 0;
            }

          }

        }

      }

      #pragma omp single
      {
        temp = x;
        x = xn;
        xn = temp;
      }
      #pragma omp barrier
      if (conv == 1)
      {
        #pragma omp single
        iter = k;
        k = 150000;
      }

    }

    #pragma omp single
    {
      gettimeofday(&tv, &tz);
      time_end = ((double) tv.tv_sec) + (((double) tv.tv_usec) / 1000000.0);
      if (!conv)
        iter = k;

    }
  }
  printf("number of iterations is %d \n", iter);
  printf("print some diagonal elements for checking results: \n");
  for (i = 1; i <= n; i = i + (n / 8))
    printf(" %f ", x[i][i]);

  printf("\n ");
  printf("time: %lf\n", time_end - time_start);
  return 0;

  int matrix_size_iter;
  for (matrix_size_iter = 200; matrix_size_iter <= 700; matrix_size_iter += 100)
  {
    int threads_num_iter;
    for (threads_num_iter = 1; threads_num_iter <= 8; threads_num_iter *= 2)
    {
      N = matrix_size_iter;
      omp_set_num_threads(threads_num_iter);
      double time0;
      double time1;
      FILE *in;
      int i;
      int j;
      int k;
      A = (double *) malloc((N * (N + 1)) * (sizeof(double)));
      X = (double *) malloc(N * (sizeof(double)));
      printf("GAUSS %dx%d\n----------------------------------\n", N, N);
      wtime(&time0);
      #pragma omp parallel private(k,j,i) shared(A,X)
      {
        #pragma omp for
        for (i = 0; i <= (N - 1); i++)
          for (j = 0; j <= N; j++)
          if ((i == j) || (j == N))
          A[(i * (N + 1)) + j] = 1.f;
        else
          A[(i * (N + 1)) + j] = 0.f;



        for (i = 0; i < (N - 1); i++)
        {
          #pragma omp for
          for (k = i + 1; k <= (N - 1); k++)
            for (j = i + 1; j <= N; j++)
            A[(k * (N + 1)) + j] = A[(k * (N + 1)) + j] - ((A[(k * (N + 1)) + i] * A[(i * (N + 1)) + j]) / A[(i * (N + 1)) + i]);


        }

        #pragma omp single
        X[N - 1] = A[((N - 1) * (N + 1)) + N] / A[((N - 1) * (N + 1)) + (N - 1)];
        for (j = N - 2; j >= 0; j--)
        {
          #pragma omp for
          for (k = 0; k <= j; k++)
            A[(k * (N + 1)) + N] = A[(k * (N + 1)) + N] - (A[(k * (N + 1)) + (j + 1)] * X[j + 1]);

          X[j] = A[(j * (N + 1)) + N] / A[(j * (N + 1)) + j];
        }

      }
      wtime(&time1);
      printf("Time in seconds=%gs\n", time1 - time0);
      prt1a("X=(", X, (N > 9) ? (9) : (N), "...)\n");
      free(A);
      free(X);
    }

  }

  return 0;
}

