float *MulMat(float *mat1, int alto1, int ancho1, float *mat2, int alto2, int ancho2)
{
  float *matriz;
  matriz = (float *) malloc((alto1 * ancho2) * (sizeof(float)));
  int i;
  int j;
  int o;
  int m;
  int n;
  int cont;
  int pos;
  int IDhilo;
  int Nhilos;
  int PosMAx;
  float valor;
  PosMAx = alto1 * ancho2;
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (o = 0; o < alto1; o++)
    {
      IDhilo = omp_get_thread_num();
      Nhilos = omp_get_num_threads();
      pos = o * ancho1;
      cont = pos;
      m = 0;
      while (m < ancho2)
      {
        i = cont;
        j = m;
        valor = 0;
        n = 0;
        while (n < alto2)
        {
          valor = valor + (mat1[i] * mat2[j]);
          i = i + 1;
          j = j + ancho2;
          n = n + 1;
        }

        matriz[pos] = valor;
        m = m + 1;
        pos = pos + 1;
      }

    }

  }
  return matriz;
}

