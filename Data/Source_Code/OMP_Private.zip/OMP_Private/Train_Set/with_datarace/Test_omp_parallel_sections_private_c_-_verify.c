void verify()
{
  int i = 0;
  #pragma omp parallel sections
  {
    #pragma omp section
    i++;
    #pragma omp section
    i++;
  }
  if (i != 0)
    printf("\nthe value of i= %d and omp parallel sections private test : FAILS\n", i);
  else
    printf("\nthe value of i= %d and  omp parallel sections private test : PASSES\n", i);

}

