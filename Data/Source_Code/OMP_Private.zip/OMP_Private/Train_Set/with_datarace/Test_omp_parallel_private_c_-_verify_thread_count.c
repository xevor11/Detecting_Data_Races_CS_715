void verify_thread_count()
{
  int actual_thread_count = 0;
  #pragma omp parallel
  {
    actual_thread_count++;
  }
  if (actual_thread_count != 0)
  {
    printf("\nThe \"omp_parallel_private\" construct test verification : FAILS ");
    printf("\nPrivate variable count = %d ", actual_thread_count);
  }
  else
  {
    printf("\nThe omp_parallel_private construct test verification : PASSES ");
    printf("\nPrivate variable count = %d \n", actual_thread_count);
  }

}

