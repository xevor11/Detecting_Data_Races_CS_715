void printR(double *v, double **m, double *r);
void printMatrix(double **matrix, int noLines, int noColumns);
int p_main(double **matrix1, double **matrix2, int noLines, int noColumns);
void matrixPow2(double **matrix, int noLines, int noColumns);
double **matrixSub(double **matrix1, double **matrix2, int noLines, int noColumns);
double matrixAccumulate(double **matrix, int noLines, int noColumns);
double matrixAccumulate(double **matrix, int noLines, int noColumns)
{
  double start_time;
  double run_time;
  start_time = omp_get_wtime();
  double acc = 0.0;
  int i;
  int j;
  #pragma omp parallel for shared(i, matrix) reduction(+:acc)
  for (i = 0; i < noLines; i++)
    for (j = 0; j < noColumns; j++)
    acc += matrix[i][j];


  run_time = omp_get_wtime() - start_time;
  printf("Tempo para acumular:                 %lf s\n", run_time);
  return acc;
}

