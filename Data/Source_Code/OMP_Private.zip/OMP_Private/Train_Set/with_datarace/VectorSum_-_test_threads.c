long long serial_sum(const char *a, size_t n);
long long time_optimal_sum(const char *a, size_t n);
long long cost_optimal_sum(const char *a, size_t n);
int test_threads(int argc, char *argv[])
{
  int numThreads;
  int tid;
  #pragma omp parallel
  {
    tid = omp_get_thread_num();
    printf("Hello World from thread number %d\n", tid);
    if (tid == 0)
    {
      numThreads = omp_get_num_threads();
      printf("Number of threads is %d\n", numThreads);
    }

  }
  return 0;
}

