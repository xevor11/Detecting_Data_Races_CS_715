int main(void)
{
  int i;
  int j;
  int **pRawNums = (int **) calloc(4, sizeof(int *));
  int **pDataSorted = (int **) calloc(4, sizeof(int *));
  for (int i = 0; i < 4; i++)
  {
    pRawNums[i] = (int *) calloc(2500000, sizeof(int));
    pDataSorted[i] = (int *) calloc(2 * 2500000, sizeof(int));
  }

  int *pAnswer = (int *) calloc(4 * 2500000, sizeof(int));
  int *pCorrect = (int *) calloc(4 * 2500000, sizeof(int));
  int candidates[4 * (4 - 1)] = {0};
  int split_bound[4 - 1] = {0};
  int thread_element_count[4] = {0};
  int s_index[4 + 1] = {0};
  omp_set_num_threads(4);
  int c_num = 4 * (4 - 1);
  int c_index = 0;
  int c_Count = 4 - 1;
  int c_Interval = 2500000 / (4 - 1);
  srand(time(0));
  struct timespec t_start;
  struct timespec t_end;
  double elapsedTime;
  double totalTime = 0;
  for (i = 0; i < 4; i++)
  {
    for (j = 0; j < 2500000; j++)
    {
      pRawNums[i][j] = (rand() % 2147483647) + 1;
      pCorrect[(i * 2500000) + j] = pRawNums[i][j];
    }

  }

  clock_gettime(CLOCK_REALTIME, &t_start);
  int count = 0;
  for (i = 0; i < 4; i++)
  {
    for (j = 0; j < (4 - 1); j++)
    {
      int e_index = rand() % 2500000;
      candidates[count] = pRawNums[i][e_index];
      count++;
    }

  }

  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Choose candidates:", elapsedTime);
  totalTime += elapsedTime;
  clock_gettime(CLOCK_REALTIME, &t_start);
  qsort(candidates, 4 * (4 - 1), sizeof(int), compare);
  for (i = 0; i < (4 - 1); i++)
  {
    split_bound[i] = candidates[(int) (4 * (i + 0.5))];
  }

  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Sort candidates and choose splitters:", elapsedTime);
  totalTime += elapsedTime;
  clock_gettime(CLOCK_REALTIME, &t_start);
  int desThread = 0;
  for (i = 0; i < 4; i++)
  {
    for (j = 0; j < 2500000; j++)
    {
      desThread = findDesThread(split_bound, pRawNums[i][j]);
      pDataSorted[desThread][thread_element_count[desThread]] = pRawNums[i][j];
      thread_element_count[desThread]++;
    }

  }

  for (i = 0; i < 4; i++)
    printf("%d ", thread_element_count[i]);

  printf("\n");
  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Seperate data into chunks by values:", elapsedTime);
  totalTime += elapsedTime;
  clock_gettime(CLOCK_REALTIME, &t_start);
  for (i = 1; i < 4; i++)
    s_index[i] = s_index[i - 1] + thread_element_count[i - 1];

  s_index[4] = 4 * 2500000;
  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Calculate start indices:", elapsedTime);
  totalTime += elapsedTime;
  clock_gettime(CLOCK_REALTIME, &t_start);
  #pragma omp parallel for
  for (i = 0; i < 4; i++)
    qsort(pDataSorted[i], thread_element_count[i], sizeof(int), compare);

  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Apply quick sort to each chunk:", elapsedTime);
  totalTime += elapsedTime;
  clock_gettime(CLOCK_REALTIME, &t_start);
  #pragma omp parallel for
  for (i = 0; i < 4; i++)
  {
    for (j = 0; j < thread_element_count[i]; j++)
      pAnswer[s_index[i] + j] = pDataSorted[i][j];

  }

  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("%-40s %lf ms\n", "Merge data:", elapsedTime);
  totalTime += elapsedTime;
  printf("\nParallel sample sort(static) elapsedTime: %lf ms\n", totalTime);
  clock_gettime(CLOCK_REALTIME, &t_start);
  qsort(pCorrect, 4 * 2500000, sizeof(int), compare);
  clock_gettime(CLOCK_REALTIME, &t_end);
  elapsedTime = (t_end.tv_sec - t_start.tv_sec) * 1000.0;
  elapsedTime += (t_end.tv_nsec - t_start.tv_nsec) / 1000000.0;
  printf("Plugin quick sort elapsedTime: %lf ms\n", elapsedTime);
  int tmpcount = 0;
  for (i = 0; i < 4; i++)
  {
    for (j = 0; j < 2500000; j++)
    {
      if (pCorrect[(i * 2500000) + j] != pAnswer[tmpcount])
      {
        printf("Answer is wrong, index is at %d\n", (i * 2500000) + j);
        break;
      }

      tmpcount++;
    }

  }

  for (int i = 0; i < 4; i++)
  {
    free(pRawNums[i]);
    free(pDataSorted[i]);
  }

  free(pRawNums);
  free(pCorrect);
  free(pDataSorted);
  free(pAnswer);
  return 0;
}

