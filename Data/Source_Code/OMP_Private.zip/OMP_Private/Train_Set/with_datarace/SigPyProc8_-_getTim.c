void getTim(unsigned char *inbuffer, float *outbuffer, int nchans, int nsamps, int index)
{
  int ii;
  int jj;
  int val;
  #pragma omp parallel for default(shared)
  for (ii = 0; ii < nsamps; ii++)
  {
    for (jj = 0; jj < nchans; jj++)
    {
      outbuffer[index + ii] += inbuffer[(nchans * ii) + jj];
    }

  }

}

