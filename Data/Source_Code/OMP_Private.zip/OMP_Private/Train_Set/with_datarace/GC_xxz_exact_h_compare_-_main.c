double min_QR_method(double _alpha[], double _beta[], int MAX);
double SSD_function(int l, int i);
int main(void)
{
  int n;
  int n_temp;
  int i;
  int j;
  int k;
  int m;
  int NSYSTEM = (2 * 0.5) + 1;
  int NSTATE = pow(NSYSTEM, 20);
  int NSTATE_2d = pow(NSYSTEM, 20 / 2);
  int nud;
  int ndu;
  int mud;
  int mdu;
  double S1;
  double S2;
  double M;
  double Wud;
  double Wdu;
  long PS1;
  long PS2;
  static long LIST1[700000];
  static int LIST2a[20000];
  static int LIST2b[20000];
  int ia;
  int ib;
  int ja = 0;
  int jb = 0;
  int pib = -1;
  double h;
  double h_var[20];
  double stz[20];
  double SZVAL;
  int dim_subspace;
  static double v0[700000];
  static double v1[700000];
  static double v2[700000];
  static double alpha[300 + 1];
  static double beta[300 + 1];
  double dd = 0.3;
  static double B[700000 + 1] = {0};
  static double R[700000 + 1] = {0};
  static double PP[700000 + 1] = {0};
  static double X[700000 + 1] = {0};
  static double XX[700000 + 1] = {0};
  static double Y[700000 + 1] = {0};
  double alphaj;
  double betaj;
  int II;
  int ii;
  double BNORM;
  double RNORM;
  double RNORM2;
  double XNORM;
  double RP;
  double YP;
  double XB;
  int data_num = (20 / 2) - 2;
  double m0;
  double m_exact;
  FILE *fp;
  fp = fopen("site20xxz_stz_data.txt", "r");
  printf("(h	m_step)\n");
  for (i = 0; i < ((20 / 2) + 1); i++)
  {
    fscanf(fp, "%lf	%lf\n", &h_var[i], &stz[i]);
    printf("%lf	%lf\n", h_var[i], stz[i]);
  }

  fclose(fp);
  double Output_data[200][4] = {0};
  static double H_exact_delta03[101] = {0.45950, 0.45954, 0.45985, 0.46045, 0.46135, 0.46255, 0.46404, 0.46582, 0.46789, 0.47024, 0.47287, 0.47578, 0.47897, 0.48244, 0.48618, 0.49019, 0.49447, 0.49902, 0.50385, 0.50893, 0.51428, 0.51990, 0.52578, 0.53192, 0.53832, 0.54498, 0.55190, 0.55907, 0.56650, 0.57419, 0.58212, 0.59031, 0.59875, 0.60744, 0.61638, 0.62556, 0.63499, 0.64465, 0.65456, 0.66470, 0.67507, 0.68567, 0.69649, 0.70754, 0.71881, 0.73029, 0.74197, 0.75386, 0.76594, 0.77821, 0.79066, 0.80328, 0.81607, 0.82901, 0.84210, 0.85532, 0.86866, 0.88212, 0.89567, 0.90931, 0.92302, 0.93678, 0.95058, 0.96441, 0.97824, 0.99205, 1.0058, 1.0196, 1.0332, 1.0468, 1.0602, 1.0735, 1.0867, 1.0996, 1.1123, 1.1249, 1.1371, 1.1491, 1.1607, 1.1721, 1.1830, 1.1936, 1.2038, 1.2136, 1.2229, 1.2318, 1.2402, 1.2480, 1.2554, 1.2622, 1.2685, 1.2742, 1.2794, 1.2840, 1.2880, 1.2914, 1.2943, 1.2966, 1.2983, 1.2994, 1.2999};
  static double m_exact_delta03[101] = {0.0000, 0.00060400, 0.0018220, 0.0030540, 0.0043030, 0.0055680, 0.0068520, 0.0081540, 0.0094760, 0.010820, 0.012187, 0.013577, 0.014992, 0.016434, 0.017902, 0.019400, 0.020928, 0.022487, 0.024080, 0.025707, 0.027369, 0.029069, 0.030808, 0.032587, 0.034408, 0.036273, 0.038184, 0.040141, 0.042147, 0.044204, 0.046314, 0.048478, 0.050699, 0.052978, 0.055317, 0.057719, 0.060186, 0.062720, 0.065323, 0.067998, 0.070746, 0.073571, 0.076475, 0.079461, 0.082530, 0.085686, 0.088932, 0.092270, 0.095703, 0.099234, 0.10287, 0.10660, 0.11045, 0.11440, 0.11847, 0.12266, 0.12696, 0.13139, 0.13595, 0.14064, 0.14546, 0.15042, 0.15552, 0.16078, 0.16617, 0.17173, 0.17744, 0.18331, 0.18935, 0.19555, 0.20193, 0.20849, 0.21522, 0.22215, 0.22926, 0.23657, 0.24407, 0.25178, 0.25969, 0.26781, 0.27615, 0.28470, 0.29347, 0.30247, 0.31170, 0.32116, 0.33085, 0.34078, 0.35096, 0.36139, 0.37206, 0.38298, 0.39417, 0.40561, 0.41731, 0.42928, 0.44152, 0.45403, 0.46682, 0.47988, 0.49322};
  printf(" SPIN=%.1f NSITE=%d dd=%lf\n", 0.5, 20, dd);
  printf("-------------------------------------------------------\n");
  int i_h;
  for (i_h = 0; i_h < 101; i_h++)
  {
    h = H_exact_delta03[i_h];
    m_exact = m_exact_delta03[i_h];
    for (i = 1; i < ((20 / 2) + 1); i++)
    {
      if (h_var[i] > h)
      {
        SZVAL = stz[i - 1] * 20;
        break;
      }

    }

    if (fabs(SZVAL - (20 * 0.5)) < 0.00001)
    {
      break;
    }

    m = 0;
    ja = 0, jb = 0, pib = -1;
    for (n = 0; n < NSTATE; n++)
    {
      M = 0;
      n_temp = n;
      for (i = 0; i < 20; i++)
      {
        M += (n_temp % NSYSTEM) - 0.5;
        n_temp /= NSYSTEM;
      }

      if (fabs(M - SZVAL) < 0.01)
      {
        m++;
        ia = n % NSTATE_2d;
        ib = n / NSTATE_2d;
        if (ib == pib)
        {
          ja++;
        }
        else
        {
          jb = jb + ja;
          ja = 1;
          pib = ib;
          LIST2b[ib] = jb;
        }

        LIST2a[ia] = ja;
        LIST1[m] = n;
      }

    }

    dim_subspace = m;
    for (m = 1; m <= dim_subspace; m++)
    {
      v0[m] = 0;
      v1[m] = 0;
      v2[m] = 0;
    }

    v1[4] = 1;
    #pragma omp parallel for
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      for (i = 1; i <= 20; i++)
      {
        PS1 = pow(NSYSTEM, i - 1);
        PS2 = pow(NSYSTEM, i);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
        Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1.0))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1.0));
        Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1.0))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1.0));
        if (Wud < 0.0000001)
        {
          nud = n_temp;
        }
        else
        {
          nud = (n_temp + PS1) - PS2;
        }

        if (Wdu < 0.0000001)
        {
          ndu = n_temp;
        }
        else
        {
          ndu = (n_temp - PS1) + PS2;
        }

        ia = nud % NSTATE_2d;
        ib = nud / NSTATE_2d;
        mud = LIST2a[ia] + LIST2b[ib];
        ia = ndu % NSTATE_2d;
        ib = ndu / NSTATE_2d;
        mdu = LIST2a[ia] + LIST2b[ib];
        v0[m] += ((S1 * S2) * SSD_function(1, i)) * v1[m];
        v0[m] += ((dd * SSD_function(1, i)) * Wud) * v1[mud];
        v0[m] += ((dd * SSD_function(1, i)) * Wdu) * v1[mdu];
        v0[m] += (((-h) * SSD_function(0, i)) * S1) * v1[m];
      }

    }

    alpha[1] = 0;
    for (k = 1; k <= dim_subspace; k++)
    {
      alpha[1] += v1[k] * v0[k];
    }

    double sum = 0;
    for (k = 1; k <= dim_subspace; k++)
    {
      v2[k] = v0[k] - (alpha[1] * v1[k]);
      sum += v2[k] * v2[k];
    }

    beta[1] = sqrt(sum);
    for (k = 1; k <= dim_subspace; k++)
    {
      v2[k] = v2[k] / beta[1];
    }

    int I;
    double E0 = 0;
    double Emin = 0;
    double E_before = 0;
    for (I = 2; I <= 300; I++)
    {
      for (m = 1; m <= dim_subspace; m++)
      {
        v0[m] = 0;
      }

      #pragma omp parallel for
      for (m = 1; m <= dim_subspace; m++)
      {
        n_temp = LIST1[m];
        for (i = 1; i <= 20; i++)
        {
          PS1 = pow(NSYSTEM, i - 1);
          PS2 = pow(NSYSTEM, i);
          S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
          S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
          Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
          Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
          if (Wud < 0.0000001)
          {
            nud = n_temp;
          }
          else
          {
            nud = (n_temp + PS1) - PS2;
          }

          if (Wdu < 0.0000001)
          {
            ndu = n_temp;
          }
          else
          {
            ndu = (n_temp - PS1) + PS2;
          }

          ia = nud % NSTATE_2d;
          ib = nud / NSTATE_2d;
          mud = LIST2a[ia] + LIST2b[ib];
          ia = ndu % NSTATE_2d;
          ib = ndu / NSTATE_2d;
          mdu = LIST2a[ia] + LIST2b[ib];
          v0[m] += ((S1 * S2) * SSD_function(1, i)) * v2[m];
          v0[m] += ((dd * SSD_function(1, i)) * Wud) * v2[mud];
          v0[m] += ((dd * SSD_function(1, i)) * Wdu) * v2[mdu];
          v0[m] += (((-h) * SSD_function(0, i)) * S1) * v2[m];
        }

      }

      alpha[I] = 0;
      for (k = 1; k <= dim_subspace; k++)
      {
        alpha[I] += v2[k] * v0[k];
      }

      for (k = 1; k <= dim_subspace; k++)
      {
        v0[k] = (v0[k] - (alpha[I] * v2[k])) - (beta[I - 1] * v1[k]);
        v1[k] = v2[k];
      }

      beta[I] = 0;
      sum = 0;
      for (k = 1; k <= dim_subspace; k++)
      {
        sum += v0[k] * v0[k];
      }

      beta[I] = sqrt(sum);
      for (k = 1; k <= dim_subspace; k++)
      {
        v2[k] = v0[k] / beta[I];
      }

      if (((I % 4) == 0) && (5 < I))
      {
        Emin = min_QR_method(alpha, beta, I);
        if ((fabs(Emin - E_before) < 0.00001) || (I == 300))
        {
          E0 = Emin;
          break;
        }

        E_before = Emin;
      }

    }

    for (m = 1; m <= dim_subspace; m++)
    {
      B[m] = 0;
      R[m] = 0;
      PP[m] = 0;
      X[m] = 0;
      XX[m] = 0;
      Y[m] = 0;
    }

    B[4] = 1.0;
    for (II = 1; II <= 300; II++)
    {
      BNORM = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        BNORM += B[m] * B[m];
        R[m] = B[m];
        PP[m] = B[m];
        X[m] = 0.0;
      }

      for (ii = 1; ii <= 50; ii++)
      {
        for (m = 1; m <= dim_subspace; m++)
        {
          Y[m] = (-PP[m]) * E0;
        }

        #pragma omp parallel for
        for (m = 1; m <= dim_subspace; m++)
        {
          n_temp = LIST1[m];
          for (i = 1; i <= 20; i++)
          {
            PS1 = pow(NSYSTEM, i - 1);
            PS2 = pow(NSYSTEM, i);
            S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
            S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
            Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
            Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
            if (Wud < 0.0000001)
            {
              nud = n_temp;
            }
            else
            {
              nud = (n_temp + PS1) - PS2;
            }

            if (Wdu < 0.0000001)
            {
              ndu = n_temp;
            }
            else
            {
              ndu = (n_temp - PS1) + PS2;
            }

            ia = nud % NSTATE_2d;
            ib = nud / NSTATE_2d;
            mud = LIST2a[ia] + LIST2b[ib];
            ia = ndu % NSTATE_2d;
            ib = ndu / NSTATE_2d;
            mdu = LIST2a[ia] + LIST2b[ib];
            Y[m] += ((S1 * S2) * SSD_function(1, i)) * PP[m];
            Y[m] += ((dd * SSD_function(1, i)) * Wud) * PP[mud];
            Y[m] += ((dd * SSD_function(1, i)) * Wdu) * PP[mdu];
            Y[m] += (((-h) * SSD_function(0, i)) * S1) * PP[m];
          }

        }

        RP = 0.0;
        YP = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          RP += PP[m] * R[m];
          YP += PP[m] * Y[m];
        }

        alphaj = RP / YP;
        RNORM = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          X[m] += alphaj * PP[m];
          RNORM += R[m] * R[m];
        }

        RNORM2 = 0.0;
        for (m = 1; m <= dim_subspace; m++)
        {
          R[m] += (-alphaj) * Y[m];
          RNORM2 += R[m] * R[m];
        }

        betaj = RNORM2 / RNORM;
        for (m = 1; m <= dim_subspace; m++)
        {
          PP[m] = R[m] + (betaj * PP[m]);
        }

        if ((sqrt(RNORM2) / sqrt(BNORM)) < 0.00001)
        {
          break;
        }

      }

      XNORM = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        XNORM += X[m] * X[m];
      }

      XNORM = sqrt(XNORM);
      XB = 0.0;
      for (m = 1; m <= dim_subspace; m++)
      {
        X[m] /= XNORM;
        XB += X[m] * B[m];
      }

      if (fabs(fabs(XB) - 1.0) < 0.00001)
      {
        for (m = 1; m <= dim_subspace; m++)
        {
          XX[m] = X[m];
        }

        break;
      }

      for (m = 1; m <= dim_subspace; m++)
      {
        B[m] = X[m];
      }

    }

    Wud = 0;
    for (m = 1; m <= dim_subspace; m++)
    {
      Wud += XX[m] * XX[m];
    }

    Wud = sqrt(Wud);
    for (m = 1; m <= dim_subspace; m++)
    {
      XX[m] /= Wud;
    }

    double output_E = 0.0;
    for (m = 1; m <= dim_subspace; m++)
    {
      PP[m] = 0;
    }

    #pragma omp paralell for reduction(+:output_E)
    for (m = 1; m <= dim_subspace; m++)
    {
      n_temp = LIST1[m];
      for (i = 1; i < 20; i++)
      {
        PS1 = pow(NSYSTEM, i - 1);
        PS2 = pow(NSYSTEM, i);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        S2 = ((n_temp / PS2) % NSYSTEM) - 0.5;
        Wud = (0.5 * sqrt((0.5 - S1) * ((0.5 + S1) + 1))) * sqrt((0.5 + S2) * ((0.5 - S2) + 1));
        Wdu = (0.5 * sqrt((0.5 + S1) * ((0.5 - S1) + 1))) * sqrt((0.5 - S2) * ((0.5 + S2) + 1));
        if (Wud < 0.0000001)
        {
          nud = n_temp;
        }
        else
        {
          nud = (n_temp + PS1) - PS2;
        }

        if (Wdu < 0.0000001)
        {
          ndu = n_temp;
        }
        else
        {
          ndu = (n_temp - PS1) + PS2;
        }

        ia = nud % NSTATE_2d;
        ib = nud / NSTATE_2d;
        mud = LIST2a[ia] + LIST2b[ib];
        ia = ndu % NSTATE_2d;
        ib = ndu / NSTATE_2d;
        mdu = LIST2a[ia] + LIST2b[ib];
        PP[m] += ((S1 * S2) * SSD_function(1, i)) * XX[m];
        PP[m] += ((dd * SSD_function(1, i)) * Wud) * XX[mud];
        PP[m] += ((dd * SSD_function(1, i)) * Wdu) * XX[mdu];
        PP[m] += (((-h) * SSD_function(0, i)) * S1) * XX[m];
      }

      PP[m] += (((-h) * SSD_function(0, 20)) * S2) * XX[m];
      output_E += PP[m] * XX[m];
    }

    printf("SPIN=%.1f NSITE=%d dim_subspace=%d(SZ=%4.2f) H=%.2lf(i_h=%d) dd=%.1lf\n", 0.5, 20, dim_subspace, SZVAL, h, i_h, dd);
    printf("E0_Lanczos = %lf\n", E0);
    printf("E0_exp = %lf\n", output_E);
    if (fabs(E0 - output_E) > 0.01)
    {
      printf("E0_Lanczos error! \n");
      printf("E0_exp-E0_Lanczos = %lf \n", E0 - output_E);
      exit(1);
    }

    double Siz_exp[20 + 1] = {0};
    printf("Siz_exp\n");
    for (i = 1; i <= 20; i++)
    {
      for (m = 1; m <= dim_subspace; m++)
      {
        n_temp = LIST1[m];
        PS1 = pow(NSYSTEM, i - 1);
        S1 = ((n_temp / PS1) % NSYSTEM) - 0.5;
        Siz_exp[i] += (S1 * XX[m]) * XX[m];
      }

      printf("%d %lf\n", i, Siz_exp[i]);
    }

    double Or[20 + 1];
    int r;
    for (r = 1; r < (20 / 2); r++)
    {
      Or[r] = 0;
      for (i = -r; i < r; i++)
      {
        Or[r] += Siz_exp[(i + (20 / 2)) + (20 % 2)];
      }

      Or[r] /= 2 * r;
    }

    for (i = 2; i <= data_num; i++)
    {
      double sum_x4 = 0;
      double sum_x2 = 0;
      double sum_xxy = 0;
      double sum_y = 0;
      for (r = 1; r <= i; r++)
      {
        sum_x4 += pow(r, 4);
        sum_x2 += pow(r, 2);
        sum_xxy += (r * r) * Or[r];
        sum_y += Or[r];
      }

      m0 = ((sum_x2 * sum_xxy) - (sum_x4 * sum_y)) / ((sum_x2 * sum_x2) - (i * sum_x4));
      if (isnan(m0))
      {
        printf("m0 is nan\n");
        exit(1);
      }

      printf("r = %d,m0 = %lf\n", i, m0);
    }

    printf("h = %lf, m0 = %lf, m_exact = %lf, error = %lf\n", h, m0, m_exact, m0 - m_exact);
    Output_data[i_h][0] = h;
    Output_data[i_h][1] = m0;
    Output_data[i_h][2] = m_exact;
    Output_data[i_h][3] = m0 - m_exact;
  }

  printf("magnetization data\n");
  printf("(h	m	m_exact	m0-m_exact)\n");
  for (i_h = 0; i_h < 101; i_h++)
  {
    printf("%lf	%lf	%lf	%lf\n", Output_data[i_h][0], Output_data[i_h][1], Output_data[i_h][2], Output_data[i_h][3]);
  }

  return 0;
}

