void NLmean(double *x_NLM, double *weight_NLM, double *x_ref, double *x_moving, double *x_fusion, int *gridy, int *gridz, int *accids)
{
  int i = 0;
  int j = 0;
  int k = 0;
  omp_set_num_threads(threadCount);
  #pragma omp parallel default(none) private(i,j,k) shared(A,B,C,N)
  {
    #pragma omp for schedule(static) nowait
    for (i = 0; i < N; i++)
    {
      for (j = 0; j < N; j++)
      {
        for (k = 0; k < N; k++)
        {
          C[i][j] = C[i][j] + (A[i][k] * B[k][j]);
        }

      }

    }

  }
  return;

  double norm_fact = 1.0 / ((double) (((2 * 12) + 1) * ((2 * 12) + 1)));
  int ri = (5 * ((2 * 5) + 1)) + 5;
  int est_idy;
  #pragma omp parallel for
  for (est_idy = 0; est_idy < 96; est_idy++)
    for (int est_idz = 0; est_idz < 96; est_idz++)
    for (int ni = 0; ni < (((2 * 5) + 1) * ((2 * 5) + 1)); ni++)
  {
    int ref_idy;
    int ref_idz;
    int moving_idy;
    int moving_idz;
    double du;
    double d = 0.0;
    long int grid_rid;
    long int grid_nid;
    for (int si = 0; si < (((2 * 12) + 1) * ((2 * 12) + 1)); si++)
    {
      grid_rid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ri * ((2 * 12) + 1)) * ((2 * 12) + 1))) + si;
      grid_nid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ni * ((2 * 12) + 1)) * ((2 * 12) + 1))) + si;
      ref_idy = gridy[grid_rid];
      moving_idy = gridy[grid_nid];
      ref_idz = gridz[grid_rid];
      moving_idz = gridz[grid_nid];
      du = x_ref[(ref_idy * 96) + ref_idz] - x_moving[(moving_idy * 96) + moving_idz];
      d = d + ((norm_fact * du) * du);
    }

    double w = exp((-d) / ((2.0 * 0.1) * 0.1));
    for (int k = 0; k < (((2 * 12) + 1) * ((2 * 12) + 1)); k++)
    {
      int ai = accids[k];
      grid_rid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ri * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ai;
      grid_nid = (((((((est_idy * 96) * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1)) + ((((est_idz * ((2 * 5) + 1)) * ((2 * 5) + 1)) * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ((ni * ((2 * 12) + 1)) * ((2 * 12) + 1))) + ai;
      ref_idy = gridy[grid_rid];
      moving_idy = gridy[grid_nid];
      ref_idz = gridz[grid_rid];
      moving_idz = gridz[grid_nid];
      x_NLM[(ref_idy * 96) + ref_idz] = x_NLM[(ref_idy * 96) + ref_idz] + (w * x_fusion[(moving_idy * 96) + moving_idz]);
      weight_NLM[(ref_idy * 96) + ref_idz] = weight_NLM[(ref_idy * 96) + ref_idz] + w;
    }

  }



}

