int main()
{
  double *a;
  double *nz;
  double *nzc;
  int *ia;
  int *ja;
  int *ic;
  int *jc;
  int *pos;
  int info = 1;
  int i;
  int j;
  int k;
  double avg_time = 0;
  double s_time;
  double e_time;
  FILE *fp1;
  int m = 4;
  int iterations;
  for (iterations = 0; iterations < 10; iterations++)
  {
    m *= 2;
    int n = m;
    nz = calloc(m * n, sizeof(double));
    ia = calloc(m * n, sizeof(int));
    ja = calloc(m * n, sizeof(int));
    nzc = calloc(m * n, sizeof(double));
    ic = calloc(m * n, sizeof(int));
    jc = calloc(m * n, sizeof(int));
    char trans = 'N';
    int request = 1;
    int sort = 8;
    int nzmax = 0;
    k = 0;
    double dense_const = 0.03;
    int temp5;
    int temp6;
    int temp3;
    int temp4;
    int density = (m * n) * dense_const;
    pos = calloc(m * n, sizeof(int));
    int temp;
    int temp1;
    printf("the density is %d\n", density);
    for (i = 0; i < density; i++)
    {
      temp1 = rand() % (m * n);
      pos[i] = temp1;
    }

    for (i = 0; i < density; i++)
    {
      int d = i;
      int t;
      while ((d > 0) && (pos[d] < pos[d - 1]))
      {
        t = pos[d];
        pos[d] = pos[d - 1];
        pos[d - 1] = t;
        d--;
      }

    }

    j = 1;
    ja[0] = 1;
    int p = 0;
    for (i = 0; i < density; i++)
    {
      temp = pos[i];
      nz[k] = rand();
      ia[k] = temp % m;
      k++;
      p++;
      temp5 = pos[i];
      temp6 = pos[i + 1];
      temp3 = temp5 - (temp5 % m);
      temp4 = temp6 - (temp6 % m);
      if (!(temp3 == temp4))
      {
        if ((temp3 + m) == temp6)
        {
        }
        else
        {
          ja[j] = p + 1;
          j++;
        }

      }

    }

    s_time = timerval();
    #pragma omp parallel shared(m,n,ia,ja,jc,ic,nz,nzc,nzmax,info,request,sort,trans)
    {
      #pragma omp for
      for (i = 0; i < 1000; i++)
      {
        mkl_dcsrmultcsr(&trans, &request, &sort, &m, &n, &n, nz, ia, ja, nz, ia, ja, nzc, jc, ic, &nzmax, &info);
      }

    }
    e_time = timerval();
    avg_time = e_time - s_time;
    avg_time = avg_time / 1000;
    if ((fp1 = fopen("output.txt", "w+")) == 0)
    {
      printf("error opening file\n");
    }

    lseek(fp1, 0, 2);
    fprintf(fp1, "/n Input size: %d x %d ,Time: %lf\n", m, n, avg_time);
    fclose(fp1);
    free(ja);
    free(ia);
    free(nz);
    free(jc);
    free(ic);
    free(nzc);
  }

  return 0;
}

