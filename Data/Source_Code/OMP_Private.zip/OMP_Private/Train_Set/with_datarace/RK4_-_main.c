int main(int argc, char *argv[])
{
  int i;
  int j;
  #pragma omp parallel for shared(a,m,n,b,c) private(i,j) default(none)
  for (i = 0; i < m; ++i)
  {
    for (j = 0; j < n; j++)
      a[i] += b[(i * n) + j] * c[j];

  }


  int N = 4;
  double x0 = 0;
  double z0 = 0;
  double v0 = 40;
  double alpha = M_PI / 4;
  double gamma = 0.7;
  double g = 9.8;
  double t0 = 0;
  double t1 = 100;
  double h = 1e-4;
  double y[N];
  int Ngamma = 1e2;
  double alpha_gamma[Ngamma];
  double hgamma = 5.0 / Ngamma;
  int Nalpha = 1e3;
  double halpha = (M_PI / 2.0) / Nalpha;
  char filename[128];
  sprintf(filename, "Trajectory.log");
  FILE *pFile;
  pFile = fopen("alpha_gamma.txt", "w");
  for (int j = 0; j < Ngamma; j++)
  {
    double xrange = 0;
    double alphamax = 0;
    gamma = j * hgamma;
    alpha_gamma[j] = alphamax;
    #pragma omp parallel for shared(xrange, alphamax)
    for (int k = 0; k < Nalpha; k++)
    {
      alpha = k * halpha;
      double vx = v0 * cos(alpha);
      double vz = v0 * sin(alpha);
      y[0] = x0;
      y[1] = z0;
      y[2] = vx;
      y[3] = vz;
      RK4(N, t0, t1, h, y, gamma, g, filename);
      if ((y[0] - x0) > xrange)
      {
        xrange = y[0] - x0;
        alphamax = alpha;
      }

    }

    alpha_gamma[j] = alphamax;
    printf("%f\t%f\n", gamma, alphamax);
  }

  for (int j = 0; j < Ngamma; j++)
  {
    gamma = j * hgamma;
    fprintf(pFile, "%f\t%f\n", gamma, alpha_gamma[j]);
  }

  fclose(pFile);
  return 0;
}

