int timeval_subtract(struct timeval *, struct timeval *, struct timeval *);
int main()
{
  int i;
  int j;
  int k;
  double *a;
  double *b;
  double *c;
  int size;
  int count;
  int l;
  double sum = 0.0;
  double flops = 0.0;
  double start;
  double end;
  size = 512 * 512;
  a = (double *) calloc(size, sizeof(double));
  b = (double *) calloc(size, sizeof(double));
  c = (double *) calloc(size, sizeof(double));
  printf("OK\n");
  start = omp_get_wtime();
  #pragma omp parallel for
  for (k = 0; k < size; k++)
  {
    i = k / 512;
    j = k % 512;
    a[k] = ((double) (i + 1)) / ((double) (j + 1));
    b[k] = ((double) (j + 1)) / ((double) (i + 1));
  }

  #pragma omp parallel for
  for (k = 0; k < size; k++)
  {
    i = k / 512;
    j = k % 512;
    for (l = 0; l < 512; l++)
    {
      c[k] += a[(512 * i) + l] * b[(512 * j) + l];
    }

  }

  #pragma omp parallel for reduction(+:sum)
  for (k = 0; k < size; k++)
    sum += c[k];

  end = omp_get_wtime();
  printf("Elapsed time : %lf ms. sum : %lf\n", end - start, sum);
  return 0;
}

