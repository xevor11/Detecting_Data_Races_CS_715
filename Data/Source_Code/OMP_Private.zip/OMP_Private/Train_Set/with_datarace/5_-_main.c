int main(int argc, char **argv)
{
  srand(time(0));
  int matrix1[2][2];
  int matrix2[2][2];
  int outmatrix[2][2];
  fillMatrix(&matrix1);
  fillMatrix(&matrix2);
  printf("Matrix 1\n");
  printMatrix(&matrix1);
  printf("Matrix 2\n");
  printMatrix(&matrix2);
  double row;
  double x;
  int i;
  int j;
  #pragma omp parallel for
  for (i = 0; i < 2; i++)
  {
    for (j = 0; j < 2; j++)
    {
    }

    #pragma omp atomic
  }

  printf("Output\n");
  printMatrix(&outmatrix2);
  return 0;
}

