void multiplica6(int m, int n, int **matA, int **matB, int **matC, int nucleos)
{
  int i;
  int j;
  int k;
  int som;
  #pragma omp parallel for num_threads(nucleos)
  for (k = 0; k < m; k += 4)
  {
    for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
      {
        matC[i][j] += matA[i][k] * matB[k][j];
        matC[i][j] += matA[i][k + 1] * matB[k + 1][j];
        matC[i][j] += matA[i][k + 2] * matB[k + 2][j];
        matC[i][j] += matA[i][k + 3] * matB[k + 3][j];
      }

    }

  }

}

