int main(int argc, char **argv)
{
  int i;
  double cgt1;
  double cgt2;
  double ncgt;
  if (argc < 2)
  {
    printf("Faltan nº componentes del vector\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  double *v1;
  double *v2;
  double *v3;
  v1 = (double *) malloc(N * (sizeof(double)));
  v2 = (double *) malloc(N * (sizeof(double)));
  v3 = (double *) malloc(N * (sizeof(double)));
  if (((v1 == 0) || (v1 == 0)) || (v1 == 0))
  {
    printf("Error en la reserva del espacio para los vecores\n");
    exit(-2);
  }

  int num_it = N / 4;
  #pragma omp parallel
  {
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < num_it; i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = num_it; i < (num_it * 2); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = num_it * 2; i < (num_it * 3); i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

      #pragma omp section
      for (i = num_it * 3; i < N; i++)
      {
        v1[i] = (N * 0.1) + (i * 0.1);
        v2[i] = (N * 0.1) - (i * 0.1);
      }

    }
    #pragma omp single
    {
      cgt1 = omp_get_wtime();
    }
    #pragma omp sections
    {
      #pragma omp section
      for (i = 0; i < num_it; i++)
      {
        v3[i] = v1[i] + v2[i];
      }

      #pragma omp section
      for (i = num_it; i < (num_it * 2); i++)
      {
        v3[i] = v1[i] + v2[i];
      }

      #pragma omp section
      for (i = num_it * 2; i < (num_it * 3); i++)
      {
        v3[i] = v1[i] + v2[i];
      }

      #pragma omp section
      for (i = num_it * 3; i < N; i++)
      {
        v3[i] = v1[i] + v2[i];
      }

    }
    #pragma omp single
    {
      cgt2 = omp_get_wtime();
    }
  }
  ncgt = cgt2 - cgt1;
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\t/ V1[0]+V2[0]=V3[0](%8.6f+%8.6f=%8.6f) / / V1[%d]+V2[%d]=V3[%d](%8.6f+%8.6f=%8.6f) /\n", ncgt, N, v1[0], v2[0], v3[0], N - 1, N - 1, N - 1, v1[N - 1], v2[N - 1], v3[N - 1]);
  free(v1);
  free(v2);
  free(v3);
  return 0;
}

