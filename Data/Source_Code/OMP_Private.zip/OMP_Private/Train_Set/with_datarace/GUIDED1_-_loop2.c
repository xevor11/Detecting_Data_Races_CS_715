double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void loop2(void)
{
  int i;
  int j;
  int k;
  double rN2;
  rN2 = 1.0 / ((double) (729 * 729));
  #pragma omp parallel for default(none) shared(a,b,c,jmax,rN2) schedule(guided, 1)
  for (i = 0; i < 729; i++)
  {
    for (j = 0; j < jmax[i]; j++)
    {
      for (k = 0; k < j; k++)
      {
        c[i] += ((k + 1) * log(b[i][j])) * rN2;
      }

    }

  }

}

