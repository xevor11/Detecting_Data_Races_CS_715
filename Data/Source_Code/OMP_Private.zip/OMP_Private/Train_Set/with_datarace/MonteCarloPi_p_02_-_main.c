int main(int argc, char **argv)
{
  int num_procs;
  int max_threads;
  int thread_id;
  int N = pow(2, 30);
  int dart_chunk;
  int dart_llimit;
  int dart_ulimit;
  int n_circle = 0;
  int i;
  double pi = 3.141592653589793;
  double pi_computed = 0.00;
  double pi_error = 0.00;
  double R = 2.00;
  double x;
  double y;
  double z;
  double wall_time = 0.00;
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  dart_chunk = N / max_threads;
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  if (thread_id == 0)
  {
    printf("\n");
    printf("  OpenMP C program to evaluate PI using Monte Carlo method\n");
    printf("  (Dart Board algorithm).\n\n");
    printf("  Total number of processors available : %d\n", num_procs);
    printf("  Maximum number of usable threads     : %d\n", max_threads);
    printf("  Total number of darts thrown         : %d\n", N);
    printf("  Number of darts per usable thread    : %d\n", dart_chunk);
  }

  #pragma omp parallel shared(R, dart_chunk, n_circle)
  {
    thread_id = omp_get_thread_num();
    dart_llimit = thread_id * dart_chunk;
    dart_ulimit = (dart_llimit + dart_chunk) - 1;
    struct timeval t1;
    gettimeofday(&t1, 0);
    srand((t1.tv_usec * t1.tv_sec) * (thread_id + 1));
    for (i = dart_llimit; i <= dart_ulimit; i++)
    {
      x = random_number_generator(-R, R);
      y = random_number_generator(-R, R);
      z = sqrt((x * x) + (y * y));
      if (z <= R)
      {
        n_circle++;
      }

    }

  }
  if (thread_id == 0)
  {
    pi_computed = (4.0 * ((double) n_circle)) / ((double) N);
    pi_error = fabs(pi - pi_computed);
  }

  wall_time = omp_get_wtime() - wall_time;
  if (thread_id == 0)
  {
    printf("  Total number of darts in the circle  : %d\n", n_circle);
    printf("  Known value of PI                    : %16.15f\n", pi);
    printf("  Computed value of PI                 : %16.15f\n", pi_computed);
    printf("  Error in the computed value of PI    : %16.15f\n", pi_error);
    printf("  Total time taken                     : %f seconds\n\n", wall_time);
  }

  return 0;

  int i;
  int a;
  int *x = (int *) malloc(size * (sizeof(int)));
  int *y = (int *) malloc(size * (sizeof(int)));
  if ((x == 0) || (y == 0))
  {
    printf("Out Of Memory: could not allocate space for the two arrays.\n");
    return 0;
  }

  a = KISS;
  #pragma omp parallel for schedule(static)
  for (i = 0; i < size; i++)
  {
    x[i] = KISS;
    y[i] = KISS;
  }

  struct timespec start;
  struct timespec end;
  clock_gettime(CLOCK, &start);
  #pragma omp parallel for schedule(static) default(none) shared(size, a, x, y) private(i)
  for (i = 0; i < size; i++)
  {
    y[i] = (a * x[i]) + y[i];
  }

  clock_gettime(CLOCK, &end);
  elapsed_time_hr(start, end, "Int AXPY.");
  printf("APXY result = %d\n", y[0]);
  free(x);
  free(y);
  return 0;
}

