int main(int argc, char *argv[])
{
  if (argc < 2)
  {
    printf("Uso: %s <imagen_a_procesar>\n", argv[0]);
    return 0;
  }

  char *image_filename = argv[1];
  int rows = -1;
  int columns = -1;
  int *matrixData = 0;
  int *matrixResult = 0;
  int *matrixResultCopy = 0;
  int numBlocks = -1;
  FILE *f = cp_abrir_fichero(image_filename);
  if (f == 0)
  {
    perror("Error al abrir fichero.txt");
    return -1;
  }

  int i;
  int j;
  int valor;
  fscanf(f, "%d\n", &rows);
  fscanf(f, "%d\n", &columns);
  rows = rows + 2;
  columns = columns + 2;
  matrixData = (int *) malloc((rows * columns) * (sizeof(int)));
  if (matrixData == 0)
  {
    perror("Error reservando memoria");
    return -1;
  }

  for (i = 0; i < rows; i++)
  {
    for (j = 0; j < columns; j++)
    {
      matrixData[(i * columns) + j] = -1;
    }

  }

  for (i = 1; i < (rows - 1); i++)
  {
    matrixData[(i * columns) + 0] = 0;
    matrixData[((i * columns) + columns) - 1] = 0;
  }

  for (i = 1; i < (columns - 1); i++)
  {
    matrixData[(0 * columns) + i] = 0;
    matrixData[((columns - 1) * columns) + i] = 0;
  }

  for (i = 1; i < (rows - 1); i++)
  {
    for (j = 1; j < (columns - 1); j++)
    {
      fscanf(f, "%d\n", &matrixData[(i * columns) + j]);
    }

  }

  fclose(f);
  double t_ini = cp_Wtime();
  matrixResult = (int *) malloc((rows * columns) * (sizeof(int)));
  matrixResultCopy = (int *) malloc((rows * columns) * (sizeof(int)));
  if ((matrixResult == 0) || (matrixResultCopy == 0))
  {
    perror("Error reservando memoria");
    return -1;
  }

  #pragma omp parallel for shared(matrixResult, matrixData)
  for (i = 0; i < rows; i++)
  {
    for (j = 0; j < columns; j++)
    {
      matrixResult[(i * columns) + j] = -1;
      if (matrixData[(i * columns) + j] != 0)
      {
        matrixResult[(i * columns) + j] = (i * columns) + j;
      }

    }

  }

  int t = 0;
  int flagCambio = 1;
  for (t = 0; flagCambio != 0; t++)
  {
    flagCambio = 0;
    #pragma omp parallel for shared (matrixResult, matrixResultCopy)
    for (i = 1; i < (rows - 1); i++)
    {
      for (j = 1; j < (columns - 1); j++)
      {
        matrixResultCopy[(i * columns) + j] = matrixResult[(i * columns) + j];
      }

    }

    #pragma omp parallel for shared (matrixData, matrixResult ) reduction(+:flagCambio)
    for (i = 1; i < (rows - 1); i++)
    {
      for (j = 1; j < (columns - 1); j++)
      {
        flagCambio = flagCambio + computation(i, j, columns, matrixData, matrixResult);
      }

    }

  }

  numBlocks = 0;
  #pragma omp parallel for shared(matrixResult) reduction(+:numBlocks)
  for (i = 1; i < (rows - 1); i++)
  {
    for (j = 1; j < (columns - 1); j++)
    {
      if (matrixResult[(i * columns) + j] == ((i * columns) + j))
        numBlocks++;

    }

  }

  double t_fin = cp_Wtime();
  double t_total = (double) (t_fin - t_ini);
  printf("Result: %d\n", numBlocks);
  printf("Time: %lf\n", t_total);
  free(matrixData);
  free(matrixResult);
  free(matrixResultCopy);
}

