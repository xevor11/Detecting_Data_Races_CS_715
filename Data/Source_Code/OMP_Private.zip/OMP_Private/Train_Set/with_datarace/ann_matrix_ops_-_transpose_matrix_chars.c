int transpose_matrix_chars(char **src_matrix, int rows, int cols, char **dest_matrix)
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  buff = (int *) malloc((sizeof(int)) * (100 * thds));
  if (buff == 0)
  {
    printf("can not allocate memory.\n");
  }

  omp_set_dynamic(0);
  #pragma omp parallel private(prvt)
  {
    int i;
    for (prvt = 1; prvt <= 10; prvt++)
    {
      #pragma omp for schedule(static, prvt)
      for (i = 0; i < (100 * thds); i++)
      {
        buff[i] = omp_get_thread_num();
      }

      check(prvt);
      #pragma omp barrier
    }

  }
  if (errors == 0)
  {
    printf("private 026 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("private 026 : FAILED\n");
    return 1;
  }


  int i;
  int j;
  if ((src_matrix == 0) || (dest_matrix == 0))
  {
    return -1;
  }

  #pragma omp parallel shared(dest_matrix, src_matrix, rows, cols)
  {
    #pragma omp for schedule(static)
    for (i = 0; i < rows; i++)
    {
      for (j = 0; j < cols; j++)
      {
        dest_matrix[j][i] = src_matrix[i][j];
      }

    }

  }
  return 0;
}

