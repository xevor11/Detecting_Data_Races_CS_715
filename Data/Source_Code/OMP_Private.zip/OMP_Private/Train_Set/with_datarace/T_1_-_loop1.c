double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
double valid1(void);
double valid2(void);
void loop1(void)
{
  double *product = (double *) calloc(n * n, sizeof(double));
  register int i;
  register int j;
  register unsigned int k;
  register unsigned int ii;
  register unsigned int jj;
  register unsigned int BLSR;
  register unsigned int BLSC;
  BLSR = 4;
  BLSC = 2;
  if (n < 100)
  {
    BLSR = 1;
    BLSC = 1;
  }

  #pragma omp parallel for schedule(static) private(i, j)
  for (i = 0; i < n; i += BLSR)
    for (j = 0; j < n; j += BLSC)
    for (k = 0; k < n; k++)
    for (ii = i; ii < (i + BLSR); ii++)
    for (jj = j; jj < (j + BLSC); jj++)
    product[ii + (jj * n)] += mtx1[ii + (k * n)] * mtx2[k + (jj * n)];





  return product;

  int i;
  int j;
  #pragma omp parallel for num_threads(N_Threads) schedule(dynamic,16) default(none) shared(a,b)
  for (i = 0; i < 729; i++)
  {
    for (j = 729 - 1; j > i; j--)
    {
      a[i][j] += cos(b[i][j]);
    }

  }

}

