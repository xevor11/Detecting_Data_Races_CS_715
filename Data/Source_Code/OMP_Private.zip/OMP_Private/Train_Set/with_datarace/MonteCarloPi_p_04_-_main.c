int main(int argc, char **argv)
{
  int i;
  const float dt = 0.01;
  const float mass = 1.0;
  const float mdthalf = (dt * 0.5) / mass;
  float *rAx = &rA[0];
  float *rAy = &rA[nBod];
  float *rAz = &rA[2 * nBod];
  float *vAx = &vA[0];
  float *vAy = &vA[nBod];
  float *vAz = &vA[2 * nBod];
  float *fAx = &fA[0];
  float *fAy = &fA[nBod];
  float *fAz = &fA[2 * nBod];
  #pragma omp parallel for num_threads(numProc) private(i)
  for (i = 0; i < nBod; i++)
  {
    rAx[i] += (vAx[i] + (fAx[i] * mdthalf)) * dt;
    rAy[i] += (vAy[i] + (fAy[i] * mdthalf)) * dt;
    rAz[i] += (vAz[i] + (fAz[i] * mdthalf)) * dt;
    vAx[i] += fAx[i] * dt;
    vAy[i] += fAy[i] * dt;
    vAz[i] += fAz[i] * dt;
  }


  int num_procs;
  int max_threads;
  int thread_id;
  int N = pow(2, 30);
  int dart_chunk;
  int dart_llimit;
  int dart_ulimit;
  int n_circle = 0;
  int C[N];
  int i;
  double pi = 3.141592653589793;
  double pi_computed = 0.00;
  double pi_error = 0.00;
  double R = 2.00;
  double x;
  double y;
  double z;
  double wall_time = 0.00;
  num_procs = omp_get_num_procs();
  max_threads = omp_get_max_threads();
  dart_chunk = N / max_threads;
  thread_id = omp_get_thread_num();
  wall_time = omp_get_wtime();
  if (thread_id == 0)
  {
    printf("\n");
    printf("  OpenMP C program to evaluate PI using Monte Carlo method\n");
    printf("  (Dart Board algorithm).\n\n");
    printf("  Total number of processors available : %d\n", num_procs);
    printf("  Maximum number of usable threads     : %d\n", max_threads);
    printf("  Total number of darts thrown         : %d\n", N);
    printf("  Number of darts per usable thread    : %d\n", dart_chunk);
    for (i = 0; i < N; i++)
    {
      C[i] = 0;
    }

  }

  #pragma omp parallel shared(R, dart_chunk)
  {
    thread_id = omp_get_thread_num();
    dart_llimit = thread_id * dart_chunk;
    dart_ulimit = (dart_llimit + dart_chunk) - 1;
    struct timeval t1;
    gettimeofday(&t1, 0);
    srand((t1.tv_usec * t1.tv_sec) * (thread_id + 1));
    #pragma omp sections
    {
      #pragma omp section
      {
        for (i = dart_llimit; i <= dart_ulimit; i++)
        {
          x = random_number_generator(-R, R);
          y = random_number_generator(-R, R);
          z = sqrt((x * x) + (y * y));
          if (z <= R)
          {
            C[i] = 1;
          }

        }

      }
    }
  }
  if (thread_id == 0)
  {
    for (i = 0; i < N; i++)
    {
      n_circle = n_circle + C[i];
    }

    pi_computed = (4.0 * ((double) n_circle)) / ((double) N);
    pi_error = fabs(pi - pi_computed);
  }

  wall_time = omp_get_wtime() - wall_time;
  if (thread_id == 0)
  {
    printf("  Total number of darts in the circle  : %d\n", n_circle);
    printf("  Known value of PI                    : %16.15f\n", pi);
    printf("  Computed value of PI                 : %16.15f\n", pi_computed);
    printf("  Error in the computed value of PI    : %16.15f\n", pi_error);
    printf("  Total time taken                     : %f seconds\n\n", wall_time);
  }

  return 0;
}

