{
  unsigned char value;
} PPMGrayPixel;
{
  unsigned char red;
  unsigned char green;
  unsigned char blue;
} PPMPixel;
{
  int x;
  int y;
  PPMPixel *data;
  PPMGrayPixel *grayData;
  PPMPixel *ColTopBorder;
  PPMGrayPixel *GrayTopBorder;
  PPMPixel *ColBotBorder;
  PPMGrayPixel *GrayBotBorder;
} PPMImage;
void GrayscaleSmooth(PPMImage *imagemFonte, PPMImage *imagemResult)
{
  int largura;
  int altura;
  int i;
  int j;
  int k;
  int l;
  int contador;
  int V;
  largura = imagemFonte->x;
  altura = imagemFonte->y;
  #pragma omp parallel for collapse(2)
  for (i = 0; i < altura; i++)
  {
    for (j = 0; j < largura; j++)
    {
      V = 0;
      contador = 0;
      for (k = -((5 - 1) / 2); k <= ((5 - 1) / 2); k++)
      {
        for (l = -((5 - 1) / 2); l <= ((5 - 1) / 2); l++)
        {
          if (((j + l) >= 0) && ((j + l) < largura))
          {
            if ((i + k) >= 0)
            {
              if ((i + k) < altura)
              {
                V += imagemFonte->grayData[((i + k) * largura) + (j + l)].value;
                contador++;
              }
              else
                if (imagemFonte->GrayBotBorder != 0)
              {
                V += imagemFonte->GrayBotBorder[(((i + k) * largura) + (j + l)) - (imagemFonte->y * imagemFonte->x)].value;
                contador++;
              }


            }
            else
              if (imagemFonte->GrayTopBorder != 0)
            {
              V += imagemFonte->GrayTopBorder[(((i + k) * largura) + (j + l)) + (5 * imagemFonte->x)].value;
              contador++;
            }


          }

        }

      }

      imagemResult->grayData[(i * largura) + j].value = (unsigned char) (V / contador);
    }

  }

}

