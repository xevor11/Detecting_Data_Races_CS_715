int main()
{
  FILE *fp;
  FILE *fp1;
  double *positionx;
  double *positiony;
  double *velx;
  double *vely;
  double *mass;
  double *newpositionx;
  double *newpositiony;
  double time;
  double G;
  double forcex;
  double forcey;
  double diffx;
  double diffy;
  double gmm;
  double ax;
  double ay;
  int n;
  int i;
  int j;
  int k;
  double starttime;
  double endtime;
  G = 6.67428e-11;
  time = 250;
  fp = fopen("/Users/TuTumm/Desktop/miniproject/inputTest.txt", "r");
  fscanf(fp, "%d", &n);
  fp1 = fopen("/Users/TuTumm/Desktop/miniproject/result.txt", "w");
  fprintf(fp1, "%d %d\n", n, 1000);
  printf("%d\n", n);
  positionx = malloc(n * (sizeof(double)));
  positiony = malloc(n * (sizeof(double)));
  velx = malloc(n * (sizeof(double)));
  vely = malloc(n * (sizeof(double)));
  mass = malloc(n * (sizeof(double)));
  newpositionx = malloc((n * n) * (sizeof(double)));
  newpositiony = malloc((n * n) * (sizeof(double)));
  for (i = 0; i < n; i++)
  {
    fscanf(fp, "%lf %lf %lf", &positionx[i], &positiony[i], &mass[i]);
  }

  starttime = omp_get_wtime();
  omp_set_num_threads(5);
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    velx[i] = 0;
    vely[i] = 0;
  }

  #pragma omp parallel for
  for (i = 0; i < (n * n); i++)
  {
    newpositionx[i] = 0;
    newpositiony[i] = 0;
  }

  for (k = 0; k < 1000; k++)
  {
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      forcex = 0;
      forcey = 0;
      for (j = 0; j < n; j++)
      {
        if (i != j)
        {
          diffx = positionx[j] - positionx[i];
          diffy = positiony[j] - positiony[i];
          gmm = ((G * mass[i]) * mass[j]) / ((diffx * diffx) + (diffy * diffy));
          forcex += gmm * diffx;
          forcey += gmm * diffy;
        }

      }

      ax = forcex / mass[i];
      positionx[i] += (velx[i] * time) + ((((forcex / mass[i]) * time) * time) / 2);
      velx[i] = velx[i] + (ax * time);
      ay = forcey / mass[i];
      positiony[i] += (vely[i] * time) + ((((forcey / mass[i]) * time) * time) / 2);
      vely[i] = vely[i] + (ay * time);
      newpositionx[(k * n) + i] = positionx[i];
      newpositiony[(k * n) + i] = positiony[i];
    }

  }

  endtime = omp_get_wtime();
  for (i = 0; i < (n * n); i++)
  {
    fprintf(fp1, "%lf %lf \n", newpositionx[i], newpositiony[i]);
  }

  for (i = 0; i < n; i++)
  {
    printf("%lf %lf %.0lf\n", positionx[i], positiony[i], mass[i]);
  }

  printf("Time = %lf\n", endtime - starttime);
  fclose(fp);
  fclose(fp1);
}

