double T[200][200][40];
double T_old[200][200][40];
void Initialization();
void SetBoundary();
double MaxFunc(double a, double b);
void SetBoundary()
{
  int i;
  int j;
  #pragma omp parallel for
  for (i = 200 / 4; i < ((3 * 200) / 4); ++i)
  {
    for (j = 200 / 4; j < ((3 * 200) / 4); ++j)
    {
      T[i][j][0] = 1000.0;
    }

  }


  int c[1000];
  int x;
  #pragma omp parallel for private(x)
  for (int i = 0; i < 1000; i++)
  {
    x = i;
    c[i] = i;
  }

  {
    int i;
    for (i = 0; i < 1000; i++)
    {
      if (c[i] != i)
        abort();

    }

  }
  return 0;
}

