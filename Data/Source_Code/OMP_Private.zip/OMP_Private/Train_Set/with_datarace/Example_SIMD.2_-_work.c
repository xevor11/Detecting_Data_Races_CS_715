#pragma omp declare simd uniform(fact);
#pragma omp declare simd uniform(a,b,fact) linear(i:1);
#pragma omp declare simd uniform(fact) linear(a,b:1);
void work(double *a, double *b, int n)
{
  int i;
  double tmp;
  #pragma omp simd
  for (i = 0; i < n; i++)
  {
    tmp = add1(a[i], b[i], 1.0);
    a[i] = add2(a, b, i, 1.0) + tmp;
    a[i] = add3(&a[i], &b[i], 1.0);
  }


  int i;
  if (is_para)
  {
    #pragma omp parallel for private(a,b)
    for (i = 0; i < n; i++)
      b[i] = (a[i] + a[i - 1]) / 2.0;

  }
  else
  {
    for (i = 0; i < n; i++)
      b[i] = (a[i] + a[i - 1]) / 2.0;

  }

}

