float Height(int, int);
int main(int argc, char *argv[])
{
  fprintf(stderr, "OpenMP is not supported here -- sorry.\n");
  return 1;
  omp_set_num_threads(NUMT);
  int i;
  int iu;
  int iv;
  float height;
  float area;
  float volume;
  float fullTileArea = ((3. - 0.) / ((float) (NUMNODES - 1))) * ((3. - 0.) / ((float) (NUMNODES - 1)));
  float quarterTileArea = fullTileArea / 4;
  float halfTileArea = fullTileArea / 2;
  volume = 0.;
  area = 0.;
  height = 0.;
  double time0 = omp_get_wtime();
  #pragma omp parallel for reduction(+:height,area)
  for (i = 0; i < (NUMNODES * NUMNODES); i++)
  {
    iu = i % NUMNODES;
    iv = i / NUMNODES;
    if (((((iu == 0) && (iv == 0)) || ((iu == 0) && (iv == (NUMNODES - 1)))) || ((iu == (NUMNODES - 1)) && (iv == 0))) || ((iu == (NUMNODES - 1)) && (iv == (NUMNODES - 1))))
    {
      height += Height(iu, iv);
      area += quarterTileArea;
    }
    else
      if ((iu > 0) && (iv == 0))
    {
      height += Height(iu, iv);
      area += halfTileArea;
    }
    else
      if ((iu > 0) && (iv == (NUMNODES - 1)))
    {
      height += Height(iu, iv);
      area += halfTileArea;
    }
    else
      if ((iu == 0) && (iv > 0))
    {
      height += Height(iu, iv);
      area += halfTileArea;
    }
    else
      if ((iu == (NUMNODES - 1)) && (iv > 0))
    {
      height += Height(iu, iv);
      area += halfTileArea;
    }
    else
    {
      height += Height(iu, iv);
      area += fullTileArea;
    }





  }

  double time1 = omp_get_wtime();
  volume = area * (height / (NUMNODES * NUMNODES));
  printf("Volume = %lf,Execution Time = %lf\n", volume, time1 - time0);
}

