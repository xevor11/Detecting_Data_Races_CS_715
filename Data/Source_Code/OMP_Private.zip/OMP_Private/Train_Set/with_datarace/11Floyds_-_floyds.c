void floyds(int a[10][10], int n)
{
  int thread_id;
  int i;
  int j;
  int k;
  int starttime;
  int endtime;
  starttime = omp_get_wtime();
  omp_set_num_threads(2);
  #pragma omp parallel for shared(a)
  for (k = 0; k < n; k++)
    for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
  {
    thread_id = omp_get_thread_num();
    a[i][j] = (a[i][j] < (a[i][k] + a[k][j])) ? (a[i][j]) : (a[i][k] + a[k][j]);
    printf("Thread %d : a[%d][%d] = %d\n", thread_id, i, j, a[i][j]);
  }



  endtime = omp_get_wtime();
  printf("Shortest path :\n");
  for (i = 0; i < n; i++)
  {
    for (j = 0; j < n; j++)
      printf("%d ", a[i][j]);

    printf("\n");
  }

  printf("Time taken is : %d\n", endtime - starttime);

  int i;
  int j;
  int k;
  int ct;
  int size;
  int boxct;
  int min_dim;
  int max_box;
  double sizes_avg;
  double boxes_avg;
  double sizes_sum;
  double boxes_sum;
  double cross;
  double r;
  double *sizes;
  double *boxes;
  min_dim = MIN(MIN(dimx, dimy), dimz);
  max_box = ((int) ((log((double) min_dim) / log(2.0)) + 0.5)) - 1;
  if (wr_log != 0)
  {
    wr_log("\t----");
    wr_log("\tMinimum box side adopted: 2");
    wr_log("\tMaximum box side adopted: %d. ", (int) pow(2, (double) max_box));
  }

  sizes = (double *) malloc(max_box * (sizeof(double)));
  boxes = (double *) malloc(max_box * (sizeof(double)));
  sizes_avg = 0;
  boxes_avg = 0;
  for (ct = 0; ct < max_box; ct++)
  {
    size = (int) pow((double) 2.0, ((double) ct) + 1);
    boxct = 0;
    #pragma omp parallel for private(i, j) reduction (+ : boxct)
    for (k = 0; k < dimz; k = k + size)
      for (j = 0; j < dimy; j = j + size)
      for (i = 0; i < dimx; i = i + size)
    {
      if (_p3dCheckForObjectVoxel(in_im, (int) dimx, (int) dimy, (int) dimz, i, j, k, size) == 1)
        boxct++;

    }



    sizes[ct] = -log((double) size);
    boxes[ct] = log((double) boxct);
    sizes_avg += sizes[ct];
    boxes_avg += boxes[ct];
  }

  sizes_avg /= (double) max_box;
  boxes_avg /= (double) max_box;
  sizes_sum = 0;
  boxes_sum = 0;
  cross = 0;
  for (ct = 0; ct < max_box; ct++)
  {
    cross += (boxes[ct] - boxes_avg) * (sizes[ct] - sizes_avg);
    boxes_sum += (boxes[ct] - boxes_avg) * (boxes[ct] - boxes_avg);
    sizes_sum += (sizes[ct] - sizes_avg) * (sizes[ct] - sizes_avg);
  }

  r = cross / sqrt(boxes_sum * sizes_sum);
  *fd = (r * sqrt(boxes_sum)) / sqrt(sizes_sum);
  if (sizes != 0)
    free(sizes);

  if (boxes != 0)
    free(boxes);

  return P3D_SUCCESS;
}

