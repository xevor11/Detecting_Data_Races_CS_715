{
  int i;
  int chunk = 10;
  for (i = 0; i < 100; i++)
  {
    vectA[i] = (i + 1) * 10;
  }

  for (i = 0; i < 100; i++)
  {
    vectB[i] = vectA[i];
  }

  #pragma omp parallel shared(vectSum, vectA, vectB, chunk) private(i)
  {
    #pragma omp for schedule(dynamic,chunk)
    for (i = 0; i < 100; i++)
    {
      vectSum[i] = vectA[i] + vectB[i];
      printf("Thread %d Did Itteration [ %d ] : \nVector Add: A[ %.2f ] + B[ %.2f ] = Sum[ %.2f ] \n", omp_get_thread_num(), i, vectA[i], vectB[i], vectSum[i]);
    }

  }
  return vectSum;

  int y;
  int x;
} Antena;
{
  int valor;
  int x;
  int y;
} Registro;
int calcular_max(int *mapa, int rows, int cols, Registro *registros)
{
  int maximo = 0;
  int ii = 0;
  int jj = 0;
  int i;
  int j;
  #pragma omp parallel for shared(mapa,registros) firstprivate(ii,jj,maximo)
  for (i = 0; i < rows; i++)
  {
    for (j = 0; j < cols; j++)
    {
      if (mapa[(i * cols) + j] > maximo)
      {
        maximo = mapa[(i * cols) + j];
        ii = i;
        jj = j;
      }

    }

    registros[omp_get_thread_num()].x = ii;
    registros[omp_get_thread_num()].y = jj;
    registros[omp_get_thread_num()].valor = maximo;
  }

  maximo = 0;
  for (i = 0; i < 11; i++)
  {
    if (registros[i].valor > maximo)
    {
      maximo = registros[i].valor;
      registros[11].valor = maximo;
      registros[11].x = registros[i].x;
      registros[11].y = registros[i].y;
    }

  }

  return registros[11].valor;
}

