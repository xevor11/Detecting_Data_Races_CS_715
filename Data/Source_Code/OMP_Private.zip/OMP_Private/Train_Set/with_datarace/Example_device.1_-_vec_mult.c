#pragma omp declare target;
void vec_mult(float *p, float *v1, float *v2, int N);
extern float *p;
extern float *v1;
extern float *v2;
extern int N;
#pragma omp end declare target;
extern void init_vars(float *, float *, int);
extern void output(float *, int);
void vec_mult(float *p, float *v1, float *v2, int N)
{
  int i;
  int nthreads;
  if (!omp_is_initial_device())
  {
    printf("1024 threads on target device\n");
    nthreads = 1024;
  }
  else
  {
    printf("8 threads on initial device\n");
    nthreads = 8;
  }

  #pragma omp parallel for num_threads(nthreads)
  for (i = 0; i < N; i++)
    p[i] = v1[i] * v2[i];


  int i;
  int j;
  int k;
  float del[3];
  float norm;
  zero(f);
  potE = 0;
  for (int i = begin; i < (1000 - 1); i += shift)
  {
    del[0] = x[i][0] - x[i + 1][0];
    del[1] = x[i][1] - x[i + 1][1];
    del[2] = x[i][2] - x[i + 1][2];
    norm = sqrt(((del[0] * del[0]) + (del[1] * del[1])) + (del[2] * del[2]));
    del[0] /= norm;
    del[1] /= norm;
    del[2] /= norm;
    norm -= 1;
    norm *= 100;
    del[0] *= norm;
    del[1] *= norm;
    del[2] *= norm;
    #pragma omp atomic update
    f[i][0] -= del[0];
    #pragma omp atomic update
    f[i][1] -= del[1];
    #pragma omp atomic update
    f[i][2] -= del[2];
    #pragma omp atomic update
    f[i + 1][0] += del[0];
    #pragma omp atomic update
    f[i + 1][1] += del[1];
    #pragma omp atomic update
    f[i + 1][2] += del[2];
  }

  float rsq;
  float cutsq = 1.0 * 1.0;
  #pragma omp parallel for private (k,j,rsq,del,norm)
  for (i = begin; i < 1000; i += shift)
    for (k = 1; k < (neigh[i][0] + 1); k++)
  {
    j = neigh[i][k];
    del[0] = x[i][0] - x[j][0];
    del[1] = x[i][1] - x[j][1];
    del[2] = x[i][2] - x[j][2];
    rsq = ((del[0] * del[0]) + (del[1] * del[1])) + (del[2] * del[2]);
    if (rsq < cutsq)
    {
      norm = sqrt(rsq);
      del[0] /= norm;
      del[1] /= norm;
      del[2] /= norm;
      norm -= 1.0;
      norm *= 100;
      del[0] *= norm;
      del[1] *= norm;
      del[2] *= norm;
      #pragma omp atomic update
      f[i][0] -= del[0];
      #pragma omp atomic update
      f[i][1] -= del[1];
      #pragma omp atomic update
      f[i][2] -= del[2];
      #pragma omp atomic update
      f[j][0] += del[0];
      #pragma omp atomic update
      f[j][1] += del[1];
      #pragma omp atomic update
      f[j][2] += del[2];
    }

  }


}

