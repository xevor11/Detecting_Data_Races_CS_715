int main(int argc, char *argv[])
{
  int *A;
  int *L;
  int N;
  int part;
  int x;
  int lcount;
  int tcount = 0;
  int i;
  int id;
  int P;
  double start;
  double stop;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &id);
  MPI_Comm_size(MPI_COMM_WORLD, &P);
  if (id == 0)
  {
    printf("\nInsert N, size of A: ");
    scanf("%d", &N);
    if ((N == 0) || ((N % P) != 0))
    {
      printf("\nInvalid size!");
      printf("\n*Terminated*\n\n");
      return -1;
    }

    A = malloc(N * (sizeof(int)));
    for (i = 0; i < N; i++)
    {
      A[i] = rand() % 100;
    }

    printf("\nInsert value to search for (range 0-100): ");
    scanf("%d", &x);
    while ((x < 0) || (x > 100))
    {
      printf("\nOut of bounds!");
      printf("\nInsert value to search for (range 0-100): ");
      scanf("%d", &x);
    }

    part = N / P;
  }

  MPI_Bcast(&part, 1, MPI_INT, 0, MPI_COMM_WORLD);
  MPI_Bcast(&x, 1, MPI_INT, 0, MPI_COMM_WORLD);
  L = malloc(part * (sizeof(int)));
  MPI_Scatter(&A[0], part, MPI_INT, &L[0], part, MPI_INT, 0, MPI_COMM_WORLD);
  if (id == 0)
  {
    start = MPI_Wtime();
  }

  lcount = 0;
  #pragma omp parallel for shared(part) reduction(+:lcount)
  for (i = 0; i < part; i++)
  {
    if (L[i] == x)
    {
      lcount++;
    }

  }

  MPI_Reduce(&lcount, &tcount, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
  if (id == 0)
  {
    stop = MPI_Wtime();
    printf("\n\nSearch finished!");
    printf("\n\nFound %d in array %d times in total.", x, tcount);
    printf("\n\nTotal run time: %.6fs\n", stop - start);
    free(A);
  }

  free(L);
  MPI_Finalize();
  return 0;
}

