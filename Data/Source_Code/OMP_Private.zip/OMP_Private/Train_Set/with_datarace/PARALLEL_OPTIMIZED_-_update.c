int **current_state;
int **next_state;
int **debug_state;
int debug = 0;
int dy[] = {-1, -1, -1, 0, 0, 1, 1, 1};
int dx[] = {-1, 0, 1, -1, 1, -1, 0, 1};
void update(int r, int c)
{
  int i;
  int j;
  int k;
  #pragma omp parallel for
  for (i = 1; i < (r - 1); i++)
  {
    int alive_neigbours;
    int is_alive;
    int v3 = 0;
    int v2 = 0;
    int v1 = 0;
    int k;
    j = 1;
    v1 = (current_state[i][j - 1] + current_state[i - 1][j - 1]) + current_state[i + 1][j - 1];
    v2 = current_state[i - 1][j] + current_state[i + 1][j];
    v3 = (current_state[i][j + 1] + current_state[i - 1][j + 1]) + current_state[i + 1][j + 1];
    for (j = 1; j < (c - 1); j++)
    {
      alive_neigbours = (v1 + v2) + v3;
      v2 += current_state[i][j];
      v3 -= current_state[i][j + 1];
      v1 = v2;
      v2 = v3;
      v3 = (current_state[i - 1][j + 2] + current_state[i][j + 2]) + current_state[i + 1][j + 2];
      is_alive = current_state[i][j];
      next_state[i][j] = is_alive;
      if (is_alive && ((alive_neigbours < 2) || (alive_neigbours > 3)))
      {
        next_state[i][j] = 0;
      }

      if ((!is_alive) && (alive_neigbours == 3))
      {
        next_state[i][j] = 1;
      }

    }

  }

  for (i = 0; i < r; i++)
  {
    j = 0;
    int alive_neighbours = 0;
    for (k = 0; k < 8; k++)
    {
      int ni = i + dx[k];
      int nj = j + dy[k];
      if (ni < 0)
        ni += r;

      if (nj < 0)
        nj += c;

      if (ni >= r)
        ni -= r;

      if (nj >= c)
        nj -= c;

      alive_neighbours += current_state[ni][nj];
    }

    int is_alive = current_state[i][j];
    next_state[i][j] = is_alive;
    if (is_alive && ((alive_neighbours < 2) || (alive_neighbours > 3)))
    {
      next_state[i][j] = 0;
    }

    if ((!is_alive) && (alive_neighbours == 3))
    {
      next_state[i][j] = 1;
    }

    j = c - 1;
    alive_neighbours = 0;
    for (k = 0; k < 8; k++)
    {
      int ni = i + dx[k];
      int nj = j + dy[k];
      if (ni < 0)
        ni += r;

      if (nj < 0)
        nj += c;

      if (ni >= r)
        ni -= r;

      if (nj >= c)
        nj -= c;

      alive_neighbours += current_state[ni][nj];
    }

    is_alive = current_state[i][j];
    next_state[i][j] = is_alive;
    if (is_alive && ((alive_neighbours < 2) || (alive_neighbours > 3)))
    {
      next_state[i][j] = 0;
    }

    if ((!is_alive) && (alive_neighbours == 3))
    {
      next_state[i][j] = 1;
    }

  }

  for (j = 0; j < c; j++)
  {
    i = 0;
    int alive_neighbours = 0;
    for (k = 0; k < 8; k++)
    {
      int ni = i + dx[k];
      int nj = j + dy[k];
      if (ni < 0)
        ni += r;

      if (nj < 0)
        nj += c;

      if (ni >= r)
        ni -= r;

      if (nj >= c)
        nj -= c;

      alive_neighbours += current_state[ni][nj];
    }

    int is_alive = current_state[i][j];
    next_state[i][j] = is_alive;
    if (is_alive && ((alive_neighbours < 2) || (alive_neighbours > 3)))
    {
      next_state[i][j] = 0;
    }

    if ((!is_alive) && (alive_neighbours == 3))
    {
      next_state[i][j] = 1;
    }

    i = r - 1;
    alive_neighbours = 0;
    for (k = 0; k < 8; k++)
    {
      int ni = i + dx[k];
      int nj = j + dy[k];
      if (ni < 0)
        ni += r;

      if (nj < 0)
        nj += c;

      if (ni >= r)
        ni -= r;

      if (nj >= c)
        nj -= c;

      alive_neighbours += current_state[ni][nj];
    }

    is_alive = current_state[i][j];
    next_state[i][j] = is_alive;
    if (is_alive && ((alive_neighbours < 2) || (alive_neighbours > 3)))
    {
      next_state[i][j] = 0;
    }

    if ((!is_alive) && (alive_neighbours == 3))
    {
      next_state[i][j] = 1;
    }

  }

  if (debug)
    if (check_correctness(r, c))
    printf("error\n");


  int **temp = current_state;
  current_state = next_state;
  next_state = temp;

  int *data;
  int limit;
} vector;
void init_vector(vector *v, int size);
void fill_vector(vector *v, int t_count);
void fill_matrix(int rows, int cols, vector **matrix, int t_count);
void print_vector(vector *v);
void print_matrix(int rows, vector **matrix);
void multiply(vector *vec, vector **m, vector *vec_mult, int size, int t_count);
void mult_vec(vector *v1, vector *v2, vector *vec_m, int index, int t_count);
void fill_vector(vector *v, int t_count)
{
  int size = v->limit;
  int i;
  #pragma omp parallel for num_threads(t_count) private(i) shared(size)
  for (i = 0; i < size; i++)
  {
    v->data[i] = rand() % 20;
  }

}

